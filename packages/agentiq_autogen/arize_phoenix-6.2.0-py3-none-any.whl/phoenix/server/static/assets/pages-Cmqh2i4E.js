import{z as A,am as de,an as Ie,ao as Pe,ap as La,A as Ao,r as m,j as e,R as Se,n as ya,D as C,l as o,aq as Ve,G as ne,U as G,t as P,ac as je,ad as W,O as Te,P as De,T as Z,ar as he,as as an,at as tn,au as Ue,av as Ma,$ as le,aw as Ia,S as Un,g as bl,ax as Mo,K as ft,ay as _n,I as No,az as zo,aA as nt,aB as at,aC as ta,aD as fa,o as ht,aE as Vo,aF as $o,ah as Oo,ai as Qo,aG as jo,p as Sl,q as qo,aH as Uo,aI as Bo,Z as Ho,aJ as Go,aK as Qt,aL as Wo,aM as Jo,aN as Zo,aO as Yo,aP as Xo,aQ as ed,aR as nd,aS as ad,aT as td}from"./vendor-Cdrqqth8.js";import{c as h,I as L,a as D,e as z,d as F,x as ce,H as q,B as kt,D as Y,G as ae,b as x,m as ge,N as bt,K as $e,M as X,O as qe,Q as ke,S as ld,p as Oa,J as Qa,P as Bn,C as Rn,l as ha,s as An,v as Hn,t as xe,q as vl,U as Be,L as Ea,V as Cl,W as Fl,X as Kl,Y as id,Z as rd,$ as Gn,j as Oe,k as ka,T as pe,a0 as St,w as we,n as ee,E as ja,f as Fe,a1 as vt,a2 as sd,h as Mn,u as od,a3 as dd,o as cd,R as ca,i as xl}from"./vendor-arizeai-BSCL03yQ.js";import{s as Ct,a as ue,l as ud,j as Tl,b as Me,i as Dl,c as Il,d as Wn,e as Pl,f as md,g as ma,D as gd,h as wa,k as pd,T as Tn,m as yd,n as jt,o as fd,p as hd,q as qt,r as kd,t as bd,N as Sd,u as vd,L as ye,v as be,w as ba,B as Cd,x as Cn,y as Fd,G as Kd,z as xd,A as Td,S as Dd,C as en,J as Ee,E as Jn,F as _e,H as Ke,I as Re,K as Sa,M as yn,O as ve,P as se,Q as nn,R as fn,U as Ne,V as We,W as on,X as Ft,Y as Ll,Z as El,_ as Ut,$ as Bt,a0 as Zn,a1 as Id,a2 as Pd,a3 as B,a4 as wl,a5 as qa,a6 as Yn,a7 as _l,a8 as Xn,a9 as ea,aa as Rl,ab as dn,ac as ln,ad as Le,ae as Ua,af as hn,ag as Kt,ah as Je,ai as Al,aj as Ld,ak as Ed,al as wd,am as _d,an as Rd,ao as Ad,ap as rn,aq as Md,ar as Nd,as as Ml,at as zd,au as Vd,av as Ht,aw as $d,ax as Od,ay as Qd,az as jd,aA as qd,aB as Ud,aC as Nl,aD as Bd,aE as Hd,aF as Gd,aG as Wd,aH as Jd,aI as Pn,aJ as xt,aK as zl,aL as Qn,aM as mt,aN as xn,aO as un,aP as Zd,aQ as Yd,aR as Vl,aS as $l,aT as Ba,aU as va,aV as Ze,aW as Xd,aX as Ol,aY as ec,aZ as Ae,a_ as Tt,a$ as Ql,b0 as nc,b1 as Dt,b2 as Qe,b3 as He,b4 as na,b5 as ac,b6 as Ha,b7 as jl,b8 as ql,b9 as tc,ba as Ul,bb as Bl,bc as Hl,bd as Gl,be as mn,bf as cn,bg as lc,bh as Gt,bi as Wl,bj as ic,bk as rc,bl as sc,bm as oc,bn as dc,bo as jn,bp as Kn,bq as gt,br as Ye,bs as Jl,bt as cc,bu as uc,bv as Ga,bw as mc,bx as Zl,by as Ca,bz as Wt,bA as Yl,bB as It,bC as Xl,bD as ei,bE as gc,bF as pt,bG as ni,bH as pc,bI as yc,bJ as Pa,bK as fc,bL as ai,bM as ti,bN as hc,bO as kc,bP as bc,bQ as Pt,bR as li,bS as Sc,bT as Na,bU as vc,bV as Cc,bW as Fc,bX as Kc,bY as xc,bZ as ii,b_ as Tc,b$ as Dc,c0 as Ic,c1 as Pc,c2 as Lc,c3 as Ec,c4 as wc,c5 as _c}from"./components-DrwPLMB6.js";import{R as kn,C as Fa,X as bn,Y as Ge,a as Sn,T as vn,B as qn,A as ga,b as ri,c as Lt,L as si,d as Rc,P as Ac,e as Mc,f as Nc}from"./vendor-recharts-CNNUvc5T.js";import{p as Et,R as Ka,n as xa,i as zc,E as oi,m as Vc,o as $c,g as Oc}from"./vendor-codemirror-Utqu7Snw.js";const Qc=4,jc={user:["user","human"],ai:["assistant","bot","ai"],system:["system"],tool:["tool"]},qc="Unable to parse span input messages, expected messages which include a role and content.",Uc="Unable to parse span output messages, expected messages which include a role and content.",Bc="Unable to parse span output expected output.value to be present.",Hc="Unable to parse span attributes, attributes must be valid JSON.",Gc="Unable to parse model config, expected llm.model_name to be present.",Wc="Unable to parse model config, expected llm.invocation_parameters JSON string to be present.",Jc="Unable to parse invocation parameters response_format, expected llm.invocation_parameters.response_format to be a well formed json object or undefined.",Zc="Unable to parse tools, expected tools to be an array of valid tools.",Yc="Unable to parse prompt template variables, expected prompt template variables to be a valid JSON object string.",Jt={AZURE_OPENAI:[],ANTHROPIC:["claude"],OPENAI:["gpt","o1"],GEMINI:["gemini"]},ua="TOOL_CHOICE",_a="tool_choice",Ln="RESPONSE_FORMAT",Dn="response_format",Xc=[ua,Ln],wt=Ct()(A.union([A.literal("auto"),A.literal("none"),A.literal("required"),A.object({type:A.literal("function"),function:A.object({name:A.string()})})])),_t=A.object({type:A.union([A.literal("auto"),A.literal("any"),A.literal("tool")]),disable_parallel_tool_use:A.boolean().optional(),name:A.string().optional()}),eu=_t.transform(n=>{switch(n.type){case"any":case"auto":return"auto";case"tool":return n.name?{type:"function",function:{name:n.name}}:"auto";default:return"auto"}}),nu=wt.transform(n=>typeof n=="string"?{type:"auto"}:{type:"tool",name:n.function.name});A.union([wt,_t]);const au=n=>{const{success:a,data:t}=wt.safeParse(n);if(a)return{provider:"OPENAI",toolChoice:t};const{success:l,data:i}=_t.safeParse(n);return l?{provider:"ANTHROPIC",toolChoice:i}:{provider:null,toolChoice:null}},tu=n=>{const{provider:a,toolChoice:t}=au(n);if(a==null||t==null)throw new Error("Could not detect provider of tool choice");switch(a){case"AZURE_OPENAI":case"OPENAI":return t;case"ANTHROPIC":return eu.parse(t);default:ue()}},lu=({toolChoice:n,targetProvider:a})=>{switch(a){case"AZURE_OPENAI":case"OPENAI":return n;case"ANTHROPIC":return nu.parse(n);case"GEMINI":return n;default:ue()}},iu=({toolChoice:n,targetProvider:a})=>{try{const t=tu(n);return lu({toolChoice:t,targetProvider:a})}catch{return null}},ru=A.object({tool_call:A.object({id:A.string().optional(),function:A.object({name:A.string(),arguments:A.string()}).partial()}).partial()}).partial(),di=A.object({[de.message]:A.object({[Ie.role]:A.string(),[Ie.content]:A.union([A.string(),A.array(A.record(A.string(),A.unknown()))]).default(""),[Ie.tool_calls]:A.array(ru).optional(),[Ie.tool_call_id]:A.string().optional()})}),su=A.object({[de.llm]:A.object({[Pe.input_messages]:A.array(di)})}),ou=A.object({[de.llm]:A.object({[Pe.output_messages]:A.array(di)})}),du=A.object({[de.output]:A.object({value:A.string()})}),ci=Ct()(A.enum(["user","ai","system","tool"])),cu=Ct()(A.object({id:A.number(),role:ci,content:A.string().optional(),toolCallId:A.string().optional(),toolCalls:A.array(ud).optional()})),uu=A.array(cu),Rt=A.lazy(()=>A.record(Tl)),mu=Rt,ui=A.string().transform((n,a)=>{const{json:t}=Me(n);if(!Dl(t))return a.addIssue({code:A.ZodIssueCode.custom,message:"The invocation parameters must be a valid JSON object"}),A.NEVER;const{success:l,data:i}=mu.safeParse(t);return l?i:(a.addIssue({code:A.ZodIssueCode.custom,message:"The invocation parameters must be a valid JSON object"}),A.NEVER)}).default("{}"),gu=A.object({[de.llm]:A.object({[Pe.provider]:A.string().optional(),[Pe.model_name]:A.string()})}),mi=A.object({[de.llm]:A.object({[Pe.invocation_parameters]:ui})}),pu=A.object({[de.llm]:A.object({[Pe.invocation_parameters]:ui.pipe(A.object({response_format:Rt.optional()}))})}),yu=A.string().transform((n,a)=>{const{json:t}=Me(n);return t==null||!Dl(t)?(a.addIssue({code:A.ZodIssueCode.custom,message:"The tool JSON schema must be a valid JSON object"}),A.NEVER):t}).transform((n,a)=>{const{data:t,success:l}=Il.safeParse(n);return l?t:(a.addIssue({code:A.ZodIssueCode.custom,message:"The tool JSON schema must be a valid tool schema"}),A.NEVER)}),fu=A.object({[de.llm]:A.object({[Pe.tools]:A.array(A.object({[de.tool]:A.object({[La.json_schema]:yu})}).optional()).optional()}).optional()}).optional(),hu=A.lazy(()=>A.object({type:A.literal("json_schema"),json_schema:A.object({name:A.string().describe("The name of the schema"),schema:Tl.describe("The schema itself in JSON format"),strict:A.literal(!0).describe("The schema must be strict")})})),ku=Ao(hu,{removeAdditionalStrategy:"passthrough"}),bu=A.string().transform((n,a)=>{const{json:t}=Me(n);return Wn(t)?Object.entries(t).reduce((i,[r,s])=>{if(typeof s=="string")i[r]=s;else{const{json:c}=Pl(s);c!=null&&(i[r]=c)}return i},{}):(a.addIssue({code:A.ZodIssueCode.custom,message:"The prompt template variables must be a valid JSON object"}),A.NEVER)}),Su=A.object({[de.llm]:A.object({[Pe.prompt_template]:A.object({variables:bu}).optional()}).optional()}).optional();function gi(n){return ci.safeParse(n).success}function za(n){if(gi(n))return n;for(const[a,t]of Object.entries(jc))if(t.includes(n))return a;return pd}function vu({toolCalls:n,provider:a}){if(n!=null)return n.map(({tool_call:t})=>{var i,r,s,c;if(t==null)return null;let l={};if(((i=t.function)==null?void 0:i.arguments)!=null){const{json:d}=Me(t.function.arguments);Wn(d)&&(l=d)}switch(a){case"OPENAI":case"AZURE_OPENAI":return{id:t.id??"",function:{name:((r=t.function)==null?void 0:r.name)??"",arguments:l}};case"ANTHROPIC":return{id:t.id??"",type:"tool_use",name:((s=t.function)==null?void 0:s.name)??"",input:l};case"GEMINI":return{id:t.id??"",function:{name:((c=t.function)==null?void 0:c.name)??"",arguments:l}};default:ue()}}).filter(t=>t!=null)}function pi({messages:n,provider:a}){return n.map(({message:t})=>({id:ma(),role:t.tool_call_id!=null?za("tool"):za(t.role),content:typeof t.content=="string"?t.content:void 0,toolCalls:vu({provider:a,toolCalls:t.tool_calls}),toolCallId:t.tool_call_id}))}function Cu({provider:n,parsedAttributes:a}){var l;const t=su.safeParse(a);if(!t.success)return{messageParsingErrors:[qc],messages:null};if(n==="ANTHROPIC"){const{success:i,data:r}=mi.safeParse(a);if(i){const s=t.data.llm.input_messages,c=(l=r.llm.invocation_parameters)==null?void 0:l.system;typeof c=="string"&&c&&(!s||s[0].message.role!=="system")&&t.data.llm.input_messages.unshift({message:{role:"system",content:c}})}}return{messageParsingErrors:[],messages:pi({provider:n,messages:t.data.llm.input_messages})}}function Fu({provider:n,parsedAttributes:a}){const t=[],l=ou.safeParse(a);if(l.success)return{output:pi({provider:n,messages:l.data.llm.output_messages}),outputParsingErrors:t};t.push(Uc);const i=du.safeParse(a);return i.success?{output:i.data.output.value,outputParsingErrors:t}:(t.push(Bc),{output:void 0,outputParsingErrors:t})}function Ku(n){if(n==null)return null;switch(n.toLowerCase()){case"openai":return"OPENAI";case"anthropic":return"ANTHROPIC";case"google":return"GEMINI";case"azure":return"AZURE_OPENAI";default:return null}}function xu(n){for(const a of Object.keys(Jt))if(Jt[a].some(l=>n.includes(l)))return a;return gd}function Tu(n){const{success:a,data:t}=gu.safeParse(n);if(a){const l=Ku(t.llm.provider)||xu(t.llm.model_name);return{modelConfig:{modelName:t.llm.model_name,provider:l,invocationParameters:[],supportedInvocationParameters:[]},parsingErrors:[]}}return{modelConfig:null,parsingErrors:[Gc]}}function Du(n,a=[]){const{success:t,data:l}=mi.safeParse(n),i=[];return t||i.push(Wc),{invocationParameters:Mu((l==null?void 0:l.llm.invocation_parameters)??{},a),parsingErrors:i}}function Iu(n){const{success:a,data:t}=pu.safeParse(n);return a?{responseFormat:t.llm.invocation_parameters.response_format,parsingErrors:[]}:{responseFormat:void 0,parsingErrors:[Jc]}}function Pu(n){var a;return(((a=n==null?void 0:n.llm)==null?void 0:a.tools)??[]).map(t=>(t==null?void 0:t.tool)==null?null:{id:wa(),definition:t.tool.json_schema}).filter(t=>t!=null)}function Lu(n){var l;const{data:a,success:t}=fu.safeParse(n);return t?((l=a==null?void 0:a.llm)==null?void 0:l.tools)==null?{tools:null,parsingErrors:[]}:{tools:Pu(a),parsingErrors:[]}:{tools:null,parsingErrors:[Zc]}}function Eu(n){var l;const{success:a,data:t}=Su.safeParse(n);return a?((l=t==null?void 0:t.llm)==null?void 0:l.prompt_template)==null?{variables:null,parsingErrors:[]}:{variables:t.llm.prompt_template.variables,parsingErrors:[]}:{variables:null,parsingErrors:[Yc]}}function wu(n){const a=md(),{json:t,parseError:l}=Me(n.attributes);if(l)return{playgroundInstance:{...a,spanId:(n==null?void 0:n.id)??null},parsingErrors:[Hc]};const i=n.invocationParameters,r=Tu(t);let{modelConfig:s}=r;const{parsingErrors:c}=r,{messages:d,messageParsingErrors:u}=Cu({provider:(s==null?void 0:s.provider)??a.model.provider,parsedAttributes:t}),{output:y,outputParsingErrors:g}=Fu({provider:(s==null?void 0:s.provider)??a.model.provider,parsedAttributes:t}),{invocationParameters:p,parsingErrors:f}=Du(t,i),{variables:k,parsingErrors:b}=Eu(t),{parsingErrors:S}=Iu(t);s=s!=null?{...s,invocationParameters:S.length>0?p.filter(w=>w.invocationName!==Dn&&w.canonicalName!==Ln):p}:null;const{tools:v,parsingErrors:I}=Lu(t);return{playgroundInstance:{...a,model:s??a.model,template:d!=null?{__type:"chat",messages:d}:a.template,output:y,spanId:n.id,tools:v??a.tools},playgroundInput:k!=null?{variablesValueCache:k}:void 0,parsingErrors:[...u,...g,...c,...I,...f,...S,...b]}}const _u=n=>uu.safeParse(n).success,yi=({instance:n,templateLanguage:a})=>{if(a==Tn.NONE)return[];const t=new Set,l=n.template.__type,i=yd(a);switch(l){case"chat":{n.template.messages.forEach(r=>{(r.content==null?[]:i.extractVariables(r.content)).forEach(c=>{t.add(c)})});break}case"text_completion":{i.extractVariables(n.template.prompt).forEach(s=>{t.add(s)});break}default:ue()}return Array.from(t)},Ru=({instances:n,templateLanguage:a})=>a==Tn.NONE?[]:Array.from(new Set(n.flatMap(t=>yi({instance:t,templateLanguage:a})))),fi=({instances:n,templateLanguage:a,input:t})=>{if(a==Tn.NONE)return{variablesMap:{},variableKeys:[]};const l=Ru({instances:n,templateLanguage:a}),i=t.variablesValueCache??{};return{variablesMap:l.reduce((s,c)=>(s[c]=i[c]||"",s),{}),variableKeys:l}};function En(n,a){return n.invocationName===a.invocationName||n.canonicalName!=null&&a.canonicalName!=null&&n.canonicalName===a.canonicalName}const Au=(n,a)=>n.filter(t=>a.some(l=>En(l,t))).map(t=>{var l;return{...t,invocationName:((l=a.find(i=>En(i,t)))==null?void 0:l.invocationName)??t.invocationName}}),Wa=n=>n.replace(/_([a-z])/g,(a,t)=>t.toUpperCase()),Mu=(n,a)=>Object.entries(n).map(([t,l])=>{const i=a.find(r=>r.canonicalName&&r.canonicalName.toLowerCase()===t.toLowerCase()||r.invocationName&&r.invocationName.toLowerCase()===t.toLowerCase());return i==null||i.invocationInputField==null||i.invocationName==null?null:{canonicalName:i.canonicalName,invocationName:i.invocationName,[Wa(i.invocationInputField)]:l}}).filter(t=>t!=null),Ra=n=>{const{provider:a,validatedToolDefinition:t}=hd(n.definition);switch(a){case"OPENAI":case"AZURE_OPENAI":return t.function.name;case"ANTHROPIC":return t.name;case"UNKNOWN":return null;default:ue()}},Zt=({provider:n,toolNumber:a})=>{switch(n){case"OPENAI":case"AZURE_OPENAI":return{id:wa(),definition:qt(a)};case"ANTHROPIC":return{id:wa(),definition:kd(a)};case"GEMINI":return{id:wa(),definition:qt(a)};default:ue()}},Nu=n=>{switch(n){case"OPENAI":case"AZURE_OPENAI":return jt();case"ANTHROPIC":return fd();case"GEMINI":return jt();default:ue()}};function zu(n){return{content:n.content,role:Vu(n.role),toolCalls:n.toolCalls,toolCallId:n.toolCallId}}function Vu(n){switch(n){case"system":return"SYSTEM";case"user":return"USER";case"tool":return"TOOL";case"ai":return"AI";default:ue()}}const hi=({playgroundStore:n,instanceId:a,credentials:t})=>{const{instances:l}=n.getState(),i=l.find(u=>u.id===a);if(!i)throw new Error(`No instance found for id ${a}`);if(i.template.__type!=="chat")throw new Error("We only support chat templates for now");const r=i.model.supportedInvocationParameters;let s=[...i.model.invocationParameters];const c=iu({toolChoice:i.toolChoice,targetProvider:i.model.provider});i.tools.length>0?(s=s.filter(u=>u.invocationName!==_a&&u.canonicalName!==ua),s.push({canonicalName:ua,invocationName:_a,valueJson:c})):s=s.filter(u=>u.invocationName!==_a&&u.canonicalName!==ua),s=r.length?Au(s,r):s;const d=i.model.provider==="AZURE_OPENAI"?{endpoint:i.model.endpoint,apiVersion:i.model.apiVersion}:{};return{messages:i.template.messages.map(zu),model:{providerKey:i.model.provider,name:i.model.modelName||"",...d},invocationParameters:s,tools:i.tools.length?i.tools.map(u=>u.definition):void 0,apiKey:t[i.model.provider]||null}},$u=({playgroundStore:n,instanceId:a,credentials:t})=>{const l=hi({playgroundStore:n,instanceId:a,credentials:t}),{instances:i,templateLanguage:r,input:s}=n.getState(),{variablesMap:c}=fi({instances:i,input:s,templateLanguage:r});return{...l,template:{variables:c,language:r}}},Yt=({playgroundStore:n,instanceId:a,credentials:t,datasetId:l})=>({...hi({playgroundStore:n,instanceId:a,credentials:t}),templateLanguage:n.getState().templateLanguage,datasetId:l});function ki(n){return n==null||n===""?"{}":typeof n=="string"?n:JSON.stringify(n,null,2)}function bi(n,a){return a.filter(t=>t.required).every(t=>n.some(l=>En(l,t)))}const Ou=n=>{for(const[a,t]of Object.entries(n))if(a.endsWith("DefaultValue")&&t!=null)return n[a]};function Wh(n,a){const t=new Map(n.map(l=>[l.canonicalName||l.invocationName,l]));return a.forEach(l=>{var d;const i=l.canonicalName||l.invocationName,r=Ou(l),s=Wa(l.invocationInputField||"");if(!l.invocationName||!l.invocationInputField||!i||r==null||((d=t.get(i))==null?void 0:d[s])!=null)return;const c={canonicalName:l.canonicalName,invocationName:l.invocationName,[s]:r};t.set(i,c)}),Array.from(t.values())}const Si=m.createContext(null);function Jh({children:n,...a}){const[t]=m.useState(()=>bd(a));return e(Si.Provider,{value:t,children:n})}function Va(n,a){const t=Se.useContext(Si);if(!t)throw new Error("Missing CredentialsContext.Provider in the tree");return ya(t,n,a)}const vi=m.createContext(null);function Qu(){const n=m.useContext(vi);if(n===null)throw new Error("useFunctionality must be used within a FunctionalityProvider");return n}function Zh(n){return e(vi.Provider,{value:{authenticationEnabled:window.Config.authenticationEnabled},children:n.children})}const ju=C`
  display: flex;
  direction: row;
  height: 100vh;
  overflow: hidden;
`,qu=C`
  display: flex;
  flex-direction: column;
  flex: 1 1 auto;
  height: 100%;
  overflow: hidden;
  padding-left: var(--px-nav-collapsed-width);
`,Uu=C`
  flex: 1 1 auto;
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
`,Bu=C`
  display: flex;
  flex-direction: column;
  margin: 0;
  list-style: none;
  gap: var(--ac-global-dimension-size-50);
  padding-inline-start: 0;
`,Hu=C`
  display: flex;
  flex-direction: column;
  gap: var(--ac-global-dimension-size-50);
`;function Yh(){return o("div",{css:ju,"data-testid":"layout",children:[e(Gu,{}),o("div",{css:qu,children:[e(vd,{children:e(Sd,{})}),e("div",{"data-testid":"content",css:Uu,children:e(m.Suspense,{fallback:e(ye,{}),children:e(Ve,{})})})]})]})}function Gu(){const n=m.useMemo(()=>window.Config.hasInferences,[]),a=be(),{authenticationEnabled:t}=Qu(),l=ne(),i=m.useCallback(async()=>{const r=await fetch(ba("/auth/logout"),{method:"POST"});if(r.ok){l("/login");return}a({title:"Logout Failed",message:"Failed to log out: "+r.statusText})},[l,a]);return o(Dd,{children:[e(Cd,{}),o(h,{direction:"column",justifyContent:"space-between",flex:"1 1 auto",children:[o("ul",{css:Hu,children:[n&&e("li",{children:e(Cn,{to:"/model",text:"Model",icon:e(L,{svg:e(D.CubeOutline,{})})})}),e("li",{children:e(Cn,{to:"/projects",text:"Projects",icon:e(L,{svg:e(D.GridOutline,{})})})}),e("li",{children:e(Cn,{to:"/datasets",text:"Datasets",icon:e(L,{svg:e(D.DatabaseOutline,{})})})}),e("li",{children:e(Cn,{to:"/playground",text:"Playground",icon:e(L,{svg:e(D.PlayCircleOutline,{})})})}),e("li",{children:e(Cn,{to:"/apis",text:"APIs",icon:e(L,{svg:e(D.Code,{})})})})]}),o("ul",{css:Bu,children:[e("li",{children:e(Cn,{to:"/settings",text:"Settings",icon:e(L,{svg:e(D.SettingsOutline,{})})})}),e("li",{children:e(Fd,{})}),e("li",{children:e(Kd,{})}),e("li",{children:e(xd,{})}),t&&o(G,{children:[e("li",{children:e(Cn,{to:"/profile",text:"Profile",icon:e(L,{svg:e(D.PersonOutline,{})})})}),e("li",{children:e(Td,{text:"Log Out",icon:e(L,{svg:e(D.LogOut,{})}),onClick:i})})]})]})]})]})}const Ci=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"exampleId"}],a=[{kind:"Variable",name:"id",variableName:"exampleId"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null},i={alias:"latestRevision",args:null,concreteType:"DatasetExampleRevision",kind:"LinkedField",name:"revision",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"input",storageKey:null},l,{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null}],storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null},s={alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"span",plural:!1,selections:[t,{alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[r],storageKey:null},{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[t],storageKey:null}],storageKey:null},c={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},d=[{kind:"Literal",name:"first",value:100}],u={alias:null,args:null,concreteType:"Trace",kind:"LinkedField",name:"trace",plural:!1,selections:[r,{alias:null,args:null,kind:"ScalarField",name:"projectId",storageKey:null}],storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExampleDetailsDialogQuery",selections:[{alias:"example",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[t,i,s],type:"DatasetExample",abstractKey:null},{args:null,kind:"FragmentSpread",name:"ExampleExperimentRunsTableFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExampleDetailsDialogQuery",selections:[{alias:"example",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[c,{kind:"TypeDiscriminator",abstractKey:"__isNode"},t,{kind:"InlineFragment",selections:[i,s,{alias:null,args:d,concreteType:"ExperimentRunConnection",kind:"LinkedField",name:"experimentRuns",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"run",args:null,concreteType:"ExperimentRun",kind:"LinkedField",name:"node",plural:!1,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"error",storageKey:null},l,u,{alias:null,args:null,concreteType:"ExperimentRunAnnotationConnection",kind:"LinkedField",name:"annotations",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunAnnotationEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"annotation",args:null,concreteType:"ExperimentRunAnnotation",kind:"LinkedField",name:"node",plural:!1,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},u],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"ExperimentRun",kind:"LinkedField",name:"node",plural:!1,selections:[c],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:"experimentRuns(first:100)"},{alias:null,args:d,filters:null,handle:"connection",key:"ExampleExperimentRunsTable_experimentRuns",kind:"LinkedHandle",name:"experimentRuns"}],type:"DatasetExample",abstractKey:null}],storageKey:null}]},params:{cacheID:"6fa23dc80c23ecdf48e57d139d76a721",id:null,metadata:{},name:"ExampleDetailsDialogQuery",operationKind:"query",text:`query ExampleDetailsDialogQuery(
  $exampleId: GlobalID!
) {
  example: node(id: $exampleId) {
    __typename
    ... on DatasetExample {
      id
      latestRevision: revision {
        input
        output
        metadata
      }
      span {
        id
        context {
          traceId
        }
        project {
          id
        }
      }
    }
    ...ExampleExperimentRunsTableFragment
    __isNode: __typename
    id
  }
}

fragment ExampleExperimentRunsTableFragment on DatasetExample {
  experimentRuns(first: 100) {
    edges {
      run: node {
        id
        startTime
        endTime
        error
        output
        trace {
          traceId
          projectId
        }
        annotations {
          edges {
            annotation: node {
              id
              name
              label
              score
              explanation
              annotatorKind
              trace {
                traceId
                projectId
              }
            }
          }
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();Ci.hash="65b1c049bacc1ef8739c61af32a9414c";const Fi=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"patchDatasetExamples",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"EditExampleDialogMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"EditExampleDialogMutation",selections:a},params:{cacheID:"7217082d3d3796ecb60481d17133c351",id:null,metadata:{},name:"EditExampleDialogMutation",operationKind:"mutation",text:`mutation EditExampleDialogMutation(
  $input: PatchDatasetExamplesInput!
) {
  patchDatasetExamples(input: $input) {
    __typename
  }
}
`}}}();Fi.hash="a5e0e601ed24ffaa37a99ba358f960d3";const tt={backgroundColor:"light",borderColor:"light",collapsible:!0,bodyStyle:{padding:0}};function Wu(n){const{exampleId:a,onCompleted:t}=n,[l,i]=m.useState(null),[r,s]=P.useMutation(Fi),{control:c,setError:d,handleSubmit:u,formState:{isValid:y}}=je({defaultValues:n.currentRevision}),g=m.useCallback(p=>{if(i(null),!en(p==null?void 0:p.input))return d("input",{message:"Input must be a valid JSON object"});if(!en(p==null?void 0:p.output))return d("output",{message:"Output must be a valid JSON object"});if(!en(p==null?void 0:p.metadata))return d("metadata",{message:"Metadata must be a valid JSON object"});r({variables:{input:{patches:[{exampleId:a,input:JSON.parse(p.input),output:JSON.parse(p.output),metadata:JSON.parse(p.metadata)}],versionDescription:p.description}},onCompleted:()=>{t()},onError:f=>{i(f.message)}})},[r,a,d,t]);return e(Y,{size:"fullscreen",title:`Edit Example: ${a}`,extra:e(z,{variant:"primary",size:"compact",disabled:!y||s,loading:s,onClick:u(g),children:"Save Changes"}),children:e("div",{css:C`
          overflow-y: auto;
          padding: var(--ac-global-dimension-size-400);
          /* Make widths configurable */
          .dataset-picker {
            width: 100%;
            .ac-dropdown--picker,
            .ac-dropdown-button {
              width: 100%;
            }
          }
        `,children:e(h,{direction:"row",justifyContent:"center",children:e(F,{width:"900px",paddingStart:"auto",paddingEnd:"auto",children:o(h,{direction:"column",gap:"size-200",children:[l?e(ce,{variant:"danger",children:l}):null,e(W,{control:c,name:"input",render:({field:{onChange:p,onBlur:f,value:k},fieldState:{invalid:b,error:S}})=>o(q,{title:"Input",subTitle:"The input to the LLM, retriever, program, etc.",...tt,children:[b?e(ce,{variant:"danger",banner:!0,children:S==null?void 0:S.message}):null,e(Ee,{value:k,onChange:p,onBlur:f})]})}),e(W,{control:c,name:"output",render:({field:{onChange:p,onBlur:f,value:k},fieldState:{invalid:b,error:S}})=>o(q,{title:"Output",subTitle:"The output of the LLM or program to be used as an expected output",...tt,backgroundColor:"green-100",borderColor:"green-700",children:[b?e(ce,{variant:"danger",banner:!0,children:S==null?void 0:S.message}):null,e(Ee,{value:k,onChange:p,onBlur:f})]})}),e(W,{control:c,name:"metadata",render:({field:{onChange:p,onBlur:f,value:k},fieldState:{invalid:b,error:S}})=>o(q,{title:"Metadata",subTitle:"All data from the span to use during experimentation or evaluation",...tt,children:[b?e(ce,{variant:"danger",banner:!0,children:S==null?void 0:S.message}):null,e(Ee,{value:k,onChange:p,onBlur:f})]})}),e(W,{control:c,name:"description",render:({field:{onChange:p,onBlur:f,value:k},fieldState:{invalid:b,error:S}})=>e(kt,{label:"Revision Description",value:k,onChange:p,onBlur:f,errorMessage:S==null?void 0:S.message,validationState:b?"invalid":"valid",placeholder:"A description of the changes made in this revision. Will be displayed in the version history.",height:100})})]})})})})})}function Ju(n){const{onCompleted:a,...t}=n,[l,i]=m.useState(null);return o(G,{children:[e(z,{variant:"default",size:"compact",icon:e(L,{svg:e(D.EditOutline,{})}),onClick:()=>i(e(Wu,{...t,onCompleted:()=>{i(null),a()}})),children:"Edit Example"}),e(ae,{type:"slideOver",isDismissable:!0,onDismiss:()=>i(null),children:l})]})}const Ki=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:100,kind:"LocalArgument",name:"first"},{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t=[{kind:"Variable",name:"after",variableName:"after"},{kind:"Variable",name:"first",variableName:"first"}],l={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={alias:null,args:null,concreteType:"Trace",kind:"LinkedField",name:"trace",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"projectId",storageKey:null}],storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExampleExperimentRunsTableQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:t,kind:"FragmentSpread",name:"ExampleExperimentRunsTableFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExampleExperimentRunsTableQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[l,{kind:"TypeDiscriminator",abstractKey:"__isNode"},i,{kind:"InlineFragment",selections:[{alias:null,args:t,concreteType:"ExperimentRunConnection",kind:"LinkedField",name:"experimentRuns",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"run",args:null,concreteType:"ExperimentRun",kind:"LinkedField",name:"node",plural:!1,selections:[i,{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"error",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null},r,{alias:null,args:null,concreteType:"ExperimentRunAnnotationConnection",kind:"LinkedField",name:"annotations",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunAnnotationEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"annotation",args:null,concreteType:"ExperimentRunAnnotation",kind:"LinkedField",name:"node",plural:!1,selections:[i,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},r],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"ExperimentRun",kind:"LinkedField",name:"node",plural:!1,selections:[l],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:t,filters:null,handle:"connection",key:"ExampleExperimentRunsTable_experimentRuns",kind:"LinkedHandle",name:"experimentRuns"}],type:"DatasetExample",abstractKey:null}],storageKey:null}]},params:{cacheID:"2ec7ead16e6df0877bc47db0ed7c7553",id:null,metadata:{},name:"ExampleExperimentRunsTableQuery",operationKind:"query",text:`query ExampleExperimentRunsTableQuery(
  $after: String = null
  $first: Int = 100
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...ExampleExperimentRunsTableFragment_2HEEH6
    __isNode: __typename
    id
  }
}

fragment ExampleExperimentRunsTableFragment_2HEEH6 on DatasetExample {
  experimentRuns(first: $first, after: $after) {
    edges {
      run: node {
        id
        startTime
        endTime
        error
        output
        trace {
          traceId
          projectId
        }
        annotations {
          edges {
            annotation: node {
              id
              name
              label
              score
              explanation
              annotatorKind
              trace {
                traceId
                projectId
              }
            }
          }
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();Ki.hash="6ca0f938b309407e8c184a1c13d1c52d";const xi=function(){var n=["experimentRuns"],a={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},t={alias:null,args:null,concreteType:"Trace",kind:"LinkedField",name:"trace",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"projectId",storageKey:null}],storageKey:null};return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:100,kind:"LocalArgument",name:"first"}],kind:"Fragment",metadata:{connection:[{count:"first",cursor:"after",direction:"forward",path:n}],refetch:{connection:{forward:{count:"first",cursor:"after"},backward:null,path:n},fragmentPathInResult:["node"],operation:Ki,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"ExampleExperimentRunsTableFragment",selections:[{alias:"experimentRuns",args:null,concreteType:"ExperimentRunConnection",kind:"LinkedField",name:"__ExampleExperimentRunsTable_experimentRuns_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"run",args:null,concreteType:"ExperimentRun",kind:"LinkedField",name:"node",plural:!1,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"error",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null},t,{alias:null,args:null,concreteType:"ExperimentRunAnnotationConnection",kind:"LinkedField",name:"annotations",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunAnnotationEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"annotation",args:null,concreteType:"ExperimentRunAnnotation",kind:"LinkedField",name:"node",plural:!1,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},t],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"ExperimentRun",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},a],type:"DatasetExample",abstractKey:null}}();xi.hash="6ca0f938b309407e8c184a1c13d1c52d";const Zu=100;function Yu(){return e("tbody",{className:"is-empty",children:e("tr",{children:e("td",{colSpan:100,css:n=>C`
            text-align: center;
            padding: ${n.spacing.margin24}px ${n.spacing.margin24}px !important;
          `,children:"No experiments have been run for this example."})})})}const Xu=C`
  display: flex;
  flex-direction: row;
  align-items: center;
  color: var(--ac-global-color-primary);
  gap: var(--ac-global-dimension-size-50);
`;function em({example:n}){const a=m.useRef(null),t=ne(),{data:l,loadNext:i,hasNext:r,isLoadingNext:s}=P.usePaginationFragment(xi,n),c=m.useMemo(()=>l.experimentRuns.edges.map(f=>{let k=null;return f.run.startTime&&f.run.endTime&&(k=new Date(f.run.endTime).getTime()-new Date(f.run.startTime).getTime()),{...f.run,output:JSON.stringify(f.run.output),latencyMs:k}}),[l]),u=Te({columns:[{header:"start time",accessorKey:"startTime",cell:_e},{header:"output",accessorKey:"output",cell:f=>{var b;const k=(b=f.row.original)==null?void 0:b.error;return k!==null?e(x,{color:"danger",children:k}):e(Ke,{...f})}},{header:"latency",accessorKey:"latencyMs",cell:({getValue:f})=>{const k=f();return k===null||typeof k!="number"?"--":e(Re,{latencyMs:k})}},{header:"evaluations",accessorKey:"annotations",cell:({row:f})=>e(h,{direction:"row",gap:"size-50",wrap:"wrap",children:f.original.annotations.edges.map((k,b)=>{const S=k.annotation;return e(Sa,{annotation:S,extra:S.trace&&e(F,{paddingTop:"size-100",children:o("div",{css:Xu,children:[e(L,{svg:e(D.InfoOutline,{})}),e("span",{children:"Click to view evaluator trace"})]})}),children:e(yn,{annotation:S,onClick:()=>{S.trace&&t(`/projects/${S.trace.projectId}/traces/${S.trace.traceId}`)}},b)},b)})})},{id:"actions",cell:({row:f})=>{const k=f.original.trace;if(k)return e(z,{variant:"default",size:"compact",icon:e(L,{svg:e(D.Trace,{})}),onClick:()=>{t(`/projects/${k.projectId}/traces/${k.traceId}`)},"aria-label":"view trace"})}}],data:c,getCoreRowModel:De()}),y=u.getRowModel().rows,g=y.length===0,p=m.useCallback(f=>{if(f){const{scrollHeight:k,scrollTop:b,clientHeight:S}=f;k-b-S<300&&!s&&r&&i(Zu)}},[r,s,i]);return e("div",{css:C`
        flex: 1 1 auto;
        overflow: auto;
      `,ref:a,onScroll:f=>p(f.target),children:o("table",{css:Jn,children:[e("thead",{children:u.getHeaderGroups().map(f=>e("tr",{children:f.headers.map(k=>e("th",{children:e("div",{children:Z(k.column.columnDef.header,k.getContext())})},k.id))},f.id))}),g?e(Yu,{}):e("tbody",{children:y.map(f=>e("tr",{children:f.getVisibleCells().map(k=>e("td",{children:Z(k.column.columnDef.cell,k.getContext())},k.id))},f.id))})]})})}function At({exampleId:n,onDismiss:a}){const[t,l]=m.useState(0),i=P.useLazyLoadQuery(Ci,{exampleId:n},{fetchKey:t,fetchPolicy:"store-and-network"}),r=m.useMemo(()=>{const p=i.example.latestRevision;return{input:JSON.stringify(p==null?void 0:p.input,null,2),output:JSON.stringify(p==null?void 0:p.output,null,2),metadata:JSON.stringify(p==null?void 0:p.metadata,null,2)}},[i]),s=m.useMemo(()=>{const p=i.example.span;return p?{id:p.id,traceId:p.context.traceId,projectId:p.project.id}:null},[i]),{input:c,output:d,metadata:u}=r,y=ne(),g=ve();return e(ae,{type:"slideOver",isDismissable:!0,onDismiss:a,children:e(Y,{size:"XL",title:`Example: ${n}`,extra:o(h,{direction:"row",gap:"size-100",children:[s?e(z,{variant:"default",size:"compact",onClick:()=>{y(`/projects/${s.projectId}/traces/${s.traceId}?selectedSpanNodeId=${s.id}`)},children:"View Source Span"}):null,e(Ju,{exampleId:n,currentRevision:r,onCompleted:()=>{g({title:"Example updated",message:`Example ${n} has been updated.`}),l(p=>p+1)}})]}),children:o(tn,{direction:"vertical",autoSaveId:"example-panel-group",children:[e(he,{defaultSize:200,children:e("div",{css:C`
                overflow-y: auto;
                height: 100%;
              `,children:e(h,{direction:"row",justifyContent:"center",children:e(F,{width:"900px",paddingStart:"auto",paddingEnd:"auto",paddingTop:"size-200",paddingBottom:"size-200",children:o(h,{direction:"column",gap:"size-200",children:[e(q,{title:"Input",...lt,extra:e(se,{text:c}),children:e(nn,{value:c})}),e(q,{title:"Output",...lt,extra:e(se,{text:d}),children:e(nn,{value:d})}),e(q,{title:"Metadata",...lt,extra:e(se,{text:u}),children:e(nn,{value:u})})]})})})})}),e(an,{css:fn}),e(he,{defaultSize:100,children:o(h,{direction:"column",height:"100%",children:[e(F,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderBottomColor:"dark",borderBottomWidth:"thin",flex:"none",children:e(ge,{level:3,children:"Experiment Runs"})}),e(em,{example:i.example})]})})]})})})}const lt={backgroundColor:"light",borderColor:"light",variant:"compact",collapsible:!0,bodyStyle:{padding:0}};function Xh(){const{exampleId:n,datasetId:a}=Ue(),t=ne();return e(At,{exampleId:n,onDismiss:()=>{t(`/playground/datasets/${a}`)}})}const Ti=function(){var n=[{alias:null,args:null,concreteType:"Functionality",kind:"LinkedField",name:"functionality",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"modelInferences",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"homeLoaderQuery",selections:n,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"homeLoaderQuery",selections:n},params:{cacheID:"8bfba02258509f0b645b86f3322838d8",id:null,metadata:{},name:"homeLoaderQuery",operationKind:"query",text:`query homeLoaderQuery {
  functionality {
    modelInferences
  }
}
`}}}();Ti.hash="a248736e236c8d5348e0ecfbe9440ca2";async function e1(n){const a=await P.fetchQuery(Ne,Ti,{}).toPromise();return a!=null&&a.functionality.modelInferences?Ma("/model"):Ma("/projects")}const Di=function(){var n={defaultValue:null,kind:"LocalArgument",name:"endTime"},a={defaultValue:null,kind:"LocalArgument",name:"startTime"},t=[{kind:"Variable",name:"endTime",variableName:"endTime"},{kind:"Variable",name:"startTime",variableName:"startTime"}],l=[{kind:"Literal",name:"first",value:50}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},s={fields:[{kind:"Variable",name:"end",variableName:"endTime"},{kind:"Variable",name:"start",variableName:"startTime"}],kind:"ObjectValue",name:"timeRange"},c={alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},d=[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],u={alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null};return{fragment:{argumentDefinitions:[n,a],kind:"Fragment",metadata:null,name:"ModelPageQuery",selections:[{args:t,kind:"FragmentSpread",name:"ModelSchemaTable_dimensions"},{args:t,kind:"FragmentSpread",name:"ModelEmbeddingsTable_embeddingDimensions"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,n],kind:"Operation",name:"ModelPageQuery",selections:[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:l,concreteType:"DimensionConnection",kind:"LinkedField",name:"dimensions",plural:!1,selections:[{alias:null,args:null,concreteType:"DimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"dimension",args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[i,r,{alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dataType",storageKey:null},{alias:"cardinality",args:[{kind:"Literal",name:"metric",value:"cardinality"},s],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"percentEmpty",args:[{kind:"Literal",name:"metric",value:"percentEmpty"},s],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"min",args:[{kind:"Literal",name:"metric",value:"min"},s],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"mean",args:[{kind:"Literal",name:"metric",value:"mean"},s],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"max",args:[{kind:"Literal",name:"metric",value:"max"},s],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"psi",args:[{kind:"Literal",name:"metric",value:"psi"},s],kind:"ScalarField",name:"driftMetric",storageKey:null}],storageKey:null},c,{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:d,storageKey:null}],storageKey:null},u],storageKey:"dimensions(first:50)"},{alias:null,args:l,filters:null,handle:"connection",key:"ModelSchemaTable_dimensions",kind:"LinkedHandle",name:"dimensions"},{alias:null,args:l,concreteType:"EmbeddingDimensionConnection",kind:"LinkedField",name:"embeddingDimensions",plural:!1,selections:[{alias:null,args:null,concreteType:"EmbeddingDimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"embedding",args:null,concreteType:"EmbeddingDimension",kind:"LinkedField",name:"node",plural:!1,selections:[i,r,{alias:"euclideanDistance",args:[{kind:"Literal",name:"metric",value:"euclideanDistance"},s],kind:"ScalarField",name:"driftMetric",storageKey:null}],storageKey:null},c,{alias:null,args:null,concreteType:"EmbeddingDimension",kind:"LinkedField",name:"node",plural:!1,selections:d,storageKey:null}],storageKey:null},u],storageKey:"embeddingDimensions(first:50)"},{alias:null,args:l,filters:null,handle:"connection",key:"ModelEmbeddingsTable_embeddingDimensions",kind:"LinkedHandle",name:"embeddingDimensions"}],storageKey:null}]},params:{cacheID:"18059ac8df6b3c15d5e4bc04ca2c9877",id:null,metadata:{},name:"ModelPageQuery",operationKind:"query",text:`query ModelPageQuery(
  $startTime: DateTime!
  $endTime: DateTime!
) {
  ...ModelSchemaTable_dimensions_3uKjWt
  ...ModelEmbeddingsTable_embeddingDimensions_3uKjWt
}

fragment ModelEmbeddingsTable_embeddingDimensions_3uKjWt on Query {
  model {
    embeddingDimensions(first: 50) {
      edges {
        embedding: node {
          id
          name
          euclideanDistance: driftMetric(metric: euclideanDistance, timeRange: {start: $startTime, end: $endTime})
        }
        cursor
        node {
          __typename
        }
      }
      pageInfo {
        endCursor
        hasNextPage
      }
    }
  }
}

fragment ModelSchemaTable_dimensions_3uKjWt on Query {
  model {
    dimensions(first: 50) {
      edges {
        dimension: node {
          id
          name
          type
          dataType
          cardinality: dataQualityMetric(metric: cardinality, timeRange: {start: $startTime, end: $endTime})
          percentEmpty: dataQualityMetric(metric: percentEmpty, timeRange: {start: $startTime, end: $endTime})
          min: dataQualityMetric(metric: min, timeRange: {start: $startTime, end: $endTime})
          mean: dataQualityMetric(metric: mean, timeRange: {start: $startTime, end: $endTime})
          max: dataQualityMetric(metric: max, timeRange: {start: $startTime, end: $endTime})
          psi: driftMetric(metric: psi, timeRange: {start: $startTime, end: $endTime})
        }
        cursor
        node {
          __typename
        }
      }
      pageInfo {
        endCursor
        hasNextPage
      }
    }
  }
}
`}}}();Di.hash="b612239336c7638df42037315b00f635";function n1(n){const{referenceInferences:a}=We(),{timeRange:t}=on(),l=P.useLazyLoadQuery(Di,{startTime:t.start.toISOString(),endTime:t.end.toISOString()});return o("main",{children:[o(Ft,{children:[e(Ll,{}),a?e(El,{inferencesRole:"reference",timeRange:{start:new Date(a.startTime),end:new Date(a.endTime)}}):null]}),e("section",{css:C`
          margin: var(--ac-global-dimension-static-size-200);
        `,children:e(bt,{title:"Model Schema",variant:"compact",bodyStyle:{padding:0},children:o($e,{children:[e(X,{name:"All",children:o(qe,{children:[e(ke,{title:"Embeddings",id:"embeddings",children:e(Ut,{model:l})}),e(ke,{title:"Dimensions",id:"dimensions",children:e(Bt,{model:l})})]})},"all"),e(X,{name:"Embeddings",children:e(Ut,{model:l})},"embeddings"),e(X,{name:"Dimensions",children:e(Bt,{model:l})},"dimensions")]})})}),e(Ve,{})]})}const Ii={fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"EmbeddingPageModelQuery",selections:[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"MetricSelector_dimensions"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"EmbeddingPageModelQuery",selections:[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:"numericDimensions",args:[{kind:"Literal",name:"include",value:{dataTypes:["numeric"]}}],concreteType:"DimensionConnection",kind:"LinkedField",name:"dimensions",plural:!1,selections:[{alias:null,args:null,concreteType:"DimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:'dimensions(include:{"dataTypes":["numeric"]})'}],storageKey:null}]},params:{cacheID:"4ccf476dd862525b059197daccd0d4d9",id:null,metadata:{},name:"EmbeddingPageModelQuery",operationKind:"query",text:`query EmbeddingPageModelQuery {
  model {
    ...MetricSelector_dimensions
  }
}

fragment MetricSelector_dimensions on Model {
  numericDimensions: dimensions(include: {dataTypes: [numeric]}) {
    edges {
      node {
        id
        name
        type
      }
    }
  }
}
`}};Ii.hash="374499f7f8ce6919e4a0a4ecbe380c52";const Pi=function(){var n={defaultValue:null,kind:"LocalArgument",name:"clusterMinSamples"},a={defaultValue:null,kind:"LocalArgument",name:"clusterSelectionEpsilon"},t={defaultValue:null,kind:"LocalArgument",name:"dataQualityMetricColumnName"},l={defaultValue:null,kind:"LocalArgument",name:"fetchDataQualityMetric"},i={defaultValue:null,kind:"LocalArgument",name:"fetchPerformanceMetric"},r={defaultValue:null,kind:"LocalArgument",name:"id"},s={defaultValue:null,kind:"LocalArgument",name:"minClusterSize"},c={defaultValue:null,kind:"LocalArgument",name:"minDist"},d={defaultValue:null,kind:"LocalArgument",name:"nNeighbors"},u={defaultValue:null,kind:"LocalArgument",name:"nSamples"},y={defaultValue:null,kind:"LocalArgument",name:"performanceMetric"},g={defaultValue:null,kind:"LocalArgument",name:"timeRange"},p=[{kind:"Variable",name:"id",variableName:"id"}],f={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},k={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},b={alias:null,args:null,kind:"ScalarField",name:"x",storageKey:null},S={alias:null,args:null,kind:"ScalarField",name:"y",storageKey:null},v=[f,{alias:null,args:null,kind:"ScalarField",name:"eventId",storageKey:null},{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"coordinates",plural:!1,selections:[k,{kind:"InlineFragment",selections:[b,S,{alias:null,args:null,kind:"ScalarField",name:"z",storageKey:null}],type:"Point3D",abstractKey:null},{kind:"InlineFragment",selections:[b,S],type:"Point2D",abstractKey:null}],storageKey:null},{alias:null,args:null,concreteType:"EmbeddingMetadata",kind:"LinkedField",name:"embeddingMetadata",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"linkToData",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"rawData",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"EventMetadata",kind:"LinkedField",name:"eventMetadata",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"predictionId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"predictionLabel",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"actualLabel",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"predictionScore",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"actualScore",storageKey:null}],storageKey:null}],I=[{alias:null,args:null,kind:"ScalarField",name:"primaryValue",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"referenceValue",storageKey:null}],w={kind:"InlineFragment",selections:[{alias:null,args:[{kind:"Variable",name:"clusterMinSamples",variableName:"clusterMinSamples"},{kind:"Variable",name:"clusterSelectionEpsilon",variableName:"clusterSelectionEpsilon"},{kind:"Variable",name:"minClusterSize",variableName:"minClusterSize"},{kind:"Variable",name:"minDist",variableName:"minDist"},{kind:"Variable",name:"nNeighbors",variableName:"nNeighbors"},{kind:"Variable",name:"nSamples",variableName:"nSamples"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],concreteType:"UMAPPoints",kind:"LinkedField",name:"UMAPPoints",plural:!1,selections:[{alias:null,args:null,concreteType:"UMAPPoint",kind:"LinkedField",name:"data",plural:!0,selections:v,storageKey:null},{alias:null,args:null,concreteType:"UMAPPoint",kind:"LinkedField",name:"referenceData",plural:!0,selections:v,storageKey:null},{alias:null,args:null,concreteType:"UMAPPoint",kind:"LinkedField",name:"corpusData",plural:!0,selections:v,storageKey:null},{alias:null,args:null,concreteType:"Cluster",kind:"LinkedField",name:"clusters",plural:!0,selections:[f,{alias:null,args:null,kind:"ScalarField",name:"eventIds",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"driftRatio",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"primaryToCorpusRatio",storageKey:null},{condition:"fetchDataQualityMetric",kind:"Condition",passingValue:!0,selections:[{alias:null,args:[{fields:[{kind:"Variable",name:"columnName",variableName:"dataQualityMetricColumnName"},{kind:"Literal",name:"metric",value:"mean"}],kind:"ObjectValue",name:"metric"}],concreteType:"DatasetValues",kind:"LinkedField",name:"dataQualityMetric",plural:!1,selections:I,storageKey:null}]},{condition:"fetchPerformanceMetric",kind:"Condition",passingValue:!0,selections:[{alias:null,args:[{fields:[{kind:"Variable",name:"metric",variableName:"performanceMetric"}],kind:"ObjectValue",name:"metric"}],concreteType:"DatasetValues",kind:"LinkedField",name:"performanceMetric",plural:!1,selections:I,storageKey:null}]}],storageKey:null},{alias:null,args:null,concreteType:"Retrieval",kind:"LinkedField",name:"contextRetrievals",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"queryId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"documentId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"relevance",storageKey:null}],storageKey:null}],storageKey:null}],type:"EmbeddingDimension",abstractKey:null};return{fragment:{argumentDefinitions:[n,a,t,l,i,r,s,c,d,u,y,g],kind:"Fragment",metadata:null,name:"EmbeddingPageUMAPQuery",selections:[{alias:"embedding",args:p,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[w],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[r,g,c,d,u,s,n,a,l,t,i,y],kind:"Operation",name:"EmbeddingPageUMAPQuery",selections:[{alias:"embedding",args:p,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[k,w,{kind:"TypeDiscriminator",abstractKey:"__isNode"},f],storageKey:null}]},params:{cacheID:"d30210c52f86b9d9a7ac958f866aa93e",id:null,metadata:{},name:"EmbeddingPageUMAPQuery",operationKind:"query",text:`query EmbeddingPageUMAPQuery(
  $id: GlobalID!
  $timeRange: TimeRange!
  $minDist: Float!
  $nNeighbors: Int!
  $nSamples: Int!
  $minClusterSize: Int!
  $clusterMinSamples: Int!
  $clusterSelectionEpsilon: Float!
  $fetchDataQualityMetric: Boolean!
  $dataQualityMetricColumnName: String
  $fetchPerformanceMetric: Boolean!
  $performanceMetric: PerformanceMetric!
) {
  embedding: node(id: $id) {
    __typename
    ... on EmbeddingDimension {
      UMAPPoints(timeRange: $timeRange, minDist: $minDist, nNeighbors: $nNeighbors, nSamples: $nSamples, minClusterSize: $minClusterSize, clusterMinSamples: $clusterMinSamples, clusterSelectionEpsilon: $clusterSelectionEpsilon) {
        data {
          id
          eventId
          coordinates {
            __typename
            ... on Point3D {
              x
              y
              z
            }
            ... on Point2D {
              x
              y
            }
          }
          embeddingMetadata {
            linkToData
            rawData
          }
          eventMetadata {
            predictionId
            predictionLabel
            actualLabel
            predictionScore
            actualScore
          }
        }
        referenceData {
          id
          eventId
          coordinates {
            __typename
            ... on Point3D {
              x
              y
              z
            }
            ... on Point2D {
              x
              y
            }
          }
          embeddingMetadata {
            linkToData
            rawData
          }
          eventMetadata {
            predictionId
            predictionLabel
            actualLabel
            predictionScore
            actualScore
          }
        }
        corpusData {
          id
          eventId
          coordinates {
            __typename
            ... on Point3D {
              x
              y
              z
            }
            ... on Point2D {
              x
              y
            }
          }
          embeddingMetadata {
            linkToData
            rawData
          }
          eventMetadata {
            predictionId
            predictionLabel
            actualLabel
            predictionScore
            actualScore
          }
        }
        clusters {
          id
          eventIds
          driftRatio
          primaryToCorpusRatio
          dataQualityMetric(metric: {columnName: $dataQualityMetricColumnName, metric: mean}) @include(if: $fetchDataQualityMetric) {
            primaryValue
            referenceValue
          }
          performanceMetric(metric: {metric: $performanceMetric}) @include(if: $fetchPerformanceMetric) {
            primaryValue
            referenceValue
          }
        }
        contextRetrievals {
          queryId
          documentId
          relevance
        }
      }
    }
    __isNode: __typename
    id
  }
}
`}}}();Pi.hash="f1ee7ce02317f1c3fe96b77af405095f";function nm(){const{theme:n}=Zn();return m.useMemo(()=>n==="light"?Id:Pd,[n])}function am(){const{embeddingDimensionId:n}=Ue();if(!n)throw new Error("Missing embeddingDimensionId in URL params");return n}const Li={euclideanDistance:{name:"Euclidean Distance",shortName:"Euc. Distance",definition:"Euclidean distance over time captures how much your primary inferences's embeddings are drifting from the reference data. Euclidean distance of the embeddings is calculated by taking the centroid of the embedding vectors for each inferences and calculating the distance between the two centroids."},queryDistance:{name:"Query Distance",shortName:"Query Distance",definition:"The query distance is the euclidean distance of the centroid of queries from the centroid of the corpus."},accuracyScore:{name:"Accuracy Score",shortName:"Accuracy",definition:"Accuracy classification score. In multi-label classification, this function computes subset accuracy: the set of labels predicted for a sample must exactly match the corresponding set of labels in the ground truth."}};function In(n){const a=Li[n];return a!=null?a.shortName:n}function it(n){const a=Li[n];return a&&a.definition!=null&&a.definition||null}function zn(n){return`${n.column}:${n.dir}`}function tm(){const{referenceInferences:n}=We(),a=!!n,t=B(d=>d.clusterSort),l=B(d=>d.setClusterSort),[i,r]=m.useState(!1),s=m.useMemo(()=>{const d=[];return a&&d.push({label:"Most drift",value:zn({column:"driftRatio",dir:"desc"})}),[...d,{label:"Largest clusters",value:zn({column:"size",dir:"desc"})},{label:"Smallest clusters",value:zn({column:"size",dir:"asc"})},{label:"Highest metric value",value:zn({column:"primaryMetricValue",dir:"desc"})},{label:"Lowest metric value",value:zn({column:"primaryMetricValue",dir:"asc"})}]},[a]),c=zn(t);return e("div",{css:d=>C`
        .ac-action-button {
          background: none;
          border: none;
          color: ${"var(--ac-global-text-color-700)"};
          font-size: ${d.typography.sizes.small.fontSize}px;
          line-height: ${d.typography.sizes.small.lineHeight}px;
          cursor: pointer;
          outline: none;
          &:hover {
            color: var(--ac-global-text-color-900);
          }
        }
      `,children:o(Bn,{placement:"bottom right","aria-label":"Sort clusters by",isOpen:i,onOpenChange:d=>r(d),children:[o(ld,{children:["Sort",e("span",{"aria-hidden":!0,"data-testid":"dropdown-caret",css:C`
              margin-left: var(--ac-global-dimension-static-size-50);
              border-bottom-color: #0000;
              border-left-color: #0000;
              border-right-color: #0000;
              border-style: solid;
              border-width: 3px 3px 0;
              content: "";
              display: inline-block;
              height: 0;
              vertical-align: middle;
              width: 0;
            `})]}),e(Oa,{children:e(Qa,{style:{width:200},selectedKeys:[c],selectionMode:"single",items:s,onSelectionChange:d=>{if(d instanceof Set&&d.size>0){const[u]=d.values(),[y,g]=u.split(":");l({column:y,dir:g})}r(!1)},children:d=>e(le,{children:d.label},d.value)})})]})})}const Ei=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"clusters"}],a=[{alias:null,args:[{kind:"Variable",name:"clusters",variableName:"clusters"}],concreteType:"ExportedFile",kind:"LinkedField",name:"exportClusters",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"fileName",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"EmbeddingActionMenuExportClustersMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"EmbeddingActionMenuExportClustersMutation",selections:a},params:{cacheID:"1bef6586fcb3d6eb7034204fbe49633c",id:null,metadata:{},name:"EmbeddingActionMenuExportClustersMutation",operationKind:"mutation",text:`mutation EmbeddingActionMenuExportClustersMutation(
  $clusters: [ClusterInput!]!
) {
  exportClusters(clusters: $clusters) {
    fileName
  }
}
`}}}();Ei.hash="b5ff2517dbb0d19a1b24dea1796a3576";function lm(){const n=B(r=>r.clusters),{notifyError:a,notifySuccess:t}=wl(),[l,i]=P.useMutation(Ei);return e(Rn,{align:"end",buttonSize:"compact",icon:i?e(L,{svg:e(D.LoadingOutline,{})}):null,onAction:r=>{switch(r){case"export_cluster":l({variables:{clusters:n.map(s=>({eventIds:s.eventIds,id:s.id}))},onCompleted:s=>{const{fileName:c}=s.exportClusters;t({title:"Clusters Exported",message:"dataframe is available via px.active_session().exports or can be downloaded by clicking below",action:{text:"Download",onClick:()=>{window.open(`/exports?filename=${c}`,"_self")}}})},onError:s=>{a({title:"Failed to export clusters",message:`Failed to export clusters: ${s.message}`})}});break}},children:o(le,{children:[e(L,{svg:e(D.Download,{})}),"Export clusters"]},"export_cluster")})}const wi={argumentDefinitions:[],kind:"Fragment",metadata:null,name:"MetricSelector_dimensions",selections:[{alias:"numericDimensions",args:[{kind:"Literal",name:"include",value:{dataTypes:["numeric"]}}],concreteType:"DimensionConnection",kind:"LinkedField",name:"dimensions",plural:!1,selections:[{alias:null,args:null,concreteType:"DimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:'dimensions(include:{"dataTypes":["numeric"]})'}],type:"Model",abstractKey:null};wi.hash="55d03de16503d7af254c17cef7d18ee0";const $n=":";function im(n){return["drift","performance","dataQuality","retrieval"].includes(n)}function la(n){const{type:a,metric:t}=n;switch(a){case"drift":return`${a}${$n}${t}`;case"retrieval":return`${a}${$n}${t}`;case"performance":return`${a}${$n}${t}`;case"dataQuality":{const{name:l}=n.dimension;return`${a}${$n}${t}${$n}${l}`}default:ue()}}function rm({metricKey:n,dimensions:a}){const[t,l,i]=n.split($n);if(!im(t))throw new Error(`Invalid metric type: ${t}`);switch(t){case"drift":return{type:t,metric:l};case"retrieval":return{type:t,metric:l};case"performance":return{type:t,metric:l};case"dataQuality":{const r=a.find(s=>s.name===i);if(!r)throw new Error(`Invalid dimension name: ${i}`);return{type:t,metric:l,dimension:r}}default:ue()}}const sm=o(Hn,{variant:"info",children:[e(ge,{level:4,children:"Analysis Metric"}),o(An,{children:[e("p",{children:"Select a metric to drive the analysis of your embeddings."}),e("p",{children:"To analyze the the drift between your two inferencess, select a drift metric and the UI will highlight areas of high drift."}),e("p",{children:"To analyze the quality of your embeddings, select a dimension data quality metric by which to analyze the point cloud. The UI will highlight areas where the data quality is degrading."})]})]});function om({model:n}){const[,a]=m.useTransition(),t=P.useFragment(wi,n),{referenceInferences:l,corpusInferences:i}=We(),r=!!l,s=!!i,c=B(f=>f.metric),d=B(f=>f.loading),u=B(f=>f.setMetric),y=t.numericDimensions.edges.map(f=>f.node),g=y.length>0,p=m.useCallback(f=>{const k=rm({metricKey:f,dimensions:y});a(()=>{u(k)})},[u,y,a]);return o(ha,{label:"metric",labelExtra:sm,selectedKey:c?la(c):void 0,onSelectionChange:p,placeholder:"Select a metric...",isDisabled:d,children:[r?e(Ia,{title:"Drift",children:e(le,{children:"Euclidean Distance"},la({type:"drift",metric:"euclideanDistance"}))}):null,s?e(Ia,{title:"Retrieval",children:e(le,{children:"Query Distance"},la({type:"retrieval",metric:"queryDistance"}))}):null,e(Ia,{title:"Performance",children:e(le,{children:"Accuracy Score"},la({type:"performance",metric:"accuracyScore"}))}),g?e(Ia,{title:"Data Quality",children:y.map(f=>e(le,{children:`${f.name} avg`},la({type:"dataQuality",metric:"average",dimension:f})))}):null]})}const _i=function(){var n={defaultValue:null,kind:"LocalArgument",name:"countGranularity"},a={defaultValue:null,kind:"LocalArgument",name:"dimensionId"},t={defaultValue:null,kind:"LocalArgument",name:"embeddingDimensionId"},l={defaultValue:null,kind:"LocalArgument",name:"fetchDataQuality"},i={defaultValue:null,kind:"LocalArgument",name:"fetchDrift"},r={defaultValue:null,kind:"LocalArgument",name:"fetchPerformance"},s={defaultValue:null,kind:"LocalArgument",name:"fetchQueryDistance"},c={defaultValue:null,kind:"LocalArgument",name:"metricGranularity"},d={defaultValue:null,kind:"LocalArgument",name:"performanceMetric"},u={defaultValue:null,kind:"LocalArgument",name:"timeRange"},y=[{kind:"Variable",name:"id",variableName:"embeddingDimensionId"}],g={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},p={kind:"Variable",name:"granularity",variableName:"metricGranularity"},f={kind:"Variable",name:"timeRange",variableName:"timeRange"},k=[p,{kind:"Literal",name:"metric",value:"euclideanDistance"},f],b=[{alias:null,args:null,concreteType:"TimeSeriesDataPoint",kind:"LinkedField",name:"data",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"timestamp",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"value",storageKey:null}],storageKey:null}],S={kind:"InlineFragment",selections:[{condition:"fetchDrift",kind:"Condition",passingValue:!0,selections:[{alias:"euclideanDistanceTimeSeries",args:k,concreteType:"DriftTimeSeries",kind:"LinkedField",name:"driftTimeSeries",plural:!1,selections:b,storageKey:null}]},{condition:"fetchQueryDistance",kind:"Condition",passingValue:!0,selections:[{alias:null,args:k,concreteType:"DriftTimeSeries",kind:"LinkedField",name:"retrievalMetricTimeSeries",plural:!1,selections:b,storageKey:null}]},{alias:"trafficTimeSeries",args:[{kind:"Variable",name:"granularity",variableName:"countGranularity"},{kind:"Literal",name:"metric",value:"count"},f],concreteType:"DataQualityTimeSeries",kind:"LinkedField",name:"dataQualityTimeSeries",plural:!1,selections:b,storageKey:null}],type:"EmbeddingDimension",abstractKey:null},v=[{kind:"Variable",name:"id",variableName:"dimensionId"}],I={kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:[p,{kind:"Literal",name:"metric",value:"mean"},f],concreteType:"DataQualityTimeSeries",kind:"LinkedField",name:"dataQualityTimeSeries",plural:!1,selections:b,storageKey:null}],type:"Dimension",abstractKey:null},w={alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{condition:"fetchPerformance",kind:"Condition",passingValue:!0,selections:[{alias:null,args:[p,{fields:[{kind:"Variable",name:"metric",variableName:"performanceMetric"}],kind:"ObjectValue",name:"metric"},f],concreteType:"PerformanceTimeSeries",kind:"LinkedField",name:"performanceTimeSeries",plural:!1,selections:b,storageKey:null}]}],storageKey:null},R={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null};return{fragment:{argumentDefinitions:[n,a,t,l,i,r,s,c,d,u],kind:"Fragment",metadata:null,name:"MetricTimeSeriesQuery",selections:[{alias:"embedding",args:y,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[g,S],storageKey:null},{condition:"fetchDataQuality",kind:"Condition",passingValue:!0,selections:[{alias:"dimension",args:v,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[I],storageKey:null}]},w],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[t,u,c,n,i,s,l,a,r,d],kind:"Operation",name:"MetricTimeSeriesQuery",selections:[{alias:"embedding",args:y,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[R,g,S],storageKey:null},{condition:"fetchDataQuality",kind:"Condition",passingValue:!0,selections:[{alias:"dimension",args:v,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[R,I,{kind:"TypeDiscriminator",abstractKey:"__isNode"},g],storageKey:null}]},w]},params:{cacheID:"a68a8204bf7fdd13e6915b338d4b5497",id:null,metadata:{},name:"MetricTimeSeriesQuery",operationKind:"query",text:`query MetricTimeSeriesQuery(
  $embeddingDimensionId: GlobalID!
  $timeRange: TimeRange!
  $metricGranularity: Granularity!
  $countGranularity: Granularity!
  $fetchDrift: Boolean!
  $fetchQueryDistance: Boolean!
  $fetchDataQuality: Boolean!
  $dimensionId: GlobalID!
  $fetchPerformance: Boolean!
  $performanceMetric: PerformanceMetric!
) {
  embedding: node(id: $embeddingDimensionId) {
    __typename
    id
    ... on EmbeddingDimension {
      euclideanDistanceTimeSeries: driftTimeSeries(metric: euclideanDistance, timeRange: $timeRange, granularity: $metricGranularity) @include(if: $fetchDrift) {
        data {
          timestamp
          value
        }
      }
      retrievalMetricTimeSeries(metric: euclideanDistance, timeRange: $timeRange, granularity: $metricGranularity) @include(if: $fetchQueryDistance) {
        data {
          timestamp
          value
        }
      }
      trafficTimeSeries: dataQualityTimeSeries(metric: count, timeRange: $timeRange, granularity: $countGranularity) {
        data {
          timestamp
          value
        }
      }
    }
  }
  dimension: node(id: $dimensionId) @include(if: $fetchDataQuality) {
    __typename
    ... on Dimension {
      name
      dataQualityTimeSeries(metric: mean, timeRange: $timeRange, granularity: $metricGranularity) {
        data {
          timestamp
          value
        }
      }
    }
    __isNode: __typename
    id
  }
  model {
    performanceTimeSeries(metric: {metric: $performanceMetric}, timeRange: $timeRange, granularity: $metricGranularity) @include(if: $fetchPerformance) {
      data {
        timestamp
        value
      }
    }
  }
}
`}}}();_i.hash="f31abad2141a5a1c461ef2a598ffa4f3";const Xt=new Intl.NumberFormat([],{maximumFractionDigits:2}),Ri=()=>{const n=dn(),a=n.blue400,t=n.gray500;return{color:a,barColor:t}};function dm({active:n,payload:a,label:t}){var r,s,c;const{color:l,barColor:i}=Ri();if(n&&a&&a.length){const d=((r=a[1])==null?void 0:r.value)??null,u=((s=a[0])==null?void 0:s.value)??null,y=typeof d=="number"?Xt.format(d):"--",g=typeof u=="number"?Xt.format(u):"--";return o(hn,{children:[e(x,{weight:"heavy",textSize:"medium",children:`${ln(new Date(t))}`}),e(Le,{color:l,name:((c=a[1])==null?void 0:c.payload.metricName)??"Metric",value:y}),e(Le,{color:i,shape:"square",name:"Count",value:g}),e(Ua,{}),o("div",{css:C`
            display: flex;
            flex-direction: row;
            align-items: center;
            color: var(--ac-global-color-primary);
            gap: var(--ac-global-dimension-static-size-50);

            margin-top: var(--ac-global-dimension-static-size-50);
          `,children:[e(L,{svg:e(vl,{})}),e("span",{children:"Click to view the point cloud at this time"})]})]})}return null}function cm(n){switch(n.type){case"drift":return"Embedding Drift";case"performance":return"Model Performance";case"dataQuality":return"Data Quality";case"retrieval":return"Query Distance";default:ue()}}function um(n){if(n)switch(n.type){case"drift":return In(n.metric);case"performance":return In(n.metric);case"dataQuality":return`${n.dimension.name} avg`;case"retrieval":return In(n.metric);default:ue()}else return"Count"}function mm(n){switch(n.type){case"drift":return it(n.metric);case"performance":return it(n.metric);case"dataQuality":return null;case"retrieval":return it(n.metric);default:ue()}}function gm({embeddingDimensionId:n}){const a=B(K=>K.metric),t=a.type==="drift",l=a.type==="retrieval",i=a.type==="dataQuality",r=a.type==="performance",{timeRange:s}=on(),{selectedTimestamp:c,setSelectedTimestamp:d}=qa(),u=Yn(s),y=P.useLazyLoadQuery(_i,{embeddingDimensionId:n,timeRange:{start:s.start.toISOString(),end:s.end.toISOString()},metricGranularity:_l(s),countGranularity:u,fetchDrift:t,fetchQueryDistance:l,fetchDataQuality:i,fetchPerformance:r,dimensionId:a.type==="dataQuality"?a.dimension.id:n,performanceMetric:a.type==="performance"?a.metric:"accuracyScore"}),g=Xn({samplingIntervalMinutes:u.samplingIntervalMinutes}),p=m.useCallback(K=>{const{activePayload:T}=K;if(T!=null&&T.length>0){const E=T[0].payload;d(new Date(E.timestamp))}},[d]),f=pm({data:y,metric:a}),b=ym(y).reduce((K,T)=>(K[T.timestamp]=T.value,K),{})??{},S=f.map(K=>{const T=b[K.timestamp];return{...K,traffic:T,timestamp:new Date(K.timestamp).getTime()}}),v=um(a),I=mm(a),{color:w,barColor:R}=Ri();return o("section",{css:C`
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        h3 {
          padding: var(--ac-global-dimension-static-size-50)
            var(--ac-global-dimension-static-size-200) 0
            var(--ac-global-dimension-static-size-200);
          flex: none;
          display: flex;
          flex-direction: row;
          align-items: center;
          gap: var(--ac-global-dimension-static-size-50);
        }
        & > div {
          flex: 1 1 auto;
          width: 100%;
          overflow: hidden;
        }
      `,children:[o(ge,{level:3,children:[cm(a),I!=null?o(Hn,{children:[e(ge,{level:4,children:v}),e(An,{children:I})]}):null]}),e("div",{children:e(kn,{width:"100%",height:"100%",children:o(Fa,{data:S,margin:{top:25,right:18,left:18,bottom:10},onClick:p,children:[o("defs",{children:[o("linearGradient",{id:"colorUv",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"5%",stopColor:w,stopOpacity:.8}),e("stop",{offset:"95%",stopColor:w,stopOpacity:0})]}),o("linearGradient",{id:"barColor",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"5%",stopColor:R,stopOpacity:.3}),e("stop",{offset:"95%",stopColor:R,stopOpacity:0})]})]}),e(bn,{...ea,tickFormatter:K=>g(new Date(K)),style:{fill:"var(--ac-global-text-color-700)"}}),e(Ge,{stroke:xe.colors.gray200,label:{value:v,angle:-90,position:"insideLeft",style:{textAnchor:"middle",fill:"var(--ac-global-text-color-900)"}},style:{fill:"var(--ac-global-text-color-700)"}}),e(Ge,{yAxisId:"right",orientation:"right",label:{value:"Count",angle:90,position:"insideRight",style:{textAnchor:"middle",fill:"var(--ac-global-text-color-900)"}},style:{fill:"var(--ac-global-text-color-700)"}}),e(Sn,{strokeDasharray:"4 4",stroke:xe.colors.gray200,strokeOpacity:.5}),e(vn,{content:e(dm,{})}),e(qn,{yAxisId:"right",dataKey:"traffic",fill:"url(#barColor)",spacing:5}),e(ga,{type:"monotone",dataKey:"value",stroke:w,fillOpacity:1,fill:"url(#colorUv)"}),c!=null?e(ri,{...Rl,x:c.getTime()}):null]})})})]})}function pm({data:n,metric:a}){var t,l,i,r,s,c;if(((t=n.embedding.euclideanDistanceTimeSeries)==null?void 0:t.data)!=null&&n.embedding.euclideanDistanceTimeSeries.data.length>0)return n.embedding.euclideanDistanceTimeSeries.data.map(d=>({metricName:In(a.metric),...d}));if(((l=n.embedding.retrievalMetricTimeSeries)==null?void 0:l.data)!=null&&n.embedding.retrievalMetricTimeSeries.data.length>0)return n.embedding.retrievalMetricTimeSeries.data.map(d=>({metricName:In(a.metric),...d}));if(n.dimension&&((r=(i=n.dimension)==null?void 0:i.dataQualityTimeSeries)==null?void 0:r.data)!=null&&n.dimension.dataQualityTimeSeries.data.length>0){const d=n.dimension.name||"unknown";return n.dimension.dataQualityTimeSeries.data.map(u=>({metricName:`${d} avg`,...u}))}else{if(n.model&&((s=n.model.performanceTimeSeries)==null?void 0:s.data)!=null&&n.model.performanceTimeSeries.data.length>0)return n.model.performanceTimeSeries.data.map(d=>({metricName:In(a.metric),...d}));if(((c=n.embedding.trafficTimeSeries)==null?void 0:c.data)!=null)return n.embedding.trafficTimeSeries.data.map(d=>({metricName:"Count",...d}))}return[]}function ym(n){var a;return((a=n.embedding.trafficTimeSeries)==null?void 0:a.data)!=null?[...n.embedding.trafficTimeSeries.data]:[]}const Ai=function(){var n={defaultValue:null,kind:"LocalArgument",name:"corpusEventIds"},a={defaultValue:null,kind:"LocalArgument",name:"primaryEventIds"},t={defaultValue:null,kind:"LocalArgument",name:"referenceEventIds"},l=[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,concreteType:"DimensionWithValue",kind:"LinkedField",name:"dimensions",plural:!0,selections:[{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"dimension",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"value",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"EventMetadata",kind:"LinkedField",name:"eventMetadata",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"predictionId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"predictionLabel",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"predictionScore",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"actualLabel",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"actualScore",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PromptResponse",kind:"LinkedField",name:"promptAndResponse",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"prompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"response",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"documentText",storageKey:null}],i=[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"primaryInferences",plural:!1,selections:[{alias:null,args:[{kind:"Variable",name:"eventIds",variableName:"primaryEventIds"}],concreteType:"Event",kind:"LinkedField",name:"events",plural:!0,selections:l,storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"referenceInferences",plural:!1,selections:[{alias:null,args:[{kind:"Variable",name:"eventIds",variableName:"referenceEventIds"}],concreteType:"Event",kind:"LinkedField",name:"events",plural:!0,selections:l,storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"corpusInferences",plural:!1,selections:[{alias:null,args:[{kind:"Variable",name:"eventIds",variableName:"corpusEventIds"}],concreteType:"Event",kind:"LinkedField",name:"events",plural:!0,selections:l,storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"PointSelectionPanelContentQuery",selections:i,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,t,n],kind:"Operation",name:"PointSelectionPanelContentQuery",selections:i},params:{cacheID:"8b48064eba35d0d6c8dc834c2f7795c0",id:null,metadata:{},name:"PointSelectionPanelContentQuery",operationKind:"query",text:`query PointSelectionPanelContentQuery(
  $primaryEventIds: [ID!]!
  $referenceEventIds: [ID!]!
  $corpusEventIds: [ID!]!
) {
  model {
    primaryInferences {
      events(eventIds: $primaryEventIds) {
        id
        dimensions {
          dimension {
            name
            type
          }
          value
        }
        eventMetadata {
          predictionId
          predictionLabel
          predictionScore
          actualLabel
          actualScore
        }
        promptAndResponse {
          prompt
          response
        }
        documentText
      }
    }
    referenceInferences {
      events(eventIds: $referenceEventIds) {
        id
        dimensions {
          dimension {
            name
            type
          }
          value
        }
        eventMetadata {
          predictionId
          predictionLabel
          predictionScore
          actualLabel
          actualScore
        }
        promptAndResponse {
          prompt
          response
        }
        documentText
      }
    }
    corpusInferences {
      events(eventIds: $corpusEventIds) {
        id
        dimensions {
          dimension {
            name
            type
          }
          value
        }
        eventMetadata {
          predictionId
          predictionLabel
          predictionScore
          actualLabel
          actualScore
        }
        promptAndResponse {
          prompt
          response
        }
        documentText
      }
    }
  }
}
`}}}();Ai.hash="4bd627481610322f2acbcf73dfbfaadc";const el=C`
  margin: var(--ac-global-dimension-static-size-200);
  display: flex;
  flex-direction: column;
  gap: var(--ac-global-dimension-static-size-100);
  & > div {
    display: flex;
    flex-direction: row;
    dt {
      font-weight: bold;
      flex: none;
      width: 130px;
    }
    dd {
      flex: 1 1 auto;
      margin-inline-start: 0;
    }
  }
`;function ia(n){return e("div",{css:C`
        max-height: 200px;
        overflow-y: auto;
      `,children:e("pre",{css:C`
          padding: var(--ac-global-dimension-static-size-200);
          color: var(--ac-global-text-color-900);
          white-space: normal;
          margin: 0;
        `,children:n.children})})}function fm({event:n}){const a=n.retrievedDocuments&&n.retrievedDocuments.length>0,t=!n.id.includes("CORPUS");return o("section",{css:C`
        height: 100%;
        overflow-y: auto;
      `,children:[e(Sm,{event:n}),o(qe,{children:[t?e(ke,{id:"prediction",title:"Prediction Details",children:o("dl",{css:el,children:[n.predictionId!=null&&o("div",{children:[e("dt",{children:"Prediction ID"}),e("dd",{css:C`
                      display: flex;
                      align-items: center;
                    `,children:n.predictionId})]}),n.predictionLabel!=null&&o("div",{children:[e("dt",{children:"Prediction Label"}),e("dd",{children:n.predictionLabel})]}),n.predictionScore!=null&&o("div",{children:[e("dt",{children:"Prediction Score"}),e("dd",{children:n.predictionScore})]}),n.actualLabel!=null&&o("div",{children:[e("dt",{children:"Actual Label"}),e("dd",{children:n.actualLabel})]}),n.actualScore!=null&&o("div",{children:[e("dt",{children:"Actual Score"}),e("dd",{children:n.actualScore})]})]})}):e(ke,{id:"document",title:"Document Details",children:e("dl",{css:el,children:n.predictionId!=null&&o("div",{children:[e("dt",{children:"Document ID"}),e("dd",{css:C`
                      display: flex;
                      align-items: center;
                    `,children:n.predictionId})]})})}),e(ke,{id:"dimensions",title:"Dimensions",children:e(km,{dimensions:n.dimensions})}),a&&e(ke,{id:"retrievals",title:"Retrieved Documents",titleExtra:e(Be,{variant:"light",children:n.retrievedDocuments.length}),children:e("ul",{css:C`
                padding: var(--ac-global-dimension-static-size-100);
                li + li {
                  margin-top: var(--ac-global-dimension-static-size-100);
                }
              `,children:n.retrievedDocuments.map(l=>e("li",{children:e(hm,{document:l})},l.id))})})]})]})}function hm({document:n}){return e(F,{borderRadius:"medium",backgroundColor:"light",children:o(h,{direction:"column",children:[e(F,{width:"100%",borderBottomWidth:"thin",borderBottomColor:"dark",children:o(h,{direction:"row",justifyContent:"space-between",margin:"size-100",alignItems:"center",children:[o(h,{direction:"row",gap:"size-50",alignItems:"center",children:[e(L,{svg:e(D.FileOutline,{})}),o(ge,{level:4,children:["document ",n.id]})]}),typeof n.relevance=="number"&&e(Ea,{color:"blue",children:`relevance ${Kt(n.relevance)}`})]})}),e("pre",{css:C`
            padding: var(--ac-global-dimension-static-size-200);
            white-space: normal;
            margin: 0;
          `,children:n.text})]})})}function km({dimensions:n}){const a=m.useMemo(()=>n.map(i=>({name:i.dimension.name,type:i.dimension.type,value:i.value??"--"})),[n]),t=m.useMemo(()=>[{header:()=>"Name",accessorKey:"name"},{header:()=>"Type",accessorKey:"type"},{header:()=>"Value",accessorKey:"value"}],[]),l=Te({columns:t,data:a,getCoreRowModel:De()});return o("table",{css:Je,children:[e("thead",{children:l.getHeaderGroups().map(i=>e("tr",{children:i.headers.map(r=>e("th",{colSpan:r.colSpan,children:r.isPlaceholder?null:e("div",{children:Z(r.column.columnDef.header,r.getContext())})},r.id))},i.id))}),l.getCoreRowModel().rows.length?e("tbody",{children:l.getRowModel().rows.map(i=>e("tr",{children:i.getVisibleCells().map(r=>e("td",{children:Z(r.column.columnDef.cell,r.getContext())},r.id))},i.id))}):e(vm,{})]})}function bm({dataUrl:n}){const a=Ld(n),t=Ed(n);return a?e("video",{src:n,controls:!0,css:C`
          width: 100%;
          height: 500px;
          background-color: black;
        `}):t?e("audio",{src:n,controls:!0,autoPlay:!0}):e("img",{src:n,alt:"event image",width:"100%",height:"200px",css:C`
        object-fit: contain;
        background-color: black;
      `})}function Sm({event:n}){const a=n.linkToData||void 0,t=n.rawData,l=n.prompt||n.response?{prompt:n.prompt,response:n.response}:null,i=n.documentText;let r=null;return a?r=o(h,{direction:"column",children:[e(bm,{dataUrl:a}),t&&e(qe,{children:e(ke,{id:"raw",title:"Raw Data",children:e(ia,{children:t})})})]}):i?r=e(qe,{children:e(ke,{id:"document",title:"Document",children:e(ia,{children:i})})}):l?r=o(qe,{children:[e(ke,{id:"prompt",title:"Prompt",children:e(ia,{children:l.prompt})}),e(ke,{id:"response",title:"Response",children:e(ia,{children:l.response})})]}):n.rawData&&n.rawData&&n.rawData,r}function vm(){return e("tbody",{className:"is-empty",children:e("tr",{children:e("td",{colSpan:100,css:n=>C`
            text-align: center;
            padding: ${n.spacing.margin24}px ${n.spacing.margin24}px !important;
          `,children:e(Al,{graphicKey:"documents",message:"This embedding has no associated dimensions"})})})})}const Mi=function(){var n=[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:null,concreteType:"ExportedFile",kind:"LinkedField",name:"exportedFiles",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"fileName",storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"ExportSelectionButtonExportsQuery",selections:n,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"ExportSelectionButtonExportsQuery",selections:n},params:{cacheID:"2f7e3554305121746dc799b6a8d120da",id:null,metadata:{},name:"ExportSelectionButtonExportsQuery",operationKind:"query",text:`query ExportSelectionButtonExportsQuery {
  model {
    exportedFiles {
      fileName
    }
  }
}
`}}}();Mi.hash="7e6db431afe21f137e54505645c787f4";const Ni=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"eventIds"}],a=[{alias:null,args:[{kind:"Variable",name:"eventIds",variableName:"eventIds"}],concreteType:"ExportedFile",kind:"LinkedField",name:"exportEvents",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"fileName",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExportSelectionButtonMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExportSelectionButtonMutation",selections:a},params:{cacheID:"d370df04ca30a5059288c7aa298239a8",id:null,metadata:{},name:"ExportSelectionButtonMutation",operationKind:"mutation",text:`mutation ExportSelectionButtonMutation(
  $eventIds: [ID!]!
) {
  exportEvents(eventIds: $eventIds) {
    fileName
  }
}
`}}}();Ni.hash="8b0d6962e2034d4c148d1b9919111d2f";const Cm=`import phoenix as px

exports = px.active_session().exports
dataframe = exports[-1]
dataframe`,Fm=C`
  .cm-content {
    padding: var(--ac-global-dimension-static-size-100);
  }
`;function Km({value:n}){const{theme:a}=Zn(),t=a==="light"?void 0:xa;return e(Ka,{value:n,basicSetup:!1,extensions:[Et()],editable:!1,theme:t,css:Fm})}function xm(){const n=B(s=>s.selectedEventIds),[a,t]=P.useMutation(Ni),[l,i]=m.useState(null),r=m.useCallback(()=>{a({variables:{eventIds:[...n]},onCompleted:s=>{i(s.exportEvents)}})},[a,n]);return o(G,{children:[e(z,{variant:"default",size:"compact",icon:e(L,{svg:e(Cl,{})}),"aria-label":"Export selection / cluster",loading:t,onClick:r,children:t?"Exporting":"Export"}),e(ae,{type:"slideOver",isDismissable:!0,onDismiss:()=>i(null),children:l!=null&&o(Y,{title:"Cluster Exports",size:"M",children:[e(ce,{variant:"success",banner:!0,title:"Export succeeded",extra:e(z,{variant:"success",size:"compact",onClick:()=>{window.open(`/exports?filename=${l.fileName}`,"_self")},children:"Download"})}),o("div",{css:C`
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                align-items: flex-start;
                padding: 16px;
                gap: 16px;
              `,children:[e("p",{css:C`
                  margin: 0;
                  flex: 1 1 auto;
                `,children:"You can retrieve your export in your notebook via"}),e(F,{borderColor:"light",borderWidth:"thin",borderRadius:"medium",children:e(Km,{value:Cm})})]}),e(qe,{children:e(ke,{id:"all-exports",title:"Latest Exports",children:e(m.Suspense,{fallback:e(ye,{}),children:e(Tm,{})})})})]})})]})}function Tm(){const n=P.useLazyLoadQuery(Mi,{},{fetchPolicy:"network-only"});return e(Kl,{children:n.model.exportedFiles.map((a,t)=>e(Fl,{children:o("div",{css:C`
              display: flex;
              flex-direction: row;
              justify-content: space-between;
              align-items: center;
            `,children:[a.fileName,e(z,{size:"compact","aria-label":"Download",variant:"default",icon:e(L,{svg:e(Cl,{})}),onClick:()=>{window.open(`/exports?filename=${a.fileName}`,"_self")}})]})},t))})}function Dm(n){const{getInferencesNameByRole:a}=We(),{events:t,onItemSelected:l}=n,i=B(u=>u.eventIdToDataMap),r=B(u=>u.eventIdToGroup),s=B(u=>u.pointGroupColors),c=B(u=>u.selectionGridSize),d=B(u=>u.setHoveredEventId);return e("div",{css:C`
        flex: 1 1 auto;
        overflow-y: auto;
      `,"data-testid":"grid-view-scroll-container",children:e("ul",{"data-grid-size":c,css:C`
          &[data-grid-size="small"] {
            --grid-item-min-width: 100px;
            --grid-item-height: 100px;
          }
          &[data-grid-size="medium"] {
            --grid-item-min-width: 200px;
            --grid-item-height: 200px;
          }
          &[data-grid-size="large"] {
            --grid-item-min-width: 300px;
            --grid-item-height: 200px;
          }
          padding: var(--ac-global-dimension-static-size-200);
          transition: all 0.2s ease-in-out;
          display: grid;
          grid-template-columns: repeat(
            auto-fill,
            minmax(var(--grid-item-min-width), 1fr)
          );
          flex-wrap: wrap;
          gap: var(--ac-global-dimension-static-size-200);
          & > li {
            min-width: var(--grid-item-min-width);
            height: var(--grid-item-height);
          }
        `,children:t.map((u,y)=>{const g=i.get(u.id),{rawData:p=null,linkToData:f=null}=(g==null?void 0:g.embeddingMetadata)??{},{predictionLabel:k=null,actualLabel:b=null}=(g==null?void 0:g.eventMetadata)??{},S=wd(u.id),v=a(S),I=r[u.id],w=s[I];return e("li",{children:e(_d,{rawData:p,linkToData:f,inferencesName:v,group:I,onClick:()=>{l(u.id)},onMouseOver:()=>{d(u.id)},onMouseOut:()=>{d(null)},color:w,size:c,predictionLabel:k,actualLabel:b,promptAndResponse:u.promptAndResponse,documentText:u.documentText,autoPlay:!1})},y)})})})}function Im({data:n,onPointSelected:a}){const{primaryInferences:t,referenceInferences:l}=We(),i=B(y=>y.metric),[r,s]=m.useState([]),{columns:c,tableData:d}=m.useMemo(()=>{const y=n.filter(w=>w.id.includes("CORPUS")===!1);let g=!1,p=!1,f=!1,k=!1,b=!1;n.forEach(w=>{w.linkToData&&(g=!0),w.rawData&&(p=!0),(w.prompt||w.response)&&(f=!0),w.predictionLabel&&(k=!0),w.actualLabel&&(b=!0)});const S=[];l&&S.push({header:"Inference Set",accessorKey:"id",size:50,cell:({getValue:w})=>e(Pm,{id:w(),primaryInferencesName:t.name,referenceInferencesName:(l==null?void 0:l.name)??"reference"})}),g&&S.push({header:"Link",accessorKey:"linkToData",cell:({getValue:w})=>{const R=w();if(typeof R=="string"){const K=R.split("/").pop();return e(rn,{href:R,children:K})}return null}}),f?(S.push({header:"Prompt",accessorKey:"prompt",cell:Ke,size:200}),S.push({header:"Response",accessorKey:"response",cell:Ke,size:200})):p&&S.push({header:"Raw Data",accessorKey:"rawData"}),k&&S.push({header:"Prediction Label",accessorKey:"predictionLabel",size:50}),b&&S.push({header:"Actual Label",accessorKey:"actualLabel",size:50});const v=[];if(i&&i.type==="dataQuality"){const w=i.dimension.name;v.push({header:i.dimension.name,accessorKey:"metric",cell:Rd,sortingFn:"basic"}),y.forEach(R=>{var T;const K=(T=R.dimensions.find(E=>E.dimension.name===w))==null?void 0:T.value;R.metric=K!=null?Number(K):null})}return{columns:[...S,...v,{header:"",id:"view-details",size:50,cell:({row:w})=>e(Ad,{"aria-label":"view point details",onClick:()=>{a(w.original.id)},children:"view details"})}],tableData:y}},[n,a,t,l,i]),u=Te({columns:c,data:d,state:{sorting:r},getCoreRowModel:De(),onSortingChange:s,getSortedRowModel:Un()});return o("table",{css:Je,children:[e("thead",{children:u.getHeaderGroups().map(y=>e("tr",{children:y.headers.map(g=>o("th",{children:[g.isPlaceholder?null:o("div",{className:g.column.getCanSort()?"cursor-pointer":"",onClick:g.column.getToggleSortingHandler(),children:[Z(g.column.columnDef.header,g.getContext()),g.column.getIsSorted()?e(L,{className:"sort-icon",svg:g.column.getIsSorted()==="asc"?e(D.ArrowDownFilled,{}):e(D.ArrowUpFilled,{})}):null]}),e("div",{onMouseDown:g.getResizeHandler(),onTouchStart:g.getResizeHandler(),className:`resizer ${g.column.getIsResizing()?"isResizing":""}`,style:{transform:g.column.getIsResizing()?`translateX(${u.getState().columnSizingInfo.deltaOffset}px)`:""}})]},g.id))},y.id))}),e("tbody",{children:u.getRowModel().rows.map(y=>e("tr",{children:y.getVisibleCells().map(g=>e("td",{style:{width:g.column.getSize()},children:Z(g.column.columnDef.cell,g.getContext())},g.id))},y.id))})]})}function Pm({id:n,primaryInferencesName:a,referenceInferencesName:t}){const l=n.includes("PRIMARY"),i=nm();return o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(Nd,{shape:Md.circle,color:i[l?0:1]}),l?a:t]})}const Lm=C`
  width: 100%;
  height: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  /* Give spacing for the close icon */
  & > .ac-tabs {
    padding-top: 17px;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    [role="tablist"] {
      flex: none;
    }
    .ac-tabs__pane-container {
      display: flex;
      flex-direction: column;
      flex: 1 1 auto;
      overflow: hidden;
      [role="tabpanel"] {
        display: flex;
        flex-direction: column;
        flex: 1 1 auto;
        overflow: hidden;
      }
    }
  }
`;function Em({event:n,relevance:a}){return{id:n.eventMetadata.predictionId||"unknown id",text:n.documentText??"empty document",relevance:a}}function wm(){const n=B(K=>K.selectedEventIds),a=B(K=>K.setSelectedEventIds),t=B(K=>K.setSelectedClusterId),l=B(K=>K.selectionDisplay),[i,r]=Se.useState(null),{primaryEventIds:s,referenceEventIds:c,corpusEventIds:d}=m.useMemo(()=>{const K=[],T=[],E=[];return n.forEach(_=>{_.includes("PRIMARY")?K.push(_):_.includes("CORPUS")?E.push(_):T.push(_)}),{primaryEventIds:K,referenceEventIds:T,corpusEventIds:E}},[n]),u=P.useLazyLoadQuery(Ai,{primaryEventIds:[...s],referenceEventIds:[...c],corpusEventIds:[...d]}),y=m.useMemo(()=>{var _,j,V,H,te,oe;const K=((j=(_=u.model)==null?void 0:_.primaryInferences)==null?void 0:j.events)??[],T=((H=(V=u.model)==null?void 0:V.referenceInferences)==null?void 0:H.events)??[],E=((oe=(te=u.model)==null?void 0:te.corpusInferences)==null?void 0:oe.events)??[];return[...K,...T,...E]},[u]),g=()=>{a(new Set),t(null)},p=B(K=>K.eventIdToDataMap),f=B(K=>K.pointData),k=B(K=>K.selectionSearchText),b=m.useMemo(()=>y.map(K=>{var _,j,V,H,te,oe,N;const T=p.get(K.id),E=[];return f!=null&&(T==null?void 0:T.retrievals)!=null&&T.retrievals.forEach(({documentId:Q,relevance:M})=>{const U=f[Q];U!=null&&E.push(Em({event:U,relevance:M}))}),{id:K.id,predictionId:((_=K.eventMetadata)==null?void 0:_.predictionId)??null,actualLabel:((j=K.eventMetadata)==null?void 0:j.actualLabel)??null,actualScore:((V=K.eventMetadata)==null?void 0:V.actualScore)??null,predictionLabel:((H=K.eventMetadata)==null?void 0:H.predictionLabel)??null,predictionScore:((te=K.eventMetadata)==null?void 0:te.predictionScore)??null,rawData:(T==null?void 0:T.embeddingMetadata.rawData)??null,linkToData:(T==null?void 0:T.embeddingMetadata.linkToData)??null,dimensions:K.dimensions,prompt:((oe=K.promptAndResponse)==null?void 0:oe.prompt)??null,response:((N=K.promptAndResponse)==null?void 0:N.response)??null,retrievedDocuments:E,documentText:K.documentText??null}}),[y,p,f]),S=m.useMemo(()=>{if(k){const K=k.toLowerCase();return b.filter(T=>{var E,_,j,V;return T.id.includes(K)||((E=T.documentText)==null?void 0:E.toLowerCase().includes(K))||((_=T.predictionId)==null?void 0:_.includes(K))||((j=T.prompt)==null?void 0:j.toLowerCase().includes(K))||((V=T.response)==null?void 0:V.toLowerCase().includes(K))})}return b},[b,k]),v=m.useMemo(()=>{if(k){const K=k.toLowerCase();return y.filter(T=>{var E,_,j,V,H,te,oe;return T.id.includes(K)||((E=T.documentText)==null?void 0:E.toLowerCase().includes(K))||((j=(_=T.eventMetadata)==null?void 0:_.predictionId)==null?void 0:j.includes(K))||((H=(V=T.promptAndResponse)==null?void 0:V.prompt)==null?void 0:H.toLowerCase().includes(K))||((oe=(te=T.promptAndResponse)==null?void 0:te.response)==null?void 0:oe.toLowerCase().includes(K))})}return y},[y,k]),I=m.useMemo(()=>i?b.find(T=>T.id===i)??null:null,[b,i]),w=y.length,R=v.length;return o("section",{css:Lm,children:[o("div",{role:"toolbar",css:C`
          position: absolute;
          top: var(--ac-global-dimension-static-size-100);
          right: var(--ac-global-dimension-static-size-200);
          display: flex;
          flex-direction: row-reverse;
          gap: var(--ac-global-dimension-static-size-100);
        `,children:[e(z,{variant:"default",size:"compact",icon:e(L,{svg:e(id,{})}),"aria-label":"Clear selection",onClick:g}),e(xm,{})]}),e($e,{children:o(X,{name:"Selection",children:[e(_m,{numSelectedEvents:w,numMatchingEvents:R,searchText:k}),l===Ml.list?e("div",{css:C`
                flex: 1 1 auto;
                overflow-y: auto;
              `,children:e(Im,{data:S,onPointSelected:r})}):e(Dm,{events:v,onItemSelected:r})]})}),e(ae,{type:"slideOver",isDismissable:!0,onDismiss:()=>r(null),children:I&&e(Y,{title:"Embedding Details",size:"L",children:e(fm,{event:I})})})]})}function _m({numSelectedEvents:n,numMatchingEvents:a,searchText:t}){const l=B(u=>u.selectionDisplay),i=B(u=>u.setSelectionDisplay),r=B(u=>u.selectionGridSize),s=B(u=>u.setSelectionGridSize),c=B(u=>u.setSelectionSearchText),d=m.useMemo(()=>t?`${a}/${n} match "${t}"`:`${n} selected`,[n,a,t]);return e(Ft,{extra:o("div",{css:C`
            display: flex;
            flex-direction: row;
            gap: var(--ac-global-dimension-static-size-100);
          `,children:[e(rd,{placeholder:"Search by text or ID",onChange:u=>{c(u)}}),l===Ml.gallery&&e(zd,{size:r,onChange:s}),e(Vd,{mode:l,onChange:u=>{i(u)}})]}),children:e(x,{children:d})})}const zi=Pi;function a1(){const{referenceInferences:n,corpusInferences:a}=We(),{timeRange:t}=on(),l=m.useMemo(()=>{let i={};return a!=null?i=Qd():n!=null?i=jd():i=qd(),i={...i,umapParameters:{...window.Config.UMAP}},i},[a,n]);return e(Nl,{initialTimestamp:t.end,children:e(Ud,{...l,children:e(Rm,{})})})}function Rm(){const n=am(),{primaryInferences:a,referenceInferences:t}=We(),l=B(v=>v.umapParameters),i=B(v=>v.getHDSCANParameters),r=B(v=>v.getMetric),s=B(v=>v.reset),c=B(v=>v.setLoading),[d,u]=m.useState(!0),[y,g,p]=P.useQueryLoader(zi),{selectedTimestamp:f}=qa(),k=m.useMemo(()=>f??new Date(a.endTime),[f,a.endTime]),b=m.useMemo(()=>({start:bl(k,2).toISOString(),end:k.toISOString()}),[k]),S=P.useLazyLoadQuery(Ii,{});return m.useEffect(()=>{s(),c(!0);const v=r();return g({id:n,timeRange:b,...l,...i(),fetchDataQualityMetric:v.type==="dataQuality",fetchPerformanceMetric:v.type==="performance",dataQualityMetricColumnName:v.type==="dataQuality"?v.dimension.name:null,performanceMetric:v.type==="performance"?v.metric:"accuracyScore"},{fetchPolicy:"network-only"}),()=>{p()}},[c,s,n,g,p,l,i,r,b]),o("main",{css:C`
        flex: 1 1 auto;
        display: flex;
        flex-direction: column;
        overflow: hidden;
      `,children:[e(Qm,{}),o(Ft,{extra:o(h,{direction:"row",justifyContent:"center",alignItems:"center",gap:"size-100",children:[e(Gn,{onChange:v=>{u(v)},defaultSelected:!0,labelPlacement:"start",children:"Show Timeseries"}),e(lm,{})]}),children:[e(Ll,{}),t?e(El,{inferencesRole:"reference",timeRange:{start:new Date(t.startTime),end:new Date(t.endTime)}}):null,e(om,{model:S.model})]}),o(tn,{direction:"vertical",children:[d?o(G,{children:[e(he,{defaultSize:20,collapsible:!0,order:1,children:e(m.Suspense,{fallback:e(ye,{}),children:e(gm,{embeddingDimensionId:n})})}),e(an,{css:fn})]}):null,e(he,{order:2,children:e("div",{css:C`
              width: 100%;
              height: 100%;
              position: relative;
            `,children:e(m.Suspense,{fallback:e(Bd,{}),children:y?e(Mm,{queryReference:y}):null})})})]})]})}function Am(n){if(n.__typename!=="Point3D")throw new Error(`Expected Point3D but got ${n.__typename} for coordinates`);return[n.x,n.y,n.z]}function Mm({queryReference:n}){const a=P.usePreloadedQuery(zi,n),t=m.useMemo(()=>{var u,y;return((y=(u=a.embedding)==null?void 0:u.UMAPPoints)==null?void 0:y.data)??[]},[a]),l=m.useMemo(()=>{var u,y;return((y=(u=a.embedding)==null?void 0:u.UMAPPoints)==null?void 0:y.referenceData)??[]},[a]),i=m.useMemo(()=>{var u,y;return((y=(u=a.embedding)==null?void 0:u.UMAPPoints)==null?void 0:y.corpusData)??[]},[a]),r=m.useMemo(()=>{var u,y;return((y=(u=a.embedding)==null?void 0:u.UMAPPoints)==null?void 0:y.contextRetrievals)??[]},[a]),s=m.useMemo(()=>[...t,...l,...i].map(y=>({...y,position:Am(y.coordinates),metaData:{id:y.eventId}})),[l,t,i]),c=B(u=>u.setInitialData),d=B(u=>u.setClusters);return Mo(()=>{var y,g;const u=((g=(y=a.embedding)==null?void 0:y.UMAPPoints)==null?void 0:g.clusters)||[];c({points:s,clusters:u,retrievals:r})},[s,n,r,c,d]),e("div",{css:C`
        flex: 1 1 auto;
        display: flex;
        flex-direction: row;
        align-items: stretch;
        width: 100%;
        height: 100%;
      `,"data-testid":"point-cloud-display",children:o(tn,{direction:"horizontal",children:[e(he,{id:"embedding-left",defaultSize:15,maxSize:30,minSize:10,collapsible:!0,children:o(tn,{autoSaveId:"embedding-controls-vertical",direction:"vertical",children:[e(he,{css:C`
                display: flex;
                flex-direction: column;
                .ac-tabs {
                  height: 100%;
                  overflow: hidden;
                  display: flex;
                  flex-direction: column;
                  [role="tablist"] {
                    flex: none;
                  }
                  .ac-tabs__pane-container {
                    flex: 1 1 auto;
                    overflow: hidden;
                    display: flex;
                    flex-direction: column;
                    & > div {
                      height: 100%;
                    }
                  }
                }
              `,children:e($m,{})}),e(an,{css:fn}),e(he,{css:C`
                .ac-tabs {
                  height: 100%;
                  overflow: hidden;
                  .ac-tabs__pane-container {
                    height: 100%;
                    overflow-y: auto;
                  }
                }
              `,children:o($e,{children:[e(X,{name:"Display",children:e(Hd,{})}),e(X,{name:"Hyperparameters",children:e(Gd,{})})]})})]})}),e(an,{css:Wd}),e(he,{children:o("div",{css:C`
              position: relative;
              width: 100%;
              height: 100%;
            `,children:[e(Nm,{}),e(Jd,{})]})})]})})}function Nm(){return B(a=>a.selectedEventIds).size===0?null:e("div",{css:C`
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
      `,"data-testid":"selection-panel",children:o(tn,{direction:"vertical",children:[e(he,{}),e(an,{css:fn,style:{zIndex:1}}),e(he,{id:"embedding-point-selection",defaultSize:40,minSize:20,order:2,style:{zIndex:1},children:e(zm,{children:e(m.Suspense,{fallback:e(ye,{}),children:e(wm,{})})})})]})})}function zm(n){return e("div",{css:C`
        background-color: var(--ac-global-color-grey-75);
        width: 100%;
        height: 100%;
      `,children:n.children})}const Vm=1,$m=Se.memo(function(){const{referenceInferences:a}=We(),t=B(g=>g.clusters),l=B(g=>g.selectedClusterId),i=B(g=>g.metric),r=B(g=>g.setSelectedClusterId),s=B(g=>g.setSelectedEventIds),c=B(g=>g.setHighlightedClusterId),d=B(g=>g.setClusterColorMode),u=a==null||i.type==="drift",y=m.useCallback(g=>{d(g===Vm?Ht.highlight:Ht.default)},[d]);return o($e,{onChange:y,children:[e(X,{name:"Clusters",extra:e(Be,{children:t.length}),children:o(h,{direction:"column",height:"100%",children:[e(F,{borderBottomColor:"dark",borderBottomWidth:"thin",backgroundColor:"dark",flex:"none",padding:"size-50",children:e(h,{direction:"row",justifyContent:"end",children:e(tm,{})})}),e(F,{flex:"1 1 auto",overflow:"auto",children:e("ul",{css:g=>C`
                flex: 1 1 auto;
                display: flex;
                flex-direction: column;
                gap: ${g.spacing.margin8}px;
                margin: ${g.spacing.margin8}px;
              `,children:t.map(g=>e("li",{children:e($d,{clusterId:g.id,numPoints:g.eventIds.length,isSelected:l===g.id,driftRatio:g.driftRatio,primaryToCorpusRatio:g.primaryToCorpusRatio,primaryMetricValue:g.primaryMetricValue,referenceMetricValue:g.referenceMetricValue,metricName:Om(i),hideReference:u,onClick:()=>{l!==g.id?(r(g.id),s(new Set(g.eventIds))):(r(null),s(new Set))},onMouseEnter:()=>{c(g.id)},onMouseLeave:()=>{c(null)}})},g.id))})})]})}),e(X,{name:"Configuration",children:e(F,{overflow:"auto",height:"100%",children:e(Od,{})})})]})});function Om(n){const{type:a,metric:t}=n;switch(a){case"dataQuality":return`${n.dimension.name} avg`;case"drift":{switch(t){case"euclideanDistance":return"Cluster Drift";default:ue()}break}case"performance":return In(t);case"retrieval":{switch(t){case"queryDistance":return"% Query";default:ue()}break}default:ue()}}function Qm(){const{notifyError:n}=wl(),a=B(l=>l.errorMessage),t=B(l=>l.setErrorMessage);return m.useEffect(()=>{a!==null&&n({title:"An error occurred",message:a,action:{text:"Dismiss",onClick:()=>{t(null)}}})},[a,n,t]),null}const Vi=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"embeddingLoaderQuery",selections:[{alias:"embedding",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[t,l],type:"EmbeddingDimension",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"embeddingLoaderQuery",selections:[{alias:"embedding",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},t,{kind:"InlineFragment",selections:[l],type:"EmbeddingDimension",abstractKey:null}],storageKey:null}]},params:{cacheID:"cff0ac130f1ef79784f7bef4161ac60d",id:null,metadata:{},name:"embeddingLoaderQuery",operationKind:"query",text:`query embeddingLoaderQuery(
  $id: GlobalID!
) {
  embedding: node(id: $id) {
    __typename
    ... on EmbeddingDimension {
      id
      name
    }
    __isNode: __typename
    id
  }
}
`}}}();Vi.hash="c049e57d92943f64b5e751e0daa89dc8";async function t1(n){const{embeddingDimensionId:a}=n.params;return P.fetchQuery(Ne,Vi,{id:a}).toPromise()}const $i=function(){var n={defaultValue:null,kind:"LocalArgument",name:"dimensionId"},a={defaultValue:null,kind:"LocalArgument",name:"hasReference"},t={defaultValue:null,kind:"LocalArgument",name:"timeRange"},l=[{kind:"Variable",name:"id",variableName:"dimensionId"}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={kind:"Variable",name:"timeRange",variableName:"timeRange"},s=[r],c=[{kind:"Variable",name:"hasReference",variableName:"hasReference"},r],d={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},u=[{alias:null,args:null,kind:"ScalarField",name:"primaryValue",storageKey:null}],y={kind:"Literal",name:"metric",value:"cardinality"},g={kind:"Literal",name:"metric",value:"percentEmpty"},p={kind:"Literal",name:"inferencesRole",value:"reference"};return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"DimensionPageQuery",selections:[{alias:"dimension",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[i,{args:s,kind:"FragmentSpread",name:"DimensionSegmentsBarChart_dimension"},{args:s,kind:"FragmentSpread",name:"DimensionCountStats_dimension"},{args:s,kind:"FragmentSpread",name:"DimensionDriftStats_dimension"},{args:c,kind:"FragmentSpread",name:"DimensionCardinalityStats_dimension"},{args:c,kind:"FragmentSpread",name:"DimensionPercentEmptyStats_dimension"},{args:s,kind:"FragmentSpread",name:"DimensionQuantilesStats_dimension"}],type:"Dimension",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,t,a],kind:"Operation",name:"DimensionPageQuery",selections:[{alias:"dimension",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[d,{kind:"TypeDiscriminator",abstractKey:"__isNode"},i,{kind:"InlineFragment",selections:[{alias:null,args:[{kind:"Variable",name:"primaryTimeRange",variableName:"timeRange"}],concreteType:"Segments",kind:"LinkedField",name:"segmentsComparison",plural:!1,selections:[{alias:null,args:null,concreteType:"Segment",kind:"LinkedField",name:"segments",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"bin",plural:!1,selections:[d,{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],type:"NominalBin",abstractKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"NumericRange",kind:"LinkedField",name:"range",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"start",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"end",storageKey:null}],storageKey:null}],type:"IntervalBin",abstractKey:null}],storageKey:null},{alias:null,args:null,concreteType:"DatasetValues",kind:"LinkedField",name:"counts",plural:!1,selections:u,storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"DatasetValues",kind:"LinkedField",name:"totalCounts",plural:!1,selections:u,storageKey:null}],storageKey:null},{alias:"count",args:[{kind:"Literal",name:"metric",value:"count"},r],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"psi",args:[{kind:"Literal",name:"metric",value:"psi"},r],kind:"ScalarField",name:"driftMetric",storageKey:null},{alias:"cardinality",args:[y,r],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"percentEmpty",args:[g,r],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"p99",args:[{kind:"Literal",name:"metric",value:"p99"},r],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"p75",args:[{kind:"Literal",name:"metric",value:"p75"},r],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"p50",args:[{kind:"Literal",name:"metric",value:"p50"},r],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"p25",args:[{kind:"Literal",name:"metric",value:"p25"},r],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"p1",args:[{kind:"Literal",name:"metric",value:"p01"},r],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{condition:"hasReference",kind:"Condition",passingValue:!0,selections:[{alias:"referenceCardinality",args:[p,y],kind:"ScalarField",name:"dataQualityMetric",storageKey:'dataQualityMetric(inferencesRole:"reference",metric:"cardinality")'},{alias:"referencePercentEmpty",args:[p,g],kind:"ScalarField",name:"dataQualityMetric",storageKey:'dataQualityMetric(inferencesRole:"reference",metric:"percentEmpty")'}]}],type:"Dimension",abstractKey:null}],storageKey:null}]},params:{cacheID:"2ad937e56d4647309b9d78ac11f57265",id:null,metadata:{},name:"DimensionPageQuery",operationKind:"query",text:`query DimensionPageQuery(
  $dimensionId: GlobalID!
  $timeRange: TimeRange!
  $hasReference: Boolean!
) {
  dimension: node(id: $dimensionId) {
    __typename
    ... on Dimension {
      id
      ...DimensionSegmentsBarChart_dimension_3E0ZE6
      ...DimensionCountStats_dimension_3E0ZE6
      ...DimensionDriftStats_dimension_3E0ZE6
      ...DimensionCardinalityStats_dimension_1JBzL3
      ...DimensionPercentEmptyStats_dimension_1JBzL3
      ...DimensionQuantilesStats_dimension_3E0ZE6
    }
    __isNode: __typename
    id
  }
}

fragment DimensionCardinalityStats_dimension_1JBzL3 on Dimension {
  id
  cardinality: dataQualityMetric(metric: cardinality, timeRange: $timeRange)
  referenceCardinality: dataQualityMetric(metric: cardinality, inferencesRole: reference) @include(if: $hasReference)
}

fragment DimensionCountStats_dimension_3E0ZE6 on Dimension {
  id
  count: dataQualityMetric(metric: count, timeRange: $timeRange)
}

fragment DimensionDriftStats_dimension_3E0ZE6 on Dimension {
  id
  psi: driftMetric(metric: psi, timeRange: $timeRange)
}

fragment DimensionPercentEmptyStats_dimension_1JBzL3 on Dimension {
  id
  percentEmpty: dataQualityMetric(metric: percentEmpty, timeRange: $timeRange)
  referencePercentEmpty: dataQualityMetric(metric: percentEmpty, inferencesRole: reference) @include(if: $hasReference)
}

fragment DimensionQuantilesStats_dimension_3E0ZE6 on Dimension {
  p99: dataQualityMetric(metric: p99, timeRange: $timeRange)
  p75: dataQualityMetric(metric: p75, timeRange: $timeRange)
  p50: dataQualityMetric(metric: p50, timeRange: $timeRange)
  p25: dataQualityMetric(metric: p25, timeRange: $timeRange)
  p1: dataQualityMetric(metric: p01, timeRange: $timeRange)
}

fragment DimensionSegmentsBarChart_dimension_3E0ZE6 on Dimension {
  id
  segmentsComparison(primaryTimeRange: $timeRange) {
    segments {
      bin {
        __typename
        ... on NominalBin {
          __typename
          name
        }
        ... on IntervalBin {
          __typename
          range {
            start
            end
          }
        }
        ... on MissingValueBin {
          __typename
        }
      }
      counts {
        primaryValue
      }
    }
    totalCounts {
      primaryValue
    }
  }
}
`}}}();$i.hash="d194bfd656408e8ba7cb427ddc80fc85";const Oi=function(){var n={kind:"Literal",name:"metric",value:"cardinality"};return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"hasReference"},{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],kind:"Fragment",metadata:null,name:"DimensionCardinalityStats_dimension",selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:"cardinality",args:[n,{kind:"Variable",name:"timeRange",variableName:"timeRange"}],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{condition:"hasReference",kind:"Condition",passingValue:!0,selections:[{alias:"referenceCardinality",args:[{kind:"Literal",name:"inferencesRole",value:"reference"},n],kind:"ScalarField",name:"dataQualityMetric",storageKey:'dataQualityMetric(inferencesRole:"reference",metric:"cardinality")'}]}],type:"Dimension",abstractKey:null}}();Oi.hash="8b4edef350e4df49e799afa70ca34918";function jm(n){const a=P.useFragment(Oi,n.dimension);return o(G,{children:[e(x,{elementType:"h3",textSize:"small",color:"text-700",children:"Cardinality"}),e(x,{textSize:"xlarge",children:Pn(a.cardinality)}),a.referenceCardinality!=null&&e(x,{textSize:"medium",color:"designationPurple",children:Pn(a.referenceCardinality)})]})}const Qi=function(){var n={defaultValue:null,kind:"LocalArgument",name:"dimensionId"},a={defaultValue:null,kind:"LocalArgument",name:"granularity"},t={defaultValue:null,kind:"LocalArgument",name:"timeRange"},l=[{kind:"Variable",name:"id",variableName:"dimensionId"}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={kind:"InlineFragment",selections:[{alias:"cardinalityTimeSeries",args:[{kind:"Variable",name:"granularity",variableName:"granularity"},{kind:"Literal",name:"metric",value:"cardinality"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],concreteType:"DataQualityTimeSeries",kind:"LinkedField",name:"dataQualityTimeSeries",plural:!1,selections:[{alias:null,args:null,concreteType:"TimeSeriesDataPoint",kind:"LinkedField",name:"data",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"timestamp",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"value",storageKey:null}],storageKey:null}],storageKey:null}],type:"Dimension",abstractKey:null};return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"DimensionCardinalityTimeSeriesQuery",selections:[{alias:"dimension",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[i,r],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,t,a],kind:"Operation",name:"DimensionCardinalityTimeSeriesQuery",selections:[{alias:"dimension",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i,r],storageKey:null}]},params:{cacheID:"f53e5ac5e0bfd6a0a6c50b761223a617",id:null,metadata:{},name:"DimensionCardinalityTimeSeriesQuery",operationKind:"query",text:`query DimensionCardinalityTimeSeriesQuery(
  $dimensionId: GlobalID!
  $timeRange: TimeRange!
  $granularity: Granularity!
) {
  dimension: node(id: $dimensionId) {
    __typename
    id
    ... on Dimension {
      cardinalityTimeSeries: dataQualityTimeSeries(metric: cardinality, timeRange: $timeRange, granularity: $granularity) {
        data {
          timestamp
          value
        }
      }
    }
  }
}
`}}}();Qi.hash="88ce04bb2022d5e2bc75c663abd7e5de";const Ta={top:25,right:18,left:18,bottom:5},qm=new Intl.NumberFormat([],{maximumFractionDigits:2}),ji=()=>{const{gray300:n}=dn();return{color:n}};function Um({active:n,payload:a,label:t}){var i;const{color:l}=ji();if(n&&a&&a.length){const r=((i=a[0])==null?void 0:i.value)??null,s=typeof r=="number"?qm.format(r):"--";return o(hn,{children:[e(x,{weight:"heavy",textSize:"medium",children:`${ln(new Date(t))}`}),e(Le,{color:l,name:"Cardinality",value:s}),e(Ua,{})]})}return null}function Bm({dimensionId:n}){var c;const{timeRange:a}=on(),t=Yn(a),l=P.useLazyLoadQuery(Qi,{dimensionId:n,timeRange:{start:a.start.toISOString(),end:a.end.toISOString()},granularity:t}),{color:i}=ji(),r=((c=l.dimension.cardinalityTimeSeries)==null?void 0:c.data.map(d=>({timestamp:new Date(d.timestamp).valueOf(),value:d.value})))||[],s=Xn({samplingIntervalMinutes:t.samplingIntervalMinutes});return e(kn,{width:"100%",height:"100%",children:o(Fa,{data:r,margin:Ta,syncId:"dimensionDetails",children:[e("defs",{children:o("linearGradient",{id:"cardinalityColorUv",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"5%",stopColor:i,stopOpacity:.8}),e("stop",{offset:"95%",stopColor:i,stopOpacity:0})]})}),e(bn,{...ea,tickFormatter:d=>s(new Date(d))}),e(Ge,{stroke:xe.colors.gray200,label:{value:"Cardinality",angle:-90,position:"insideLeft",style:{textAnchor:"middle",fill:"var(--ac-global-text-color-900)"}},style:{fill:"var(--ac-global-text-color-700)"}}),e(Sn,{strokeDasharray:"4 4",stroke:xe.colors.gray200,strokeOpacity:.5}),e(vn,{content:e(Um,{})}),e(ga,{type:"monotone",dataKey:"value",stroke:i,fillOpacity:1,fill:"url(#cardinalityColorUv)"})]})})}const qi={argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],kind:"Fragment",metadata:null,name:"DimensionCountStats_dimension",selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:"count",args:[{kind:"Literal",name:"metric",value:"count"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],kind:"ScalarField",name:"dataQualityMetric",storageKey:null}],type:"Dimension",abstractKey:null};qi.hash="6dccac51f3fb0853276677c692af5a43";function Hm(n){const t=P.useFragment(qi,n.dimension).count??0;return o(G,{children:[e(x,{elementType:"h3",textSize:"small",color:"text-700",children:"Total Count"}),e(x,{textSize:"xlarge",children:Pn(t)})]})}const Ui=function(){var n={defaultValue:null,kind:"LocalArgument",name:"countGranularity"},a={defaultValue:null,kind:"LocalArgument",name:"dimensionId"},t={defaultValue:null,kind:"LocalArgument",name:"timeRange"},l=[{kind:"Variable",name:"id",variableName:"dimensionId"}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={kind:"InlineFragment",selections:[{alias:"trafficTimeSeries",args:[{kind:"Variable",name:"granularity",variableName:"countGranularity"},{kind:"Literal",name:"metric",value:"count"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],concreteType:"DataQualityTimeSeries",kind:"LinkedField",name:"dataQualityTimeSeries",plural:!1,selections:[{alias:null,args:null,concreteType:"TimeSeriesDataPoint",kind:"LinkedField",name:"data",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"timestamp",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"value",storageKey:null}],storageKey:null}],storageKey:null}],type:"Dimension",abstractKey:null};return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"DimensionCountTimeSeriesQuery",selections:[{alias:"embedding",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[i,r],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,t,n],kind:"Operation",name:"DimensionCountTimeSeriesQuery",selections:[{alias:"embedding",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i,r],storageKey:null}]},params:{cacheID:"1f9eff6d8d453148844edae32b844df7",id:null,metadata:{},name:"DimensionCountTimeSeriesQuery",operationKind:"query",text:`query DimensionCountTimeSeriesQuery(
  $dimensionId: GlobalID!
  $timeRange: TimeRange!
  $countGranularity: Granularity!
) {
  embedding: node(id: $dimensionId) {
    __typename
    id
    ... on Dimension {
      trafficTimeSeries: dataQualityTimeSeries(metric: count, timeRange: $timeRange, granularity: $countGranularity) {
        data {
          timestamp
          value
        }
      }
    }
  }
}
`}}}();Ui.hash="9677ef7c6b298554824fe3fd3904c7aa";const Gm=new Intl.NumberFormat([],{maximumFractionDigits:2}),Bi=()=>{const{gray300:n}=dn();return{barColor:n}};function Wm({active:n,payload:a,label:t}){var i;const{barColor:l}=Bi();if(n&&a&&a.length){const r=((i=a[0])==null?void 0:i.value)??null,s=typeof r=="number"?Gm.format(r):"--";return o(hn,{children:[e(x,{weight:"heavy",textSize:"medium",children:`${ln(new Date(t))}`}),e(Le,{color:l,shape:"square",name:"Count",value:s})]})}return null}function Jm({dimensionId:n}){var d;const{timeRange:a}=on(),t=Yn(a),r=(((d=P.useLazyLoadQuery(Ui,{dimensionId:n,timeRange:{start:a.start.toISOString(),end:a.end.toISOString()},countGranularity:t}).embedding.trafficTimeSeries)==null?void 0:d.data)||[]).map(u=>({...u,timestamp:new Date(u.timestamp).valueOf()})),s=Xn({samplingIntervalMinutes:t.samplingIntervalMinutes}),{barColor:c}=Bi();return e(kn,{width:"100%",height:"100%",children:o(Lt,{data:r,margin:Ta,syncId:"dimensionDetails",children:[e("defs",{children:o("linearGradient",{id:"countBarColor",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"5%",stopColor:c,stopOpacity:1}),e("stop",{offset:"95%",stopColor:c,stopOpacity:.5})]})}),e(bn,{...ea,tickFormatter:u=>s(new Date(u))}),e(Ge,{stroke:xe.colors.gray200,label:{value:"Count",angle:-90,position:"insideLeft",style:{textAnchor:"middle",fill:"var(--ac-global-text-color-900)"}},style:{fill:"var(--ac-global-text-color-700)"}}),e(Sn,{strokeDasharray:"4 4",stroke:xe.colors.gray200,strokeOpacity:.5}),e(vn,{...xt,content:e(Wm,{})}),e(qn,{dataKey:"value",fill:"url(#countBarColor)",spacing:5})]})})}const Hi=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"dimensionId"},{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],a=[{kind:"Variable",name:"id",variableName:"dimensionId"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l=[{kind:"Variable",name:"primaryTimeRange",variableName:"timeRange"}],i={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},s={alias:null,args:null,concreteType:"NumericRange",kind:"LinkedField",name:"range",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"start",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"end",storageKey:null}],storageKey:null},c=[{alias:null,args:null,kind:"ScalarField",name:"primaryValue",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"referenceValue",storageKey:null}],d={alias:null,args:null,concreteType:"DatasetValues",kind:"LinkedField",name:"counts",plural:!1,selections:c,storageKey:null},u={alias:null,args:null,concreteType:"DatasetValues",kind:"LinkedField",name:"totalCounts",plural:!1,selections:c,storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"DimensionDriftBreakdownSegmentBarChartQuery",selections:[{alias:"dimension",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"InlineFragment",selections:[{kind:"RequiredField",field:{alias:null,args:l,concreteType:"Segments",kind:"LinkedField",name:"segmentsComparison",plural:!1,selections:[{alias:null,args:null,concreteType:"Segment",kind:"LinkedField",name:"segments",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"bin",plural:!1,selections:[{kind:"InlineFragment",selections:[i,r],type:"NominalBin",abstractKey:null},{kind:"InlineFragment",selections:[i,s],type:"IntervalBin",abstractKey:null},{kind:"InlineFragment",selections:[i],type:"MissingValueBin",abstractKey:null}],storageKey:null},d],storageKey:null},u],storageKey:null},action:"THROW",path:"dimension.segmentsComparison"}],type:"Dimension",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"DimensionDriftBreakdownSegmentBarChartQuery",selections:[{alias:"dimension",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[i,t,{kind:"InlineFragment",selections:[{alias:null,args:l,concreteType:"Segments",kind:"LinkedField",name:"segmentsComparison",plural:!1,selections:[{alias:null,args:null,concreteType:"Segment",kind:"LinkedField",name:"segments",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"bin",plural:!1,selections:[i,{kind:"InlineFragment",selections:[r],type:"NominalBin",abstractKey:null},{kind:"InlineFragment",selections:[s],type:"IntervalBin",abstractKey:null}],storageKey:null},d],storageKey:null},u],storageKey:null}],type:"Dimension",abstractKey:null}],storageKey:null}]},params:{cacheID:"7d11d88f419003f5ee8cd9d11312e427",id:null,metadata:{},name:"DimensionDriftBreakdownSegmentBarChartQuery",operationKind:"query",text:`query DimensionDriftBreakdownSegmentBarChartQuery(
  $dimensionId: GlobalID!
  $timeRange: TimeRange!
) {
  dimension: node(id: $dimensionId) {
    __typename
    id
    ... on Dimension {
      segmentsComparison(primaryTimeRange: $timeRange) {
        segments {
          bin {
            __typename
            ... on NominalBin {
              __typename
              name
            }
            ... on IntervalBin {
              __typename
              range {
                start
                end
              }
            }
            ... on MissingValueBin {
              __typename
            }
          }
          counts {
            primaryValue
            referenceValue
          }
        }
        totalCounts {
          primaryValue
          referenceValue
        }
      }
    }
  }
}
`}}}();Hi.hash="6bb76e3cce4ee28c333e485b3aa2dffd";const nl=ft(".2f"),Gi=()=>{const{primary:n,reference:a}=dn();return{primaryBarColor:n,referenceBarColor:a}};function Zm({active:n,payload:a,label:t}){var r,s,c,d,u,y;const{primaryBarColor:l,referenceBarColor:i}=Gi();if(n&&a&&a.length){const g=(s=(r=a[0])==null?void 0:r.payload)==null?void 0:s.primaryName,p=(c=a[0])==null?void 0:c.value,f=(u=(d=a[0])==null?void 0:d.payload)==null?void 0:u.referenceName,k=(y=a[1])==null?void 0:y.value;return o(hn,{children:[e(x,{elementType:"h3",textSize:"medium",weight:"heavy",children:t}),e(Le,{color:l,shape:"square",name:g,value:p!=null?`${nl(p)}%`:"--"}),e(Le,{color:i,shape:"square",name:f,value:k!=null?`${nl(k)}%`:"--"})]})}return null}function Ym(n){var p,f,k,b,S;const{primaryInferences:a,referenceInferences:t}=We(),l=a.name,i=(t==null?void 0:t.name)||"reference",{selectedTimestamp:r}=qa(),s=m.useMemo(()=>r??new Date(a.endTime),[r,a.endTime]),c=m.useMemo(()=>({start:bl(s,2).toISOString(),end:s.toISOString()}),[s]),d=P.useLazyLoadQuery(Hi,{dimensionId:n.dimensionId,timeRange:c}),u=m.useMemo(()=>{var R,K,T,E,_;const v=((R=d.dimension.segmentsComparison)==null?void 0:R.segments)??[],I=((T=(K=d.dimension.segmentsComparison)==null?void 0:K.totalCounts)==null?void 0:T.primaryValue)??0,w=((_=(E=d.dimension.segmentsComparison)==null?void 0:E.totalCounts)==null?void 0:_.referenceValue)??0;return v.map(j=>{var Q,M;const V=((Q=j.counts)==null?void 0:Q.primaryValue)??0,H=((M=j.counts)==null?void 0:M.referenceValue)??0,te=zl(j.bin),oe=V/I*100,N=H/w*100;return{name:te,primaryName:l,referenceName:i,primaryPercent:oe,referencePercent:N}})},[(p=d.dimension.segmentsComparison)==null?void 0:p.segments,(k=(f=d.dimension.segmentsComparison)==null?void 0:f.totalCounts)==null?void 0:k.primaryValue,(S=(b=d.dimension.segmentsComparison)==null?void 0:b.totalCounts)==null?void 0:S.referenceValue,l,i]),{primaryBarColor:y,referenceBarColor:g}=Gi();return o(h,{direction:"column",height:"100%",children:[e(F,{flex:"none",paddingTop:"size-100",paddingStart:"size-200",children:e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:`Distribution comparison at ${ln(new Date(c.end))}`})}),e(F,{flex:!0,children:e(kn,{children:o(Lt,{data:u,margin:{top:15,right:18,left:18,bottom:5},children:[o("defs",{children:[o("linearGradient",{id:"dimensionPrimarySegmentsBarColor",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"5%",stopColor:y,stopOpacity:1}),e("stop",{offset:"95%",stopColor:y,stopOpacity:.5})]}),o("linearGradient",{id:"dimensionReferenceSegmentsBarColor",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"5%",stopColor:g,stopOpacity:1}),e("stop",{offset:"95%",stopColor:g,stopOpacity:.5})]})]}),e(bn,{dataKey:"name",style:{fill:"var(--ac-global-text-color-700)"}}),e(Ge,{stroke:xe.colors.gray200,label:{value:"Percent",angle:-90,position:"insideLeft",style:{textAnchor:"middle",fill:"var(--ac-global-text-color-900)"}},style:{fill:"var(--ac-global-text-color-700)"}}),e(Sn,{strokeDasharray:"4 4",stroke:xe.colors.gray200,strokeOpacity:.5}),e(vn,{...xt,content:e(Zm,{})}),e(qn,{dataKey:"primaryPercent",fill:"url(#dimensionPrimarySegmentsBarColor)"}),e(qn,{dataKey:"referencePercent",fill:"url(#dimensionReferenceSegmentsBarColor)"})]})})})]})}const Wi={argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],kind:"Fragment",metadata:null,name:"DimensionDriftStats_dimension",selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:"psi",args:[{kind:"Literal",name:"metric",value:"psi"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],kind:"ScalarField",name:"driftMetric",storageKey:null}],type:"Dimension",abstractKey:null};Wi.hash="f8a9fb08a14f63906e38bc247d50b189";const Xm=o(Hn,{variant:"info",placement:"top end",children:[e(ge,{weight:"heavy",level:4,children:"Population Stability Index"}),e(An,{children:e(x,{children:"PSI is a symmetric metric that measures the relative entropy, or difference in information represented by two distributions. It can be thought of as measuring the distance between two data distributions showing how different the two distributions are from each other."})}),e("footer",{children:e(rn,{href:"https://arize.com/blog-course/population-stability-index-psi/#:~:text=Population%20Stability%20Index%20(PSI)%20Overview,distributions%20are%20from%20each%20other.",children:"Learn more"})})]});function eg(n){const a=P.useFragment(Wi,n.dimension);return o(G,{children:[o(h,{direction:"row",alignItems:"center",gap:"size-25",children:[e(x,{elementType:"h3",textSize:"small",color:"text-700",children:"PSI"}),Xm]}),e(x,{textSize:"xlarge",children:Qn(a.psi)})]})}const Ji=function(){var n={defaultValue:null,kind:"LocalArgument",name:"countGranularity"},a={defaultValue:null,kind:"LocalArgument",name:"dimensionId"},t={defaultValue:null,kind:"LocalArgument",name:"driftGranularity"},l={defaultValue:null,kind:"LocalArgument",name:"timeRange"},i=[{kind:"Variable",name:"id",variableName:"dimensionId"}],r={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},s={kind:"Variable",name:"timeRange",variableName:"timeRange"},c=[{alias:null,args:null,concreteType:"TimeSeriesDataPoint",kind:"LinkedField",name:"data",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"timestamp",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"value",storageKey:null}],storageKey:null}],d={kind:"InlineFragment",selections:[{alias:null,args:[{kind:"Variable",name:"granularity",variableName:"driftGranularity"},{kind:"Literal",name:"metric",value:"psi"},s],concreteType:"DriftTimeSeries",kind:"LinkedField",name:"driftTimeSeries",plural:!1,selections:c,storageKey:null},{alias:"trafficTimeSeries",args:[{kind:"Variable",name:"granularity",variableName:"countGranularity"},{kind:"Literal",name:"metric",value:"count"},s],concreteType:"DataQualityTimeSeries",kind:"LinkedField",name:"dataQualityTimeSeries",plural:!1,selections:c,storageKey:null}],type:"Dimension",abstractKey:null};return{fragment:{argumentDefinitions:[n,a,t,l],kind:"Fragment",metadata:null,name:"DimensionDriftTimeSeriesQuery",selections:[{alias:"embedding",args:i,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[r,d],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,l,t,n],kind:"Operation",name:"DimensionDriftTimeSeriesQuery",selections:[{alias:"embedding",args:i,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},r,d],storageKey:null}]},params:{cacheID:"af2d25e28675891b3c8a6bc75027f731",id:null,metadata:{},name:"DimensionDriftTimeSeriesQuery",operationKind:"query",text:`query DimensionDriftTimeSeriesQuery(
  $dimensionId: GlobalID!
  $timeRange: TimeRange!
  $driftGranularity: Granularity!
  $countGranularity: Granularity!
) {
  embedding: node(id: $dimensionId) {
    __typename
    id
    ... on Dimension {
      driftTimeSeries(metric: psi, timeRange: $timeRange, granularity: $driftGranularity) {
        data {
          timestamp
          value
        }
      }
      trafficTimeSeries: dataQualityTimeSeries(metric: count, timeRange: $timeRange, granularity: $countGranularity) {
        data {
          timestamp
          value
        }
      }
    }
  }
}
`}}}();Ji.hash="6312b58dbb252b17efdf08d44dd58630";const Zi=()=>{const{orange300:n,gray300:a}=dn();return{color:n,barColor:a}};function ng({active:n,payload:a,label:t}){var i;const{color:l}=Zi();if(n&&a&&a.length){const r=((i=a[1])==null?void 0:i.value)??null;return o(hn,{children:[e(x,{weight:"heavy",textSize:"medium",children:`${ln(new Date(t))}`}),e(Le,{color:l,name:"PSI",value:Qn(r)}),e(Ua,{}),o("div",{css:C`
            display: flex;
            flex-direction: row;
            align-items: center;
            color: var(--ac-global-color-primary);
            gap: var(--ac-global-dimension-static-size-50);

            margin-top: var(--ac-global-dimension-static-size-50);
          `,children:[e(L,{svg:e(vl,{})}),e("span",{children:"Click to view details"})]})]})}return null}function ag({dimensionId:n}){var f,k;const{timeRange:a}=on(),{selectedTimestamp:t,setSelectedTimestamp:l}=qa(),i=Yn(a),r=P.useLazyLoadQuery(Ji,{dimensionId:n,timeRange:{start:a.start.toISOString(),end:a.end.toISOString()},driftGranularity:_l(a),countGranularity:i}),s=((f=r.embedding.driftTimeSeries)==null?void 0:f.data)||[],c=((k=r.embedding.trafficTimeSeries)==null?void 0:k.data.reduce((b,S)=>(b[S.timestamp]=S.value,b),{}))??{},d=s.map(b=>{const S=c[b.timestamp];return{...b,traffic:S,timestamp:new Date(b.timestamp).valueOf()}}),u=Xn({samplingIntervalMinutes:i.samplingIntervalMinutes}),y=m.useCallback(b=>{const{activePayload:S}=b;if(S!=null&&S.length>0){const v=S[0].payload;l(new Date(v.timestamp))}},[l]),{color:g,barColor:p}=Zi();return e(kn,{width:"100%",height:"100%",children:o(Fa,{data:d,margin:Ta,onClick:y,syncId:"dimensionDetails",children:[o("defs",{children:[o("linearGradient",{id:"dimensionDriftColorUv",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"5%",stopColor:g,stopOpacity:.8}),e("stop",{offset:"95%",stopColor:g,stopOpacity:0})]}),o("linearGradient",{id:"barColor",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"5%",stopColor:p,stopOpacity:.8}),e("stop",{offset:"95%",stopColor:p,stopOpacity:0})]})]}),e(bn,{...ea,tickFormatter:b=>u(new Date(b))}),e(Ge,{stroke:xe.colors.gray200,label:{value:"PSI",angle:-90,position:"insideLeft",style:{textAnchor:"middle",fill:"var(--ac-global-text-color-900)"}},style:{fill:"var(--ac-global-text-color-700)"}}),e(Ge,{yAxisId:"right",orientation:"right",tick:!1,tickLine:!1,width:0}),e(Sn,{strokeDasharray:"4 4",stroke:xe.colors.gray200,strokeOpacity:.5}),e(vn,{content:e(ng,{})}),e(qn,{yAxisId:"right",dataKey:"traffic",fill:"url(#barColor)",spacing:5}),e(ga,{type:"monotone",dataKey:"value",stroke:g,fillOpacity:1,fill:"url(#dimensionDriftColorUv)"}),t!=null?e(ri,{...Rl,x:t.getTime()}):null]})})}const Yi=function(){var n={kind:"Literal",name:"metric",value:"percentEmpty"};return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"hasReference"},{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],kind:"Fragment",metadata:null,name:"DimensionPercentEmptyStats_dimension",selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:"percentEmpty",args:[n,{kind:"Variable",name:"timeRange",variableName:"timeRange"}],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{condition:"hasReference",kind:"Condition",passingValue:!0,selections:[{alias:"referencePercentEmpty",args:[{kind:"Literal",name:"inferencesRole",value:"reference"},n],kind:"ScalarField",name:"dataQualityMetric",storageKey:'dataQualityMetric(inferencesRole:"reference",metric:"percentEmpty")'}]}],type:"Dimension",abstractKey:null}}();Yi.hash="1e10d0449d6607d9292f355548c41c78";function tg(n){const a=P.useFragment(Yi,n.dimension);return o(G,{children:[e(x,{elementType:"h3",textSize:"small",color:"text-700",children:"% Empty"}),e(x,{textSize:"xlarge",children:mt(a.percentEmpty)}),a.referencePercentEmpty!=null&&e(x,{textSize:"medium",color:"designationPurple",children:mt(a.referencePercentEmpty)})]})}const Xi=function(){var n={defaultValue:null,kind:"LocalArgument",name:"dimensionId"},a={defaultValue:null,kind:"LocalArgument",name:"granularity"},t={defaultValue:null,kind:"LocalArgument",name:"timeRange"},l=[{kind:"Variable",name:"id",variableName:"dimensionId"}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={kind:"InlineFragment",selections:[{alias:"percentEmptyTimeSeries",args:[{kind:"Variable",name:"granularity",variableName:"granularity"},{kind:"Literal",name:"metric",value:"percentEmpty"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],concreteType:"DataQualityTimeSeries",kind:"LinkedField",name:"dataQualityTimeSeries",plural:!1,selections:[{alias:null,args:null,concreteType:"TimeSeriesDataPoint",kind:"LinkedField",name:"data",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"timestamp",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"value",storageKey:null}],storageKey:null}],storageKey:null}],type:"Dimension",abstractKey:null};return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"DimensionPercentEmptyTimeSeriesQuery",selections:[{alias:"embedding",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[i,r],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,t,a],kind:"Operation",name:"DimensionPercentEmptyTimeSeriesQuery",selections:[{alias:"embedding",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i,r],storageKey:null}]},params:{cacheID:"9be05c72f19755036f4829777a96f97d",id:null,metadata:{},name:"DimensionPercentEmptyTimeSeriesQuery",operationKind:"query",text:`query DimensionPercentEmptyTimeSeriesQuery(
  $dimensionId: GlobalID!
  $timeRange: TimeRange!
  $granularity: Granularity!
) {
  embedding: node(id: $dimensionId) {
    __typename
    id
    ... on Dimension {
      percentEmptyTimeSeries: dataQualityTimeSeries(metric: percentEmpty, timeRange: $timeRange, granularity: $granularity) {
        data {
          timestamp
          value
        }
      }
    }
  }
}
`}}}();Xi.hash="1e843d6c8dbe05b389b24188c6bdb394";const lg=new Intl.NumberFormat([],{maximumFractionDigits:2}),er=()=>{const{gray100:n}=dn();return{color:n}};function ig({active:n,payload:a,label:t}){var i;const{color:l}=er();if(n&&a&&a.length){const r=((i=a[0])==null?void 0:i.value)??null,s=typeof r=="number"?lg.format(r):"--";return o(hn,{children:[e(x,{weight:"heavy",textSize:"medium",children:`${ln(new Date(t))}`}),e(Le,{color:l,name:"% Empty",value:s})]})}return null}function rg({dimensionId:n}){var c;const{timeRange:a}=on(),t=Yn(a),i=((c=P.useLazyLoadQuery(Xi,{dimensionId:n,timeRange:{start:a.start.toISOString(),end:a.end.toISOString()},granularity:t}).embedding.percentEmptyTimeSeries)==null?void 0:c.data.map(d=>({timestamp:new Date(d.timestamp).valueOf(),value:d.value})))||[],r=Xn({samplingIntervalMinutes:t.samplingIntervalMinutes}),{color:s}=er();return e(kn,{width:"100%",height:"100%",children:o(Fa,{data:i,margin:Ta,syncId:"dimensionDetails",children:[e("defs",{children:o("linearGradient",{id:"percentEmptyColorUv",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"5%",stopColor:s,stopOpacity:.8}),e("stop",{offset:"95%",stopColor:s,stopOpacity:0})]})}),e(bn,{...ea,tickFormatter:d=>r(new Date(d))}),e(Ge,{stroke:xe.colors.gray200,label:{value:"% Empty",angle:-90,position:"insideLeft",style:{textAnchor:"middle",fill:"var(--ac-global-text-color-900)"}},style:{fill:"var(--ac-global-text-color-700)"}}),e(Sn,{strokeDasharray:"4 4",stroke:xe.colors.gray200,strokeOpacity:.5}),e(vn,{content:e(ig,{})}),e(si,{type:"monotone",dataKey:"value",stroke:s,fillOpacity:1,fill:"url(#percentEmptyColorUv)"})]})})}const nr=function(){var n={kind:"Variable",name:"timeRange",variableName:"timeRange"};return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],kind:"Fragment",metadata:null,name:"DimensionQuantilesStats_dimension",selections:[{alias:"p99",args:[{kind:"Literal",name:"metric",value:"p99"},n],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"p75",args:[{kind:"Literal",name:"metric",value:"p75"},n],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"p50",args:[{kind:"Literal",name:"metric",value:"p50"},n],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"p25",args:[{kind:"Literal",name:"metric",value:"p25"},n],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"p1",args:[{kind:"Literal",name:"metric",value:"p01"},n],kind:"ScalarField",name:"dataQualityMetric",storageKey:null}],type:"Dimension",abstractKey:null}}();nr.hash="c306c8eafb1d34be464d3a658d5f94a7";function sg(n){const a=P.useFragment(nr,n.dimension);return e("ul",{css:C`
        display: flex;
        flex-direction: column;
        gap: var(--ac-global-dimension-static-size-50);
      `,children:Object.keys(a).map(t=>{const l=a[t];return o("li",{css:C`
              display: flex;
              flex-direction: column;
              align-items: flex-end;
            `,children:[e(x,{elementType:"h3",textSize:"xsmall",color:"text-700",children:t}),e(x,{textSize:"medium","data-raw":l,children:Kt(l)})]},t)})})}const ar=function(){var n={defaultValue:null,kind:"LocalArgument",name:"dimensionId"},a={defaultValue:null,kind:"LocalArgument",name:"granularity"},t={defaultValue:null,kind:"LocalArgument",name:"timeRange"},l=[{kind:"Variable",name:"id",variableName:"dimensionId"}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={kind:"Variable",name:"granularity",variableName:"granularity"},s={kind:"Variable",name:"timeRange",variableName:"timeRange"},c=[{alias:null,args:null,concreteType:"TimeSeriesDataPoint",kind:"LinkedField",name:"data",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"timestamp",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"value",storageKey:null}],storageKey:null}],d={kind:"InlineFragment",selections:[{alias:"p99TimeSeries",args:[r,{kind:"Literal",name:"metric",value:"p99"},s],concreteType:"DataQualityTimeSeries",kind:"LinkedField",name:"dataQualityTimeSeries",plural:!1,selections:c,storageKey:null},{alias:"p75TimeSeries",args:[r,{kind:"Literal",name:"metric",value:"p75"},s],concreteType:"DataQualityTimeSeries",kind:"LinkedField",name:"dataQualityTimeSeries",plural:!1,selections:c,storageKey:null},{alias:"p50TimeSeries",args:[r,{kind:"Literal",name:"metric",value:"p50"},s],concreteType:"DataQualityTimeSeries",kind:"LinkedField",name:"dataQualityTimeSeries",plural:!1,selections:c,storageKey:null},{alias:"p25TimeSeries",args:[r,{kind:"Literal",name:"metric",value:"p25"},s],concreteType:"DataQualityTimeSeries",kind:"LinkedField",name:"dataQualityTimeSeries",plural:!1,selections:c,storageKey:null},{alias:"p01TimeSeries",args:[r,{kind:"Literal",name:"metric",value:"p01"},s],concreteType:"DataQualityTimeSeries",kind:"LinkedField",name:"dataQualityTimeSeries",plural:!1,selections:c,storageKey:null}],type:"Dimension",abstractKey:null};return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"DimensionQuantilesTimeSeriesQuery",selections:[{alias:"dimension",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[i,d],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,t,a],kind:"Operation",name:"DimensionQuantilesTimeSeriesQuery",selections:[{alias:"dimension",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i,d],storageKey:null}]},params:{cacheID:"0bb3d9faf9d7f0c2e27995120ae24e1c",id:null,metadata:{},name:"DimensionQuantilesTimeSeriesQuery",operationKind:"query",text:`query DimensionQuantilesTimeSeriesQuery(
  $dimensionId: GlobalID!
  $timeRange: TimeRange!
  $granularity: Granularity!
) {
  dimension: node(id: $dimensionId) {
    __typename
    id
    ... on Dimension {
      p99TimeSeries: dataQualityTimeSeries(metric: p99, timeRange: $timeRange, granularity: $granularity) {
        data {
          timestamp
          value
        }
      }
      p75TimeSeries: dataQualityTimeSeries(metric: p75, timeRange: $timeRange, granularity: $granularity) {
        data {
          timestamp
          value
        }
      }
      p50TimeSeries: dataQualityTimeSeries(metric: p50, timeRange: $timeRange, granularity: $granularity) {
        data {
          timestamp
          value
        }
      }
      p25TimeSeries: dataQualityTimeSeries(metric: p25, timeRange: $timeRange, granularity: $granularity) {
        data {
          timestamp
          value
        }
      }
      p01TimeSeries: dataQualityTimeSeries(metric: p01, timeRange: $timeRange, granularity: $granularity) {
        data {
          timestamp
          value
        }
      }
    }
  }
}
`}}}();ar.hash="134f0dad0e0ecc7863dfbb0f437d829b";const og=ft("~s");var tr=(n=>(n.p99_p01="p99_p01",n.p75_p25="p75_p25",n.p50="p50",n))(tr||{});const dg=new Intl.NumberFormat([],{maximumFractionDigits:2});function ra(n){return typeof n=="number"?dg.format(n):"--"}const lr=()=>{const n=dn();return{outerColor:n.gray500,innerColor:n.gray300,lineColor:n.default}};function cg({active:n,payload:a,label:t}){const{outerColor:l,innerColor:i,lineColor:r}=lr();if(n&&a&&a.length){const s=a[0].payload;return o(hn,{children:[e(x,{weight:"heavy",textSize:"medium",children:`${ln(new Date(t))}`}),e(Le,{color:l,name:"p99",value:ra(s.p99_p01[0])}),e(Le,{color:i,name:"p75",value:ra(s.p75_p25[0])}),e(Le,{color:r,name:"p50",value:ra(s.p50)}),e(Le,{color:i,name:"p25",value:ra(s.p75_p25[1])}),e(Le,{color:l,name:"p01",value:ra(s.p99_p01[1])})]})}return null}function ug({dimensionId:n}){var w,R,K,T,E;const{timeRange:a}=on(),t=Yn(a),l=P.useLazyLoadQuery(ar,{dimensionId:n,timeRange:{start:a.start.toISOString(),end:a.end.toISOString()},granularity:t}),i=((w=l.dimension.p99TimeSeries)==null?void 0:w.data.map(_=>_))||[],r=((R=l.dimension.p01TimeSeries)==null?void 0:R.data.map(_=>_))||[],s=((K=l.dimension.p75TimeSeries)==null?void 0:K.data.map(_=>_))||[],c=((T=l.dimension.p25TimeSeries)==null?void 0:T.data.map(_=>_))||[],d=((E=l.dimension.p50TimeSeries)==null?void 0:E.data.map(_=>_))||[],u=i.map((_,j)=>({timestamp:new Date(_.timestamp).valueOf(),p99_p01:[_.value,r[j].value],p75_p25:[s[j].value,c[j].value],p50:d[j].value})),y=Xn({samplingIntervalMinutes:t.samplingIntervalMinutes}),[g,p]=m.useState(Object.keys(tr).reduce((_,j)=>(_[j]=!1,_),{})),f=_=>{g[_.dataKey]||p({...g})},k=()=>{p({...g})},b=_=>{p({...g,[String(_.dataKey)]:!g[_.dataKey]})},{outerColor:S,innerColor:v,lineColor:I}=lr();return e(kn,{width:"100%",height:"100%",children:o(Fa,{data:u,margin:Ta,syncId:"dimensionDetails",children:[o("defs",{children:[o("linearGradient",{id:"p99_p01ColorUV",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"10%",stopColor:S,stopOpacity:.7}),e("stop",{offset:"50%",stopColor:S,stopOpacity:.3}),e("stop",{offset:"90%",stopColor:S,stopOpacity:.7})]}),o("linearGradient",{id:"p75_p25ColorUV",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"10%",stopColor:v,stopOpacity:.7}),e("stop",{offset:"50%",stopColor:v,stopOpacity:.3}),e("stop",{offset:"90%",stopColor:v,stopOpacity:.7})]})]}),e(bn,{...ea,tickFormatter:_=>y(new Date(_))}),e(Ge,{stroke:xe.colors.gray200,label:{value:"Value",angle:-90,position:"insideLeft",style:{textAnchor:"middle",fill:"var(--ac-global-text-color-900)"}},tickFormatter:_=>og(_),style:{fill:"var(--ac-global-text-color-700)"}}),e(Sn,{strokeDasharray:"4 4",stroke:xe.colors.gray200,strokeOpacity:.5}),e(vn,{content:e(cg,{})}),e(Rc,{onClick:b,onMouseOver:f,onMouseOut:k}),e(ga,{type:"monotone",dataKey:"p99_p01",name:"p99 - p01",fillOpacity:1,fill:"url(#p99_p01ColorUV)",stroke:S,hide:g.p99_p01===!0}),e(ga,{type:"monotone",dataKey:"p75_p25",name:"p75 - p25",fillOpacity:1,stroke:v,fill:"url(#p75_p25ColorUV)",hide:g.p75_p25===!0}),e(si,{type:"monotone",dataKey:"p50",stroke:I,hide:g.p50===!0})]})})}const ir=function(){var n={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},a=[{alias:null,args:null,kind:"ScalarField",name:"primaryValue",storageKey:null}];return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],kind:"Fragment",metadata:null,name:"DimensionSegmentsBarChart_dimension",selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:[{kind:"Variable",name:"primaryTimeRange",variableName:"timeRange"}],concreteType:"Segments",kind:"LinkedField",name:"segmentsComparison",plural:!1,selections:[{alias:null,args:null,concreteType:"Segment",kind:"LinkedField",name:"segments",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"bin",plural:!1,selections:[{kind:"InlineFragment",selections:[n,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],type:"NominalBin",abstractKey:null},{kind:"InlineFragment",selections:[n,{alias:null,args:null,concreteType:"NumericRange",kind:"LinkedField",name:"range",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"start",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"end",storageKey:null}],storageKey:null}],type:"IntervalBin",abstractKey:null},{kind:"InlineFragment",selections:[n],type:"MissingValueBin",abstractKey:null}],storageKey:null},{alias:null,args:null,concreteType:"DatasetValues",kind:"LinkedField",name:"counts",plural:!1,selections:a,storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"DatasetValues",kind:"LinkedField",name:"totalCounts",plural:!1,selections:a,storageKey:null}],storageKey:null}],type:"Dimension",abstractKey:null}}();ir.hash="8cef9841e9a5bd7d0d50acb5db9028b0";const mg=ft(".2f"),rr=()=>{const{primary:n}=dn();return{color:n}};function gg({active:n,payload:a,label:t}){var i;const{color:l}=rr();if(n&&a&&a.length){const r=(i=a[0])==null?void 0:i.value;return e(hn,{children:e(Le,{color:l,shape:"square",name:t,value:r!=null?`${mg(r)}%`:"--"})})}return null}function pg(n){const a=P.useFragment(ir,n.dimension),t=m.useMemo(()=>{var s,c,d;const i=((s=a.segmentsComparison)==null?void 0:s.segments)??[],r=((d=(c=a.segmentsComparison)==null?void 0:c.totalCounts)==null?void 0:d.primaryValue)??0;return i.map(u=>{var f;const y=((f=u.counts)==null?void 0:f.primaryValue)??0,g=zl(u.bin),p=y/r*100;return{name:g,percent:p}})},[a]),{color:l}=rr();return e(kn,{children:o(Lt,{data:t,margin:{top:25,right:18,left:18,bottom:5},children:[e("defs",{children:o("linearGradient",{id:"dimensionSegmentsBarColor",x1:"0",y1:"0",x2:"0",y2:"1",children:[e("stop",{offset:"5%",stopColor:l,stopOpacity:1}),e("stop",{offset:"95%",stopColor:l,stopOpacity:.5})]})}),e(bn,{dataKey:"name",style:{fill:"var(--ac-global-text-color-700)"}}),e(Ge,{stroke:xe.colors.gray200,label:{value:"% Volume",angle:-90,position:"insideLeft",style:{textAnchor:"middle",fill:"var(--ac-global-text-color-900)"}},style:{fill:"var(--ac-global-text-color-700)"}}),e(Sn,{strokeDasharray:"4 4",stroke:xe.colors.gray200,strokeOpacity:.5}),e(vn,{...xt,content:e(gg,{})}),e(qn,{dataKey:"percent",fill:"url(#dimensionSegmentsBarColor)",spacing:15})]})})}function l1(){const{dimensionId:n}=Ue(),{timeRange:a}=on(),t=_n(),{referenceInferences:l}=We(),i=l!==null,r=i,s=t.dimension.shape!=="continuous",c=t.dimension.dataType==="numeric",d=ne(),u=P.useLazyLoadQuery($i,{dimensionId:n,timeRange:{start:a.start.toISOString(),end:a.end.toISOString()},hasReference:i});if(!n)throw new Error("Dimension ID is required to display a dimension");return e(Nl,{initialTimestamp:new Date(a.end),children:e(ae,{type:"slideOver",isDismissable:!0,onDismiss:()=>d(-1),children:e(Y,{size:"L",title:t.dimension.name,children:e("main",{css:C`
              padding: var(--ac-global-dimension-static-size-100);
              display: flex;
              flex-direction: column;
              min-height: 400px;
              overflow-y: auto;
              height: 100%;
            `,children:e(m.Suspense,{fallback:e(ye,{}),children:o(h,{direction:"column",gap:"size-100",children:[e(F,{borderColor:"dark",borderRadius:"medium",borderWidth:"thin",height:"size-1600",children:e(pg,{dimension:u.dimension})}),e(F,{borderColor:"dark",borderRadius:"medium",borderWidth:"thin",height:"size-1600","data-testid":"dimension-count-time-series-view",children:o(h,{direction:"row",alignItems:"stretch",height:"100%",children:[e(Jm,{dimensionId:n}),e(xn,{children:e(Hm,{dimension:u.dimension})})]})}),r?e(F,{borderColor:"dark",borderRadius:"medium",borderWidth:"thin",children:o(h,{direction:"column",alignItems:"stretch",children:[e(F,{width:"100%",height:"size-1600",children:o(h,{direction:"row",alignItems:"stretch",height:"100%",children:[e(F,{flex:!0,children:e(ag,{dimensionId:n})}),e(xn,{children:e(eg,{dimension:u.dimension})})]})}),e(F,{height:"size-1600",width:"100%",borderTopColor:"dark",borderTopWidth:"thin",children:e(m.Suspense,{fallback:e(ye,{}),children:e(Ym,{dimensionId:n})})})]})}):null,c?e(F,{borderColor:"dark",borderRadius:"medium",borderWidth:"thin",height:"size-3000",children:o(h,{direction:"row",alignItems:"stretch",height:"100%",children:[e(F,{flex:!0,children:e(ug,{dimensionId:n})}),e(xn,{children:e(sg,{dimension:u.dimension})})]})}):null,s?e(F,{borderColor:"dark",borderRadius:"medium",borderWidth:"thin",height:"size-1600",children:o(h,{direction:"row",alignItems:"stretch",height:"100%",children:[e(F,{flex:!0,children:e(Bm,{dimensionId:n})}),e(xn,{children:e(jm,{dimension:u.dimension})})]})}):null,e(F,{borderColor:"dark",borderRadius:"medium",borderWidth:"thin",height:"size-1600",children:o(h,{direction:"row",alignItems:"stretch",height:"100%",children:[e(rg,{dimensionId:n}),e(xn,{children:e(tg,{dimension:u.dimension})})]})})]})})})})})})}const sr=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"dataType",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"shape",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"dimensionLoaderQuery",selections:[{alias:"dimension",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[t,l,i,r],type:"Dimension",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"dimensionLoaderQuery",selections:[{alias:"dimension",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},t,{kind:"InlineFragment",selections:[l,i,r],type:"Dimension",abstractKey:null}],storageKey:null}]},params:{cacheID:"03a9aafe3f08a9d093b029ff4a9e3253",id:null,metadata:{},name:"dimensionLoaderQuery",operationKind:"query",text:`query dimensionLoaderQuery(
  $id: GlobalID!
) {
  dimension: node(id: $id) {
    __typename
    ... on Dimension {
      id
      name
      dataType
      shape
    }
    __isNode: __typename
    id
  }
}
`}}}();sr.hash="5a662d77e69d2e9bb4eb2af4cad6b722";async function i1(n){const{dimensionId:a}=n.params;return P.fetchQuery(Ne,sr,{id:a}).toPromise()}const or=function(){var n={defaultValue:null,kind:"LocalArgument",name:"id"},a={defaultValue:null,kind:"LocalArgument",name:"traceId"},t=[{kind:"Variable",name:"id",variableName:"id"}],l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},r={kind:"InlineFragment",selections:[{alias:null,args:[{kind:"Variable",name:"traceId",variableName:"traceId"}],concreteType:"Trace",kind:"LinkedField",name:"trace",plural:!1,selections:[{alias:null,args:[{kind:"Literal",name:"first",value:1e3}],concreteType:"SpanConnection",kind:"LinkedField",name:"spans",plural:!1,selections:[{alias:null,args:null,concreteType:"SpanEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"span",args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[l,{alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"spanId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null}],storageKey:null},i,{alias:null,args:null,kind:"ScalarField",name:"spanKind",storageKey:null},{alias:"statusCode",args:null,kind:"ScalarField",name:"propagatedStatusCode",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"parentId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[i,{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:"spans(first:1000)"}],storageKey:null}],type:"Project",abstractKey:null};return{fragment:{argumentDefinitions:[n,a],kind:"Fragment",metadata:null,name:"TraceDetailsQuery",selections:[{alias:"project",args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[r],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,n],kind:"Operation",name:"TraceDetailsQuery",selections:[{alias:"project",args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},r,{kind:"TypeDiscriminator",abstractKey:"__isNode"},l],storageKey:null}]},params:{cacheID:"22103e9bb1f983529081ca93d60e76ef",id:null,metadata:{},name:"TraceDetailsQuery",operationKind:"query",text:`query TraceDetailsQuery(
  $traceId: ID!
  $id: GlobalID!
) {
  project: node(id: $id) {
    __typename
    ... on Project {
      trace(traceId: $traceId) {
        spans(first: 1000) {
          edges {
            span: node {
              id
              context {
                spanId
                traceId
              }
              name
              spanKind
              statusCode: propagatedStatusCode
              startTime
              parentId
              latencyMs
              tokenCountTotal
              tokenCountPrompt
              tokenCountCompletion
              spanAnnotations {
                name
                label
                score
                annotatorKind
              }
            }
          }
        }
      }
    }
    __isNode: __typename
    id
  }
}
`}}}();or.hash="8b568616f23f7d349cac5a31807463fb";const dr=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"spanId"}],a=[{kind:"Variable",name:"id",variableName:"spanId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i={alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"spanId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null}],storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},s={alias:null,args:null,kind:"ScalarField",name:"spanKind",storageKey:null},c={alias:"statusCode",args:null,kind:"ScalarField",name:"propagatedStatusCode",storageKey:null},d={alias:null,args:null,kind:"ScalarField",name:"statusMessage",storageKey:null},u={alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},y={alias:null,args:null,kind:"ScalarField",name:"parentId",storageKey:null},g={alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null},p={alias:null,args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},f={alias:null,args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},k={alias:null,args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},b=[{alias:null,args:null,kind:"ScalarField",name:"value",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"mimeType",storageKey:null}],S={alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"input",plural:!1,selections:b,storageKey:null},v={alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"output",plural:!1,selections:b,storageKey:null},I={alias:null,args:null,kind:"ScalarField",name:"attributes",storageKey:null},w={alias:null,args:null,concreteType:"SpanEvent",kind:"LinkedField",name:"events",plural:!0,selections:[r,{alias:null,args:null,kind:"ScalarField",name:"message",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"timestamp",storageKey:null}],storageKey:null},R={alias:null,args:null,concreteType:"DocumentRetrievalMetrics",kind:"LinkedField",name:"documentRetrievalMetrics",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"evaluationName",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"ndcg",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"precision",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hit",storageKey:null}],storageKey:null},K={alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},T={alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},E={alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},_={alias:null,args:null,concreteType:"DocumentEvaluation",kind:"LinkedField",name:"documentEvaluations",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"documentPosition",storageKey:null},r,K,T,E],storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SpanDetailsQuery",selections:[{alias:"span",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"InlineFragment",selections:[l,i,r,s,c,d,u,y,g,p,f,k,S,v,I,{kind:"RequiredField",field:w,action:"THROW",path:"span.events"},R,_,{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[r],storageKey:null},{args:null,kind:"FragmentSpread",name:"SpanFeedback_annotations"},{args:null,kind:"FragmentSpread",name:"SpanAside_span"}],type:"Span",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SpanDetailsQuery",selections:[{alias:"span",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"TypeDiscriminator",abstractKey:"__isNode"},l,{kind:"InlineFragment",selections:[i,r,s,c,d,u,y,g,p,f,k,S,v,I,w,R,_,{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[r,K,T,E,{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},l],storageKey:null},{alias:"code",args:null,kind:"ScalarField",name:"statusCode",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}]},params:{cacheID:"b1a80a0108c40baebf6e64b811ca0202",id:null,metadata:{},name:"SpanDetailsQuery",operationKind:"query",text:`query SpanDetailsQuery(
  $spanId: GlobalID!
) {
  span: node(id: $spanId) {
    __typename
    ... on Span {
      id
      context {
        spanId
        traceId
      }
      name
      spanKind
      statusCode: propagatedStatusCode
      statusMessage
      startTime
      parentId
      latencyMs
      tokenCountTotal
      tokenCountPrompt
      tokenCountCompletion
      input {
        value
        mimeType
      }
      output {
        value
        mimeType
      }
      attributes
      events {
        name
        message
        timestamp
      }
      documentRetrievalMetrics {
        evaluationName
        ndcg
        precision
        hit
      }
      documentEvaluations {
        documentPosition
        name
        label
        score
        explanation
      }
      spanAnnotations {
        name
      }
      ...SpanFeedback_annotations
      ...SpanAside_span
    }
    __isNode: __typename
    id
  }
}

fragment SpanAside_span on Span {
  id
  code: statusCode
  startTime
  endTime
  tokenCountTotal
  tokenCountPrompt
  tokenCountCompletion
  spanAnnotations {
    id
    name
    label
    annotatorKind
    score
  }
}

fragment SpanFeedback_annotations on Span {
  spanAnnotations {
    name
    label
    score
    explanation
    annotatorKind
  }
}
`}}}();dr.hash="eaf52d9b37b1f5a29cae360a05b7c975";function Mt(n){return m.useMemo(()=>n==="user"||n==="human"?{backgroundColor:"grey-100",borderColor:"grey-500"}:n==="assistant"||n==="ai"?{backgroundColor:"blue-100",borderColor:"blue-700"}:n==="system"?{backgroundColor:"indigo-100",borderColor:"indigo-700"}:["function","tool"].includes(n)?{backgroundColor:"yellow-100",borderColor:"yellow-700"}:{backgroundColor:"grey-100",borderColor:"grey-700"},[n])}function al(n){return Array.isArray(n)&&n.every(a=>typeof a=="object"&&de.message in a&&yg(a[de.message]))}function yg(n){return typeof n=="object"&&n!==null&&Ie.role in n}const rt=C`
  display: flex;
  align-items: center;
  .ac-text {
    display: inline-block;
    max-width: 9rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`;function ze(n){const{name:a,metric:t,k:l,score:i}=n,r=typeof l=="number"?`${t}@${l}`:t,s=m.useMemo(()=>t==="hit"?i?"true":"false":typeof i=="number"&&un(i)||"--",[i,t]);return o(pe,{delay:500,offset:3,children:[e(Oe,{children:e("div",{css:Zd,children:o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(Yd,{color:"var(--ac-global-color-seafoam-1000)"}),a?e("div",{css:rt,children:e(x,{weight:"heavy",textSize:"small",color:"inherit",children:a})}):null,e("div",{css:rt,children:e(x,{textSize:"small",color:"inherit",children:r})}),e("div",{css:rt,children:e(x,{textSize:"small",children:s})})]})})}),e(ka,{children:o(h,{direction:"row",gap:"size-100",children:[o(x,{weight:"heavy",color:"inherit",children:[a," ",r]}),e(x,{color:"inherit",children:s})]})})]})}function fg(n){const{spanNodeId:a,projectId:t}=n,[l,i]=m.useState(null);return o(G,{children:[e(z,{variant:"default",icon:e(L,{svg:e(D.EditOutline,{})}),onClick:()=>i(e(Vl,{spanNodeId:a,projectId:t})),children:"Annotate"}),e(ae,{type:"slideOver",isDismissable:!0,onDismiss:()=>i(null),children:l})]})}const cr=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SpanAsideSpanQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"SpanAside_span"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SpanAsideSpanQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},t,{kind:"InlineFragment",selections:[{alias:"code",args:null,kind:"ScalarField",name:"statusCode",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}]},params:{cacheID:"878027b90513af8f947e6aa408450057",id:null,metadata:{},name:"SpanAsideSpanQuery",operationKind:"query",text:`query SpanAsideSpanQuery(
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...SpanAside_span
    __isNode: __typename
    id
  }
}

fragment SpanAside_span on Span {
  id
  code: statusCode
  startTime
  endTime
  tokenCountTotal
  tokenCountPrompt
  tokenCountCompletion
  spanAnnotations {
    id
    name
    label
    annotatorKind
    score
  }
}
`}}}();cr.hash="cb5cab60889623d77ad0c96c98b3f8ac";const ur=function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{argumentDefinitions:[],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:["node"],operation:cr,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"SpanAside_span",selections:[n,{alias:"code",args:null,kind:"ScalarField",name:"statusCode",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[n,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}}();ur.hash="cb5cab60889623d77ad0c96c98b3f8ac";const hg=C`
  display: flex;
  padding-top: var(--ac-global-dimension-size-50);
  flex-direction: column;
  gap: var(--ac-global-dimension-size-100);
  align-items: flex-start;
`;function kg(n){const[a]=P.useRefetchableFragment(ur,n.span),{startTime:t,endTime:l,code:i,tokenCountCompletion:r,tokenCountPrompt:s,tokenCountTotal:c}=a,d=m.useMemo(()=>new Date(t),[t]),u=m.useMemo(()=>l?new Date(l):null,[l]),y=m.useMemo(()=>u?u.getTime()-d.getTime():null,[u,d]),g=$l(i),p=a.spanAnnotations,f=p.length>0;return e(F,{padding:"size-200",borderColor:"dark",backgroundColor:"dark",borderLeftWidth:"thin",width:"230px",flex:"none",minHeight:"100%",children:o(h,{direction:"column",gap:"size-200",children:[e(Vn,{label:"Status",children:o(h,{direction:"row",gap:"size-50",alignItems:"center",children:[e(Ba,{statusCode:i}),e(x,{textSize:"xlarge",color:g,children:i})]})}),e(Vn,{label:"Start Time",children:e(x,{textSize:"xlarge",children:ln(d)})}),u&&e(Vn,{label:"End Time",children:e(x,{textSize:"xlarge",children:ln(u)})}),e(Vn,{label:"Latency",children:e(x,{textSize:"xlarge",children:typeof y=="number"?e(Re,{latencyMs:y,textSize:"xlarge"}):"--"})}),c?e(Vn,{label:"Total Tokens",children:e(va,{tokenCountTotal:c,tokenCountPrompt:s??0,tokenCountCompletion:r??0,textSize:"xlarge"})},"tokens"):null,f&&e(Vn,{label:"Feedback",children:e("ul",{css:hg,children:p.map(k=>e("li",{children:e(yn,{annotation:k,annotationDisplayPreference:"label"})},k.id))})})]})})}function Vn({label:n,children:a}){return o(h,{direction:"column",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:n}),a]})}function bg(n){const{spanId:a,traceId:t}=n;return e("div",{css:C`
        button.ac-dropdown-button {
          min-width: 50px;
          .ac-dropdown-button__text {
            padding-right: 10px;
          }
        }
      `,children:o(Bn,{placement:"bottom right",children:[e(St,{addonBefore:e(L,{svg:e(D.Code,{})}),children:"Code"}),e(Oa,{children:e(F,{padding:"size-200",children:o(we,{children:[o(h,{direction:"row",gap:"size-100",alignItems:"end",children:[e(ee,{label:"Span ID",isReadOnly:!0,value:a}),e(se,{text:a,size:"default"})]}),o(h,{direction:"row",gap:"size-100",alignItems:"end",children:[e(ee,{label:"Trace ID",isReadOnly:!0,value:t}),e(se,{text:t,size:"default"})]})]})})})]})})}const mr={argumentDefinitions:[],kind:"Fragment",metadata:null,name:"SpanFeedback_annotations",selections:[{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null};mr.hash="6199ecd4f0143cffbaa2fe5e19a8739c";function Sg(){const[n,a]=m.useState(null);return o(F,{padding:"size-200",children:[o(h,{direction:"column",gap:"size-100",alignItems:"center",children:[e(ja,{graphicKey:"documents"}),e(x,{children:"No annotations for this span"}),e(z,{variant:"default",size:"compact",onClick:()=>{a(e(Y,{title:"Span Annotations",isDismissable:!0,children:o(F,{padding:"size-200",children:[e("p",{css:C`
              margin: 0 0 var(--ac-global-dimension-size-100) 0;
            `,children:"Annotations are pivotal for tracking and improving the performance of your application. Phoenix allows for both LLM and HUMAN annotations."}),e(rn,{href:"https://docs.arize.com/phoenix/tracing/concepts-tracing/how-to-evaluate-traces",children:"View annotation documentation"})]})}))},icon:e(L,{svg:e(D.Edit2Outline,{})}),children:"How to Annotate"})]}),e(ae,{onDismiss:()=>a(null),isDismissable:!0,children:n})]})}const vg=[{header:"name",accessorKey:"name",size:100},{header:"label",accessorKey:"label",size:100},{header:"score",accessorKey:"score",size:100},{header:"explanation",accessorKey:"explanation",cell:Xd,size:400}];function tl({annotations:n}){const a=m.useMemo(()=>[...n],[n]),t=Te({columns:vg,data:a,getCoreRowModel:De()}),i=t.getRowModel().rows.length===0;return o("table",{css:Je,children:[e("thead",{children:t.getHeaderGroups().map(r=>e("tr",{children:r.headers.map(s=>e("th",{colSpan:s.colSpan,children:s.isPlaceholder?null:e(G,{children:Z(s.column.columnDef.header,s.getContext())})},s.id))},r.id))}),i?e(Ze,{}):e("tbody",{children:t.getRowModel().rows.map(r=>e("tr",{children:r.getVisibleCells().map(s=>e("td",{style:{width:s.column.getSize()},children:Z(s.column.columnDef.cell,s.getContext())},s.id))},r.id))})]})}function Cg({span:n}){const a=P.useFragment(mr,n),t=m.useMemo(()=>a.spanAnnotations.filter(r=>r.annotatorKind==="HUMAN"),[a.spanAnnotations]),l=m.useMemo(()=>a.spanAnnotations.filter(r=>r.annotatorKind==="LLM"),[a.spanAnnotations]);return a.spanAnnotations.length>0?o(qe,{children:[e(ke,{id:"evaluations",title:"Evaluations",children:e(tl,{annotations:l})}),e(ke,{id:"human",title:"Human Annotations",children:e(tl,{annotations:t})})]}):e(Sg,{})}function Fg(n){return n==="__REDACTED__"}const Kg=C`
  position: relative;
  overflow: hidden;
  width: 200px;
  height: 200px;
  border-radius: var(--ac-global-rounding-small);
  border: 1px solid var(--ac-global-color-grey-500);
  background-color: var(--ac-global-color-grey-200);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  transition:
    width 0.1s ease-in-out,
    height 0.1s ease-in-out opacity 0.1s ease-in-out;
  button {
    position: absolute;
    right: var(--ac-global-dimension-size-100);
    top: var(--ac-global-dimension-size-100);
    z-index: 1;
    opacity: 0;
  }
  &:hover button {
    opacity: 1;
  }
  img {
    width: inherit;
    height: inherit;
    object-fit: contain;
  }

  &.is-expanded {
    width: 100%;
    height: 100%;
    img {
      object-fit: cover;
    }
  }
`;function xg(n){const[a,t]=m.useState(!1);let l;const i=Fg(n.url);return i?l=e(Tg,{}):l=e("img",{src:n.url}),o("div",{className:No({"is-expanded":a}),css:Kg,children:[!i&&e(z,{variant:"default",size:"compact",onClick:()=>t(!a),icon:e(L,{svg:a?e(D.CollapseOutline,{}):e(D.ExpandOutline,{})}),"aria-label":"Expand / Collapse Image"}),l]})}const Tg=()=>o("svg",{width:"130",height:"130",viewBox:"0 0 130 130",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"1.5",y:"1.5",width:"127",height:"127",rx:"6.5",strokeOpacity:"0.8",strokeWidth:"3"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M40 27.5H90C96.8917 27.5 102.5 33.1083 102.5 40V90C102.5 96.8917 96.8917 102.5 90 102.5H40C33.1083 102.5 27.5 96.8917 27.5 90V40C27.5 33.1083 33.1083 27.5 40 27.5ZM40 35.8333H90C92.3 35.8333 94.1667 37.7 94.1667 40V74.85L80.8208 63.4667C76.6958 59.9583 70.2417 59.9583 66.1542 63.4417L35.8333 88.7417V40C35.8333 37.7 37.7 35.8333 40 35.8333ZM54.5833 50.4167C54.5833 53.8667 51.7833 56.6667 48.3333 56.6667C44.8833 56.6667 42.0833 53.8667 42.0833 50.4167C42.0833 46.9667 44.8833 44.1667 48.3333 44.1667C51.7833 44.1667 54.5833 46.9667 54.5833 50.4167ZM42.3375 94.1667H90C92.3 94.1667 94.1667 92.3 94.1667 90V85.8083L75.4125 69.8083C74.4083 68.9458 72.55 68.9417 71.525 69.8125L42.3375 94.1667Z",fill:"var(--ac-global-color-grey-300)"})]}),gr=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"addExamplesToDataset",plural:!1,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"dataset",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SpanToDatasetExampleDialogAddExampleToDatasetMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SpanToDatasetExampleDialogAddExampleToDatasetMutation",selections:a},params:{cacheID:"d93c9d47668fc266ba09ecb14c2b72ae",id:null,metadata:{},name:"SpanToDatasetExampleDialogAddExampleToDatasetMutation",operationKind:"mutation",text:`mutation SpanToDatasetExampleDialogAddExampleToDatasetMutation(
  $input: AddExamplesToDatasetInput!
) {
  addExamplesToDataset(input: $input) {
    dataset {
      id
    }
  }
}
`}}}();gr.hash="75120065d239f28304e9dd91fc34bec9";const pr=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"spanId"}],a=[{kind:"Variable",name:"id",variableName:"spanId"}],t={kind:"InlineFragment",selections:[{alias:"revision",args:null,concreteType:"SpanAsExampleRevision",kind:"LinkedField",name:"asExampleRevision",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"input",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SpanToDatasetExampleDialogQuery",selections:[{alias:"span",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SpanToDatasetExampleDialogQuery",selections:[{alias:"span",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t,{kind:"TypeDiscriminator",abstractKey:"__isNode"},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"68887dda2ffa7793e66ff83d472c72f8",id:null,metadata:{},name:"SpanToDatasetExampleDialogQuery",operationKind:"query",text:`query SpanToDatasetExampleDialogQuery(
  $spanId: GlobalID!
) {
  span: node(id: $spanId) {
    __typename
    ... on Span {
      revision: asExampleRevision {
        input
        output
        metadata
      }
    }
    __isNode: __typename
    id
  }
}
`}}}();pr.hash="647a1865dacf40ce9bbb255b572a9a68";const st={backgroundColor:"light",borderColor:"light",collapsible:!0,bodyStyle:{padding:0}};function Dg({spanId:n,onCompleted:a}){const[t,l]=m.useState(null),i=P.useLazyLoadQuery(pr,{spanId:n},{fetchPolicy:"store-and-network"}),{span:{revision:r}}=i,[s,c]=P.useMutation(gr),{control:d,setError:u,handleSubmit:y,formState:{isValid:g}}=je({defaultValues:{input:JSON.stringify(r==null?void 0:r.input,null,2),output:JSON.stringify(r==null?void 0:r.output,null,2),metadata:JSON.stringify(r==null?void 0:r.metadata,null,2),datasetId:""}}),p=m.useCallback(f=>{if(l(null),!en(f==null?void 0:f.input))return u("input",{message:"Input must be a valid JSON object"});if(!en(f==null?void 0:f.output))return u("output",{message:"Output must be a valid JSON object"});if(!en(f==null?void 0:f.metadata))return u("metadata",{message:"Metadata must be a valid JSON object"});if(!(f!=null&&f.datasetId))return u("datasetId",{message:"Dataset is required"});s({variables:{input:{datasetId:f.datasetId,examples:[{input:JSON.parse(f.input),output:JSON.parse(f.output),metadata:JSON.parse(f.metadata),spanId:n}]}},onCompleted:()=>{a(f.datasetId)},onError:k=>{l(k.message)}})},[s,u,n,a]);return e(Y,{size:"fullscreen",title:"Add Example to Dataset",extra:e(z,{variant:"primary",size:"compact",disabled:!g||c,loading:c,onClick:y(p),icon:e(L,{svg:e(D.PlusCircleOutline,{})}),children:"Add Example"}),children:e("div",{css:C`
          overflow-y: auto;
          padding: var(--ac-global-dimension-size-400);
          /* Make widths configurable */
          .dataset-picker {
            width: 100%;
            .ac-dropdown--picker,
            .ac-dropdown-button {
              width: 100%;
            }
          }
        `,children:e(h,{direction:"row",justifyContent:"center",children:e(F,{width:"900px",paddingStart:"auto",paddingEnd:"auto",children:o(h,{direction:"column",gap:"size-200",children:[t?e(ce,{variant:"danger",children:t}):null,e(W,{control:d,name:"datasetId",render:({field:{onChange:f,onBlur:k},fieldState:{invalid:b,error:S}})=>o(h,{direction:"row",gap:"size-100",alignItems:"end",children:[e(Ol,{onSelectionChange:f,onBlur:k,validationState:b?"invalid":"valid",errorMessage:S==null?void 0:S.message,label:"Dataset"}),e(ec,{})]})}),e(W,{control:d,name:"input",render:({field:{onChange:f,onBlur:k,value:b},fieldState:{invalid:S,error:v}})=>o(q,{title:"Input",subTitle:"The input to the LLM, retriever, program, etc.",...st,children:[S?e(ce,{variant:"danger",banner:!0,children:v==null?void 0:v.message}):null,e(Ee,{value:b,onChange:f,onBlur:k})]})}),e(W,{control:d,name:"output",render:({field:{onChange:f,onBlur:k,value:b},fieldState:{invalid:S,error:v}})=>o(q,{title:"Output",subTitle:"The output of the LLM or program to be used as an expected output",...st,backgroundColor:"green-100",borderColor:"green-700",children:[S?e(ce,{variant:"danger",banner:!0,children:v==null?void 0:v.message}):null,e(Ee,{value:b,onChange:f,onBlur:k})]})}),e(W,{control:d,name:"metadata",render:({field:{onChange:f,onBlur:k,value:b},fieldState:{invalid:S,error:v}})=>o(q,{title:"Metadata",subTitle:"All data from the span to use during experimentation or evaluation",...st,children:[S?e(ce,{variant:"danger",banner:!0,children:v==null?void 0:v.message}):null,e(Ee,{value:b,onChange:f,onBlur:k})]})})]})})})})})}const Ig=n=>m.useMemo(()=>Me(n),[n]),Pg=n=>n.events.some(a=>a.name==="exception"),me={backgroundColor:"light",borderColor:"light",variant:"compact",collapsible:!0};function Lg({spanNodeId:n,projectId:a}){const t=ne(),{span:l}=P.useLazyLoadQuery(dr,{spanId:n});if(l.__typename!=="Span")throw new Error("Expected a span, but got a different type"+l.__typename);const i=m.useMemo(()=>Pg(l),[l]),r=Ae(c=>c.showSpanAside),s=Ae(c=>c.setShowSpanAside);return o(h,{direction:"column",flex:"1 1 auto",height:"100%",children:[e(F,{paddingTop:"size-100",paddingBottom:"size-100",paddingStart:"size-150",paddingEnd:"size-200",flex:"none",children:o(h,{direction:"row",gap:"size-200",alignItems:"center",children:[o(h,{direction:"row",gap:"size-100",width:"100%",height:"100%",alignItems:"center",children:[e(Tt,{spanKind:l.spanKind}),e(x,{children:l.name})]}),o(h,{flex:"none",direction:"row",alignItems:"center",gap:"size-100",children:[e(z,{variant:"default",icon:e(L,{svg:e(D.PlayCircleOutline,{})}),disabled:l.spanKind!=="llm",onClick:()=>{t(`/playground/spans/${l.id}`)},children:"Playground"}),e(bg,{traceId:l.context.traceId,spanId:l.context.spanId}),e(_g,{span:l}),e(fg,{spanNodeId:l.id,projectId:a}),o(pe,{placement:"top",offset:5,children:[e(z,{variant:"default","aria-label":"Toggle showing span details",onClick:()=>{s(!r)},icon:e(L,{svg:r?e(D.SlideIn,{}):e(D.SlideOut,{})})}),e(Fe,{children:r?"Hide Span Details":"Show Span Details"})]})]})]})}),o($e,{children:[e(X,{name:"Info",children:o(h,{direction:"row",height:"100%",children:[e(wg,{children:e(Ql,{children:e(Rg,{span:l})})}),r?e(kg,{span:l}):null]})}),e(X,{name:"Feedback",extra:e(Be,{variant:"light",children:l.spanAnnotations.length}),children:c=>c?e(Cg,{span:l}):null}),e(X,{name:"Attributes",title:"Attributes",children:e(F,{padding:"size-200",children:e(q,{title:"All Attributes",...me,titleExtra:hr,extra:e(se,{text:l.attributes}),bodyStyle:{padding:0},children:e(gn,{children:l.attributes})})})}),e(X,{name:"Events",extra:e(Be,{variant:i?"danger":"light",children:l.events.length}),children:e(Zg,{events:l.events})})]})]})}const Eg=C`
  flex: 1 1 auto;
  overflow-y: auto;
  // Overflow fails to take into account padding
  & > *:after {
    content: "";
    display: block;
    height: var(--ac-global-dimension-static-size-400);
  }
`;function wg({children:n}){return e("div",{css:Eg,"data-testid":"span-info-wrap",children:n})}function _g({span:n}){const[a,t]=m.useState(null),l=ve(),i=ne(),r=m.useCallback(()=>{t(e(Dg,{spanId:n.id,onCompleted:s=>{t(null),l({title:"Span Added to Dataset",message:"Successfully added span to dataset",action:{text:"View Dataset",onClick:()=>{i(`/datasets/${s}/examples`)}}})}}))},[n.id,l,i]);return o(G,{children:[e(z,{variant:"default",icon:e(L,{svg:e(D.DatabaseOutline,{})}),onClick:r,children:"Add to Dataset"}),e(m.Suspense,{children:e(ae,{type:"slideOver",isDismissable:!0,onDismiss:()=>t(null),children:a})})]})}function Rg({span:n}){const{spanKind:a,attributes:t}=n,{json:l,parseError:i}=Ig(t),r=m.useMemo(()=>n.statusMessage?e(ce,{variant:"danger",title:"Status Description",children:n.statusMessage}):null,[n]);if(i||!l)return e(F,{padding:"size-200",children:o(h,{direction:"column",gap:"size-200",children:[r,e(ce,{variant:"warning",title:"Un-parsable attributes",children:`Failed to parse span attributes. ${i instanceof Error?i.message:""}`}),e(q,{...me,title:"Attributes",children:e(F,{padding:"size-100",children:t})})]})});let s;switch(a){case"llm":{s=e(Ag,{span:n,spanAttributes:l});break}case"retriever":{s=e(Mg,{span:n,spanAttributes:l});break}case"reranker":{s=e(Ng,{span:n,spanAttributes:l});break}case"embedding":{s=e(zg,{span:n,spanAttributes:l});break}case"tool":{s=e(Vg,{span:n,spanAttributes:l});break}default:s=e(yr,{span:n})}return e(F,{padding:"size-200",children:o(h,{direction:"column",gap:"size-200",children:[r,s,l!=null&&l.metadata?e(q,{...me,title:"Metadata",children:e(gn,{children:JSON.stringify(l.metadata)})}):null]})})}function Ag(n){const{spanAttributes:a,span:t}=n,{input:l,output:i}=t,r=m.useMemo(()=>a[de.llm]||null,[a]),s=m.useMemo(()=>{if(r==null)return null;const E=r[Pe.model_name];return typeof E=="string"?E:null},[r]),c=m.useMemo(()=>{if(r==null)return[];const E=r[Pe.input_messages];return al(E)?(E==null?void 0:E.map(_=>_[de.message]).filter(Boolean))||[]:[]},[r]),d=m.useMemo(()=>{if(r==null)return[];const E=r[Pe.tools];return Array.isArray(E)?E==null?void 0:E.map(j=>j[de.tool]).filter(Boolean):[]},[r]),u=m.useMemo(()=>d.reduce((E,_)=>(_!=null&&_.json_schema&&E.push(_.json_schema),E),[]),[d]),y=m.useMemo(()=>{if(r==null)return[];const E=r[Pe.output_messages];return al(E)?E.map(_=>_[de.message]).filter(Boolean)||[]:[]},[r]),g=m.useMemo(()=>{if(r==null)return[];const E=r[Pe.prompts];return nc(E)?E:[]},[r]),p=m.useMemo(()=>{if(r==null)return null;const E=r[Pe.prompt_template];return E??null},[r]),f=m.useMemo(()=>r==null?"{}":r[Pe.invocation_parameters]||"{}",[r]),k=m.useMemo(()=>s==null?null:o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(Dt,{spanKind:"llm"}),e(x,{textSize:"large",weight:"heavy",children:s})]}),[s]),b=l!=null&&l.value!=null,S=c.length>0,v=u.length>0,I=i!=null&&i.value!=null,w=y.length>0,R=g.length>0,K=Object.keys(JSON.parse(f)).length>0,T=p!=null;return o(h,{direction:"column",gap:"size-200",children:[e(q,{collapsible:!0,backgroundColor:"light",borderColor:"light",bodyStyle:{padding:0},titleSeparator:!1,variant:"compact",title:k,children:o($e,{children:[S?e(X,{name:"Input Messages",hidden:!S,children:e(ll,{messages:c})}):null,v?e(X,{name:"Tools",hidden:!v,children:e(jg,{toolSchemas:u})}):null,b?e(X,{name:"Input",hidden:!b,children:e(F,{padding:"size-200",children:e(Qe,{children:e(q,{...me,title:"LLM Input",extra:o(h,{direction:"row",gap:"size-100",children:[e(He,{}),e(se,{text:l.value})]}),children:e(sn,{...l})})})})}):null,T?e(X,{name:"Prompt Template",hidden:!T,children:e(F,{padding:"size-200",children:o(h,{direction:"column",gap:"size-100",children:[e(F,{borderRadius:"medium",borderColor:"light",backgroundColor:"light",borderWidth:"thin",padding:"size-200",children:o(Aa,{text:p.template,children:[e(x,{color:"text-700",fontStyle:"italic",children:"prompt template"}),e(fr,{children:p.template})]})}),e(F,{borderRadius:"medium",borderColor:"light",backgroundColor:"light",borderWidth:"thin",padding:"size-200",children:o(Aa,{text:JSON.stringify(p.variables),children:[e(x,{color:"text-700",fontStyle:"italic",children:"template variables"}),e(gn,{children:JSON.stringify(p.variables)})]})})]})})}):null,e(X,{name:"Prompts",hidden:!R,children:e(qg,{prompts:g})}),e(X,{name:"Invocation Params",hidden:!K,children:e(Aa,{text:f,padding:"size-100",children:e(gn,{children:f})})})]})}),I||w?e(bt,{...me,children:o($e,{children:[w?e(X,{name:"Output Messages",hidden:!w,children:e(ll,{messages:y})}):null,I?e(X,{name:"Output",hidden:!I,children:e(F,{padding:"size-200",children:e(Qe,{children:e(q,{...me,title:"LLM Output",extra:o(h,{direction:"row",gap:"size-100",children:[e(He,{}),e(se,{text:i.value})]}),children:e(sn,{...i})})})})}):null]})}):null]})}function Mg(n){const{spanAttributes:a,span:t}=n,{input:l}=t,i=m.useMemo(()=>a[de.retrieval]||null,[a]),r=m.useMemo(()=>{var y;return i==null?[]:((y=i[zo.documents])==null?void 0:y.map(g=>g[de.document]).filter(Boolean))||[]},[i]),s=m.useMemo(()=>t.documentEvaluations.reduce((g,p)=>{const f=p.documentPosition,k=g[f]||[];return{...g,[f]:[...k,p]}},{}),[t.documentEvaluations]),c=l!=null&&l.value!=null,d=r.length>0,u=t.documentRetrievalMetrics.length>0;return o(h,{direction:"column",gap:"size-200",children:[c?e(Qe,{children:e(q,{title:"Input",...me,extra:o(h,{direction:"row",gap:"size-100",children:[e(He,{}),e(se,{text:l.value})]}),children:e(sn,{...l})})}):null,d?e(Qe,{children:e(q,{title:"Documents",...me,titleExtra:u&&e(h,{direction:"row",alignItems:"center",gap:"size-100",children:t.documentRetrievalMetrics.map(y=>o(G,{children:[e(ze,{name:y.evaluationName,metric:"ndcg",score:y.ndcg},"ndcg"),e(ze,{name:y.evaluationName,metric:"precision",score:y.precision},"precision"),e(ze,{name:y.evaluationName,metric:"hit",score:y.hit},"hit")]}))}),extra:e(He,{}),children:e("ul",{css:C`
                display: flex;
                flex-direction: column;
                gap: var(--ac-global-dimension-static-size-200);
              `,children:r.map((y,g)=>e("li",{children:e(yt,{document:y,documentEvaluations:s[g],borderColor:"seafoam-700",backgroundColor:"seafoam-100",labelColor:"seafoam-1000"})},g))})})}):null]})}function Ng(n){const{spanAttributes:a}=n,t=m.useMemo(()=>a[de.reranker]||null,[a]),l=m.useMemo(()=>t==null?null:t[nt.query]||null,[t]),i=m.useMemo(()=>{var d;return t==null?[]:((d=t[nt.input_documents])==null?void 0:d.map(u=>u[de.document]).filter(Boolean))||[]},[t]),r=m.useMemo(()=>{var d;return t==null?[]:((d=t[nt.output_documents])==null?void 0:d.map(u=>u[de.document]).filter(Boolean))||[]},[t]),s=i.length,c=r.length;return o(h,{direction:"column",gap:"size-200",children:[e(Qe,{children:l&&e(q,{title:"Query",...me,children:e(na,{children:l})})}),e(q,{title:"Input Documents",titleExtra:e(Be,{variant:"light",children:s}),...me,defaultOpen:!1,bodyStyle:{padding:0},children:e("ul",{css:C`
              padding: var(--ac-global-dimension-static-size-200);
              display: flex;
              flex-direction: column;
              gap: var(--ac-global-dimension-static-size-200);
            `,children:i.map((d,u)=>e("li",{children:e(yt,{document:d,borderColor:"seafoam-700",backgroundColor:"seafoam-100",labelColor:"seafoam-1000"})},u))})}),e(q,{title:"Output Documents",titleExtra:e(Be,{variant:"light",children:c}),...me,bodyStyle:{padding:0},children:e("ul",{css:C`
              padding: var(--ac-global-dimension-static-size-200);
              display: flex;
              flex-direction: column;
              gap: var(--ac-global-dimension-static-size-200);
            `,children:r.map((d,u)=>e("li",{children:e(yt,{document:d,borderColor:"celery-700",backgroundColor:"celery-100",labelColor:"celery-1000"})},u))})})]})}function zg(n){const{spanAttributes:a}=n,t=m.useMemo(()=>a[de.embedding]||null,[a]),l=m.useMemo(()=>{var s;return t==null?[]:((s=t[at.embeddings])==null?void 0:s.map(c=>c[de.embedding]).filter(Boolean))||[]},[t]),i=l.length>0,r=t==null?void 0:t[at.model_name];return e(h,{direction:"column",gap:"size-200",children:i?e(q,{title:"Embeddings"+(typeof r=="string"?`: ${r}`:""),...me,children:e("ul",{css:C`
                display: flex;
                flex-direction: column;
                gap: var(--ac-global-dimension-static-size-200);
              `,children:l.map((s,c)=>e("li",{children:e(Qe,{children:e(q,{...me,backgroundColor:"purple-100",borderColor:"purple-700",title:"Embedded Text",children:e(na,{children:s[at.text]||""})})})},c))})}):e(yr,{span:n.span})})}function Vg(n){const{span:a,spanAttributes:t}=n,{input:l,output:i}=a,r=typeof(l==null?void 0:l.value)=="string",s=typeof(i==null?void 0:i.value)=="string",c=(l==null?void 0:l.mimeType)==="text",d=(i==null?void 0:i.mimeType)==="text",u=m.useMemo(()=>t[de.tool]||{},[t]),y=Object.keys(u).length>0,g=u[La.name],p=u[La.description],f=u[La.parameters];return!r&&!s&&!y?null:o(h,{direction:"column",gap:"size-200",children:[r?e(Qe,{children:e(q,{title:"Input",...me,extra:o(h,{direction:"row",gap:"size-100",children:[c?e(He,{}):null,e(se,{text:l.value})]}),children:e(sn,{...l})})}):null,s?e(Qe,{children:e(q,{title:"Output",...me,backgroundColor:"green-100",borderColor:"green-700",extra:o(h,{direction:"row",gap:"size-100",children:[d?e(He,{}):null,e(se,{text:i.value})]}),children:e(sn,{...i})})}):null,y?e(q,{title:"Tool"+(typeof g=="string"?`: ${g}`:""),...me,children:o(h,{direction:"column",children:[p!=null?e(F,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderBottomColor:"dark",borderBottomWidth:"thin",backgroundColor:"light",children:o(h,{direction:"column",alignItems:"start",gap:"size-50",children:[e(x,{color:"text-700",fontStyle:"italic",children:"Description"}),e(x,{children:p})]})}):null,f!=null?e(F,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderBottomColor:"dark",borderBottomWidth:"thin",children:o(h,{direction:"column",alignItems:"start",width:"100%",children:[e(x,{color:"text-700",fontStyle:"italic",children:"Parameters"}),e(gn,{children:JSON.stringify(f)})]})}):null]})}):null]})}const $g=["irrelevant","unrelated"];function yt({document:n,documentEvaluations:a,backgroundColor:t,borderColor:l,labelColor:i}){const r=n[ta.metadata],s=a&&a.length,c=n[ta.content];return e(q,{...me,backgroundColor:t,borderColor:l,bodyStyle:{padding:0},title:o(h,{direction:"row",gap:"size-50",alignItems:"center",children:[e(L,{svg:e(D.FileOutline,{})}),o(ge,{level:4,children:["document ",n[ta.id]]})]}),extra:typeof n[ta.score]=="number"&&e(Ea,{color:i,children:`score ${Kt(n[ta.score])}`}),children:o(h,{direction:"column",children:[c&&e(F,{padding:"size-200",children:e(na,{children:c})}),r&&e(G,{children:e(F,{borderColor:l,borderTopWidth:"thin",children:e(gn,{children:JSON.stringify(r)})})}),s&&e(F,{borderColor:l,borderTopWidth:"thin",padding:"size-200",children:o(h,{direction:"column",gap:"size-100",children:[e(ge,{level:3,weight:"heavy",children:"Evaluations"}),e("ul",{children:a.map((d,u)=>{const y=d.label&&$g.includes(d.label)?"danger":i;return e("li",{children:e(F,{padding:"size-200",borderWidth:"thin",borderColor:l,borderRadius:"medium",children:o(h,{direction:"column",gap:"size-50",children:[o(h,{direction:"row",gap:"size-100",children:[e(x,{weight:"heavy",elementType:"h5",children:d.name}),d.label&&e(Ea,{color:y,shape:"badge",children:d.label}),typeof d.score=="number"&&e(Ea,{color:y,shape:"badge",children:o(h,{direction:"row",gap:"size-50",children:[e(x,{textSize:"xsmall",weight:"heavy",color:"inherit",children:"score"}),e(x,{textSize:"xsmall",children:un(d.score)})]})})]}),typeof d.explanation&&e("p",{css:C`
                                margin-top: var(
                                  --ac-global-dimension-static-size-100
                                );
                                margin-bottom: 0;
                              `,children:d.explanation})]})})},u)})})]})})]})})}function Og({message:n}){var c;const a=n[Ie.content],t=n[Ie.contents],l=((c=n[Ie.tool_calls])==null?void 0:c.map(d=>d[de.tool_call]).filter(Boolean))||[],i=n[Ie.function_call_arguments_json]&&n[Ie.function_call_name],r=n[Ie.role]||"unknown",s=Mt(r);return e(Qe,{children:o(q,{...me,...s,title:r+(n[Ie.name]?`: ${n[Ie.name]}`:""),extra:o(h,{direction:"row",gap:"size-100",children:[e(He,{}),e(se,{text:a||JSON.stringify(n)})]}),children:[e(Ql,{children:t?e(Bg,{messageContents:t}):null}),o(h,{direction:"column",alignItems:"start",children:[a?e(na,{children:a}):null,l.length>0?l.map((d,u)=>{var y,g;return o("pre",{css:C`
                      text-wrap: wrap;
                      margin: var(--ac-global-dimension-static-size-100) 0;
                    `,children:[(y=d==null?void 0:d.function)==null?void 0:y.name,"(",JSON.stringify(JSON.parse((g=d==null?void 0:d.function)==null?void 0:g.arguments),null,2),")"]},u)}):null,i?o("pre",{css:C`
                text-wrap: wrap;
                margin: var(--ac-global-dimension-static-size-100) 0;
              `,children:[n[Ie.function_call_name],"(",JSON.stringify(JSON.parse(n[Ie.function_call_arguments_json]),null,2),")"]}):null]})]})})}function Qg({toolSchema:n,index:a}){return e(q,{title:o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(Dt,{spanKind:"tool"}),e(x,{textSize:"large",weight:"heavy",children:"Tool"})]}),titleExtra:o(Be,{variant:"light",children:["#",a+1]}),...me,backgroundColor:"yellow-100",borderColor:"yellow-700",bodyStyle:{padding:0},extra:e(se,{text:n}),children:e(sn,{value:n,mimeType:"json"})})}function ll({messages:n}){return e("ul",{css:C`
        display: flex;
        flex-direction: column;
        gap: var(--ac-global-dimension-static-size-100);
        padding: var(--ac-global-dimension-static-size-200);
      `,children:n.map((a,t)=>e("li",{children:e(Og,{message:a})},t))})}function jg({toolSchemas:n}){return e("ul",{css:C`
        display: flex;
        flex-direction: column;
        gap: var(--ac-global-dimension-static-size-100);
        padding: var(--ac-global-dimension-static-size-200);
      `,children:n.map((a,t)=>e("li",{children:e(Qg,{toolSchema:a,index:t})},t))})}function qg({prompts:n}){return e("ul",{"data-testid":"llm-prompts-list",css:C`
        padding: var(--ac-global-dimension-size-200);
        display: flex;
        flex-direction: column;
        gap: var(--ac-global-dimension-size-100);
      `,children:n.map((a,t)=>e("li",{children:e(F,{backgroundColor:"gray-600",borderColor:"gray-400",borderWidth:"thin",borderRadius:"medium",padding:"size-100",children:e(Aa,{text:a,children:e(sn,{value:a,mimeType:"text"})})})},t))})}const Ug=C`
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-size-200);
  flex-wrap: wrap;
`;function Bg({messageContents:n}){return e("ul",{css:Ug,"data-testid":"message-content-list",children:n.map((a,t)=>e(Gg,{messageContentAttribute:a},t))})}const Hg=C`
  flex: 1 1 100%;
`;function Gg({messageContentAttribute:n}){var r;const{message_content:a}=n,t=a==null?void 0:a.text,l=a==null?void 0:a.image,i=(r=l==null?void 0:l.image)==null?void 0:r.url;return o("li",{css:t?Hg:null,children:[t?e("pre",{css:C`
            white-space: pre-wrap;
            padding: 0;
            margin: 0;
          `,children:t}):null,i?e(xg,{url:i}):null]})}function yr({span:n}){const{input:a,output:t}=n,l=a==null&&t==null,i=(a==null?void 0:a.mimeType)==="text",r=(t==null?void 0:t.mimeType)==="text";return o(h,{direction:"column",gap:"size-200",children:[a&&a.value!=null?e(Qe,{children:e(q,{title:"Input",...me,extra:o(h,{direction:"row",gap:"size-100",children:[i?e(He,{}):null,e(se,{text:a.value})]}),children:e(sn,{...a})})}):null,t&&t.value!=null?e(Qe,{children:e(q,{title:"Output",...me,backgroundColor:"green-100",borderColor:"green-700",extra:o(h,{direction:"row",gap:"size-100",children:[r?e(He,{}):null,e(se,{text:t.value})]}),children:e(sn,{...t})})}):null,l?e(q,{title:"All Attributes",titleExtra:hr,...me,bodyStyle:{padding:0},extra:e(se,{text:n.attributes}),children:e(gn,{children:n.attributes})}):null]})}const Wg=C`
  .cm-content {
    padding: var(--ac-global-dimension-static-size-200) 0;
  }
  .cm-editor,
  .cm-gutters {
    background-color: transparent;
  }
`;function Aa({text:n,children:a,padding:t}){const l=t?`var(--ac-global-dimension-${t})`:"0";return o("div",{css:C`
        position: relative;
        .copy-to-clipboard-button {
          transition: opacity 0.2s ease-in-out;
          opacity: 0;
          position: absolute;
          right: ${l};
          top: ${l};
          z-index: 1;
        }
        &:hover .copy-to-clipboard-button {
          opacity: 1;
        }
      `,children:[e(se,{text:n}),a]})}function gn({children:n}){const{theme:a}=Zn(),t=a==="light"?void 0:xa,{value:l,mimeType:i}=m.useMemo(()=>{try{return{value:JSON.stringify(JSON.parse(n),null,2),mimeType:"json"}}catch{return{value:n,mimeType:"text"}}},[n]);return i==="json"?e(Ka,{value:l,basicSetup:{lineNumbers:!0,foldGutter:!0,bracketMatching:!0,syntaxHighlighting:!0,highlightActiveLine:!1,highlightActiveLineGutter:!1},extensions:[zc(),oi.lineWrapping],editable:!1,theme:t,css:Wg}):e(fr,{children:l})}function fr({children:n}){return e("pre",{css:C`
        white-space: pre-wrap;
        padding: 0;
      `,children:n})}function sn({value:n,mimeType:a}){let t;switch(a){case"json":t=e(gn,{children:n});break;case"text":t=e(na,{children:n});break;default:ue()}return t}function Jg({text:n}){return o(h,{direction:"column",alignItems:"center",flex:"1 1 auto",height:"size-2400",justifyContent:"center",gap:"size-100",children:[e(ja,{graphicKey:"documents"}),e(x,{children:n})]})}function Zg({events:n}){return n.length===0?e(Jg,{text:"No events"}):e(Kl,{children:n.map((a,t)=>{const l=a.name==="exception";return e(Fl,{children:o(h,{direction:"row",alignItems:"center",gap:"size-100",children:[e(F,{flex:"none",children:e("div",{"data-event-type":l?"exception":"info",css:i=>C`
                    &[data-event-type="exception"] {
                      --px-event-icon-color: ${i.colors.statusDanger};
                    }
                    &[data-event-type="info"] {
                      --px-event-icon-color: ${i.colors.statusInfo};
                    }
                    .ac-icon-wrap {
                      color: var(--px-event-icon-color);
                    }
                  `,children:e(L,{svg:l?e(D.AlertTriangleOutline,{}):e(D.InfoOutline,{})})})}),o(h,{direction:"column",gap:"size-25",flex:"1 1 auto",children:[e(x,{weight:"heavy",children:a.name}),e(x,{color:"text-700",children:a.message})]}),e(F,{children:e(x,{color:"text-700",children:new Date(a.timestamp).toLocaleString()})})]})},t)})})}const hr=e(h,{alignItems:"center",justifyContent:"center",children:e(F,{marginStart:"size-100",children:o(Hn,{children:[e(ge,{weight:"heavy",level:4,children:"Span Attributes"}),e(An,{children:e(x,{children:"Attributes are key-value pairs that represent metadata associated with a span. For detailed descriptions of specific attributes, consult the semantic conventions section of the OpenInference tracing specification."})}),e("footer",{children:e(rn,{href:"https://github.com/Arize-ai/openinference/blob/main/spec/semantic_conventions.md",children:"Semantic Conventions"})})]})})}),il="selectedSpanNodeId";function Yg(n){const a=n.find(i=>i.parentId==null);if(a)return a;const t=new Set(n.map(i=>i.context.spanId)),l=n.filter(i=>i.parentId!=null&&!t.has(i.parentId));return l.length===1?l[0]:null}function Nt(n){const{traceId:a,projectId:t}=n,[l,i]=fa(),r=P.useLazyLoadQuery(or,{traceId:a,id:t},{fetchPolicy:"store-and-network"}),s=m.useMemo(()=>{var g;return(((g=r.project.trace)==null?void 0:g.spans.edges)||[]).map(p=>p.span)},[r]),d=l.get(il)??s[0].id,u=m.useMemo(()=>Yg(s),[s]);return m.useEffect(()=>()=>{i(y=>(y.delete("spanNodeId"),y),{replace:!0})},[]),o("main",{css:C`
        flex: 1 1 auto;
        overflow: hidden;
        display: flex;
        flex-direction: column;
      `,children:[e(Xg,{rootSpan:u}),o(tn,{direction:"horizontal",autoSaveId:"trace-panel-group",css:C`
          flex: 1 1 auto;
          overflow: hidden;
        `,children:[e(he,{defaultSize:30,minSize:10,maxSize:70,children:e(np,{children:e(ac,{spans:s,selectedSpanNodeId:d,onSpanClick:y=>{i(g=>(g.set(il,y.id),g),{replace:!0})}})})}),e(an,{css:fn}),e(he,{children:e(ep,{children:d?e(m.Suspense,{fallback:e(ye,{}),children:e(Lg,{spanNodeId:d,projectId:t})}):null})})]})]})}function Xg({rootSpan:n}){const{latencyMs:a,statusCode:t,spanAnnotations:l}=n??{latencyMs:null,statusCode:"UNSET",spanAnnotations:[]},i=l.length>0,r=$l(t);return e(F,{padding:"size-200",borderBottomWidth:"thin",borderBottomColor:"dark",children:o(h,{direction:"row",gap:"size-400",children:[o(h,{direction:"column",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:"Trace Status"}),e(x,{textSize:"xlarge",children:o(h,{direction:"row",gap:"size-50",alignItems:"center",children:[e(Ba,{statusCode:t}),e(x,{textSize:"xlarge",color:r,children:t})]})})]}),o(h,{direction:"column",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:"Latency"}),e(x,{textSize:"xlarge",children:typeof a=="number"?e(Re,{latencyMs:a,textSize:"xlarge"}):"--"})]}),i?o(h,{direction:"column",gap:"size-50",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:"Feedback"}),e(h,{direction:"row",gap:"size-50",children:l.map(s=>e(Sa,{annotation:s,children:e(yn,{annotation:s,annotationDisplayPreference:"label"})},s.name))})]}):null]})})}function ep({children:n}){return e("div",{"data-testid":"scrolling-tabs-wrapper",css:C`
        height: 100%;
        overflow: hidden;
        .ac-tabs {
          height: 100%;
          overflow: hidden;
          .ac-tabs__extra {
            width: 100%;
            padding-right: var(--ac-global-dimension-size-200);
            padding-bottom: var(--ac-global-dimension-size-50);
          }
          .ac-tabs__pane-container {
            min-height: 100%;
            height: 100%;
            overflow-y: auto;
            div[role="tabpanel"] {
              height: 100%;
            }
          }
        }
      `,children:n})}function np({children:n}){return e("div",{"data-testid":"scrolling-panel-content",css:C`
        height: 100%;
        overflow-y: auto;
      `,children:n})}function r1(){const{traceId:n,projectId:a}=Ue(),t=ne();return e(ae,{type:"slideOver",isDismissable:!0,onDismiss:()=>t(`/projects/${a}`),children:e(Y,{size:"fullscreen",title:"Trace Details",children:e(Nt,{traceId:n,projectId:a})})})}const kr=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"},{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},r={kind:"Variable",name:"timeRange",variableName:"timeRange"},s=[{kind:"Literal",name:"first",value:50},{kind:"Literal",name:"rootSpansOnly",value:!0},{kind:"Literal",name:"sort",value:{col:"startTime",dir:"desc"}},r],c={alias:null,args:null,kind:"ScalarField",name:"spanKind",storageKey:null},d={alias:"statusCode",args:null,kind:"ScalarField",name:"propagatedStatusCode",storageKey:null},u={alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},y={alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null},g={alias:null,args:null,kind:"ScalarField",name:"parentId",storageKey:null},p=[{alias:"value",args:null,kind:"ScalarField",name:"truncatedValue",storageKey:null}],f={alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"input",plural:!1,selections:p,storageKey:null},k={alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"output",plural:!1,selections:p,storageKey:null},b={alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"spanId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null}],storageKey:null},S={alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[i,{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null}],storageKey:null},v={alias:null,args:null,concreteType:"DocumentRetrievalMetrics",kind:"LinkedField",name:"documentRetrievalMetrics",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"evaluationName",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"ndcg",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"precision",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hit",storageKey:null}],storageKey:null},I=[r];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ProjectPageQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"TracesTable_spans"},{args:null,kind:"FragmentSpread",name:"ProjectPageHeader_stats"},{args:null,kind:"FragmentSpread",name:"StreamToggle_data"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ProjectPageQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"TypeDiscriminator",abstractKey:"__isNode"},l,{kind:"InlineFragment",selections:[i,{alias:null,args:null,kind:"ScalarField",name:"spanAnnotationNames",storageKey:null},{alias:"rootSpans",args:s,concreteType:"SpanConnection",kind:"LinkedField",name:"spans",plural:!1,selections:[{alias:null,args:null,concreteType:"SpanEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"rootSpan",args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[l,c,i,{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},d,u,y,{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountCompletion",storageKey:null},g,f,k,b,S,v,{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"descendants",plural:!0,selections:[l,c,i,d,u,y,g,{alias:"cumulativeTokenCountTotal",args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:"cumulativeTokenCountPrompt",args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:"cumulativeTokenCountCompletion",args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},f,k,b,S,v],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[t],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:"rootSpans",args:s,filters:["sort","rootSpansOnly","filterCondition","timeRange"],handle:"connection",key:"TracesTable_rootSpans",kind:"LinkedHandle",name:"spans"},{alias:null,args:I,kind:"ScalarField",name:"traceCount",storageKey:null},{alias:null,args:I,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:"latencyMsP50",args:[{kind:"Literal",name:"probability",value:.5},r],kind:"ScalarField",name:"latencyMsQuantile",storageKey:null},{alias:"latencyMsP99",args:[{kind:"Literal",name:"probability",value:.99},r],kind:"ScalarField",name:"latencyMsQuantile",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"documentEvaluationNames",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"streamingLastUpdatedAt",storageKey:null}],type:"Project",abstractKey:null}],storageKey:null}]},params:{cacheID:"400e3bc8456d6d9eb0f4f85fc862ad57",id:null,metadata:{},name:"ProjectPageQuery",operationKind:"query",text:`query ProjectPageQuery(
  $id: GlobalID!
  $timeRange: TimeRange!
) {
  project: node(id: $id) {
    __typename
    ...TracesTable_spans
    ...ProjectPageHeader_stats
    ...StreamToggle_data
    __isNode: __typename
    id
  }
}

fragment ProjectPageHeader_stats on Project {
  traceCount(timeRange: $timeRange)
  tokenCountTotal(timeRange: $timeRange)
  latencyMsP50: latencyMsQuantile(probability: 0.5, timeRange: $timeRange)
  latencyMsP99: latencyMsQuantile(probability: 0.99, timeRange: $timeRange)
  spanAnnotationNames
  documentEvaluationNames
  id
}

fragment SpanColumnSelector_annotations on Project {
  spanAnnotationNames
}

fragment StreamToggle_data on Project {
  streamingLastUpdatedAt
  id
}

fragment TracesTable_spans on Project {
  name
  ...SpanColumnSelector_annotations
  rootSpans: spans(first: 50, sort: {col: startTime, dir: desc}, rootSpansOnly: true, timeRange: $timeRange) {
    edges {
      rootSpan: node {
        id
        spanKind
        name
        metadata
        statusCode: propagatedStatusCode
        startTime
        latencyMs
        cumulativeTokenCountTotal
        cumulativeTokenCountPrompt
        cumulativeTokenCountCompletion
        parentId
        input {
          value: truncatedValue
        }
        output {
          value: truncatedValue
        }
        context {
          spanId
          traceId
        }
        spanAnnotations {
          name
          label
          score
          annotatorKind
        }
        documentRetrievalMetrics {
          evaluationName
          ndcg
          precision
          hit
        }
        descendants {
          id
          spanKind
          name
          statusCode: propagatedStatusCode
          startTime
          latencyMs
          parentId
          cumulativeTokenCountTotal: tokenCountTotal
          cumulativeTokenCountPrompt: tokenCountPrompt
          cumulativeTokenCountCompletion: tokenCountCompletion
          input {
            value: truncatedValue
          }
          output {
            value: truncatedValue
          }
          context {
            spanId
            traceId
          }
          spanAnnotations {
            name
            label
            score
            annotatorKind
          }
          documentRetrievalMetrics {
            evaluationName
            ndcg
            precision
            hit
          }
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();kr.hash="e2d168c52b9c1b5fd5543286f4d2786c";const br=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"},{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},r=[{kind:"Literal",name:"first",value:50},{kind:"Literal",name:"sort",value:{col:"startTime",dir:"desc"}},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],s=[{alias:"value",args:null,kind:"ScalarField",name:"truncatedValue",storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ProjectPageSpansQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"SpansTable_spans"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ProjectPageSpansQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"TypeDiscriminator",abstractKey:"__isNode"},l,{kind:"InlineFragment",selections:[i,{alias:null,args:null,kind:"ScalarField",name:"spanAnnotationNames",storageKey:null},{alias:null,args:r,concreteType:"SpanConnection",kind:"LinkedField",name:"spans",plural:!1,selections:[{alias:null,args:null,concreteType:"SpanEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"span",args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[l,{alias:null,args:null,kind:"ScalarField",name:"spanKind",storageKey:null},i,{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"statusCode",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},{alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"spanId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"input",plural:!1,selections:s,storageKey:null},{alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"output",plural:!1,selections:s,storageKey:null},{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[i,{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"DocumentRetrievalMetrics",kind:"LinkedField",name:"documentRetrievalMetrics",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"evaluationName",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"ndcg",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"precision",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hit",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[t],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:r,filters:["sort","filterCondition","timeRange"],handle:"connection",key:"SpansTable_spans",kind:"LinkedHandle",name:"spans"}],type:"Project",abstractKey:null}],storageKey:null}]},params:{cacheID:"09e4f18ba3f2a63560f542088a4329ff",id:null,metadata:{},name:"ProjectPageSpansQuery",operationKind:"query",text:`query ProjectPageSpansQuery(
  $id: GlobalID!
  $timeRange: TimeRange!
) {
  project: node(id: $id) {
    __typename
    ...SpansTable_spans
    __isNode: __typename
    id
  }
}

fragment SpanColumnSelector_annotations on Project {
  spanAnnotationNames
}

fragment SpansTable_spans on Project {
  name
  ...SpanColumnSelector_annotations
  spans(first: 50, sort: {col: startTime, dir: desc}, timeRange: $timeRange) {
    edges {
      span: node {
        id
        spanKind
        name
        metadata
        statusCode
        startTime
        latencyMs
        tokenCountTotal
        tokenCountPrompt
        tokenCountCompletion
        context {
          spanId
          traceId
        }
        input {
          value: truncatedValue
        }
        output {
          value: truncatedValue
        }
        spanAnnotations {
          name
          label
          score
          annotatorKind
        }
        documentRetrievalMetrics {
          evaluationName
          ndcg
          precision
          hit
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();br.hash="18fe45fad1c124d8c29cdcabf463a213";const Sr=function(){var n={defaultValue:null,kind:"LocalArgument",name:"id"},a={defaultValue:null,kind:"LocalArgument",name:"timeRange"},t=[{kind:"Variable",name:"id",variableName:"id"}],l={kind:"Variable",name:"timeRange",variableName:"timeRange"},i=[l];return{fragment:{argumentDefinitions:[n,a],kind:"Fragment",metadata:null,name:"ProjectPageHeaderQuery",selections:[{alias:null,args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"ProjectPageHeader_stats"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,n],kind:"Operation",name:"ProjectPageHeaderQuery",selections:[{alias:null,args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{kind:"InlineFragment",selections:[{alias:null,args:i,kind:"ScalarField",name:"traceCount",storageKey:null},{alias:null,args:i,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:"latencyMsP50",args:[{kind:"Literal",name:"probability",value:.5},l],kind:"ScalarField",name:"latencyMsQuantile",storageKey:null},{alias:"latencyMsP99",args:[{kind:"Literal",name:"probability",value:.99},l],kind:"ScalarField",name:"latencyMsQuantile",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"spanAnnotationNames",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"documentEvaluationNames",storageKey:null}],type:"Project",abstractKey:null}],storageKey:null}]},params:{cacheID:"264a748e3bb636d71fb6b75523a612fe",id:null,metadata:{},name:"ProjectPageHeaderQuery",operationKind:"query",text:`query ProjectPageHeaderQuery(
  $timeRange: TimeRange
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...ProjectPageHeader_stats
    __isNode: __typename
    id
  }
}

fragment ProjectPageHeader_stats on Project {
  traceCount(timeRange: $timeRange)
  tokenCountTotal(timeRange: $timeRange)
  latencyMsP50: latencyMsQuantile(probability: 0.5, timeRange: $timeRange)
  latencyMsP99: latencyMsQuantile(probability: 0.99, timeRange: $timeRange)
  spanAnnotationNames
  documentEvaluationNames
  id
}
`}}}();Sr.hash="dcce9d160db90e2b5c51eef9971101a4";const vr=function(){var n={kind:"Variable",name:"timeRange",variableName:"timeRange"},a=[n];return{argumentDefinitions:[{kind:"RootArgument",name:"timeRange"}],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:["node"],operation:Sr,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"ProjectPageHeader_stats",selections:[{alias:null,args:a,kind:"ScalarField",name:"traceCount",storageKey:null},{alias:null,args:a,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:"latencyMsP50",args:[{kind:"Literal",name:"probability",value:.5},n],kind:"ScalarField",name:"latencyMsQuantile",storageKey:null},{alias:"latencyMsP99",args:[{kind:"Literal",name:"probability",value:.99},n],kind:"ScalarField",name:"latencyMsQuantile",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"spanAnnotationNames",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"documentEvaluationNames",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],type:"Project",abstractKey:null}}();vr.hash="dcce9d160db90e2b5c51eef9971101a4";const Cr=m.createContext(null);function aa(){const n=Se.useContext(Cr);if(n===null)throw new Error("useStreamState must be used within a StreamStateProvider");return n}function ap({initialFetchKey:n="initial",children:a}){const t=Ae(c=>c.traceStreamingEnabled),l=Ae(c=>c.setTraceStreamingEnabled),[i,r]=m.useState(n),s=m.useCallback(c=>{m.startTransition(()=>{r(c)})},[r]);return e(Cr.Provider,{value:{isStreaming:t,setIsStreaming:l,fetchKey:i,setFetchKey:s},children:a})}const Fr=function(){var n={defaultValue:null,kind:"LocalArgument",name:"annotationName"},a={defaultValue:null,kind:"LocalArgument",name:"id"},t={defaultValue:null,kind:"LocalArgument",name:"timeRange"},l=[{kind:"Variable",name:"id",variableName:"id"}],i=[{kind:"Variable",name:"annotationName",variableName:"annotationName"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}];return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"AnnotationSummaryValueQuery",selections:[{alias:null,args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:i,kind:"FragmentSpread",name:"AnnotationSummaryValueFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,t,a],kind:"Operation",name:"AnnotationSummaryValueQuery",selections:[{alias:null,args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{kind:"InlineFragment",selections:[{alias:null,args:i,concreteType:"AnnotationSummary",kind:"LinkedField",name:"spanAnnotationSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"LabelFraction",kind:"LinkedField",name:"labelFractions",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"fraction",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"meanScore",storageKey:null}],storageKey:null}],type:"Project",abstractKey:null}],storageKey:null}]},params:{cacheID:"bae90b7000aa37d37050070d8504b41c",id:null,metadata:{},name:"AnnotationSummaryValueQuery",operationKind:"query",text:`query AnnotationSummaryValueQuery(
  $annotationName: String!
  $timeRange: TimeRange!
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...AnnotationSummaryValueFragment_4BTVrq
    __isNode: __typename
    id
  }
}

fragment AnnotationSummaryValueFragment_4BTVrq on Project {
  spanAnnotationSummary(annotationName: $annotationName, timeRange: $timeRange) {
    labelFractions {
      label
      fraction
    }
    meanScore
  }
  id
}
`}}}();Fr.hash="0a8e190e4d87acc87c161366f330e3af";const Kr={argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"annotationName"},{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:["node"],operation:Fr,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"AnnotationSummaryValueFragment",selections:[{alias:null,args:[{kind:"Variable",name:"annotationName",variableName:"annotationName"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],concreteType:"AnnotationSummary",kind:"LinkedField",name:"spanAnnotationSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"LabelFraction",kind:"LinkedField",name:"labelFractions",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"fraction",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"meanScore",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],type:"Project",abstractKey:null};Kr.hash="0a8e190e4d87acc87c161366f330e3af";const xr=function(){var n={defaultValue:null,kind:"LocalArgument",name:"annotationName"},a={defaultValue:null,kind:"LocalArgument",name:"id"},t={defaultValue:null,kind:"LocalArgument",name:"timeRange"},l=[{kind:"Variable",name:"id",variableName:"id"}],i=[{kind:"Variable",name:"annotationName",variableName:"annotationName"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}];return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"AnnotationSummaryQuery",selections:[{alias:"project",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:i,kind:"FragmentSpread",name:"AnnotationSummaryValueFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,n,t],kind:"Operation",name:"AnnotationSummaryQuery",selections:[{alias:"project",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{kind:"InlineFragment",selections:[{alias:null,args:i,concreteType:"AnnotationSummary",kind:"LinkedField",name:"spanAnnotationSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"LabelFraction",kind:"LinkedField",name:"labelFractions",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"fraction",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"meanScore",storageKey:null}],storageKey:null}],type:"Project",abstractKey:null}],storageKey:null}]},params:{cacheID:"88dfad5d25db7e03286a789f3ba37c75",id:null,metadata:{},name:"AnnotationSummaryQuery",operationKind:"query",text:`query AnnotationSummaryQuery(
  $id: GlobalID!
  $annotationName: String!
  $timeRange: TimeRange!
) {
  project: node(id: $id) {
    __typename
    ...AnnotationSummaryValueFragment_4BTVrq
    __isNode: __typename
    id
  }
}

fragment AnnotationSummaryValueFragment_4BTVrq on Project {
  spanAnnotationSummary(annotationName: $annotationName, timeRange: $timeRange) {
    labelFractions {
      label
      fraction
    }
    meanScore
  }
  id
}
`}}}();xr.hash="6a15ba35fe9e1e35aa4c517ab6309a2b";function tp({annotationName:n}){const{projectId:a}=Ue(),{timeRange:t}=Ha(),l=P.useLazyLoadQuery(xr,{annotationName:n,id:a,timeRange:{start:t.start.toISOString(),end:t.end.toISOString()}});return o(h,{direction:"column",flex:"none",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:n}),e(m.Suspense,{fallback:e(x,{textSize:"xlarge",children:"--"}),children:e(lp,{annotationName:n,project:l.project})})]})}function lp(n){var f,k;const{project:a,annotationName:t}=n,{fetchKey:l}=aa(),[i,r]=P.useRefetchableFragment(Kr,a);m.useEffect(()=>{m.startTransition(()=>{r({},{fetchPolicy:"store-and-network"})})},[l,r]);const s=dn(),d=[jl(t),s.default,s.gray600,s.gray400,s.gray200],u=(f=i==null?void 0:i.spanAnnotationSummary)==null?void 0:f.meanScore,y=(k=i==null?void 0:i.spanAnnotationSummary)==null?void 0:k.labelFractions,g=typeof u=="number",p=Array.isArray(y)&&y.length>0;return!g&&!p?e(x,{textSize:"xlarge",children:"--"}):o(pe,{delay:0,placement:"bottom",children:[e(Oe,{children:o(h,{direction:"row",alignItems:"center",gap:"size-50",children:[p?e(Ac,{width:24,height:24,children:e(Mc,{data:y,dataKey:"fraction",nameKey:"label",cx:"50%",cy:"50%",innerRadius:8,outerRadius:11,strokeWidth:0,stroke:"transparent",children:y.map((b,S)=>e(Nc,{fill:d[S%d.length]},`cell-${S}`))})}):null,e(x,{textSize:"xlarge",children:g?un(u):"--"})]})}),e(ka,{children:e(F,{width:"size-2400",children:o(h,{direction:"column",gap:"size-50",children:[p&&e("ul",{children:y.map((b,S)=>e("li",{children:e(Le,{color:d[S%d.length],name:b.label,shape:"square",value:ql(b.fraction*100)})},b.label))}),p&&g?e(Ua,{}):null,g?o(h,{direction:"row",justifyContent:"space-between",children:[e(x,{children:"mean"}),e(x,{children:un(u)})]}):null]})})})]})}const Tr=function(){var n={defaultValue:null,kind:"LocalArgument",name:"evaluationName"},a={defaultValue:null,kind:"LocalArgument",name:"id"},t={defaultValue:null,kind:"LocalArgument",name:"timeRange"},l=[{kind:"Variable",name:"id",variableName:"id"}],i=[{kind:"Variable",name:"evaluationName",variableName:"evaluationName"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}];return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"DocumentEvaluationSummaryValueQuery",selections:[{alias:null,args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:i,kind:"FragmentSpread",name:"DocumentEvaluationSummaryValueFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,t,a],kind:"Operation",name:"DocumentEvaluationSummaryValueQuery",selections:[{alias:null,args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{kind:"InlineFragment",selections:[{alias:null,args:i,concreteType:"DocumentEvaluationSummary",kind:"LinkedField",name:"documentEvaluationSummary",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"averageNdcg",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"averagePrecision",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"meanReciprocalRank",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hitRate",storageKey:null}],storageKey:null}],type:"Project",abstractKey:null}],storageKey:null}]},params:{cacheID:"60d7798d88e1408e6b6b0bebdc1716f5",id:null,metadata:{},name:"DocumentEvaluationSummaryValueQuery",operationKind:"query",text:`query DocumentEvaluationSummaryValueQuery(
  $evaluationName: String!
  $timeRange: TimeRange!
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...DocumentEvaluationSummaryValueFragment_1dJL9N
    __isNode: __typename
    id
  }
}

fragment DocumentEvaluationSummaryValueFragment_1dJL9N on Project {
  documentEvaluationSummary(evaluationName: $evaluationName, timeRange: $timeRange) {
    averageNdcg
    averagePrecision
    meanReciprocalRank
    hitRate
  }
  id
}
`}}}();Tr.hash="15d0652aa260c80f62acec943f615d93";const Dr={argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"evaluationName"},{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:["node"],operation:Tr,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"DocumentEvaluationSummaryValueFragment",selections:[{alias:null,args:[{kind:"Variable",name:"evaluationName",variableName:"evaluationName"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],concreteType:"DocumentEvaluationSummary",kind:"LinkedField",name:"documentEvaluationSummary",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"averageNdcg",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"averagePrecision",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"meanReciprocalRank",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hitRate",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],type:"Project",abstractKey:null};Dr.hash="15d0652aa260c80f62acec943f615d93";const Ir=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"evaluationName"},{defaultValue:null,kind:"LocalArgument",name:"id"},{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t=[{kind:"Variable",name:"evaluationName",variableName:"evaluationName"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"DocumentEvaluationSummaryQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:t,kind:"FragmentSpread",name:"DocumentEvaluationSummaryValueFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"DocumentEvaluationSummaryQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{kind:"InlineFragment",selections:[{alias:null,args:t,concreteType:"DocumentEvaluationSummary",kind:"LinkedField",name:"documentEvaluationSummary",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"averageNdcg",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"averagePrecision",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"meanReciprocalRank",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hitRate",storageKey:null}],storageKey:null}],type:"Project",abstractKey:null}],storageKey:null}]},params:{cacheID:"3ebd1cf66ef8f31c995ec6aae6505e94",id:null,metadata:{},name:"DocumentEvaluationSummaryQuery",operationKind:"query",text:`query DocumentEvaluationSummaryQuery(
  $evaluationName: String!
  $id: GlobalID!
  $timeRange: TimeRange!
) {
  project: node(id: $id) {
    __typename
    ...DocumentEvaluationSummaryValueFragment_1dJL9N
    __isNode: __typename
    id
  }
}

fragment DocumentEvaluationSummaryValueFragment_1dJL9N on Project {
  documentEvaluationSummary(evaluationName: $evaluationName, timeRange: $timeRange) {
    averageNdcg
    averagePrecision
    meanReciprocalRank
    hitRate
  }
  id
}
`}}}();Ir.hash="4d50474ffa9b9e4a68d07f6e0777c144";function ip({evaluationName:n}){const{projectId:a}=Ue(),{timeRange:t}=Ha(),l=P.useLazyLoadQuery(Ir,{id:a,evaluationName:n,timeRange:{start:t.start.toISOString(),end:t.end.toISOString()}});return o(h,{direction:"column",flex:"none",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:n}),e(m.Suspense,{fallback:e(x,{textSize:"xlarge",children:"--"}),children:e(rp,{evaluationName:n,project:l==null?void 0:l.project})})]})}function rp(n){var u,y,g,p;const{project:a}=n,{fetchKey:t}=aa(),[l,i]=P.useRefetchableFragment(Dr,a);m.useEffect(()=>{m.startTransition(()=>{i({},{fetchPolicy:"store-and-network"})})},[t,i]);const r=(u=l==null?void 0:l.documentEvaluationSummary)==null?void 0:u.averageNdcg,s=(y=l==null?void 0:l.documentEvaluationSummary)==null?void 0:y.averagePrecision,c=(g=l==null?void 0:l.documentEvaluationSummary)==null?void 0:g.hitRate,d=(p=l==null?void 0:l.documentEvaluationSummary)==null?void 0:p.meanReciprocalRank;return o(pe,{delay:0,placement:"bottom",children:[e(Oe,{children:e(h,{direction:"row",alignItems:"center",gap:"size-50",height:"28px",children:o(G,{children:[e(ze,{metric:"ndcg",score:r},"ndcg"),e(ze,{metric:"precision",score:s},"precision"),e(ze,{metric:"hit rate",score:c},"hit")]})})}),e(ka,{children:e(F,{width:"size-2400",children:o(h,{direction:"column",children:[o(h,{justifyContent:"space-between",children:[e(x,{children:"average ndcg"}),e(x,{children:typeof r=="number"?un(r):"--"})]}),o(h,{justifyContent:"space-between",children:[e(x,{children:"average precision"}),e(x,{children:typeof s=="number"?un(s):"--"})]}),o(h,{justifyContent:"space-between",children:[e(x,{children:"mean reciprocal rank"}),e(x,{children:typeof d=="number"?un(d):"--"})]}),o(h,{justifyContent:"space-between",children:[e(x,{children:"hit rate"}),e(x,{children:typeof c=="number"?un(c):"--"})]})]})})})]})}function sp(n){const{extra:a}=n,{fetchKey:t}=aa(),[l,i]=P.useRefetchableFragment(vr,n.project);m.useEffect(()=>{m.startTransition(()=>{i({},{fetchPolicy:"store-and-network"})})},[t,i]);const r=l==null?void 0:l.latencyMsP50,s=l==null?void 0:l.latencyMsP99,c=l==null?void 0:l.tokenCountTotal,d=l==null?void 0:l.spanAnnotationNames,u=l==null?void 0:l.documentEvaluationNames;return e(F,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-200",paddingBottom:"size-50",flex:"none",children:o(h,{direction:"row",justifyContent:"space-between",alignItems:"center",children:[e("div",{css:C`
            overflow-x: auto;
            overflow-y: hidden;
            flex: 1 1 auto;
            background-image: linear-gradient(
                to right,
                var(--ac-global-color-grey-75),
                var(--ac-global-color-grey-75)
              ),
              linear-gradient(
                to right,
                var(--ac-global-color-grey-75),
                var(--ac-global-color-grey-75)
              ),
              linear-gradient(
                to right,
                rgba(var(--ac-global-color-grey-300-rgb), 0.9),
                rgba(var(--ac-global-color-grey-300-rgb), 0)
              ),
              linear-gradient(
                to left,
                rgba(var(--ac-global-color-grey-300-rgb), 0.9),
                rgba(var(--ac-global-color-grey-300-rgb), 0)
              );
            background-repeat: no-repeat;
            background-size:
              32px 100%,
              32px 100%,
              32px 100%,
              32px 100%;
            background-position:
              left center,
              right center,
              left center,
              right center;
            background-attachment: local, local, scroll, scroll;
          `,children:o(h,{direction:"row",gap:"size-400",alignItems:"center",children:[o(h,{direction:"column",flex:"none",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:"Total Traces"}),e(x,{textSize:"xlarge",children:Pn(l==null?void 0:l.traceCount)})]}),o(h,{direction:"column",flex:"none",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:"Total Tokens"}),e(x,{textSize:"xlarge",children:Pn(c)})]}),o(h,{direction:"column",flex:"none",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:"Latency P50"}),r!=null?e(Re,{latencyMs:r,textSize:"xlarge"}):e(x,{textSize:"xlarge",children:"--"})]}),o(h,{direction:"column",flex:"none",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:"Latency P99"}),s!=null?e(Re,{latencyMs:s,textSize:"xlarge"}):e(x,{textSize:"xlarge",children:"--"})]}),d.map(y=>e(tp,{annotationName:y},y)),u.map(y=>e(ip,{evaluationName:y},`document-${y}`))]})}),e(F,{flex:"none",paddingStart:"size-100",children:a})]})})}const Pr=m.createContext(null);function Lr(){const n=m.useContext(Pr);if(n===null)throw new Error("useSpanFilterCondition must be used within a SpanFilterConditionProvider");return n}function rl(n){const[a,t]=m.useState(""),l=m.useCallback(r=>{m.startTransition(()=>{t(r)})},[]),i=m.useCallback(r=>{m.startTransition(()=>{a.length>0?t(a+" and "+r):t(r)})},[a]);return e(Pr.Provider,{value:{filterCondition:a,setFilterCondition:l,appendFilterCondition:i},children:n.children})}const Er=function(){var n={defaultValue:null,kind:"LocalArgument",name:"after"},a={defaultValue:null,kind:"LocalArgument",name:"filterCondition"},t={defaultValue:50,kind:"LocalArgument",name:"first"},l={defaultValue:null,kind:"LocalArgument",name:"id"},i={defaultValue:{col:"startTime",dir:"desc"},kind:"LocalArgument",name:"sort"},r={defaultValue:null,kind:"LocalArgument",name:"timeRange"},s=[{kind:"Variable",name:"id",variableName:"id"}],c={kind:"Variable",name:"after",variableName:"after"},d={kind:"Variable",name:"filterCondition",variableName:"filterCondition"},u={kind:"Variable",name:"first",variableName:"first"},y={kind:"Variable",name:"sort",variableName:"sort"},g={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},p={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},f={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},k=[c,d,u,y,{kind:"Variable",name:"timeRange",variableName:"timeRange"}],b=[{alias:"value",args:null,kind:"ScalarField",name:"truncatedValue",storageKey:null}];return{fragment:{argumentDefinitions:[n,a,t,l,i,r],kind:"Fragment",metadata:null,name:"SpansTableSpansQuery",selections:[{alias:null,args:s,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:[c,d,u,y],kind:"FragmentSpread",name:"SpansTable_spans"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,a,t,i,r,l],kind:"Operation",name:"SpansTableSpansQuery",selections:[{alias:null,args:s,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[g,{kind:"TypeDiscriminator",abstractKey:"__isNode"},p,{kind:"InlineFragment",selections:[f,{alias:null,args:null,kind:"ScalarField",name:"spanAnnotationNames",storageKey:null},{alias:null,args:k,concreteType:"SpanConnection",kind:"LinkedField",name:"spans",plural:!1,selections:[{alias:null,args:null,concreteType:"SpanEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"span",args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[p,{alias:null,args:null,kind:"ScalarField",name:"spanKind",storageKey:null},f,{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"statusCode",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},{alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"spanId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"input",plural:!1,selections:b,storageKey:null},{alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"output",plural:!1,selections:b,storageKey:null},{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[f,{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"DocumentRetrievalMetrics",kind:"LinkedField",name:"documentRetrievalMetrics",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"evaluationName",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"ndcg",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"precision",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hit",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[g],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:k,filters:["sort","filterCondition","timeRange"],handle:"connection",key:"SpansTable_spans",kind:"LinkedHandle",name:"spans"}],type:"Project",abstractKey:null}],storageKey:null}]},params:{cacheID:"21dc6f490cf749c02bc20bcdb43c199c",id:null,metadata:{},name:"SpansTableSpansQuery",operationKind:"query",text:`query SpansTableSpansQuery(
  $after: String = null
  $filterCondition: String = null
  $first: Int = 50
  $sort: SpanSort = {col: startTime, dir: desc}
  $timeRange: TimeRange
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...SpansTable_spans_1XEuU
    __isNode: __typename
    id
  }
}

fragment SpanColumnSelector_annotations on Project {
  spanAnnotationNames
}

fragment SpansTable_spans_1XEuU on Project {
  name
  ...SpanColumnSelector_annotations
  spans(first: $first, after: $after, sort: $sort, filterCondition: $filterCondition, timeRange: $timeRange) {
    edges {
      span: node {
        id
        spanKind
        name
        metadata
        statusCode
        startTime
        latencyMs
        tokenCountTotal
        tokenCountPrompt
        tokenCountCompletion
        context {
          spanId
          traceId
        }
        input {
          value: truncatedValue
        }
        output {
          value: truncatedValue
        }
        spanAnnotations {
          name
          label
          score
          annotatorKind
        }
        documentRetrievalMetrics {
          evaluationName
          ndcg
          precision
          hit
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();Er.hash="4827989f55b1c0bd269253b6bc977439";const wr=function(){var n=["spans"],a={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l=[{alias:"value",args:null,kind:"ScalarField",name:"truncatedValue",storageKey:null}];return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:null,kind:"LocalArgument",name:"filterCondition"},{defaultValue:50,kind:"LocalArgument",name:"first"},{defaultValue:{col:"startTime",dir:"desc"},kind:"LocalArgument",name:"sort"},{kind:"RootArgument",name:"timeRange"}],kind:"Fragment",metadata:{connection:[{count:"first",cursor:"after",direction:"forward",path:n}],refetch:{connection:{forward:{count:"first",cursor:"after"},backward:null,path:n},fragmentPathInResult:["node"],operation:Er,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"SpansTable_spans",selections:[a,{args:null,kind:"FragmentSpread",name:"SpanColumnSelector_annotations"},{alias:"spans",args:[{kind:"Variable",name:"filterCondition",variableName:"filterCondition"},{kind:"Variable",name:"sort",variableName:"sort"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],concreteType:"SpanConnection",kind:"LinkedField",name:"__SpansTable_spans_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"SpanEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"span",args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"spanKind",storageKey:null},a,{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"statusCode",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},{alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"spanId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"input",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"output",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"DocumentRetrievalMetrics",kind:"LinkedField",name:"documentRetrievalMetrics",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"evaluationName",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"ndcg",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"precision",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hit",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},t],type:"Project",abstractKey:null}}();wr.hash="4827989f55b1c0bd269253b6bc977439";const _r=m.createContext(null);function op({children:n,...a}){const[t]=m.useState(()=>tc(a));return e(_r.Provider,{value:t,children:n})}function pn(n,a){const t=Se.useContext(_r);if(!t)throw new Error("Missing TracingContext.Provider in the tree");return ya(t,n,a)}function Rr(n){const{appendFilterCondition:a}=Lr(),{annotation:t}=n,{name:l,label:i,score:r}=t,s=m.useMemo(()=>{const c=[];return i!=null&&(c.push({filterName:"Match label",filterCondition:`annotations['${l}'].label == "${i}"`}),c.push({filterName:"Exclude label",filterCondition:`annotations['${l}'].label != "${i}"`})),typeof r=="number"&&(c.push({filterName:"Greater than score",filterCondition:`annotations['${l}'].score > ${r}`}),c.push({filterName:"Less than score",filterCondition:`annotations['${l}'].score < ${r}`}),c.push({filterName:"Equals score",filterCondition:`annotations['${l}'].score == ${r}`})),c},[l,i,r]);return o(F,{borderStartWidth:"thin",borderColor:"dark",paddingStart:"size-200",paddingEnd:"size-100",marginStart:"size-200",width:300,children:[e(x,{textSize:"large",weight:"heavy",children:"Filters"}),e("ul",{css:C`
          display: flex;
          flex-direction: row;
          gap: var(--ac-global-dimension-size-100);
          color: var(--ac-global-color-primary);
          padding: var(--ac-global-dimension-size-100) 0;
          flex-wrap: wrap;
        `,children:s.map(c=>e("li",{children:e(dp,{onClick:()=>{a(c.filterCondition)},children:c.filterName})},c.filterName))})]})}function dp({onClick:n,children:a}){return e("button",{onClick:t=>{t.preventDefault(),t.stopPropagation(),n()},className:"button--reset",css:C`
        color: var(--ac-global-text-color-900);
        border: 1px solid var(--ac-global-color-gray-200);
        border-radius: 4px;
        padding: var(--ac-global-dimension-size-50)
          var(--ac-global-dimension-size-100);
        cursor: pointer;
        transition: background-color 0.2s;
        &:hover {
          background-color: var(--ac-global-color-gray-300);
        }
      `,children:a})}function cp({projectName:n}){const[a,t]=m.useState("Python");return e(Y,{title:"Send Traces to this Project",size:"L",children:o(F,{padding:"size-400",overflow:"auto",children:[e(F,{paddingBottom:"size-100",children:e(Ul,{language:a,onChange:t})}),a==="Python"?e(Bl,{projectName:n}):e(Hl,{projectName:n})]})})}function Ar({projectName:n}){const[a,t]=m.useState(null),l=()=>{t(e(cp,{projectName:n}))};return o("tbody",{className:"is-empty",children:[e("tr",{children:e("td",{colSpan:100,css:i=>C`
            text-align: center;
            padding: ${i.spacing.margin24}px ${i.spacing.margin24}px !important;
          `,children:o(h,{direction:"column",gap:"size-200",alignItems:"center",children:["No traces found for this project",e(z,{variant:"default",icon:e(L,{svg:e(D.PlayCircleOutline,{})}),onClick:l,children:"Get Started"})]})})}),e(ae,{onDismiss:()=>t(null),isDismissable:!0,type:"slideOver",children:a})]})}const Mr={argumentDefinitions:[],kind:"Fragment",metadata:null,name:"SpanColumnSelector_annotations",selections:[{alias:null,args:null,kind:"ScalarField",name:"spanAnnotationNames",storageKey:null}],type:"Project",abstractKey:null};Mr.hash="ad01e6897ad1ea779eb346d85783b8b4";const up=["spanKind","name"];function Nr(n){return e(vt,{menu:e(mp,{...n}),triggerProps:{placement:"bottom end"},children:o(h,{direction:"row",alignItems:"center",gap:"size-100",children:[e(L,{svg:e(D.Column,{})}),"Columns"]})})}const $a=C`
  padding: var(--ac-global-dimension-static-size-50)
    var(--ac-global-dimension-static-size-100);
  label {
    display: flex;
    align-items: center;
    gap: var(--ac-global-dimension-static-size-100);
  }
`;function mp(n){const{columns:a}=n,t=pn(d=>d.columnVisibility),l=pn(d=>d.setColumnVisibility),i=m.useMemo(()=>a.filter(d=>!up.includes(d.id)),[a]),r=m.useMemo(()=>i.every(d=>{const u=t[d.id];return u??!0}),[i,t]),s=m.useCallback(d=>{const{name:u,checked:y}=d.target;l({...t,[u]:y})},[t,l]),c=m.useCallback(d=>{const{checked:u}=d.target,y=i.reduce((g,p)=>({...g,[p.id]:u}),{});l(y)},[i,l]);return e("div",{css:C`
        overflow-y: auto;
        max-height: calc(100vh - 200px);
      `,children:o(F,{paddingTop:"size-50",paddingBottom:"size-50",children:[e(F,{borderBottomColor:"dark",borderBottomWidth:"thin",paddingBottom:"size-50",children:e("div",{css:$a,children:o("label",{children:[e("input",{type:"checkbox",name:"toggle-all",checked:r,onChange:c}),"span columns"]})})}),e("ul",{children:i.map(d=>{const u=t[d.id],y=u??!0,g=typeof d.columnDef.header=="string"?d.columnDef.header:d.id;return e("li",{css:$a,children:o("label",{children:[e("input",{type:"checkbox",name:d.id,checked:y,onChange:s}),g]})},d.id)})}),e(gp,{...n})]})})}function gp({query:n}){const a=P.useFragment(Mr,n),t=pn(s=>s.annotationColumnVisibility),l=pn(s=>s.setAnnotationColumnVisibility),i=m.useMemo(()=>a.spanAnnotationNames.every(s=>t[s]||!1),[a.spanAnnotationNames,t]),r=m.useCallback(()=>{const s=a.spanAnnotationNames.reduce((c,d)=>({...c,[d]:!i}),{});l(s)},[a.spanAnnotationNames,l,i]);return o("section",{children:[e(F,{paddingTop:"size-50",paddingBottom:"size-50",borderColor:"dark",borderTopWidth:"thin",borderBottomWidth:"thin",children:e("div",{css:$a,children:o("label",{children:[e("input",{type:"checkbox",name:"toggle-evaluations-all",checked:i,onChange:r}),"feedback"]})})}),e("ul",{children:a.spanAnnotationNames.map(s=>{const c=t[s]??!1;return e("li",{css:$a,children:o("label",{children:[e("input",{type:"checkbox",name:s,checked:c,onChange:()=>{l({...t,[s]:!c})}}),s]})},s)})})]})}const zr=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"condition"},{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={kind:"InlineFragment",selections:[{alias:null,args:[{kind:"Variable",name:"condition",variableName:"condition"}],concreteType:"ValidationResult",kind:"LinkedField",name:"validateSpanFilterCondition",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"isValid",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"errorMessage",storageKey:null}],storageKey:null}],type:"Project",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SpanFilterConditionFieldValidationQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SpanFilterConditionFieldValidationQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t,{kind:"TypeDiscriminator",abstractKey:"__isNode"},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"29583e7ec666cef832dc7effb9e75678",id:null,metadata:{},name:"SpanFilterConditionFieldValidationQuery",operationKind:"query",text:`query SpanFilterConditionFieldValidationQuery(
  $condition: String!
  $id: GlobalID!
) {
  project: node(id: $id) {
    __typename
    ... on Project {
      validateSpanFilterCondition(condition: $condition) {
        isValid
        errorMessage
      }
    }
    __isNode: __typename
    id
  }
}
`}}}();zr.hash="22836f192038b0c40201d3b25aad65b4";const Vr=C`
  flex: 1 1 auto;
  .cm-content {
    padding: var(--ac-global-dimension-static-size-100) 0;
  }
  .cm-editor {
    background-color: transparent;
  }
  .cm-focused {
    outline: none;
  }
  .cm-selectionLayer .cm-selectionBackground {
    background: var(--ac-global-color-cyan-400) !important;
  }
`,$r=C`
  border-width: var(--ac-global-border-size-thin);
  border-style: solid;
  border-color: var(--ac-global-input-field-border-color);
  border-radius: var(--ac-global-rounding-small);
  background-color: var(--ac-global-input-field-background-color);
  transition: all 0.2s ease-in-out;
  overflow-x: hidden;
  &:hover,
  &[data-is-focused="true"] {
    border-color: var(--ac-global-input-field-border-color-active);
    background-color: var(--ac-global-input-field-background-color-active);
  }
  &[data-is-invalid="true"] {
    border-color: var(--ac-global-color-danger);
  }
  box-sizing: border-box;
`;function pp(n){const a=n.matchBefore(/\w*/);return!a||a.from==a.to&&!n.explicit?null:{from:a.from,options:[{label:"span_kind",type:"variable",info:"The span variant: CHAIN, LLM, RETRIEVER, TOOL, etc."},{label:"status_code",type:"variable",info:"The span status: OK, UNSET, or ERROR"},{label:"input.value",type:"variable",info:"The input value of a span, typically a query"},{label:"output.value",type:"variable",info:"The output value of a span, typically a response"},{label:"name",type:"variable",info:"The name given to a span - e.x. OpenAI"},{label:"latency_ms",type:"variable",info:"Latency (i.e. duration) in milliseconds"},{label:"cumulative_token_count.prompt",type:"variable",info:"Sum of token count for prompt from self and all child spans"},{label:"cumulative_token_count.completion",type:"variable",info:"Sum of token count for completion from self and all child spans"},{label:"cumulative_token_count.total",type:"variable",info:"Sum of token count total (prompt + completion) from self and all child spans"},{label:"llm spans",type:"text",apply:"span_kind == 'LLM'",detail:"macro"},{label:"retriever spans",type:"text",apply:"span_kind == 'RETRIEVER'",detail:"macro"},{label:"search input",type:"text",apply:"'' in input.value",detail:"macro"},{label:"search output",type:"text",apply:"'' in output.value",detail:"macro"},{label:"status_code error",type:"text",apply:"status_code == 'ERROR'",detail:"macro"},{label:"Latency >= 10s",type:"text",apply:"latency_ms >= 10_000",detail:"macro"},{label:"Tokens >= 1,000",type:"text",apply:"llm.token_count.total >= 1_000",detail:"macro"},{label:"Hallucinations",type:"text",apply:"annotations['Hallucination'].label == 'hallucinated'",detail:"macro"},{label:"Annotations",type:"text",apply:"annotations['Hallucination'].label == 'hallucinated'",detail:"macro"},{label:"Metadata",type:"text",apply:"metadata['topic'] == 'agent'",detail:"macro"},{label:"Substring",type:"text",apply:"'agent' in input.value",detail:"macro"}]}}async function yp(n,a){if(!n)return{isValid:!0,errorMessage:null};const t=await ht.fetchQuery(Ne,zr,{condition:n,id:a}).toPromise();if(!t)throw new Error("Filter condition validation is null");return t.project.validateSpanFilterCondition}const fp=[Vc.of([{key:"Enter",run:n=>!0}]),Et(),$c({override:[pp]})];function Or(n){const{onValidCondition:a,placeholder:t="filter condition (e.x. span_kind == 'LLM')"}=n,[l,i]=m.useState(!1),[r,s]=m.useState(""),{filterCondition:c,setFilterCondition:d,appendFilterCondition:u}=Lr(),y=m.useDeferredValue(c),{theme:g}=Zn(),p=g==="dark"?xa:void 0,{projectId:f}=Ue();m.useEffect(()=>{yp(y,f).then(S=>{S!=null&&S.isValid?(s(""),m.startTransition(()=>{a(y)})):s((S==null?void 0:S.errorMessage)??"Invalid filter condition")})},[a,y,f]);const k=r!=="",b=c!=="";return o("div",{"data-is-focused":l,"data-is-invalid":k,className:"span-filter-condition-field",css:$r,children:[o(h,{direction:"row",children:[e(sd,{children:e(L,{svg:e(D.Search,{})})}),e(Ka,{css:Vr,indentWithTab:!1,basicSetup:{lineNumbers:!1,foldGutter:!1,bracketMatching:!0,syntaxHighlighting:!0,highlightActiveLine:!1,highlightActiveLineGutter:!1,defaultKeymap:!1},onFocus:()=>i(!0),onBlur:()=>i(!1),value:c,onChange:d,height:"36px",width:"100%",theme:p,placeholder:t,extensions:fp}),e("button",{css:C`
            margin-right: var(--ac-global-dimension-static-size-100);
            color: var(--ac-global-text-color-700);
            visibility: ${b?"visible":"hidden"};
          `,onClick:()=>d(""),className:"button--reset",children:e(L,{svg:e(D.CloseCircleOutline,{})})}),o(Bn,{placement:"bottom right",children:[e(Oe,{children:e("button",{css:C`
                color: var(--ac-global-text-color-700);
                background-color: var(--ac-global-color-grey-400);
                padding-left: var(--ac-global-dimension-static-size-100);
                padding-right: var(--ac-global-dimension-static-size-100);
                height: 100%;
              `,className:"button--reset",children:e(L,{svg:e(D.PlusCircleOutline,{})})})}),e(hp,{onAddFilterConditionSnippet:u})]})]}),o(pe,{isOpen:k&&l,placement:"bottom",children:[e(Oe,{children:e("div",{})}),e(ka,{children:r!=""?e(x,{color:"danger",children:r}):e(x,{color:"success",children:"Valid Expression"})})]})]})}function hp(n){const{onAddFilterConditionSnippet:a}=n;return e(F,{width:"500px",paddingTop:"size-200",paddingStart:"size-200",paddingEnd:"size-200",borderRadius:"medium",borderWidth:"thin",borderColor:"light",backgroundColor:"light",children:o(we,{children:[e(Fn,{label:"filter by kind",initialSnippet:"span_kind == 'LLM'",onAddFilterConditionSnippet:a},"kind"),e(Fn,{label:"filter by token count",initialSnippet:"cumulative_token_count.total > 1000",onAddFilterConditionSnippet:a},"token_count"),e(Fn,{label:"filter by annotation label",initialSnippet:"annotations['Hallucination'].label == 'hallucinated'",onAddFilterConditionSnippet:a},"annotation_label"),e(Fn,{label:"filter by evaluation label",initialSnippet:"evals['Hallucination'].label == 'hallucinated'",onAddFilterConditionSnippet:a},"eval_label"),e(Fn,{label:"filter by evaluation score",initialSnippet:"evals['Hallucination'].score < 1",onAddFilterConditionSnippet:a},"eval_score"),e(Fn,{label:"filter by metadata",initialSnippet:"metadata['topic'] == 'agent'",onAddFilterConditionSnippet:a},"metadata"),e(Fn,{label:"filter by substring",initialSnippet:"'agent' in input.value",onAddFilterConditionSnippet:a},"substring")]})})}function Fn(n){const{initialSnippet:a,onAddFilterConditionSnippet:t}=n,[l,i]=m.useState(a),{theme:r}=Zn(),s=r==="light"?void 0:xa;return e(Mn,{label:n.label,children:o(h,{direction:"row",width:"100%",gap:"size-100",children:[e("div",{css:C($r,C`
              flex: 1 1 auto;
            `),children:e(Ka,{value:l,basicSetup:{lineNumbers:!1,foldGutter:!1,bracketMatching:!0,syntaxHighlighting:!0,highlightActiveLine:!1,highlightActiveLineGutter:!1},extensions:[Et()],editable:!0,onChange:i,theme:s,css:Vr})}),e(z,{title:"Add to filter condition",variant:"default",onClick:()=>t(l),icon:e(L,{svg:e(D.PlusCircleOutline,{})})})]})})}const Qr=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"addSpansToDataset",plural:!1,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"dataset",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SpanSelectionToolbarAddSpansToDatasetMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SpanSelectionToolbarAddSpansToDatasetMutation",selections:a},params:{cacheID:"1c694540190478b8fba8ef3c0cacf30c",id:null,metadata:{},name:"SpanSelectionToolbarAddSpansToDatasetMutation",operationKind:"mutation",text:`mutation SpanSelectionToolbarAddSpansToDatasetMutation(
  $input: AddSpansToDatasetInput!
) {
  addSpansToDataset(input: $input) {
    dataset {
      id
    }
  }
}
`}}}();Qr.hash="5e3aef907285081a06c0e0360045e865";const jr={fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"DatasetSelectorPopoverContentDatasetsQuery",selections:[{args:null,kind:"FragmentSpread",name:"DatasetSelectorPopoverContent_datasets"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"DatasetSelectorPopoverContentDatasetsQuery",selections:[{alias:null,args:null,concreteType:"DatasetConnection",kind:"LinkedField",name:"datasets",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"dataset",args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"6d459b61a36b99979f025742892941f9",id:null,metadata:{},name:"DatasetSelectorPopoverContentDatasetsQuery",operationKind:"query",text:`query DatasetSelectorPopoverContentDatasetsQuery {
  ...DatasetSelectorPopoverContent_datasets
}

fragment DatasetSelectorPopoverContent_datasets on Query {
  datasets {
    edges {
      dataset: node {
        id
        name
      }
    }
  }
}
`}};jr.hash="40d5267ad0ec2335a73ff2a4d05bbed1";const qr={argumentDefinitions:[],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:[],operation:jr}},name:"DatasetSelectorPopoverContent_datasets",selections:[{alias:null,args:null,concreteType:"DatasetConnection",kind:"LinkedField",name:"datasets",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"dataset",args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null};qr.hash="40d5267ad0ec2335a73ff2a4d05bbed1";const Ur={fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"DatasetSelectorPopoverContentQuery",selections:[{args:null,kind:"FragmentSpread",name:"DatasetSelectorPopoverContent_datasets"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"DatasetSelectorPopoverContentQuery",selections:[{alias:null,args:null,concreteType:"DatasetConnection",kind:"LinkedField",name:"datasets",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"dataset",args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"5fb28a402f330dd235295da21efea58b",id:null,metadata:{},name:"DatasetSelectorPopoverContentQuery",operationKind:"query",text:`query DatasetSelectorPopoverContentQuery {
  ...DatasetSelectorPopoverContent_datasets
}

fragment DatasetSelectorPopoverContent_datasets on Query {
  datasets {
    edges {
      dataset: node {
        id
        name
      }
    }
  }
}
`}};Ur.hash="7cd8a13144d97d2b5294f2a09c9e1351";function kp(n){const{onCreateNewDataset:a,onDatasetSelected:t}=n,[l,i]=m.useState(""),r=P.useLazyLoadQuery(Ur,{},{fetchPolicy:"network-only"});return o(q,{title:"Add to Dataset",variant:"compact",backgroundColor:"light",borderColor:"light",bodyStyle:{padding:0},extra:e(z,{variant:"default",size:"compact",onClick:a,children:"New Dataset"}),children:[e(F,{padding:"size-100",children:e(ee,{type:"search",placeholder:"Search datasets",addonBefore:e(L,{svg:e(D.Search,{})}),onChange:s=>{i(s)}})}),e(F,{borderTopWidth:"thin",borderColor:"light",children:e("div",{css:C`
            height: 400px;
            overflow-y: auto;
          `,children:e(bp,{query:r,search:l,onDatasetSelected:t})})})]})}function bp(n){const{search:a,onDatasetSelected:t}=n,[l]=P.useRefetchableFragment(qr,n.query),i=m.useMemo(()=>{let s=l.datasets.edges.map(c=>c.dataset);return a&&(s=s.filter(c=>c.name.toLowerCase().includes(a.toLowerCase()))),s},[a,l]);return i.length===0?e(F,{padding:"size-200",children:e(h,{direction:"column",justifyContent:"center",alignItems:"center",flex:"1 1 auto",children:e(x,{children:"No datasets found"})})}):e(Qa,{selectionMode:"single",onSelectionChange:s=>{if(typeof s=="object"){const c=Array.from(s);t(c[0])}},children:i.map(s=>e(le,{children:s.name},s.id))})}function Br(n){const a=ne(),[t,l]=m.useState(null),i=ve(),r=be(),[s,c]=m.useState(!1),{selectedSpans:d,onClearSelection:u}=n,[y,g]=P.useMutation(Qr),p=d.length!==1,f=m.useCallback(k=>{y({variables:{input:{datasetId:k,spanIds:d.map(b=>b.id)}},onCompleted:()=>{i({title:"Examples added to dataset",message:`${d.length} example${p?"s":""} have been added to the dataset.`,action:{text:"View dataset",onClick:()=>{a(`/datasets/${k}/examples`)}}}),u()},onError:b=>{r({title:"An error occurred",message:`Failed to add spans to dataset: ${b.message}`})}})},[y,d,i,p,u,a,r]);return o("div",{css:C`
        position: absolute;
        bottom: var(--ac-global-dimension-size-400);
        left: 50%;
        transform: translateX(-50%);
      `,children:[e(F,{backgroundColor:"light",padding:"size-200",borderColor:"light",borderWidth:"thin",borderRadius:"medium",minWidth:"size-6000",children:o(h,{direction:"row",justifyContent:"space-between",alignItems:"center",children:[e(x,{children:`${d.length} span${p?"s":""} selected`}),o(h,{direction:"row",gap:"size-100",children:[e(z,{variant:"default",size:"compact",onClick:u,children:"Cancel"}),o(Bn,{placement:"top end",crossOffset:300,isOpen:s,onOpenChange:k=>{c(k)},children:[e(z,{variant:"primary",size:"compact",icon:e(L,{svg:e(D.DatabaseOutline,{})}),loading:g,disabled:g,children:g?"Adding to dataset":"Add to dataset"}),e(m.Suspense,{children:e(kp,{onDatasetSelected:k=>{f(k),c(!1)},onCreateNewDataset:()=>{c(!1),l(e(Y,{title:"New Dataset",isDismissable:!0,onDismiss:()=>l(null),children:e(Gl,{onDatasetCreateError:()=>{r({title:"Dataset creation failed",message:"Failed to create dataset."})},onDatasetCreated:k=>{l(null),i({title:"Dataset created",message:`${k.name} has been successfully created.`}),c(!0)}})}))}})})]})]})]})}),e(ae,{onDismiss:()=>{l(null)},children:t})]})}const Hr=C`
  display: flex;
  flex-direction: column;
  flex: 1 1 auto;
  overflow: hidden;
  .span-filter-condition-field {
    flex: 1 1 auto;
  }

  // Style the column selector
  .ac-dropdown-button {
    min-width: var(--ac-global-dimension-static-size-300);
  }
`,pa="annotations",Xe=":",Gr={col:"startTime",dir:"desc"};function Wr(n){let a=null,t=null;if(n.id&&n.id.startsWith(pa)){const[,l,i]=n.id.split(Xe);t={attr:l,name:i}}else a=n.id;return{col:a,evalResultKey:t,dir:n.desc?"desc":"asc"}}const sl=50;function Sp(n){const{fetchKey:a}=aa(),t=m.useRef(null),[l,i]=m.useState({}),[r,s]=m.useState([]),[c,d]=m.useState(""),u=pn(N=>N.columnVisibility),y=ne(),{data:g,loadNext:p,hasNext:f,isLoadingNext:k,refetch:b}=P.usePaginationFragment(wr,n.project),S=pn(N=>N.annotationColumnVisibility),v=m.useMemo(()=>Object.keys(S).filter(N=>S[N]),[S]),I=m.useMemo(()=>g.spans.edges.map(({span:Q})=>Q),[g]),w=v.map(N=>({header:N,columns:[{header:"label",accessorKey:`${pa}${Xe}label${Xe}${N}`,cell:({row:Q})=>{const M=Q.original.spanAnnotations.find(U=>U.name===N);return M?M.label:null}},{header:"score",accessorKey:`${pa}${Xe}score${Xe}${N}`,cell:({row:Q})=>{const M=Q.original.spanAnnotations.find(U=>U.name===N);return M?M.score:null}}]})),R=[{header:()=>o(h,{direction:"row",gap:"size-50",children:[e("span",{children:"feedback"}),o(Hn,{children:[e(ge,{level:3,weight:"heavy",children:"Feedback"}),e(An,{children:"Feedback includes evaluations and human annotations logged via the API or set via the UI."})]})]}),accessorKey:"spanAnnotations",enableSorting:!1,cell:({row:N})=>o(h,{direction:"row",gap:"size-50",wrap:"wrap",children:[N.original.spanAnnotations.map(Q=>e(Sa,{annotation:Q,layout:"horizontal",width:"500px",extra:e(Rr,{annotation:Q}),children:e(yn,{annotation:Q,annotationDisplayPreference:"label"})},Q.name)),N.original.documentRetrievalMetrics.map(Q=>o(G,{children:[e(ze,{name:Q.evaluationName,metric:"ndcg",score:Q.ndcg},"ndcg"),e(ze,{name:Q.evaluationName,metric:"precision",score:Q.precision},"precision"),e(ze,{name:Q.evaluationName,metric:"hit",score:Q.hit},"hit")]}))]})},...w],K=[{id:"select",maxSize:10,header:({table:N})=>e(mn,{checked:N.getIsAllRowsSelected(),indeterminate:N.getIsSomeRowsSelected(),onChange:N.getToggleAllRowsSelectedHandler()}),cell:({row:N})=>e(mn,{checked:N.getIsSelected(),disabled:!N.getCanSelect(),indeterminate:N.getIsSomeSelected(),onChange:N.getToggleSelectedHandler()})},{header:"kind",accessorKey:"spanKind",maxSize:100,enableSorting:!1,cell:({getValue:N})=>e(Tt,{spanKind:N()})},{header:"name",accessorKey:"name",enableSorting:!1,cell:({getValue:N,row:Q})=>{const M=Q.original,{traceId:U}=M.context;return e(cn,{to:`traces/${U}?selectedSpanNodeId=${M.id}`,children:N()})}},{header:"input",accessorKey:"input.value",cell:Ke,enableSorting:!1},{header:"output",accessorKey:"output.value",cell:Ke,enableSorting:!1},{header:"metadata",accessorKey:"metadata",cell:Ke,enableSorting:!1},...R,{header:"start time",accessorKey:"startTime",cell:_e},{header:"latency",accessorKey:"latencyMs",cell:({getValue:N})=>{const Q=N();return Q===null||typeof Q!="number"?null:e(Re,{latencyMs:Q})}},{header:"total tokens",accessorKey:"tokenCountTotal",cell:({row:N,getValue:Q})=>{const M=Q();return M===null?"--":e(va,{tokenCountTotal:M,tokenCountPrompt:N.original.tokenCountPrompt||0,tokenCountCompletion:N.original.tokenCountCompletion||0})}},{header:"status",accessorKey:"statusCode",enableSorting:!1,cell:({getValue:N})=>e(Ba,{statusCode:N()})}];m.useEffect(()=>{const N=r[0];m.startTransition(()=>{b({sort:N?Wr(N):Gr,after:null,first:sl,filterCondition:c},{fetchPolicy:"store-and-network"})})},[r,b,c,a]);const T=m.useCallback(N=>{if(N){const{scrollHeight:Q,scrollTop:M,clientHeight:U}=N;Q-M-U<300&&!k&&f&&p(sl)}},[f,k,p]),E=Te({columns:K,data:I,state:{sorting:r,columnVisibility:u,rowSelection:l},manualSorting:!0,enableRowSelection:!0,onRowSelectionChange:i,onSortingChange:s,getCoreRowModel:De(),getSortedRowModel:Un()}),_=E.getRowModel().rows,j=E.getSelectedRowModel().rows,V=j.map(N=>N.original),H=m.useCallback(()=>{i({})},[i]),te=_.length===0,oe=E.getAllColumns().filter(N=>N.columns.length===0);return o("div",{css:Hr,children:[e(F,{paddingTop:"size-100",paddingBottom:"size-100",paddingStart:"size-200",paddingEnd:"size-200",borderBottomColor:"grey-300",borderBottomWidth:"thin",flex:"none",children:o(h,{direction:"row",gap:"size-100",width:"100%",alignItems:"center",children:[e(Or,{onValidCondition:d}),e(Nr,{columns:oe,query:g})]})}),e("div",{css:C`
          flex: 1 1 auto;
          overflow: auto;
        `,onScroll:N=>T(N.target),ref:t,children:o("table",{css:Jn,children:[e("thead",{children:E.getHeaderGroups().map(N=>e("tr",{children:N.headers.map(Q=>e("th",{colSpan:Q.colSpan,children:Q.isPlaceholder?null:o("div",{className:Q.column.getCanSort()?"cursor-pointer":"",onClick:Q.column.getToggleSortingHandler(),style:{left:Q.getStart(),width:Q.getSize()},children:[Z(Q.column.columnDef.header,Q.getContext()),Q.column.getIsSorted()?e(L,{className:"sort-icon",svg:Q.column.getIsSorted()==="asc"?e(D.ArrowUpFilled,{}):e(D.ArrowDownFilled,{})}):null]})},Q.id))},N.id))}),te?e(Ar,{projectName:g.name}):e("tbody",{children:_.map(N=>e("tr",{onClick:()=>y(`traces/${N.original.context.traceId}?selectedSpanNodeId=${N.original.id}`),children:N.getVisibleCells().map(Q=>e("td",{children:Z(Q.column.columnDef.cell,Q.getContext())},Q.id))},N.id))})]})}),j.length?e(Br,{selectedSpans:V,onClearSelection:H}):null]})}const Jr=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"StreamToggleRefetchQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"StreamToggle_data"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"StreamToggleRefetchQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"streamingLastUpdatedAt",storageKey:null}],type:"Project",abstractKey:null}],storageKey:null}]},params:{cacheID:"4e136f41c0942f253822336dc0c5b291",id:null,metadata:{},name:"StreamToggleRefetchQuery",operationKind:"query",text:`query StreamToggleRefetchQuery(
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...StreamToggle_data
    __isNode: __typename
    id
  }
}

fragment StreamToggle_data on Project {
  streamingLastUpdatedAt
  id
}
`}}}();Jr.hash="30a8f0bcf1aa6021b2c9a47866f5dc49";const Zr={argumentDefinitions:[],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:["node"],operation:Jr,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"StreamToggle_data",selections:[{alias:null,args:null,kind:"ScalarField",name:"streamingLastUpdatedAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],type:"Project",abstractKey:null};Zr.hash="30a8f0bcf1aa6021b2c9a47866f5dc49";function Yr(n,a){const t=m.useRef(null);m.useEffect(()=>{t.current=n},[n]),m.useEffect(()=>{function l(){t.current&&t.current()}if(typeof a=="number"){const i=setInterval(l,a);return()=>clearInterval(i)}},[a])}const vp=2e3;function Cp(n){const{isStreaming:a,setIsStreaming:t,setFetchKey:l}=aa(),[i,r]=P.useRefetchableFragment(Zr,n.project),s=m.useRef(i.streamingLastUpdatedAt),c=m.useCallback(()=>{a&&m.startTransition(()=>{r({},{fetchPolicy:"store-and-network"})})},[a,r]),d=i.streamingLastUpdatedAt;return m.useEffect(()=>{d!=null&&(s.current==null||s.current<d)&&(s.current=d,l(`fetch-traces-${d}`))},[l,d]),Yr(c,vp),e(Gn,{labelPlacement:"start",isSelected:a,onChange:()=>{t(!a)},children:"Stream"})}const Xr=function(){var n={defaultValue:null,kind:"LocalArgument",name:"after"},a={defaultValue:null,kind:"LocalArgument",name:"filterCondition"},t={defaultValue:50,kind:"LocalArgument",name:"first"},l={defaultValue:null,kind:"LocalArgument",name:"id"},i={defaultValue:{col:"startTime",dir:"desc"},kind:"LocalArgument",name:"sort"},r={defaultValue:null,kind:"LocalArgument",name:"timeRange"},s=[{kind:"Variable",name:"id",variableName:"id"}],c={kind:"Variable",name:"after",variableName:"after"},d={kind:"Variable",name:"filterCondition",variableName:"filterCondition"},u={kind:"Variable",name:"first",variableName:"first"},y={kind:"Variable",name:"sort",variableName:"sort"},g={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},p={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},f={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},k=[c,d,u,{kind:"Literal",name:"rootSpansOnly",value:!0},y,{kind:"Variable",name:"timeRange",variableName:"timeRange"}],b={alias:null,args:null,kind:"ScalarField",name:"spanKind",storageKey:null},S={alias:"statusCode",args:null,kind:"ScalarField",name:"propagatedStatusCode",storageKey:null},v={alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},I={alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null},w={alias:null,args:null,kind:"ScalarField",name:"parentId",storageKey:null},R=[{alias:"value",args:null,kind:"ScalarField",name:"truncatedValue",storageKey:null}],K={alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"input",plural:!1,selections:R,storageKey:null},T={alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"output",plural:!1,selections:R,storageKey:null},E={alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"spanId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null}],storageKey:null},_={alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[f,{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null}],storageKey:null},j={alias:null,args:null,concreteType:"DocumentRetrievalMetrics",kind:"LinkedField",name:"documentRetrievalMetrics",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"evaluationName",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"ndcg",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"precision",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hit",storageKey:null}],storageKey:null};return{fragment:{argumentDefinitions:[n,a,t,l,i,r],kind:"Fragment",metadata:null,name:"TracesTableQuery",selections:[{alias:null,args:s,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:[c,d,u,y],kind:"FragmentSpread",name:"TracesTable_spans"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,a,t,i,r,l],kind:"Operation",name:"TracesTableQuery",selections:[{alias:null,args:s,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[g,{kind:"TypeDiscriminator",abstractKey:"__isNode"},p,{kind:"InlineFragment",selections:[f,{alias:null,args:null,kind:"ScalarField",name:"spanAnnotationNames",storageKey:null},{alias:"rootSpans",args:k,concreteType:"SpanConnection",kind:"LinkedField",name:"spans",plural:!1,selections:[{alias:null,args:null,concreteType:"SpanEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"rootSpan",args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[p,b,f,{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},S,v,I,{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountCompletion",storageKey:null},w,K,T,E,_,j,{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"descendants",plural:!0,selections:[p,b,f,S,v,I,w,{alias:"cumulativeTokenCountTotal",args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:"cumulativeTokenCountPrompt",args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:"cumulativeTokenCountCompletion",args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},K,T,E,_,j],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[g],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:"rootSpans",args:k,filters:["sort","rootSpansOnly","filterCondition","timeRange"],handle:"connection",key:"TracesTable_rootSpans",kind:"LinkedHandle",name:"spans"}],type:"Project",abstractKey:null}],storageKey:null}]},params:{cacheID:"572f8769fc0e90b681883b56222bdc65",id:null,metadata:{},name:"TracesTableQuery",operationKind:"query",text:`query TracesTableQuery(
  $after: String = null
  $filterCondition: String = null
  $first: Int = 50
  $sort: SpanSort = {col: startTime, dir: desc}
  $timeRange: TimeRange
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...TracesTable_spans_1XEuU
    __isNode: __typename
    id
  }
}

fragment SpanColumnSelector_annotations on Project {
  spanAnnotationNames
}

fragment TracesTable_spans_1XEuU on Project {
  name
  ...SpanColumnSelector_annotations
  rootSpans: spans(first: $first, after: $after, sort: $sort, rootSpansOnly: true, filterCondition: $filterCondition, timeRange: $timeRange) {
    edges {
      rootSpan: node {
        id
        spanKind
        name
        metadata
        statusCode: propagatedStatusCode
        startTime
        latencyMs
        cumulativeTokenCountTotal
        cumulativeTokenCountPrompt
        cumulativeTokenCountCompletion
        parentId
        input {
          value: truncatedValue
        }
        output {
          value: truncatedValue
        }
        context {
          spanId
          traceId
        }
        spanAnnotations {
          name
          label
          score
          annotatorKind
        }
        documentRetrievalMetrics {
          evaluationName
          ndcg
          precision
          hit
        }
        descendants {
          id
          spanKind
          name
          statusCode: propagatedStatusCode
          startTime
          latencyMs
          parentId
          cumulativeTokenCountTotal: tokenCountTotal
          cumulativeTokenCountPrompt: tokenCountPrompt
          cumulativeTokenCountCompletion: tokenCountCompletion
          input {
            value: truncatedValue
          }
          output {
            value: truncatedValue
          }
          context {
            spanId
            traceId
          }
          spanAnnotations {
            name
            label
            score
            annotatorKind
          }
          documentRetrievalMetrics {
            evaluationName
            ndcg
            precision
            hit
          }
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();Xr.hash="53b160969c87d5e35e08a1f4ca26aadb";const es=function(){var n=["rootSpans"],a={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"spanKind",storageKey:null},i={alias:"statusCode",args:null,kind:"ScalarField",name:"propagatedStatusCode",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},s={alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null},c={alias:null,args:null,kind:"ScalarField",name:"parentId",storageKey:null},d=[{alias:"value",args:null,kind:"ScalarField",name:"truncatedValue",storageKey:null}],u={alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"input",plural:!1,selections:d,storageKey:null},y={alias:null,args:null,concreteType:"SpanIOValue",kind:"LinkedField",name:"output",plural:!1,selections:d,storageKey:null},g={alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"spanId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null}],storageKey:null},p={alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null}],storageKey:null},f={alias:null,args:null,concreteType:"DocumentRetrievalMetrics",kind:"LinkedField",name:"documentRetrievalMetrics",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"evaluationName",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"ndcg",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"precision",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hit",storageKey:null}],storageKey:null};return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:null,kind:"LocalArgument",name:"filterCondition"},{defaultValue:50,kind:"LocalArgument",name:"first"},{defaultValue:{col:"startTime",dir:"desc"},kind:"LocalArgument",name:"sort"},{kind:"RootArgument",name:"timeRange"}],kind:"Fragment",metadata:{connection:[{count:"first",cursor:"after",direction:"forward",path:n}],refetch:{connection:{forward:{count:"first",cursor:"after"},backward:null,path:n},fragmentPathInResult:["node"],operation:Xr,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"TracesTable_spans",selections:[a,{args:null,kind:"FragmentSpread",name:"SpanColumnSelector_annotations"},{alias:"rootSpans",args:[{kind:"Variable",name:"filterCondition",variableName:"filterCondition"},{kind:"Literal",name:"rootSpansOnly",value:!0},{kind:"Variable",name:"sort",variableName:"sort"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],concreteType:"SpanConnection",kind:"LinkedField",name:"__TracesTable_rootSpans_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"SpanEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"rootSpan",args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[t,l,a,{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},i,r,s,{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountCompletion",storageKey:null},c,u,y,g,p,f,{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"descendants",plural:!0,selections:[t,l,a,i,r,s,c,{alias:"cumulativeTokenCountTotal",args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:"cumulativeTokenCountPrompt",args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:"cumulativeTokenCountCompletion",args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},u,y,g,p,f],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},t],type:"Project",abstractKey:null}}();es.hash="53b160969c87d5e35e08a1f4ca26aadb";const ol=50;function ns(n){const a=[];for(const t of n){const l={...t.span,children:ns(t.children)};a.push(l)}return a}function Fp(n){const a=m.useRef(null),[t,l]=m.useState({}),[i,r]=m.useState([]),[s,c]=m.useState(""),d=ne(),{fetchKey:u}=aa(),{data:y,loadNext:g,hasNext:p,isLoadingNext:f,refetch:k}=P.usePaginationFragment(es,n.project),b=pn(M=>M.annotationColumnVisibility),S=m.useMemo(()=>Object.keys(b).filter(M=>b[M]),[b]),v=m.useMemo(()=>y.rootSpans.edges.map(({rootSpan:U})=>{const ie=lc([U,...U.descendants]),[$]=ns(ie);return $}),[y]),I=S.map(M=>({header:M,columns:[{header:"label",accessorKey:`${pa}${Xe}label${Xe}${M}`,cell:({row:U})=>{const ie=U.original.spanAnnotations.find($=>$.name===M);return ie?ie.label:null}},{header:"score",accessorKey:`${pa}${Xe}score${Xe}${M}`,cell:({row:U})=>{const ie=U.original.spanAnnotations.find($=>$.name===M);return ie?ie.score:null}}]})),w=[{header:()=>o(h,{direction:"row",gap:"size-50",children:[e("span",{children:"feedback"}),o(Hn,{children:[e(ge,{level:3,weight:"heavy",children:"Feedback"}),e(An,{children:"Feedback includes evaluations and human annotations logged via the API or set via the UI."})]})]}),accessorKey:"spanAnnotations",enableSorting:!1,cell:({row:M})=>{const U=M.original.spanAnnotations.length===0&&M.original.documentRetrievalMetrics.length===0;return o(h,{direction:"row",gap:"size-50",wrap:"wrap",children:[M.original.spanAnnotations.map(ie=>e(Sa,{annotation:ie,layout:"horizontal",width:"500px",extra:e(Rr,{annotation:ie}),children:e(yn,{annotation:ie,annotationDisplayPreference:"label"})},ie.name)),M.original.documentRetrievalMetrics.map(ie=>o(m.Fragment,{children:[e(ze,{name:ie.evaluationName,metric:"ndcg",score:ie.ndcg},"ndcg"),e(ze,{name:ie.evaluationName,metric:"precision",score:ie.precision},"precision"),e(ze,{name:ie.evaluationName,metric:"hit",score:ie.hit},"hit")]},"doc-evals")),U?"--":null]})}},...I],R=[{id:"select",maxSize:10,header:({table:M})=>e(mn,{checked:M.getIsAllRowsSelected(),indeterminate:M.getIsSomeRowsSelected(),onChange:M.getToggleAllRowsSelectedHandler()}),cell:({row:M})=>e(mn,{checked:M.getIsSelected(),disabled:!M.getCanSelect(),indeterminate:M.getIsSomeSelected(),onChange:M.getToggleSelectedHandler()})},{header:()=>o(h,{gap:"size-50",direction:"row",alignItems:"center",children:[e(Gt,{isExpanded:j.getIsAllRowsExpanded(),onClick:j.getToggleAllRowsExpandedHandler(),"aria-label":"Expand all rows"}),"kind"]}),enableSorting:!1,accessorKey:"spanKind",maxSize:100,cell:M=>e("div",{css:C`
              // Since rows are flattened by default,
              // we can use the row.depth property
              // and paddingLeft to visually indicate the depth
              // of the row
              padding-left: ${M.row.depth*2}rem;
            `,children:o(h,{gap:"size-50",children:[M.row.getCanExpand()?e(Gt,{isExpanded:M.row.getIsExpanded(),onClick:M.row.getToggleExpandedHandler(),"aria-label":"Expand row"}):null,e(Tt,{spanKind:M.getValue()})]})})},{header:"name",accessorKey:"name",enableSorting:!1,cell:({getValue:M,row:U})=>{const{traceId:ie}=U.original.context;return e(cn,{to:`traces/${ie}?selectedSpanNodeId=${U.original.id}`,children:M()})}},{header:"input",accessorKey:"input.value",enableSorting:!1,cell:Ke},{header:"output",accessorKey:"output.value",enableSorting:!1,cell:Ke},{header:"metadata",accessorKey:"metadata",enableSorting:!1,cell:Ke},...w,{header:"start time",accessorKey:"startTime",cell:_e},{header:"latency",accessorKey:"latencyMs",cell:({getValue:M})=>{const U=M();return U===null||typeof U!="number"?null:e(Re,{latencyMs:U})}},{header:"total tokens",minSize:80,accessorKey:"cumulativeTokenCountTotal",cell:({row:M,getValue:U})=>{const ie=U();return ie===null?"--":e(va,{tokenCountTotal:ie,tokenCountPrompt:M.original.cumulativeTokenCountPrompt||0,tokenCountCompletion:M.original.cumulativeTokenCountCompletion||0})}},{header:"status",accessorKey:"statusCode",enableSorting:!1,cell:({getValue:M})=>e(Ba,{statusCode:M()})}];m.useEffect(()=>{const M=i[0];m.startTransition(()=>{k({sort:M?Wr(M):Gr,after:null,first:ol,filterCondition:s},{fetchPolicy:"store-and-network"})})},[i,k,s,u]);const K=Se.useCallback(M=>{if(M){const{scrollHeight:U,scrollTop:ie,clientHeight:$}=M;U-ie-$<300&&!f&&p&&g(ol)}},[p,f,g]),[T,E]=m.useState({}),_=pn(M=>M.columnVisibility),j=Te({columns:R,data:v,onExpandedChange:E,manualSorting:!0,getSubRows:M=>M.children,state:{sorting:i,expanded:T,columnVisibility:_,rowSelection:t},onRowSelectionChange:l,enableSubRowSelection:!1,onSortingChange:r,getCoreRowModel:De(),getSortedRowModel:Un(),getExpandedRowModel:Vo(),getRowId:M=>M.id}),V=j.getRowModel().rows,H=j.getSelectedRowModel().flatRows,te=H.map(M=>M.original),oe=m.useCallback(()=>{l({})},[l]),N=V.length===0,Q=j.getAllColumns().filter(M=>M.columns.length===0);return o("div",{css:Hr,children:[e(F,{paddingTop:"size-100",paddingBottom:"size-100",paddingStart:"size-200",paddingEnd:"size-200",borderBottomColor:"grey-300",borderBottomWidth:"thin",flex:"none",children:o(h,{direction:"row",gap:"size-100",width:"100%",alignItems:"center",children:[e(Or,{onValidCondition:c}),e(Nr,{columns:Q,query:y})]})}),e("div",{css:C`
          flex: 1 1 auto;
          overflow: auto;
        `,onScroll:M=>K(M.target),ref:a,children:o("table",{css:Jn,children:[e("thead",{children:j.getHeaderGroups().map(M=>e("tr",{children:M.headers.map(U=>e("th",{colSpan:U.colSpan,children:U.isPlaceholder?null:o("div",{"data-sortable":U.column.getCanSort(),className:U.column.getCanSort()?"cursor-pointer":"",onClick:U.column.getToggleSortingHandler(),style:{left:U.getStart(),width:U.getSize()},children:[Z(U.column.columnDef.header,U.getContext()),U.column.getIsSorted()?e(L,{className:"sort-icon",svg:U.column.getIsSorted()==="asc"?e(D.ArrowUpFilled,{}):e(D.ArrowDownFilled,{})}):null]})},U.id))},M.id))}),N?e(Ar,{projectName:y.name}):e("tbody",{children:V.map(M=>e("tr",{onClick:()=>d(`traces/${M.original.context.traceId}`),children:M.getVisibleCells().map(U=>e("td",{children:Z(U.column.columnDef.cell,U.getContext())},U.id))},M.id))})]})}),H.length?e(Br,{selectedSpans:te,onClearSelection:oe}):null]})}const Kp=C`
  flex: 1 1 auto;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  .ac-tabs {
    flex: 1 1 auto;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    div[role="tablist"] {
      flex: none;
    }
    .ac-tabs__pane-container {
      flex: 1 1 auto;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      div[role="tabpanel"]:not([hidden]) {
        flex: 1 1 auto;
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
    }
  }
`;function s1(){const{projectId:n}=Ue(),{timeRange:a}=Ha();return e(m.Suspense,{fallback:e(ye,{}),children:e(xp,{projectId:n,timeRange:a})})}const as=br;function xp({projectId:n,timeRange:a}){const t=m.useMemo(()=>({start:a.start.toISOString(),end:a.end.toISOString()}),[a]),l=P.useLazyLoadQuery(kr,{id:n,timeRange:t},{fetchPolicy:"store-and-network"}),[i,r,s]=P.useQueryLoader(as),c=m.useCallback(d=>{d===1?r({id:n,timeRange:t}):s()},[s,r,n,t]);return o("main",{css:Kp,children:[e(sp,{project:l.project,extra:o(h,{direction:"row",alignItems:"center",gap:"size-100",children:[e(Cp,{project:l.project}),e(Wl,{})]})}),o($e,{onChange:c,children:[e(X,{name:"Traces",children:({isSelected:d})=>d&&e(rl,{children:e(m.Suspense,{children:e(Fp,{project:l.project})})})}),e(X,{name:"Spans",title:"Spans",children:({isSelected:d})=>d&&i&&e(rl,{children:e(m.Suspense,{fallback:e(ye,{}),children:e(Tp,{queryReference:i})})})})]}),e(m.Suspense,{children:e(Ve,{})})]})}function Tp({queryReference:n}){const a=P.usePreloadedQuery(as,n);return e(Sp,{project:a.project})}const ts=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],type:"Project",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"projectLoaderQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,l],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"projectLoaderQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t,l],storageKey:null}]},params:{cacheID:"04c84b5bc2a01477851d347af75dcc11",id:null,metadata:{},name:"projectLoaderQuery",operationKind:"query",text:`query projectLoaderQuery(
  $id: GlobalID!
) {
  project: node(id: $id) {
    __typename
    id
    ... on Project {
      name
    }
  }
}
`}}}();ts.hash="3d31e323c06df38ec2eaa6f3adb55e79";async function o1(n){const{projectId:a}=n.params;return await P.fetchQuery(Ne,ts,{id:a}).toPromise()}function d1(){const n=$o(),a=m.useMemo(()=>n instanceof Error&&n.message==="Failed to fetch"?e(Dp,{}):e(Ip,{error:n}),[n]);return e("main",{css:C`
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
      `,children:e("section",{css:C`
          width: 500px;
          /* Add spacing on the bottom so it gets pushed down */
          margin-top: 200px;
          display: flex;
          flex-direction: column;
        `,children:a})})}function Dp(){return o(G,{children:[o(h,{direction:"column",width:"100%",alignItems:"center",children:[e(ja,{graphicKey:"not found"}),e("h1",{children:"Server disconnected"})]}),e("p",{children:"We are unable to reach the Phoenix server. Please ensure that Phoenix is running and try again."})]})}function Ip({error:n}){return o(G,{children:[o(h,{direction:"column",width:"100%",alignItems:"center",children:[e(ja,{graphicKey:"error"}),e("h1",{children:"Something went wrong"})]}),e("p",{children:"We strive to do our very best but 🐛 bugs happen. It would mean a lot to us if you could file a an issue. If you feel comfortable, please include the error details below in your issue. We will get back to you as soon as we can."}),e("p",{css:C`
          display: flex;
          flex-direction: row;
          justify-content: flex-end;
          gap: var(--ac-global-dimension-static-size-100);
        `,children:o("span",{css:C`
            display: inline-flex;
            flex-direction: row;
            align-items: baseline;
            gap: 0.2em;
          `,children:["💙 the",e(rn,{href:"mailto:phoenix-devs@arize.com",children:"phoenix team"})]})}),o("div",{css:C`
          display: flex;
          flex-direction: row;
          justify-content: flex-end;
          align-items: center;
          gap: var(--ac-global-dimension-static-size-100);
        `,children:[e(rn,{href:"https://github.com/Arize-ai/phoenix/issues/new?assignees=&labels=bug&template=bug_report.md&title=%5BBUG%5D",children:"file an issue with us"}),e(z,{variant:"primary",size:"compact",onClick:()=>{window.location.href="/"},children:"Return Home"})]}),o("details",{open:!0,children:[e("summary",{children:"error details"}),e("pre",{css:C`
            white-space: pre-wrap;
            overflow-wrap: break-word;
            overflow: hidden;
            overflow-y: auto;
            max-height: 500px;
          `,children:n instanceof Error?n.message:null})]})]})}const ls=function(){var n=[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null}],a=[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"primaryInferences",plural:!1,selections:n,storageKey:null},{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"referenceInferences",plural:!1,selections:n,storageKey:null},{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"corpusInferences",plural:!1,selections:n,storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"ModelRootQuery",selections:a,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"ModelRootQuery",selections:a},params:{cacheID:"c3baccc5527002697b40a06eef432a4d",id:null,metadata:{},name:"ModelRootQuery",operationKind:"query",text:`query ModelRootQuery {
  model {
    primaryInferences {
      name
      startTime
      endTime
    }
    referenceInferences {
      name
      startTime
      endTime
    }
    corpusInferences {
      name
      startTime
      endTime
    }
  }
}
`}}}();ls.hash="b73d8f3f532a0c6f88863f3c6dd5734f";const Pp=ls;function c1(){const n=P.useLazyLoadQuery(Pp,{}),{model:{primaryInferences:a,referenceInferences:t,corpusInferences:l}}=n;return e(rc,{primaryInferences:a,referenceInferences:t??null,corpusInferences:l??null,children:e(ic,{timeRangeBounds:{start:new Date(a.startTime),end:new Date(a.endTime)},children:e(Ve,{})})})}function u1(){return e(op,{children:e(ap,{children:e(Ve,{})})})}function m1(){return e(sc,{children:e(Ve,{})})}const is=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:50,kind:"LocalArgument",name:"first"},{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],a=[{kind:"Variable",name:"after",variableName:"after"},{kind:"Variable",name:"first",variableName:"first"}],t={kind:"Variable",name:"timeRange",variableName:"timeRange"},l=[t];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ProjectsPageProjectsQuery",selections:[{args:a,kind:"FragmentSpread",name:"ProjectsPageProjectsFragment"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ProjectsPageProjectsQuery",selections:[{alias:null,args:a,concreteType:"ProjectConnection",kind:"LinkedField",name:"projects",plural:!1,selections:[{alias:null,args:null,concreteType:"ProjectEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"project",args:null,concreteType:"Project",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"gradientStartColor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"gradientEndColor",storageKey:null},{alias:null,args:l,kind:"ScalarField",name:"traceCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null},{alias:"latencyMsP50",args:[{kind:"Literal",name:"probability",value:.5},t],kind:"ScalarField",name:"latencyMsQuantile",storageKey:null},{alias:null,args:l,kind:"ScalarField",name:"tokenCountTotal",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:a,filters:null,handle:"connection",key:"ProjectsPage_projects",kind:"LinkedHandle",name:"projects"}]},params:{cacheID:"ead527a5c3ddda0f6c906c99183edf06",id:null,metadata:{},name:"ProjectsPageProjectsQuery",operationKind:"query",text:`query ProjectsPageProjectsQuery(
  $after: String = null
  $first: Int = 50
  $timeRange: TimeRange
) {
  ...ProjectsPageProjectsFragment_2HEEH6
}

fragment ProjectsPageProjectsFragment_2HEEH6 on Query {
  projects(first: $first, after: $after) {
    edges {
      project: node {
        id
        name
        gradientStartColor
        gradientEndColor
        traceCount(timeRange: $timeRange)
        endTime
        latencyMsP50: latencyMsQuantile(probability: 0.5, timeRange: $timeRange)
        tokenCountTotal(timeRange: $timeRange)
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
}
`}}}();is.hash="56c501357948255461a24411fb6b5847";const rs=function(){var n=["projects"],a={kind:"Variable",name:"timeRange",variableName:"timeRange"},t=[a];return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:50,kind:"LocalArgument",name:"first"},{kind:"RootArgument",name:"timeRange"}],kind:"Fragment",metadata:{connection:[{count:"first",cursor:"after",direction:"forward",path:n}],refetch:{connection:{forward:{count:"first",cursor:"after"},backward:null,path:n},fragmentPathInResult:[],operation:is}},name:"ProjectsPageProjectsFragment",selections:[{alias:"projects",args:null,concreteType:"ProjectConnection",kind:"LinkedField",name:"__ProjectsPage_projects_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"ProjectEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"project",args:null,concreteType:"Project",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"gradientStartColor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"gradientEndColor",storageKey:null},{alias:null,args:t,kind:"ScalarField",name:"traceCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null},{alias:"latencyMsP50",args:[{kind:"Literal",name:"probability",value:.5},a],kind:"ScalarField",name:"latencyMsQuantile",storageKey:null},{alias:null,args:t,kind:"ScalarField",name:"tokenCountTotal",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null}}();rs.hash="56c501357948255461a24411fb6b5847";const ss=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"timeRange"}],a=[{kind:"Literal",name:"first",value:50}],t={kind:"Variable",name:"timeRange",variableName:"timeRange"},l=[t];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ProjectsPageQuery",selections:[{args:null,kind:"FragmentSpread",name:"ProjectsPageProjectsFragment"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ProjectsPageQuery",selections:[{alias:null,args:a,concreteType:"ProjectConnection",kind:"LinkedField",name:"projects",plural:!1,selections:[{alias:null,args:null,concreteType:"ProjectEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"project",args:null,concreteType:"Project",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"gradientStartColor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"gradientEndColor",storageKey:null},{alias:null,args:l,kind:"ScalarField",name:"traceCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null},{alias:"latencyMsP50",args:[{kind:"Literal",name:"probability",value:.5},t],kind:"ScalarField",name:"latencyMsQuantile",storageKey:null},{alias:null,args:l,kind:"ScalarField",name:"tokenCountTotal",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:"projects(first:50)"},{alias:null,args:a,filters:null,handle:"connection",key:"ProjectsPage_projects",kind:"LinkedHandle",name:"projects"}]},params:{cacheID:"35a420462b10b0f0158d042fd39bfabb",id:null,metadata:{},name:"ProjectsPageQuery",operationKind:"query",text:`query ProjectsPageQuery(
  $timeRange: TimeRange!
) {
  ...ProjectsPageProjectsFragment
}

fragment ProjectsPageProjectsFragment on Query {
  projects(first: 50) {
    edges {
      project: node {
        id
        name
        gradientStartColor
        gradientEndColor
        traceCount(timeRange: $timeRange)
        endTime
        latencyMsP50: latencyMsQuantile(probability: 0.5, timeRange: $timeRange)
        tokenCountTotal(timeRange: $timeRange)
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
}
`}}}();ss.hash="c28f5ced0b3ec4b3b8277d0aac29de2d";const Lp="https://docs.arize.com/phoenix/tracing/how-to-tracing/setup-tracing";function Ep(){const[n,a]=m.useState(null);return o("div",{children:[e(z,{variant:"default",icon:e(L,{svg:e(D.GridOutline,{})}),onClick:()=>{a(e(wp,{}))},children:"New Project"}),e(ae,{isDismissable:!0,type:"slideOver",onDismiss:()=>a(null),children:n})]})}function wp(){const[n,a]=m.useState("Python");return e(Y,{title:"Create a New Project",size:"L",children:o(F,{padding:"size-400",overflow:"auto",children:[e(F,{paddingBottom:"size-200",children:e(Ul,{language:n,onChange:a})}),e(F,{paddingBottom:"size-100",children:o(x,{children:["Projects are created when you log your first trace via OpenTelemetry. See the"," ",e(rn,{href:Lp,children:"documentation"})," ","for a complete guide."]})}),n==="Python"?e(Bl,{}):e(Hl,{})]})})}const os=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"Query",kind:"LinkedField",name:"clearProject",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ProjectActionMenuClearMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ProjectActionMenuClearMutation",selections:a},params:{cacheID:"63319b4e42b499db2447817f1dc821fb",id:null,metadata:{},name:"ProjectActionMenuClearMutation",operationKind:"mutation",text:`mutation ProjectActionMenuClearMutation(
  $input: ClearProjectInput!
) {
  clearProject(input: $input) {
    __typename
  }
}
`}}}();os.hash="c43eec4d6b882468c611dd9ebf3b095e";const ds=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"projectId"}],a=[{alias:null,args:[{kind:"Variable",name:"id",variableName:"projectId"}],concreteType:"Query",kind:"LinkedField",name:"deleteProject",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ProjectActionMenuDeleteMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ProjectActionMenuDeleteMutation",selections:a},params:{cacheID:"8b00ab3aaef4c5fb3de24f7295d38499",id:null,metadata:{},name:"ProjectActionMenuDeleteMutation",operationKind:"mutation",text:`mutation ProjectActionMenuDeleteMutation(
  $projectId: GlobalID!
) {
  deleteProject(id: $projectId) {
    __typename
  }
}
`}}}();ds.hash="3bf82e90b3f2d3485b4efb954e30b2cf";const cs=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"Query",kind:"LinkedField",name:"clearProject",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"RemoveProjectDataFormMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"RemoveProjectDataFormMutation",selections:a},params:{cacheID:"1b27a3f7535c3f3943b0f2248d1505a6",id:null,metadata:{},name:"RemoveProjectDataFormMutation",operationKind:"mutation",text:`mutation RemoveProjectDataFormMutation(
  $input: ClearProjectInput!
) {
  clearProject(input: $input) {
    __typename
  }
}
`}}}();cs.hash="212501fe2d6367ec1503bd7a00c1730f";function _p(n){const{projectId:a}=n,t=m.useRef(null),[l,i]=P.useMutation(cs),{control:r,handleSubmit:s,setError:c,formState:{isValid:d}}=je({defaultValues:{endDate:new Date(Date.now()-oc).toISOString().slice(0,16)}}),u=m.useCallback(y=>{const g=Oo(y.endDate);if(!Qo(g))return c("endDate",{message:"Date is not in a valid format"});l({variables:{input:{id:a,endTime:new Date(g).toISOString()}},onCompleted:()=>{n.onComplete()},onError:p=>{alert("Failed to clear project traces: "+p)}})},[l,a,n,c]);return o("form",{onSubmit:s(u),ref:t,children:[o(F,{padding:"size-200",children:[e(x,{color:"danger",children:"You are about to remove all data before the following date. This cannot be undone."}),e(W,{name:"endDate",control:r,rules:{required:"field is required"},render:({field:{name:y,onChange:g,onBlur:p,value:f},fieldState:{invalid:k,error:b}})=>e(ee,{label:"End Date",type:"datetime-local",name:y,description:"The date up to which you want to remove data",errorMessage:b==null?void 0:b.message,validationState:k?"invalid":"valid",onChange:g,onBlur:p,defaultValue:f})})]}),e(F,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:e(h,{direction:"row",justifyContent:"end",children:e(z,{type:"submit",variant:"danger",isDisabled:!d,size:"compact",loading:i,onClick:()=>{var y;(y=t.current)==null||y.requestSubmit()},children:i?"Removing...":"Remove Data"})})})]})}function Rp({projectId:n,projectName:a,onProjectDelete:t,onProjectClear:l,onProjectRemoveData:i}){const[r,s]=m.useState(null),c=a!=="default",[d]=P.useMutation(ds),[u]=P.useMutation(os),y=m.useCallback(()=>{m.startTransition(()=>{d({variables:{projectId:n}}),t()})},[d,n,t]),g=m.useCallback(()=>{m.startTransition(()=>{u({variables:{input:{id:n}},onCompleted:()=>{l()},onError:b=>{alert("Failed to clear project: "+b)}})})},[u,n,l]),p=m.useCallback(()=>{s(o(Y,{size:"S",title:"Delete Project",children:[e(F,{padding:"size-200",children:e(x,{color:"danger",children:`Are you sure you want to delete project ${a}? This cannot be undone.`})}),e(F,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:e(h,{direction:"row",justifyContent:"end",children:e(z,{variant:"danger",onClick:()=>{y(),s(null)},children:"Delete Project"})})})]}))},[y,a]),f=m.useCallback(()=>{s(o(Y,{size:"S",title:"Clear Project",children:[e(F,{padding:"size-200",children:e(x,{color:"danger",children:`Are you sure you want to clear project ${a}? All traces and evaluations for this project will be deleted. This cannot be undone.`})}),e(F,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:e(h,{direction:"row",justifyContent:"end",children:e(z,{variant:"danger",onClick:()=>{g(),s(null)},children:"Clear"})})})]}))},[g,a]),k=m.useCallback(()=>{s(e(Y,{size:"M",title:"Remove Data",children:e(_p,{projectId:n,onComplete:()=>{i(),s(null)}})}))},[i,n]);return o("div",{onClick:b=>{b.preventDefault(),b.stopPropagation()},children:[o(Rn,{buttonVariant:"quiet",align:"end",onAction:b=>{switch(b){case"deleteProject":return p();case"clearProject":return f();case"removeProjectData":return k()}},disabledKeys:c?[]:["deleteProject"],children:[e(le,{textValue:"Clear Traces",children:o(h,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(L,{svg:e(D.Refresh,{})}),e(x,{children:"Clear Data"})]})},"clearProject"),e(le,{textValue:"Remove Data",children:o(h,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(L,{svg:e(D.CloseCircleOutline,{})}),e(x,{children:"Remove Data"})]})},"removeProjectData"),c?e(le,{children:o(h,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(L,{svg:e(D.TrashOutline,{})}),e(x,{children:"Delete"})]})},"deleteProject"):null]}),e(ae,{type:"modal",isDismissable:!0,onDismiss:()=>s(null),children:r})]})}function Ap(){const n=Ae(t=>t.projectsAutoRefreshEnabled),a=Ae(t=>t.setProjectAutoRefreshEnabled);return e(Gn,{labelPlacement:"start",isSelected:n,onChange:()=>{a(!n)},children:"Auto-Refresh"})}const Mp=1e4,Np=50;function g1(){const{timeRange:n}=Ha();return e(m.Suspense,{fallback:e(ye,{}),children:e(zp,{timeRange:n})})}function zp({timeRange:n}){const a=Ae(v=>v.projectsAutoRefreshEnabled),[t,l]=od(),i=m.useMemo(()=>({start:n.start.toISOString(),end:n.end.toISOString()}),[n]),r=P.useLazyLoadQuery(ss,{timeRange:i}),{data:s,loadNext:c,hasNext:d,isLoadingNext:u,refetch:y}=P.usePaginationFragment(rs,r),g=s.projects.edges.map(v=>v.project),p=m.useRef(null),f=m.useCallback(v=>{if(v){const{scrollHeight:I,scrollTop:w,clientHeight:R}=v;I-w-R<300&&!u&&d&&c(Np)}},[d,u,c]);Yr(()=>{m.startTransition(()=>{y({},{fetchPolicy:"store-and-network"})})},a?Mp:null);const k=m.useCallback(v=>{m.startTransition(()=>{y({},{fetchPolicy:"store-and-network"}),t({variant:"success",title:"Project Deleted",message:`Project ${v} has been deleted.`})})},[t,y]),b=m.useCallback(v=>{m.startTransition(()=>{y({},{fetchPolicy:"store-and-network"}),t({variant:"success",title:"Project Cleared",message:`Project ${v} has been cleared of traces.`})})},[t,y]),S=m.useCallback(v=>{m.startTransition(()=>{y({},{fetchPolicy:"store-and-network"}),t({variant:"success",title:"Project Data Removed",message:`Old data from project ${v} have been removed.`})})},[t,y]);return o("div",{css:C`
        flex: 1 1 auto;
        overflow-y: auto;
        overflow-x: hidden;
        padding-bottom: var(--ac-global-dimension-size-750);
      `,onScroll:v=>f(v.target),ref:p,children:[e(F,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",width:"100%",borderBottomColor:"grey-200",borderBottomWidth:"thin",children:o(h,{direction:"row",justifyContent:"end",alignItems:"center",gap:"size-100",children:[e(Ap,{}),e(Ep,{}),e(Wl,{})]})}),e(F,{padding:"size-200",width:"100%",children:e("ul",{css:C`
            display: flex;
            flex-direction: row;
            gap: var(--ac-global-dimension-size-200);
            flex-wrap: wrap;
          `,children:g.map(v=>e("li",{children:e(cn,{to:`/projects/${v.id}`,css:C`
                  text-decoration: none;
                `,children:e($p,{project:v,onProjectDelete:()=>k(v.name),onProjectClear:()=>b(v.name),onProjectRemoveData:()=>S(v.name)})})},v.id))})}),l]})}function Vp({gradientStartColor:n,gradientEndColor:a}){return e("div",{css:C`
        border-radius: 50%;
        width: 32px;
        height: 32px;
        background: linear-gradient(
          136.27deg,
          ${n} 14.03%,
          ${a} 84.38%
        );
        flex-shrink: 0;
      `})}function $p({project:n,onProjectDelete:a,onProjectClear:t,onProjectRemoveData:l}){const{endTime:i,traceCount:r,tokenCountTotal:s,latencyMsP50:c,gradientStartColor:d,gradientEndColor:u}=n,y=m.useMemo(()=>i?`Last updated  ${jo(new Date(i),new Date,{addSuffix:!0})}`:"No traces uploaded yet.",[i]);return o("div",{css:C`
        padding: var(--ac-global-dimension-size-200);
        border: 1px solid var(--ac-global-color-grey-400);
        background-color: var(--ac-global-color-grey-100);
        border-radius: var(--ac-global-rounding-medium);
        height: var(--ac-global-dimension-size-1250);
        width: var(--ac-global-dimension-size-3600);
        transition: border-color 0.2s;
        &:hover {
          border-color: var(--ac-global-color-primary);
        }
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      `,children:[o(h,{direction:"row",justifyContent:"space-between",alignItems:"start",children:[o(h,{direction:"row",gap:"size-100",alignItems:"center",minWidth:0,children:[e(Vp,{gradientStartColor:d,gradientEndColor:u}),o(h,{direction:"column",minWidth:0,children:[e(ge,{level:2,css:C`
                overflow: hidden;
                white-space: nowrap;
                text-overflow: ellipsis;
              `,children:n.name}),e(x,{color:"text-700",textSize:"small",fontStyle:"italic",children:y})]})]}),e(Rp,{projectId:n.id,projectName:n.name,onProjectDelete:a,onProjectClear:t,onProjectRemoveData:l})]}),o(h,{direction:"row",justifyContent:"space-between",children:[o(h,{direction:"column",flex:"none",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:"Total Traces"}),e(x,{textSize:"xlarge",children:Pn(r)})]}),o(h,{direction:"column",flex:"none",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:"Total Tokens"}),e(x,{textSize:"xlarge",children:Pn(s)})]}),o(h,{direction:"column",flex:"none",children:[e(x,{elementType:"h3",textSize:"medium",color:"text-700",children:"Latency P50"}),c!=null?e(Re,{latencyMs:c,textSize:"xlarge"}):e(x,{textSize:"xlarge",children:"--"})]})]})]})}const us=function(){var n=[{kind:"Literal",name:"first",value:100},{kind:"Literal",name:"sort",value:{col:"createdAt",dir:"desc"}}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"DatasetsPageQuery",selections:[{args:null,kind:"FragmentSpread",name:"DatasetsTable_datasets"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"DatasetsPageQuery",selections:[{alias:null,args:n,concreteType:"DatasetConnection",kind:"LinkedField",name:"datasets",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"exampleCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"experimentCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:'datasets(first:100,sort:{"col":"createdAt","dir":"desc"})'},{alias:null,args:n,filters:["sort"],handle:"connection",key:"DatasetsTable_datasets",kind:"LinkedHandle",name:"datasets"}]},params:{cacheID:"695b221e981c4795492d79faa7d007e4",id:null,metadata:{},name:"DatasetsPageQuery",operationKind:"query",text:`query DatasetsPageQuery {
  ...DatasetsTable_datasets
}

fragment DatasetsTable_datasets on Query {
  datasets(first: 100, sort: {col: createdAt, dir: desc}) {
    edges {
      node {
        id
        name
        description
        metadata
        createdAt
        exampleCount
        experimentCount
        __typename
      }
      cursor
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
}
`}}}();us.hash="985853a7939f44c0cefdd1a91472c67e";function Op(n){const a=n.split(`
`);return a.length>0?a[0].split(",").map(t=>t.trim()):[]}function Qp(n){const{onDatasetCreated:a,onDatasetCreateError:t}=n,[l,i]=m.useState([]),{control:r,handleSubmit:s,resetField:c,formState:{isDirty:d,isValid:u}}=je({defaultValues:{name:"Dataset "+new Date().toISOString(),input_keys:[],output_keys:[],metadata_keys:[],description:"",metadata:{}}}),y=m.useCallback(g=>{const p=new FormData;return p.append("file",g.file[0]),p.append("name",g.name),p.append("description",g.description),p.append("metadata",JSON.stringify(g.metadata)),g.input_keys.forEach(f=>{p.append("input_keys[]",f)}),g.output_keys.forEach(f=>{p.append("output_keys[]",f)}),g.metadata_keys.forEach(f=>{p.append("metadata_keys[]",f)}),fetch("/v1/datasets/upload?sync=true",{method:"POST",body:p}).then(f=>{if(!f.ok)throw t(new Error(f.statusText||"Failed to create dataset"));return f.json()}).then(f=>{a({name:g.name,id:f.data.dataset_id})})},[t,a]);return o(we,{onSubmit:s(y),children:[o("div",{css:C`
          padding: var(--ac-global-dimension-size-200);
          .ac-dropdown-button {
            width: 100%;
          }
        `,children:[e(W,{name:"name",control:r,rules:{required:"field is required"},render:({field:{onChange:g,onBlur:p,value:f},fieldState:{invalid:k,error:b}})=>e(ee,{label:"Dataset Name",description:"The name of the dataset",errorMessage:b==null?void 0:b.message,validationState:k?"invalid":"valid",onChange:g,onBlur:p,value:f.toString()})}),e(W,{name:"description",control:r,render:({field:{onChange:g,onBlur:p,value:f},fieldState:{invalid:k,error:b}})=>e(kt,{label:"description",placeholder:"Description of the dataset",isRequired:!1,height:100,errorMessage:b==null?void 0:b.message,validationState:k?"invalid":"valid",onChange:g,onBlur:p,value:f.toString()})}),e(W,{control:r,name:"file",rules:{required:"CSV file is required"},render:({field:{value:g,onChange:p,...f},fieldState:{invalid:k,error:b}})=>e(Mn,{label:"CSV file",validationState:k?"invalid":"valid",errorMessage:b==null?void 0:b.message,children:e("input",{...f,onChange:S=>{var I;p(S.target.files),c("input_keys"),c("output_keys"),c("metadata_keys");const v=(I=S.target.files)==null?void 0:I[0];if(v){const w=new FileReader;w.onload=function(R){if(!R.target)return;const K=R.target.result,T=Op(K);i(T)},w.readAsText(v)}},type:"file",id:"file",accept:".csv"})})}),e(W,{name:"input_keys",control:r,rules:{required:"field is required"},render:({field:{value:g,onChange:p},fieldState:{invalid:f,error:k}})=>e(ot,{label:"input keys",validationState:f?"invalid":"valid",description:"the columns to use as input",columns:l,selectedColumns:g,onChange:p,errorMessage:k==null?void 0:k.message})}),e(W,{name:"output_keys",control:r,render:({field:{value:g,onChange:p},fieldState:{invalid:f,error:k}})=>e(ot,{label:"output keys",validationState:f?"invalid":"valid",description:"the columns to use as output",columns:l,selectedColumns:g,onChange:p,errorMessage:k==null?void 0:k.message})}),e(W,{name:"metadata_keys",control:r,render:({field:{value:g,onChange:p},fieldState:{invalid:f,error:k}})=>e(ot,{label:"metadata keys",validationState:f?"invalid":"valid",description:"the columns to use as metadata",columns:l,selectedColumns:g,onChange:p,errorMessage:k==null?void 0:k.message})})]}),e(F,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:e(h,{direction:"row",justifyContent:"end",children:e(z,{type:"submit",isDisabled:!u,variant:d?"primary":"default",size:"compact",loading:!1,children:"Create Dataset"})})})]})}function ot(n){const{columns:a,selectedColumns:t,onChange:l,label:i,validationState:r,description:s,errorMessage:c,...d}=n,u=a.length===0,y=m.useMemo(()=>u?"No columns to select":t.length>0?`${t.join(", ")}`:"No columns selected",[t,u]);return e(Mn,{label:i,isDisabled:u,validationState:r,description:s,errorMessage:c,children:e(vt,{isDisabled:u,...d,menu:e(Qa,{selectionMode:"multiple",onSelectionChange:g=>{l(Array.from(g))},selectedKeys:new Set(t),children:a.map(g=>e(le,{children:g},g))}),triggerProps:{placement:"bottom end"},children:y})})}const ms=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:100,kind:"LocalArgument",name:"first"},{defaultValue:{col:"createdAt",dir:"desc"},kind:"LocalArgument",name:"sort"}],a=[{kind:"Variable",name:"after",variableName:"after"},{kind:"Variable",name:"first",variableName:"first"},{kind:"Variable",name:"sort",variableName:"sort"}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"DatasetsTableDatasetsQuery",selections:[{args:a,kind:"FragmentSpread",name:"DatasetsTable_datasets"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"DatasetsTableDatasetsQuery",selections:[{alias:null,args:a,concreteType:"DatasetConnection",kind:"LinkedField",name:"datasets",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"exampleCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"experimentCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:a,filters:["sort"],handle:"connection",key:"DatasetsTable_datasets",kind:"LinkedHandle",name:"datasets"}]},params:{cacheID:"5ac1688f54e51f9bb3247c83e23d98fb",id:null,metadata:{},name:"DatasetsTableDatasetsQuery",operationKind:"query",text:`query DatasetsTableDatasetsQuery(
  $after: String = null
  $first: Int = 100
  $sort: DatasetSort = {col: createdAt, dir: desc}
) {
  ...DatasetsTable_datasets_dWkdd
}

fragment DatasetsTable_datasets_dWkdd on Query {
  datasets(first: $first, after: $after, sort: $sort) {
    edges {
      node {
        id
        name
        description
        metadata
        createdAt
        exampleCount
        experimentCount
        __typename
      }
      cursor
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
}
`}}}();ms.hash="fa378bc7ec26f5e877e6cf90e5ee553d";const gs=function(){var n=["datasets"];return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:100,kind:"LocalArgument",name:"first"},{defaultValue:{col:"createdAt",dir:"desc"},kind:"LocalArgument",name:"sort"}],kind:"Fragment",metadata:{connection:[{count:"first",cursor:"after",direction:"forward",path:n}],refetch:{connection:{forward:{count:"first",cursor:"after"},backward:null,path:n},fragmentPathInResult:[],operation:ms}},name:"DatasetsTable_datasets",selections:[{alias:"datasets",args:[{kind:"Variable",name:"sort",variableName:"sort"}],concreteType:"DatasetConnection",kind:"LinkedField",name:"__DatasetsTable_datasets_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"exampleCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"experimentCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null}}();gs.hash="fa378bc7ec26f5e877e6cf90e5ee553d";const ps=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"datasetId"}],a=[{alias:null,args:[{fields:[{kind:"Variable",name:"datasetId",variableName:"datasetId"}],kind:"ObjectValue",name:"input"}],concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"deleteDataset",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"DeleteDatasetDialogMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"DeleteDatasetDialogMutation",selections:a},params:{cacheID:"3d32b97acd630dd7dbc9c85a632a1d49",id:null,metadata:{},name:"DeleteDatasetDialogMutation",operationKind:"mutation",text:`mutation DeleteDatasetDialogMutation(
  $datasetId: GlobalID!
) {
  deleteDataset(input: {datasetId: $datasetId}) {
    __typename
  }
}
`}}}();ps.hash="7066cca7015a7e344b77862b0bdab21c";function jp({datasetId:n,datasetName:a,onDatasetDelete:t,onDatasetDeleteError:l}){const[i,r]=P.useMutation(ps),s=m.useCallback(()=>{m.startTransition(()=>{i({variables:{datasetId:n},onCompleted:()=>{t()},onError:c=>{l(c)}})})},[i,n,t,l]);return o(Y,{size:"S",title:"Delete Dataset",children:[e(F,{padding:"size-200",children:e(x,{color:"danger",children:`Are you sure you want to delete dataset ${a}? This will also delete all associated experiments and traces, and it cannot be undone.`})}),e(F,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:e(h,{direction:"row",justifyContent:"end",children:e(z,{variant:"danger",onClick:()=>{s()},disabled:r,loading:r,children:"Delete Dataset"})})})]})}function qp({datasetName:n,datasetId:a,datasetDescription:t,datasetMetadata:l,onDatasetEdited:i,onDatasetEditError:r}){return e(Y,{title:"Edit Dataset",size:"M",children:e(dc,{datasetName:n,datasetId:a,datasetDescription:t,datasetMetadata:l,onDatasetEdited:i,onDatasetEditError:r})})}function Up(n){const{datasetId:a,datasetName:t,datasetDescription:l,datasetMetadata:i,onDatasetDelete:r,onDatasetDeleteError:s,onDatasetEdit:c,onDatasetEditError:d}=n,[u,y]=m.useState(null),g=m.useCallback(()=>{y(e(jp,{datasetId:a,datasetName:t,onDatasetDelete:()=>{r(),y(null)},onDatasetDeleteError:s}))},[a,t,r,s]),p=m.useCallback(()=>{y(e(qp,{datasetId:a,datasetName:t,datasetDescription:l,datasetMetadata:i,onDatasetEdited:()=>{c(),y(null)},onDatasetEditError:d}))},[l,a,i,t,c,d]);return o("div",{onClick:f=>{f.preventDefault(),f.stopPropagation()},children:[o(Rn,{align:"end",buttonSize:"compact",onAction:f=>{switch(f){case"deleteDataset":g();break;case"editDataset":p();break}},children:[e(le,{children:o(h,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(L,{svg:e(D.TrashOutline,{})}),e(x,{children:"Delete"})]})},"deleteDataset"),e(le,{children:o(h,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(L,{svg:e(D.Edit2Outline,{})}),e(x,{children:"Edit"})]})},"editDataset")]}),e(ae,{type:"modal",isDismissable:!0,onDismiss:()=>y(null),children:u})]})}const dl=100;function Bp(n){const a=n.id;if(a!=="createdAt"&&a!=="name")throw new Error("Invalid sort column");return{col:a,dir:n.desc?"desc":"asc"}}function Hp(n){const[a,t]=m.useState([]),l=m.useRef(null),i=ne(),r=ve(),s=be(),{data:c,loadNext:d,hasNext:u,isLoadingNext:y,refetch:g}=P.usePaginationFragment(gs,n.query),p=m.useMemo(()=>c.datasets.edges.map(v=>v.node),[c]),f=Se.useCallback(v=>{if(v){const{scrollHeight:I,scrollTop:w,clientHeight:R}=v;I-w-R<300&&!y&&u&&d(dl)}},[u,y,d]),k=Te({columns:[{header:"name",accessorKey:"name",cell:({row:v})=>{const w=v.original.experimentCount>0?`${v.original.id}/experiments`:`${v.original.id}/examples`;return e(cn,{to:w,children:v.original.name})}},{header:"description",accessorKey:"description",enableSorting:!1},{header:"created at",accessorKey:"createdAt",cell:_e},{header:"example count",accessorKey:"exampleCount",enableSorting:!1,meta:{textAlign:"right"}},{header:"experiment count",accessorKey:"experimentCount",enableSorting:!1,meta:{textAlign:"right"}},{header:"metadata",accessorKey:"metadata",enableSorting:!1,cell:jn},{header:"",id:"actions",enableSorting:!1,size:10,cell:({row:v})=>e(Up,{datasetId:v.original.id,datasetName:v.original.name,datasetDescription:v.original.description,datasetMetadata:v.original.metadata,onDatasetEdit:()=>{r({title:"Dataset updated",message:`${v.original.name} has been successfully updated.`}),g({},{fetchPolicy:"store-and-network"})},onDatasetEditError:I=>{s({title:"Dataset update failed",message:I.message})},onDatasetDelete:()=>{r({title:"Dataset deleted",message:`${v.original.name} has been successfully deleted.`}),g({},{fetchPolicy:"store-and-network"})},onDatasetDeleteError:I=>{s({title:"Dataset deletion failed",message:I.message})}})}],data:p,state:{sorting:a},getCoreRowModel:De(),getSortedRowModel:Un(),onSortingChange:t,manualSorting:!0});m.useEffect(()=>{const v=a[0];m.startTransition(()=>{g({sort:v?Bp(v):{col:"createdAt",dir:"desc"},after:null,first:dl},{fetchPolicy:"store-and-network"})})},[a,g]);const b=k.getRowModel().rows,S=b.length===0;return e("div",{css:C`
        flex: 1 1 auto;
        overflow: auto;
      `,onScroll:v=>f(v.target),ref:l,children:o("table",{css:Jn,children:[e("thead",{children:k.getHeaderGroups().map(v=>e("tr",{children:v.headers.map(I=>{var w;return e("th",{colSpan:I.colSpan,children:I.isPlaceholder?null:o("div",{className:I.column.getCanSort()?"cursor-pointer":"",onClick:I.column.getToggleSortingHandler(),style:{textAlign:(w=I.column.columnDef.meta)==null?void 0:w.textAlign},children:[Z(I.column.columnDef.header,I.getContext()),I.column.getIsSorted()?e(L,{className:"sort-icon",svg:I.column.getIsSorted()==="asc"?e(D.ArrowUpFilled,{}):e(D.ArrowDownFilled,{})}):null]})},I.id)})},v.id))}),S?e(Ze,{}):e("tbody",{children:b.map(v=>e("tr",{onClick:()=>{const w=v.original.experimentCount>0?`${v.original.id}/experiments`:`${v.original.id}/examples`;i(w)},children:v.getVisibleCells().map(I=>{var w;return e("td",{align:(w=I.column.columnDef.meta)==null?void 0:w.textAlign,children:Z(I.column.columnDef.cell,I.getContext())},I.id)})},v.id))})]})})}function p1(){return e(m.Suspense,{fallback:e(ye,{}),children:e(Gp,{})})}function Gp(){const[n,a]=m.useState(0),t=P.useLazyLoadQuery(us,{},{fetchKey:n,fetchPolicy:"store-and-network"}),l=m.useCallback(()=>{a(i=>i+1)},[a]);return o(h,{direction:"column",height:"100%",children:[e(F,{padding:"size-200",borderBottomWidth:"thin",borderBottomColor:"dark",flex:"none",children:o(h,{direction:"row",justifyContent:"space-between",children:[e(ge,{level:1,children:"Datasets"}),e(Wp,{onDatasetCreated:l})]})}),e(Hp,{query:t})]})}function Wp({onDatasetCreated:n}){const a=ne(),t=ve(),l=be(),[i,r]=m.useState(null),s=()=>{r(e(Y,{size:"S",title:"New Dataset",children:e(Gl,{onDatasetCreated:d=>{t({title:"Dataset created",message:`${d.name} has been successfully created.`,action:{text:"Go to Dataset",onClick:()=>{a(`/datasets/${d.id}`)}}}),r(null),n()},onDatasetCreateError:d=>{l({title:"Dataset creation failed",message:d.message})}})}))},c=()=>{r(e(Y,{size:"M",title:"New Dataset from CSV",children:e(Qp,{onDatasetCreated:d=>{t({title:"Dataset created",message:`${d.name} has been successfully created.`,action:{text:"Go to Dataset",onClick:()=>{a(`/datasets/${d.id}`)}}}),r(null),n()},onDatasetCreateError:d=>{l({title:"Dataset creation failed",message:d.message})}})}))};return o(G,{children:[o(Rn,{buttonText:"Create Dataset",align:"end",icon:e(L,{svg:e(D.DatabaseOutline,{})}),onAction:d=>{switch(d){case"newDataset":s();break;case"datasetFromCSV":c();break}},children:[e(le,{children:"New Dataset"},"newDataset"),e(le,{children:"Dataset from CSV"},"datasetFromCSV")]}),e(ae,{type:"modal",isDismissable:!0,onDismiss:()=>r(null),children:i})]})}const ys=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"datasetId"}],a=[{kind:"Variable",name:"id",variableName:"datasetId"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={kind:"InlineFragment",selections:[{alias:"latestVersions",args:[{kind:"Literal",name:"first",value:1},{kind:"Literal",name:"sort",value:{col:"createdAt",dir:"desc"}}],concreteType:"DatasetVersionConnection",kind:"LinkedField",name:"versions",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetVersionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"version",args:null,concreteType:"DatasetVersion",kind:"LinkedField",name:"node",plural:!1,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:'versions(first:1,sort:{"col":"createdAt","dir":"desc"})'}],type:"Dataset",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"datasetStore_latestVersionQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,l],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"datasetStore_latestVersionQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t,l],storageKey:null}]},params:{cacheID:"d7075240e4dae8871997e57616c05302",id:null,metadata:{},name:"datasetStore_latestVersionQuery",operationKind:"query",text:`query datasetStore_latestVersionQuery(
  $datasetId: GlobalID!
) {
  dataset: node(id: $datasetId) {
    __typename
    id
    ... on Dataset {
      latestVersions: versions(first: 1, sort: {col: createdAt, dir: desc}) {
        edges {
          version: node {
            id
            description
            createdAt
          }
        }
      }
    }
  }
}
`}}}();ys.hash="a1349b92d8b0c745f5e8039c55b048c7";const Jp=n=>{const a=(t,l)=>({...n,isRefreshingLatestVersion:!1,refreshLatestVersion:async()=>{const i=l();t({isRefreshingLatestVersion:!0});const r=await Zp({datasetId:i.datasetId});t({latestVersion:r,isRefreshingLatestVersion:!1})}});return Sl()(qo(a))};async function Zp({datasetId:n}){var i;const a=await P.fetchQuery(Ne,ys,{datasetId:n}).toPromise(),t=(i=a==null?void 0:a.dataset.latestVersions)==null?void 0:i.edges;return t&&t.length&&t[0].version||null}const fs=m.createContext(null);function Yp({children:n,...a}){const[t]=m.useState(()=>Jp(a));return e(fs.Provider,{value:t,children:n})}function wn(n,a){const t=m.useContext(fs);if(!t)throw new Error("Missing DatasetContext.Provider in the tree");return ya(t,n,a)}const hs=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"addExamplesToDataset",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"AddDatasetExampleDialogMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"AddDatasetExampleDialogMutation",selections:a},params:{cacheID:"718cf02ccb39b279132822bf503e51e6",id:null,metadata:{},name:"AddDatasetExampleDialogMutation",operationKind:"mutation",text:`mutation AddDatasetExampleDialogMutation(
  $input: AddExamplesToDatasetInput!
) {
  addExamplesToDataset(input: $input) {
    __typename
  }
}
`}}}();hs.hash="8d99470f590cd5d28701fa6e3c0330e6";const dt={backgroundColor:"light",borderColor:"light",collapsible:!0,bodyStyle:{padding:0}};function Xp(n){const{datasetId:a,onCompleted:t}=n,[l,i]=m.useState(null),[r,s]=P.useMutation(hs),{control:c,setError:d,handleSubmit:u,formState:{isValid:y}}=je({defaultValues:{input:"{}",output:"{}",metadata:"{}"}}),g=m.useCallback(p=>{if(i(null),!en(p==null?void 0:p.input))return d("input",{message:"Input must be a valid JSON object"});if(!en(p==null?void 0:p.output))return d("output",{message:"Output must be a valid JSON object"});if(!en(p==null?void 0:p.metadata))return d("metadata",{message:"Metadata must be a valid JSON object"});r({variables:{input:{datasetId:a,examples:[{input:JSON.parse(p.input),output:JSON.parse(p.output),metadata:JSON.parse(p.metadata)}],datasetVersionDescription:p.description}},onCompleted:()=>{t()},onError:f=>{i(f.message)}})},[r,a,d,t]);return o(Y,{size:"L",title:"Add Example",children:[e("div",{css:C`
          overflow-y: auto;
          padding: var(--ac-global-dimension-size-400);
        `,children:e(h,{direction:"row",justifyContent:"center",children:e(F,{width:"900px",paddingStart:"auto",paddingEnd:"auto",children:o(h,{direction:"column",gap:"size-200",children:[l?e(ce,{variant:"danger",children:l}):null,e(W,{control:c,name:"input",render:({field:{onChange:p,onBlur:f,value:k},fieldState:{invalid:b,error:S}})=>o(q,{title:"Input",subTitle:"The input to the LLM, retriever, program, etc.",...dt,children:[b?e(ce,{variant:"danger",banner:!0,children:S==null?void 0:S.message}):null,e(Ee,{value:k,onChange:p,onBlur:f})]})}),e(W,{control:c,name:"output",render:({field:{onChange:p,onBlur:f,value:k},fieldState:{invalid:b,error:S}})=>o(q,{title:"Output",subTitle:"The output of the LLM or program to be used as an expected output",...dt,backgroundColor:"green-100",borderColor:"green-700",children:[b?e(ce,{variant:"danger",banner:!0,children:S==null?void 0:S.message}):null,e(Ee,{value:k,onChange:p,onBlur:f})]})}),e(W,{control:c,name:"metadata",render:({field:{onChange:p,onBlur:f,value:k},fieldState:{invalid:b,error:S}})=>o(q,{title:"Metadata",subTitle:"All data from the span to use during experimentation or evaluation",...dt,children:[b?e(ce,{variant:"danger",banner:!0,children:S==null?void 0:S.message}):null,e(Ee,{value:k,onChange:p,onBlur:f})]})}),e(W,{control:c,name:"description",render:({field:{onChange:p,onBlur:f,value:k},fieldState:{invalid:b,error:S}})=>e(kt,{label:"Version Description",value:k,onChange:p,onBlur:f,errorMessage:S==null?void 0:S.message,validationState:b?"invalid":"valid",placeholder:"A description of the changes made. Will be displayed in the version history.",height:100})})]})})})}),e(F,{padding:"size-200",borderTopColor:"light",borderTopWidth:"thin",children:e(h,{direction:"row",justifyContent:"end",gap:"size-100",children:e(z,{variant:"primary",size:"compact",disabled:!y||s,loading:s,onClick:u(g),children:"Add Example"})})})]})}function ey(n){const{datasetId:a,onAddExampleCompleted:t}=n,[l,i]=m.useState(null),r=m.useCallback(()=>{i(e(Xp,{datasetId:a,onCompleted:()=>{t(),i(null)}}))},[a,t]);return o(G,{children:[e(z,{icon:e(L,{svg:e(D.PlusCircleOutline,{})}),size:"compact",variant:"default",onClick:r,children:"Add Example"}),e(ae,{isDismissable:!0,onDismiss:()=>{i(null)},children:l})]})}function ny(){const n=wn(i=>i.datasetId),a=wn(i=>i.latestVersion);let t=`${gt}/v1/datasets/${n}/examples`;a&&(t+=`?version-id=${a.id}`);const l=m.useMemo(()=>`import phoenix as px
client = px.Client()
# Get the current dataset version
dataset = client.get_dataset(id="${n}"${a?`, version_id="${a.id}"`:""})`,[n,a]);return e("div",{css:C`
        button.ac-dropdown-button {
          min-width: 80px;
          .ac-dropdown-button__text {
            padding-right: 10px;
          }
        }
      `,children:o(Bn,{placement:"bottom right",children:[e(St,{addonBefore:e(L,{svg:e(D.Code,{})}),children:"Code"}),e(Oa,{children:o("section",{css:C`
              width: 500px;
              .ac-field {
                flex: 1 1 auto;
              }
            `,children:[e(F,{padding:"size-200",children:o(we,{children:[o(h,{direction:"row",gap:"size-100",alignItems:"end",width:"100%",children:[e(ee,{label:"Dataset ID",isReadOnly:!0,value:n}),e(se,{text:n,size:"default"})]}),o(h,{direction:"row",gap:"size-100",alignItems:"end",children:[e(ee,{label:"Version ID",isReadOnly:!0,value:(a==null?void 0:a.id)||"No Versions",validationState:a?"valid":"invalid"}),e(se,{text:(a==null?void 0:a.id)||"No Versions",disabled:!a,size:"default"})]})]})}),o($e,{children:[e(X,{name:"Python",children:e(F,{margin:"size-200",borderColor:"light",borderWidth:"thin",borderRadius:"small",children:e(Kn,{value:l})})}),e(X,{name:"REST",children:e(F,{padding:"size-200",children:e(we,{children:o(h,{direction:"row",gap:"size-100",alignItems:"end",children:[e(ee,{label:"URL",isReadOnly:!0,value:t}),e(se,{text:t,size:"default"})]})})})})]})]})})]})})}const ks=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"datasetId"}],a=[{kind:"Variable",name:"id",variableName:"datasetId"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i=[{kind:"Literal",name:"first",value:100}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"DatasetHistoryDialogQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[t,{args:null,kind:"FragmentSpread",name:"DatasetHistoryTable_versions"}],type:"Dataset",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"DatasetHistoryDialogQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[l,{kind:"TypeDiscriminator",abstractKey:"__isNode"},t,{kind:"InlineFragment",selections:[{alias:null,args:i,concreteType:"DatasetVersionConnection",kind:"LinkedField",name:"versions",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetVersionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"DatasetVersion",kind:"LinkedField",name:"node",plural:!1,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},l],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:"versions(first:100)"},{alias:null,args:i,filters:null,handle:"connection",key:"DatasetHistoryTable_versions",kind:"LinkedHandle",name:"versions"}],type:"Dataset",abstractKey:null}],storageKey:null}]},params:{cacheID:"df94b4e72c0187fd0fd1c8416af19354",id:null,metadata:{},name:"DatasetHistoryDialogQuery",operationKind:"query",text:`query DatasetHistoryDialogQuery(
  $datasetId: GlobalID!
) {
  dataset: node(id: $datasetId) {
    __typename
    ... on Dataset {
      id
      ...DatasetHistoryTable_versions
    }
    __isNode: __typename
    id
  }
}

fragment DatasetHistoryTable_versions on Dataset {
  versions(first: 100) {
    edges {
      node {
        id
        description
        createdAt
        __typename
      }
      cursor
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();ks.hash="7215c18bda690418c5ecbcb3131a288e";const bs=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:100,kind:"LocalArgument",name:"first"},{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t=[{kind:"Variable",name:"after",variableName:"after"},{kind:"Variable",name:"first",variableName:"first"}],l={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"DatasetHistoryTableVersionsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:t,kind:"FragmentSpread",name:"DatasetHistoryTable_versions"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"DatasetHistoryTableVersionsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[l,{kind:"TypeDiscriminator",abstractKey:"__isNode"},i,{kind:"InlineFragment",selections:[{alias:null,args:t,concreteType:"DatasetVersionConnection",kind:"LinkedField",name:"versions",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetVersionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"DatasetVersion",kind:"LinkedField",name:"node",plural:!1,selections:[i,{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},l],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:t,filters:null,handle:"connection",key:"DatasetHistoryTable_versions",kind:"LinkedHandle",name:"versions"}],type:"Dataset",abstractKey:null}],storageKey:null}]},params:{cacheID:"e8e3a05b4e86c8eaeea98172405fdc7e",id:null,metadata:{},name:"DatasetHistoryTableVersionsQuery",operationKind:"query",text:`query DatasetHistoryTableVersionsQuery(
  $after: String = null
  $first: Int = 100
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...DatasetHistoryTable_versions_2HEEH6
    __isNode: __typename
    id
  }
}

fragment DatasetHistoryTable_versions_2HEEH6 on Dataset {
  versions(first: $first, after: $after) {
    edges {
      node {
        id
        description
        createdAt
        __typename
      }
      cursor
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();bs.hash="37e453bc58759a1e89bc5862c460de6b";const Ss=function(){var n=["versions"],a={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:100,kind:"LocalArgument",name:"first"}],kind:"Fragment",metadata:{connection:[{count:"first",cursor:"after",direction:"forward",path:n}],refetch:{connection:{forward:{count:"first",cursor:"after"},backward:null,path:n},fragmentPathInResult:["node"],operation:bs,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"DatasetHistoryTable_versions",selections:[{alias:"versions",args:null,concreteType:"DatasetVersionConnection",kind:"LinkedField",name:"__DatasetHistoryTable_versions_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetVersionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"DatasetVersion",kind:"LinkedField",name:"node",plural:!1,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},a],type:"Dataset",abstractKey:null}}();Ss.hash="37e453bc58759a1e89bc5862c460de6b";const ay=100;function ty(n){const a=m.useRef(null),{data:t,loadNext:l,hasNext:i,isLoadingNext:r}=P.usePaginationFragment(Ss,n.dataset),s=m.useMemo(()=>t.versions.edges.map(g=>g.node),[t]),c=Se.useCallback(g=>{if(g){const{scrollHeight:p,scrollTop:f,clientHeight:k}=g;p-f-k<300&&!r&&i&&l(ay)}},[i,r,l]),d=Te({columns:[{header:"version ID",accessorKey:"id"},{header:"description",accessorKey:"description"},{header:"created at",accessorKey:"createdAt",cell:_e}],data:s,getCoreRowModel:De(),getSortedRowModel:Un()}),u=d.getRowModel().rows,y=u.length===0;return e("div",{css:C`
        flex: 1 1 auto;
        overflow: auto;
      `,onScroll:g=>c(g.target),ref:a,children:o("table",{css:Je,children:[e("thead",{children:d.getHeaderGroups().map(g=>e("tr",{children:g.headers.map(p=>e("th",{colSpan:p.colSpan,children:p.isPlaceholder?null:o("div",{className:p.column.getCanSort()?"cursor-pointer":"",onClick:p.column.getToggleSortingHandler(),style:{left:p.getStart(),width:p.getSize()},children:[Z(p.column.columnDef.header,p.getContext()),p.column.getIsSorted()?e(L,{className:"sort-icon",svg:p.column.getIsSorted()==="asc"?e(D.ArrowUpFilled,{}):e(D.ArrowDownFilled,{})}):null]})},p.id))},g.id))}),y?e(Ze,{}):e("tbody",{children:u.map(g=>e("tr",{children:g.getVisibleCells().map(p=>e("td",{children:Z(p.column.columnDef.cell,p.getContext())},p.id))},g.id))})]})})}function ly(n){const{datasetId:a}=n,t=P.useLazyLoadQuery(ks,{datasetId:a});return e(Y,{size:"L",title:"Dataset History",children:e("div",{css:C`
          height: 500px;
        `,children:e(ty,{dataset:t.dataset})})})}function iy(n){const{datasetId:a}=n,[t,l]=m.useState(null);return o(G,{children:[o(pe,{children:[e(z,{variant:"default",icon:e(L,{svg:e(D.ClockOutline,{})}),"aria-label":"Version History",onClick:()=>{l(e(ly,{datasetId:a}))}}),e(Fe,{children:"Dataset Version History"})]}),e(m.Suspense,{fallback:null,children:e(ae,{type:"modal",isDismissable:!0,onDismiss:()=>{l(null)},children:t})})]})}const ry=`pip install arize-phoenix>=${window.Config.platformVersion}`;function sy({isAuthEnabled:n}){let a=`import os
# Set the phoenix collector endpoint. Commonly http://localhost:6060 
os.environ["PHOENIX_COLLECTOR_ENDPOINT"] = "<your-phoenix-url>"`;return n&&(a+=`
# Configure access
os.environ["PHOENIX_API_KEY"] = "<your-api-key>"`),a}const oy=`from phoenix.experiments.types import Example
# Define your task
# Typically should be an LLM call or a call to your application
def my_task(example: Example) -> str:
    # This is just an example of how to return a JSON serializable value
    return f"Hello {example.input["person"]}"`,dy=`# Define an evaluator. This just an example.
def exact_match(input, output) -> float:
    return 1.0 if output is f"Hello {input}" else 0.0

# Store the evaluators for later use
evaluators = [exact_match]`,cy=`# Run an experiment
from phoenix.experiments import run_experiment

experiment = run_experiment(dataset, my_task, evaluators=evaluators)`;function vs(){const[n,a]=m.useState(null),t=m.useCallback(()=>{a(e(Y,{title:"Run Experiment",size:"XL",children:e(uy,{})}))},[]);return o(G,{children:[e(z,{size:"compact",variant:"default",icon:e(L,{svg:e(D.ExperimentOutline,{})}),onClick:t,children:"Run Experiment"}),e(ae,{isDismissable:!0,type:"slideOver",onDismiss:()=>{a(null)},children:n})]})}function uy(){const n=wn(i=>i.datasetName),a=wn(i=>i.latestVersion),t=window.Config.authenticationEnabled,l=m.useMemo(()=>`import phoenix as px
# Initialize a phoenix client
client = px.Client()
# Get the current dataset version. You can omit the version for the latest.
dataset = client.get_dataset(name="${n}"${a?`, version_id="${a.id}"`:""})`,[n,a]);return o(F,{padding:"size-400",overflow:"auto",children:[e(F,{paddingBottom:"size-100",children:e(x,{children:"Install Phoenix"})}),e(Ye,{children:e(Kn,{value:ry})}),e(F,{paddingTop:"size-100",paddingBottom:"size-100",children:e(x,{children:"Point to a running instance of Phoenix"})}),e(Ye,{children:e(Kn,{value:sy({isAuthEnabled:t})})}),e(cc,{children:e(F,{paddingBottom:"size-100",paddingTop:"size-100",children:e(Jl,{fallback:o(x,{children:["Your personal API keys can be created and managed on your"," ",e(rn,{href:"/profile",children:"Profile"})]}),children:o(x,{children:["System API keys can be created and managed in"," ",e(rn,{href:"/settings",children:"Settings"})]})})})}),e(F,{paddingTop:"size-100",paddingBottom:"size-100",children:e(x,{children:"Pull down this dataset"})}),e(Ye,{children:e(Kn,{value:l})}),e(F,{paddingTop:"size-100",paddingBottom:"size-100",children:e(x,{children:"Define your task"})}),e(Ye,{children:e(Kn,{value:oy})}),e(F,{paddingTop:"size-100",paddingBottom:"size-100",children:e(x,{children:"Define evaluators"})}),e(Ye,{children:e(Kn,{value:dy})}),e(F,{paddingTop:"size-100",paddingBottom:"size-100",children:e(x,{children:"Run an experiment"})}),e(Ye,{children:e(Kn,{value:cy})})]})}function y1(){const n=_n(),a=m.useMemo(()=>{const t=n.dataset.latestVersions;return t!=null&&t.edges&&t.edges.length?t.edges[0].version:null},[n]);return e(Yp,{datasetId:n.dataset.id,datasetName:n.dataset.name,latestVersion:a,children:e(m.Suspense,{fallback:e(ye,{}),children:e(gy,{dataset:n.dataset})})})}const my=C`
  flex: 1 1 auto;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  .ac-tabs {
    flex: 1 1 auto;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    div[role="tablist"] {
      flex: none;
    }
    .ac-tabs__pane-container {
      flex: 1 1 auto;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      div[role="tabpanel"]:not([hidden]) {
        flex: 1 1 auto;
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
    }
  }
`;function gy({dataset:n}){const a=n.id,t=wn(d=>d.refreshLatestVersion),l=ve(),i=ne(),r=m.useCallback(d=>{d===0?i(`/datasets/${a}/experiments`):d===1&&i(`/datasets/${a}/examples`)},[i,a]),c=Uo().pathname.includes("examples")?1:0;return o("main",{css:my,children:[e(F,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-200",paddingBottom:"size-50",flex:"none",children:o(h,{direction:"row",justifyContent:"space-between",alignItems:"center",children:[e(h,{direction:"column",justifyContent:"space-between",children:e(h,{direction:"row",gap:"size-200",alignItems:"center",children:o(h,{direction:"column",children:[e(x,{elementType:"h1",textSize:"xlarge",weight:"heavy",children:n.name}),e(x,{color:"text-700",children:n.description||"--"})]})})}),o(h,{direction:"row",gap:"size-100",children:[o(Rn,{align:"end",icon:e(L,{svg:e(D.DownloadOutline,{})}),onAction:d=>{switch(d){case"csv":window.open(`/v1/datasets/${n.id}/csv`,"_blank");break;case"openai-ft":window.open(`/v1/datasets/${n.id}/jsonl/openai_ft`,"_blank");break;case"openai-evals":window.open(`/v1/datasets/${n.id}/jsonl/openai_evals`,"_blank");break}},children:[e(le,{children:"Download CSV"},"csv"),e(le,{children:"Download OpenAI Fine-Tuning JSONL"},"openai-ft"),e(le,{children:"Download OpenAI Evals JSONL"},"openai-evals")]}),e(iy,{datasetId:n.id}),e(ny,{}),e(vs,{}),e(z,{variant:"default",icon:e(L,{svg:e(D.PlayCircleOutline,{})}),onClick:()=>{i(`/playground/datasets/${n.id}`)},children:"Playground"}),e(ey,{datasetId:n.id,onAddExampleCompleted:()=>{l({title:"Example added",message:"The example has been added successfully and the version has been updated."}),t()}})]})]})}),o($e,{onChange:r,defaultIndex:c,children:[e(X,{name:"Experiments",extra:e(Be,{children:n.experimentCount}),children:e(m.Suspense,{children:e(Ve,{})})}),e(X,{name:"Examples",extra:e(Be,{children:n.exampleCount}),children:e(m.Suspense,{children:e(Ve,{})})})]})]})}const Cs=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},i={kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},l,{alias:null,args:null,kind:"ScalarField",name:"exampleCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"experimentCount",storageKey:null},{alias:"latestVersions",args:[{kind:"Literal",name:"first",value:1},{kind:"Literal",name:"sort",value:{col:"createdAt",dir:"desc"}}],concreteType:"DatasetVersionConnection",kind:"LinkedField",name:"versions",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetVersionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"version",args:null,concreteType:"DatasetVersion",kind:"LinkedField",name:"node",plural:!1,selections:[t,l,{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:'versions(first:1,sort:{"col":"createdAt","dir":"desc"})'}],type:"Dataset",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"datasetLoaderQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"datasetLoaderQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t,i],storageKey:null}]},params:{cacheID:"5b221627cf7e63f41fbec41027cc0951",id:null,metadata:{},name:"datasetLoaderQuery",operationKind:"query",text:`query datasetLoaderQuery(
  $id: GlobalID!
) {
  dataset: node(id: $id) {
    __typename
    id
    ... on Dataset {
      id
      name
      description
      exampleCount
      experimentCount
      latestVersions: versions(first: 1, sort: {col: createdAt, dir: desc}) {
        edges {
          version: node {
            id
            description
            createdAt
          }
        }
      }
    }
  }
}
`}}}();Cs.hash="469da2debdebd608c88a6ef83c2540aa";async function f1(n){const{datasetId:a}=n.params;return await P.fetchQuery(Ne,Cs,{id:a}).toPromise()}function h1(){const{exampleId:n,datasetId:a}=Ue(),t=ne();return e(At,{exampleId:n,onDismiss:()=>{t(`/datasets/${a}/examples`)}})}const Fs=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i=[{kind:"Literal",name:"first",value:100}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"examplesLoaderQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{args:null,kind:"FragmentSpread",name:"ExamplesTableFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"examplesLoaderQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[l,t,{kind:"InlineFragment",selections:[{alias:null,args:i,concreteType:"DatasetExampleConnection",kind:"LinkedField",name:"examples",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetExampleEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"example",args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[t,{alias:null,args:null,concreteType:"DatasetExampleRevision",kind:"LinkedField",name:"revision",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"input",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[l],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:"examples(first:100)"},{alias:null,args:i,filters:["datasetVersionId"],handle:"connection",key:"ExamplesTable_examples",kind:"LinkedHandle",name:"examples"}],type:"Dataset",abstractKey:null}],storageKey:null}]},params:{cacheID:"7e303fa9a3c09ccd6a3dc1f3dbb2afb3",id:null,metadata:{},name:"examplesLoaderQuery",operationKind:"query",text:`query examplesLoaderQuery(
  $id: GlobalID!
) {
  dataset: node(id: $id) {
    __typename
    id
    ...ExamplesTableFragment
  }
}

fragment ExamplesTableFragment on Dataset {
  examples(first: 100) {
    edges {
      example: node {
        id
        revision {
          input
          output
          metadata
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();Fs.hash="6406bbf43a2e850b384ba9573d8e69de";async function k1(n){const{datasetId:a}=n.params;return await P.fetchQuery(Ne,Fs,{id:a}).toPromise()}const Ks=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:null,kind:"LocalArgument",name:"datasetVersionId"},{defaultValue:100,kind:"LocalArgument",name:"first"},{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t=[{kind:"Variable",name:"after",variableName:"after"},{kind:"Variable",name:"datasetVersionId",variableName:"datasetVersionId"},{kind:"Variable",name:"first",variableName:"first"}],l={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExamplesTableQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:t,kind:"FragmentSpread",name:"ExamplesTableFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExamplesTableQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[l,{kind:"TypeDiscriminator",abstractKey:"__isNode"},i,{kind:"InlineFragment",selections:[{alias:null,args:t,concreteType:"DatasetExampleConnection",kind:"LinkedField",name:"examples",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetExampleEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"example",args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[i,{alias:null,args:null,concreteType:"DatasetExampleRevision",kind:"LinkedField",name:"revision",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"input",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[l],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:t,filters:["datasetVersionId"],handle:"connection",key:"ExamplesTable_examples",kind:"LinkedHandle",name:"examples"}],type:"Dataset",abstractKey:null}],storageKey:null}]},params:{cacheID:"ca59c018695d41ca01b5f9d453386886",id:null,metadata:{},name:"ExamplesTableQuery",operationKind:"query",text:`query ExamplesTableQuery(
  $after: String = null
  $datasetVersionId: GlobalID
  $first: Int = 100
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...ExamplesTableFragment_4a6F8Z
    __isNode: __typename
    id
  }
}

fragment ExamplesTableFragment_4a6F8Z on Dataset {
  examples(datasetVersionId: $datasetVersionId, first: $first, after: $after) {
    edges {
      example: node {
        id
        revision {
          input
          output
          metadata
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();Ks.hash="e04e697cdb44ab2dd115f4562211f6a4";const xs=function(){var n=["examples"],a={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:null,kind:"LocalArgument",name:"datasetVersionId"},{defaultValue:100,kind:"LocalArgument",name:"first"}],kind:"Fragment",metadata:{connection:[{count:"first",cursor:"after",direction:"forward",path:n}],refetch:{connection:{forward:{count:"first",cursor:"after"},backward:null,path:n},fragmentPathInResult:["node"],operation:Ks,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"ExamplesTableFragment",selections:[{alias:"examples",args:[{kind:"Variable",name:"datasetVersionId",variableName:"datasetVersionId"}],concreteType:"DatasetExampleConnection",kind:"LinkedField",name:"__ExamplesTable_examples_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetExampleEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"example",args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[a,{alias:null,args:null,concreteType:"DatasetExampleRevision",kind:"LinkedField",name:"revision",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"input",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},a],type:"Dataset",abstractKey:null}}();xs.hash="e04e697cdb44ab2dd115f4562211f6a4";const Ts=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"deleteDatasetExamples",plural:!1,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"dataset",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExampleSelectionToolbarDeleteExamplesMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExampleSelectionToolbarDeleteExamplesMutation",selections:a},params:{cacheID:"b63159f3c325b9af3dc469692f9329e5",id:null,metadata:{},name:"ExampleSelectionToolbarDeleteExamplesMutation",operationKind:"mutation",text:`mutation ExampleSelectionToolbarDeleteExamplesMutation(
  $input: DeleteDatasetExamplesInput!
) {
  deleteDatasetExamples(input: $input) {
    dataset {
      id
    }
  }
}
`}}}();Ts.hash="455bf9e5dc4b9cc655095dc829ef7e12";function py(n){const a=wn(f=>f.refreshLatestVersion),{selectedExamples:t,onExamplesDeleted:l,onClearSelection:i}=n,[r,s]=m.useState(null),c=ve(),d=be(),[u,y]=P.useMutation(Ts),g=t.length!==1,p=m.useCallback(()=>{u({variables:{input:{exampleIds:t.map(f=>f.id)}},onCompleted:()=>{c({title:"Examples Deleted",message:`${t.length} example${g?"s":""} have been deleted.`}),l(),i(),a()},onError:f=>{d({title:"An error occurred",message:`Failed to delete examples: ${f.message}`})}})},[u,t,c,g,l,i,a,d]);return o("div",{css:C`
        position: absolute;
        bottom: var(--ac-global-dimension-size-400);
        left: 50%;
        transform: translateX(-50%);
      `,children:[e(F,{backgroundColor:"light",padding:"size-200",borderColor:"light",borderWidth:"thin",borderRadius:"medium",minWidth:"size-6000",children:o(h,{direction:"row",justifyContent:"space-between",alignItems:"center",children:[e(x,{children:`${t.length} example${g?"s":""} selected`}),o(h,{direction:"row",gap:"size-100",children:[e(z,{variant:"default",size:"compact",onClick:i,children:"Cancel"}),e(z,{variant:"danger",size:"compact",icon:e(L,{svg:e(D.TrashOutline,{})}),loading:y,disabled:y,onClick:p,children:y?"Deleting...":"Delete Example"+(g?"s":"")})]})]})}),e(ae,{onDismiss:()=>{s(null)},children:r})]})}const yy=100;function fy({dataset:n}){const a=wn(R=>R.latestVersion),t=m.useRef(null),[l,i]=Se.useState({}),{data:r,loadNext:s,hasNext:c,isLoadingNext:d,refetch:u}=P.usePaginationFragment(xs,n);m.useEffect(()=>{m.startTransition(()=>{u({datasetVersionId:(a==null?void 0:a.id)||null},{fetchPolicy:"store-and-network"})})},[a,u]);const y=m.useMemo(()=>r.examples.edges.map(R=>{const K=R.example,T=K.revision;return{id:K.id,input:T.input,output:T.output,metadata:T.metadata}}),[r]),p=Te({columns:[{id:"select",header:({table:R})=>e(mn,{checked:R.getIsAllRowsSelected(),indeterminate:R.getIsSomeRowsSelected(),onChange:R.getToggleAllRowsSelectedHandler()}),cell:({row:R})=>e(mn,{checked:R.getIsSelected(),disabled:!R.getCanSelect(),indeterminate:R.getIsSomeSelected(),onChange:R.getToggleSelectedHandler()})},{header:"example id",accessorKey:"id",cell:({getValue:R,row:K})=>{const T=K.original.id;return e(cn,{to:`${T}`,children:R()})}},{header:"input",accessorKey:"input",cell:jn},{header:"output",accessorKey:"output",cell:jn},{header:"metadata",accessorKey:"metadata",cell:jn}],data:y,state:{rowSelection:l},onRowSelectionChange:i,getCoreRowModel:De()}),f=p.getRowModel().rows,k=f.length===0,b=p.getSelectedRowModel().rows,S=b.map(R=>R.original),v=m.useCallback(()=>{i({})},[i]),I=m.useCallback(R=>{if(R){const{scrollHeight:K,scrollTop:T,clientHeight:E}=R;K-T-E<300&&!d&&c&&s(yy)}},[c,d,s]),w=ne();return o("div",{css:C`
        flex: 1 1 auto;
        overflow: auto;
      `,ref:t,onScroll:R=>I(R.target),children:[o("table",{css:Jn,children:[e("thead",{children:p.getHeaderGroups().map(R=>e("tr",{children:R.headers.map(K=>e("th",{children:e("div",{children:Z(K.column.columnDef.header,K.getContext())})},K.id))},R.id))}),k?e(Ze,{}):e("tbody",{children:f.map(R=>e("tr",{onClick:()=>{w(`${R.original.id}`)},children:R.getVisibleCells().map(K=>e("td",{children:Z(K.column.columnDef.cell,K.getContext())},K.id))},R.id))})]}),b.length?e(py,{selectedExamples:S,onClearSelection:v,onExamplesDeleted:()=>{u({},{fetchPolicy:"store-and-network"})}}):null]})}function b1(){const n=_n();return o(G,{children:[e(fy,{dataset:n.dataset})," ",e(m.Suspense,{children:e(Ve,{})})]})}const Ds=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"annotationName",storageKey:null},r=[{kind:"Literal",name:"first",value:100}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"experimentsLoaderQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"ExperimentsTableFragment"}],type:"Dataset",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"experimentsLoaderQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[l,t,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"ExperimentAnnotationSummary",kind:"LinkedField",name:"experimentAnnotationSummaries",plural:!0,selections:[i,{alias:null,args:null,kind:"ScalarField",name:"minScore",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"maxScore",storageKey:null}],storageKey:null},{alias:null,args:r,concreteType:"ExperimentConnection",kind:"LinkedField",name:"experiments",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"experiment",args:null,concreteType:"Experiment",kind:"LinkedField",name:"node",plural:!1,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"sequenceNumber",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"errorRate",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"runCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"averageRunLatencyMs",storageKey:null},{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[t],storageKey:null},{alias:null,args:null,concreteType:"ExperimentAnnotationSummary",kind:"LinkedField",name:"annotationSummaries",plural:!0,selections:[i,{alias:null,args:null,kind:"ScalarField",name:"meanScore",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Experiment",kind:"LinkedField",name:"node",plural:!1,selections:[l],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:"experiments(first:100)"},{alias:null,args:r,filters:null,handle:"connection",key:"ExperimentsTable_experiments",kind:"LinkedHandle",name:"experiments"}],type:"Dataset",abstractKey:null}],storageKey:null}]},params:{cacheID:"91f92395f5df4858554b124deed3f47a",id:null,metadata:{},name:"experimentsLoaderQuery",operationKind:"query",text:`query experimentsLoaderQuery(
  $id: GlobalID!
) {
  dataset: node(id: $id) {
    __typename
    id
    ... on Dataset {
      ...ExperimentsTableFragment
    }
  }
}

fragment ExperimentsTableFragment on Dataset {
  experimentAnnotationSummaries {
    annotationName
    minScore
    maxScore
  }
  experiments(first: 100) {
    edges {
      experiment: node {
        id
        name
        sequenceNumber
        description
        createdAt
        metadata
        errorRate
        runCount
        averageRunLatencyMs
        project {
          id
        }
        annotationSummaries {
          annotationName
          meanScore
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();Ds.hash="1461484d9e1232cbb99e1251edabbec3";async function S1(n){const{datasetId:a}=n.params;return await P.fetchQuery(Ne,Ds,{id:a}).toPromise()}const Is=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:100,kind:"LocalArgument",name:"first"},{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t=[{kind:"Variable",name:"after",variableName:"after"},{kind:"Variable",name:"first",variableName:"first"}],l={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"annotationName",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExperimentsTableQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:t,kind:"FragmentSpread",name:"ExperimentsTableFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExperimentsTableQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[l,{kind:"TypeDiscriminator",abstractKey:"__isNode"},i,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"ExperimentAnnotationSummary",kind:"LinkedField",name:"experimentAnnotationSummaries",plural:!0,selections:[r,{alias:null,args:null,kind:"ScalarField",name:"minScore",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"maxScore",storageKey:null}],storageKey:null},{alias:null,args:t,concreteType:"ExperimentConnection",kind:"LinkedField",name:"experiments",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"experiment",args:null,concreteType:"Experiment",kind:"LinkedField",name:"node",plural:!1,selections:[i,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"sequenceNumber",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"errorRate",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"runCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"averageRunLatencyMs",storageKey:null},{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[i],storageKey:null},{alias:null,args:null,concreteType:"ExperimentAnnotationSummary",kind:"LinkedField",name:"annotationSummaries",plural:!0,selections:[r,{alias:null,args:null,kind:"ScalarField",name:"meanScore",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Experiment",kind:"LinkedField",name:"node",plural:!1,selections:[l],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:t,filters:null,handle:"connection",key:"ExperimentsTable_experiments",kind:"LinkedHandle",name:"experiments"}],type:"Dataset",abstractKey:null}],storageKey:null}]},params:{cacheID:"1db5ce5523fa9a472c91d093b0e6160e",id:null,metadata:{},name:"ExperimentsTableQuery",operationKind:"query",text:`query ExperimentsTableQuery(
  $after: String = null
  $first: Int = 100
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...ExperimentsTableFragment_2HEEH6
    __isNode: __typename
    id
  }
}

fragment ExperimentsTableFragment_2HEEH6 on Dataset {
  experimentAnnotationSummaries {
    annotationName
    minScore
    maxScore
  }
  experiments(first: $first, after: $after) {
    edges {
      experiment: node {
        id
        name
        sequenceNumber
        description
        createdAt
        metadata
        errorRate
        runCount
        averageRunLatencyMs
        project {
          id
        }
        annotationSummaries {
          annotationName
          meanScore
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();Is.hash="c7c7580fe40888ceb86a1701fe4eedf4";const Ps=function(){var n=["experiments"],a={alias:null,args:null,kind:"ScalarField",name:"annotationName",storageKey:null},t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:100,kind:"LocalArgument",name:"first"}],kind:"Fragment",metadata:{connection:[{count:"first",cursor:"after",direction:"forward",path:n}],refetch:{connection:{forward:{count:"first",cursor:"after"},backward:null,path:n},fragmentPathInResult:["node"],operation:Is,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"ExperimentsTableFragment",selections:[{alias:null,args:null,concreteType:"ExperimentAnnotationSummary",kind:"LinkedField",name:"experimentAnnotationSummaries",plural:!0,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"minScore",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"maxScore",storageKey:null}],storageKey:null},{alias:"experiments",args:null,concreteType:"ExperimentConnection",kind:"LinkedField",name:"__ExperimentsTable_experiments_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"experiment",args:null,concreteType:"Experiment",kind:"LinkedField",name:"node",plural:!1,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"sequenceNumber",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"errorRate",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"runCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"averageRunLatencyMs",storageKey:null},{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[t],storageKey:null},{alias:null,args:null,concreteType:"ExperimentAnnotationSummary",kind:"LinkedField",name:"annotationSummaries",plural:!0,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"meanScore",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Experiment",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},t],type:"Dataset",abstractKey:null}}();Ps.hash="c7c7580fe40888ceb86a1701fe4eedf4";function hy({getValue:n}){const a=n(),t=a!==null?a*100:null,l=m.useMemo(()=>{if(t!==null)return t>=80?"red-1100":t>0?"orange-1100":"green-1100"},[t]);return e(x,{color:l,children:mt(t)})}const Ls=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"ExperimentMutationPayload",kind:"LinkedField",name:"deleteExperiments",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExperimentSelectionToolbarDeleteExperimentsMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExperimentSelectionToolbarDeleteExperimentsMutation",selections:a},params:{cacheID:"3af24cbaf3208c0d5ad1cd9313dd3823",id:null,metadata:{},name:"ExperimentSelectionToolbarDeleteExperimentsMutation",operationKind:"mutation",text:`mutation ExperimentSelectionToolbarDeleteExperimentsMutation(
  $input: DeleteExperimentsInput!
) {
  deleteExperiments(input: $input) {
    __typename
  }
}
`}}}();Ls.hash="4ab310746eb51c6a3fcb799d2c972762";function ky(n){const a=ne(),[t,l]=m.useState(null),[i,r]=P.useMutation(Ls),{datasetId:s,selectedExperiments:c,onClearSelection:d,onExperimentsDeleted:u}=n,y=c.length!==1,g=ve(),p=be(),f=m.useCallback(()=>{i({variables:{input:{experimentIds:c.map(b=>b.id)}},onCompleted:()=>{g({title:"Examples Deleted",message:`${c.length} experiment${y?"s":""} have been deleted.`}),u(),d()},onError:b=>{p({title:"An error occurred",message:`Failed to delete examples: ${b.message}`})}})},[i,y,p,g,d,u,c]),k=m.useCallback(()=>{l(o(Y,{size:"S",title:"Delete Experiments",children:[e(F,{padding:"size-200",children:e(x,{color:"danger",children:"Are you sure you want to delete these experiments? This will also delete all associated annotations and traces, and it cannot be undone."})}),e(F,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:e(h,{direction:"row",justifyContent:"end",children:e(z,{variant:"danger",onClick:()=>{f(),l(null)},children:"Delete Experiments"})})})]}))},[f]);return o("div",{css:C`
        position: absolute;
        bottom: var(--ac-global-dimension-size-400);
        left: 50%;
        transform: translateX(-50%);
      `,children:[e(F,{backgroundColor:"light",padding:"size-200",borderColor:"light",borderWidth:"thin",borderRadius:"medium",minWidth:"size-6000",children:o(h,{direction:"row",justifyContent:"space-between",alignItems:"center",gap:"size-100",children:[e(x,{children:`${c.length} experiment${y?"s":""} selected`}),o(h,{direction:"row",gap:"size-100",children:[e(z,{variant:"default",size:"compact",onClick:d,children:"Cancel"}),e(z,{variant:"danger",size:"compact",icon:e(L,{svg:e(D.TrashOutline,{})}),loading:r,disabled:r,onClick:k,children:r?"Deleting...":"Delete"}),e(z,{variant:"primary",size:"compact",onClick:()=>{a(`/datasets/${s}/compare?${c.map(b=>`experimentId=${b.id}`).join("&")}`)},icon:e(L,{svg:e(D.ArrowCompareOutline,{})}),children:"Compare Experiments"})]})]})}),e(ae,{onDismiss:()=>{l(null)},children:t})]})}const by=100;function Sy(){return e("tbody",{className:"is-empty",children:e("tr",{children:o("td",{colSpan:100,css:C`
            text-align: center;
            padding: var(--ac-global-dimension-size-400) !important;
            .ac-button {
              margin-top: var(--ac-global-dimension-size-200);
              margin-left: auto;
              margin-right: auto;
            }
          `,children:["No experiments for this dataset. To see how to run experiments on a dataset, check out the documentation.",e(vs,{})]})})})}function vy({dataset:n}){const a=m.useRef(null),[t,l]=m.useState({}),{data:i,loadNext:r,hasNext:s,isLoadingNext:c,refetch:d}=P.usePaginationFragment(Ps,n),u=m.useMemo(()=>i.experiments.edges.map(K=>{const T=K.experiment.annotationSummaries.reduce((E,_)=>(E[_.annotationName]=_,E),{});return{...K.experiment,annotationSummaryMap:T}}),[i.experiments.edges]),y=[{id:"select",header:({table:K})=>e(mn,{checked:K.getIsAllRowsSelected(),indeterminate:K.getIsSomeRowsSelected(),onChange:K.getToggleAllRowsSelectedHandler()}),cell:({row:K})=>e(mn,{checked:K.getIsSelected(),disabled:!K.getCanSelect(),indeterminate:K.getIsSomeSelected(),onChange:K.getToggleSelectedHandler()})},{header:"name",accessorKey:"name",minSize:200,cell:({getValue:K,row:T})=>{const E=T.original.id,_=T.original.sequenceNumber;return o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(Ga,{sequenceNumber:_}),e(cn,{to:`/datasets/${n.id}/compare?experimentId=${E}`,children:K()})]})}},{header:"description",accessorKey:"description",minSize:300,cell:Ke},{header:"created at",accessorKey:"createdAt",cell:_e}],g=i.experimentAnnotationSummaries.map(K=>{const{annotationName:T,minScore:E,maxScore:_}=K;return{header:()=>o(h,{direction:"row",gap:"size-100",wrap:!0,alignItems:"center",justifyContent:"end",children:[e(x,{children:T}),e(uc,{annotationName:T})]}),id:`annotation-${T}`,meta:{textAlign:"right"},cell:({row:j})=>{const V=j.original.annotationSummaryMap[T];return!V||V.meanScore==null?e("span",{css:C`
                  float: right;
                `,children:"--"}):e(Cy,{annotationName:T,value:V.meanScore,min:E,max:_})}}}),p=[{header:"run count",accessorKey:"runCount",meta:{textAlign:"right"},cell:mc},{header:"avg latency",accessorKey:"averageRunLatencyMs",meta:{textAlign:"right"},cell:({getValue:K})=>{const T=K();return T===null||typeof T!="number"?"--":e(Re,{latencyMs:T})}},{header:"error rate",accessorKey:"errorRate",meta:{textAlign:"right"},cell:hy},{header:"metadata",accessorKey:"metadata",minSize:200,cell:jn},{id:"actions",cell:({row:K})=>{const T=K.original.project,E=K.original.metadata;return e(Zl,{projectId:(T==null?void 0:T.id)||null,experimentId:K.original.id,metadata:E})}}],f=Te({columns:[...y,...g,...p],data:u,getCoreRowModel:De(),state:{rowSelection:t},onRowSelectionChange:l}),k=f.getRowModel().rows,b=f.getSelectedRowModel().rows,S=b.map(K=>K.original),v=m.useCallback(()=>{l({})},[l]),I=k.length===0,w=m.useCallback(K=>{if(K){const{scrollHeight:T,scrollTop:E,clientHeight:_}=K;T-E-_<300&&!c&&s&&r(by)}},[s,c,r]),R=ne();return o("div",{css:C`
        flex: 1 1 auto;
        overflow: auto;
        width: table.getTotalSize();
      `,ref:a,onScroll:K=>w(K.target),children:[o("table",{css:Jn,children:[e("thead",{children:f.getHeaderGroups().map(K=>e("tr",{children:K.headers.map(T=>{var E,_;return e("th",{align:(_=(E=T.column.columnDef)==null?void 0:E.meta)==null?void 0:_.textAlign,children:e("div",{children:Z(T.column.columnDef.header,T.getContext())})},T.id)})},K.id))}),I?e(Sy,{}):e("tbody",{children:k.map(K=>e("tr",{onClick:()=>{R(`/datasets/${n.id}/compare?experimentId=${K.original.id}`)},children:K.getVisibleCells().map(T=>e("td",{children:Z(T.column.columnDef.cell,T.getContext())},T.id))},K.id))})]}),b.length?e(ky,{datasetId:n.id,selectedExperiments:S,onClearSelection:v,onExperimentsDeleted:()=>{d({},{fetchPolicy:"store-and-network"})}}):null]})}function Cy({annotationName:n,value:a,min:t,max:l}){const i=jl(n),r=m.useMemo(()=>{const s=typeof t=="number"?t:0,c=typeof l=="number"?l:1;if(s===c&&c===a)return 100;const d=c-s||1;return(a-s)/d*100},[a,t,l]);return o(pe,{children:[e(Oe,{children:o("div",{css:C`
            float: right;
            --mod-barloader-fill-color: ${i};
            display: flex;
            flex-direction: row;
            align-items: center;
            gap: var(--ac-global-dimension-size-100);
          `,children:[Qn(a),e(dd,{width:"40px",value:r,"aria-label":"where the mean score lands between overall min max"})]})}),e(ka,{children:o(F,{width:"size-2400",children:[e(ge,{level:3,weight:"heavy",children:n}),o(h,{direction:"column",children:[o(h,{justifyContent:"space-between",children:[e(x,{weight:"heavy",textSize:"small",children:"Mean Score"}),e(x,{textSize:"small",children:Qn(a)})]}),o(h,{justifyContent:"space-between",children:[e(x,{weight:"heavy",textSize:"small",children:"All Experiments Min"}),e(x,{textSize:"small",children:Qn(t)})]}),o(h,{justifyContent:"space-between",children:[e(x,{weight:"heavy",textSize:"small",children:"All Experiments Max"}),e(x,{textSize:"small",children:Qn(l)})]}),o(h,{justifyContent:"space-between",children:[e(x,{weight:"heavy",textSize:"small",children:"Mean Score Percentile"}),e(x,{textSize:"small",children:ql(r)})]})]})]})})]})}function v1(){const n=_n();return o(G,{children:[e(vy,{dataset:n.dataset}),e(m.Suspense,{children:e(Ve,{})})]})}const Es=function(){var n={defaultValue:null,kind:"LocalArgument",name:"datasetId"},a={defaultValue:null,kind:"LocalArgument",name:"experimentIds"},t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={alias:null,args:null,concreteType:"Trace",kind:"LinkedField",name:"trace",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"projectId",storageKey:null}],storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},r={alias:"comparisons",args:[{kind:"Variable",name:"experimentIds",variableName:"experimentIds"}],concreteType:"ExperimentComparison",kind:"LinkedField",name:"compareExperiments",plural:!0,selections:[{alias:null,args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"example",plural:!1,selections:[t,{alias:null,args:null,concreteType:"DatasetExampleRevision",kind:"LinkedField",name:"revision",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"input",storageKey:null},{alias:"referenceOutput",args:null,kind:"ScalarField",name:"output",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"RunComparisonItem",kind:"LinkedField",name:"runComparisonItems",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"experimentId",storageKey:null},{alias:null,args:null,concreteType:"ExperimentRun",kind:"LinkedField",name:"runs",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"error",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null},l,{alias:null,args:null,concreteType:"ExperimentRunAnnotationConnection",kind:"LinkedField",name:"annotations",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunAnnotationEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"annotation",args:null,concreteType:"ExperimentRunAnnotation",kind:"LinkedField",name:"node",plural:!1,selections:[t,i,{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},l],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null},s=[{kind:"Variable",name:"id",variableName:"datasetId"}],c={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"ExperimentConnection",kind:"LinkedField",name:"experiments",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"experiment",args:null,concreteType:"Experiment",kind:"LinkedField",name:"node",plural:!1,selections:[t,i,{alias:null,args:null,kind:"ScalarField",name:"sequenceNumber",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[t],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Dataset",abstractKey:null};return{fragment:{argumentDefinitions:[n,a],kind:"Fragment",metadata:null,name:"ExperimentCompareTableQuery",selections:[r,{alias:"dataset",args:s,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,c],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,n],kind:"Operation",name:"ExperimentCompareTableQuery",selections:[r,{alias:"dataset",args:s,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t,c],storageKey:null}]},params:{cacheID:"e8b3f1f7011d0059ded7076b4d83afea",id:null,metadata:{},name:"ExperimentCompareTableQuery",operationKind:"query",text:`query ExperimentCompareTableQuery(
  $experimentIds: [GlobalID!]!
  $datasetId: GlobalID!
) {
  comparisons: compareExperiments(experimentIds: $experimentIds) {
    example {
      id
      revision {
        input
        referenceOutput: output
      }
    }
    runComparisonItems {
      experimentId
      runs {
        output
        error
        startTime
        endTime
        trace {
          traceId
          projectId
        }
        annotations {
          edges {
            annotation: node {
              id
              name
              score
              label
              annotatorKind
              explanation
              trace {
                traceId
                projectId
              }
            }
          }
        }
      }
    }
  }
  dataset: node(id: $datasetId) {
    __typename
    id
    ... on Dataset {
      experiments {
        edges {
          experiment: node {
            id
            name
            sequenceNumber
            metadata
            project {
              id
            }
          }
        }
      }
    }
  }
}
`}}}();Es.hash="7e1c83a2fa6f2f46532902b526017663";const ct={backgroundColor:"light",borderColor:"light",variant:"compact",collapsible:!0,bodyStyle:{padding:0}},Fy=C`
  flex: 1 1 auto;
  overflow: auto;
  // Make sure the table fills up the remaining space
  table {
    min-width: 100%;
    td {
      vertical-align: top;
    }
  }
`,Ky=C`
  display: flex;
  flex-direction: row;
  align-items: center;
  color: var(--ac-global-color-primary);
  gap: var(--ac-global-dimension-size-50);
`;function xy(n){const{datasetId:a,experimentIds:t,displayFullText:l}=n,i=P.useLazyLoadQuery(Es,{experimentIds:t,datasetId:a}),r=m.useMemo(()=>{var S,v;return((v=(S=i.dataset)==null?void 0:S.experiments)==null?void 0:v.edges.reduce((I,w)=>{var R,K;return I[w.experiment.id]={...w.experiment,projectId:((K=(R=w.experiment)==null?void 0:R.project)==null?void 0:K.id)||null},I},{}))||{}},[i]),s=m.useMemo(()=>i.comparisons.map(S=>{const v=S.runComparisonItems.reduce((I,w)=>(I[w.experimentId]=w,I),{});return{...S,id:S.example.id,input:S.example.revision.input,referenceOutput:S.example.revision.referenceOutput,runComparisonMap:v}}),[i]),[c,d]=m.useState(null),u=m.useMemo(()=>[{header:"input",accessorKey:"input",minWidth:500,cell:({row:S})=>e(Wt,{controls:o(pe,{children:[e(z,{variant:"default",size:"compact","aria-label":"View example details",icon:e(L,{svg:e(D.ExpandOutline,{})}),onClick:()=>{m.startTransition(()=>{d(e(m.Suspense,{children:e(At,{exampleId:S.original.example.id,onDismiss:()=>{d(null)}})}))})}}),e(Fe,{children:"View Example"})]}),children:e(zt,{children:e(Ca,{json:S.original.input,disableTitle:!0,space:l?2:0})})})},{header:"reference output",accessorKey:"referenceOutput",minWidth:500,cell:l?Py:jn}],[l]),y=m.useMemo(()=>t.map(S=>({header:()=>{var K,T,E,_;const v=(K=r[S])==null?void 0:K.name,I=(T=r[S])==null?void 0:T.metadata,w=(E=r[S])==null?void 0:E.projectId,R=((_=r[S])==null?void 0:_.sequenceNumber)||0;return o(h,{direction:"row",gap:"size-100",wrap:!0,alignItems:"center",justifyContent:"space-between",children:[o(h,{direction:"row",gap:"size-100",wrap:!0,alignItems:"center",children:[e(Ga,{sequenceNumber:R}),e(x,{children:v})]}),e(Zl,{experimentId:S,metadata:I,isQuiet:!0,projectId:w})]})},accessorKey:S,minSize:500,cell:({row:v})=>{var j,V;const I=v.original.runComparisonMap[S],w=(I==null?void 0:I.runs.length)||0;if(w===0)return e(cl,{});if(w>1)return e(x,{color:"warning",children:`${w} runs`});const R=I==null?void 0:I.runs[0];let K=null;const T=(j=R==null?void 0:R.trace)==null?void 0:j.traceId,E=(V=R==null?void 0:R.trace)==null?void 0:V.projectId;T&&E&&(K=o(pe,{children:[e(z,{variant:"default",className:"trace-button",size:"compact","aria-label":"View run trace",icon:e(L,{svg:e(D.Trace,{})}),onClick:H=>{H.preventDefault(),H.stopPropagation(),m.startTransition(()=>{d(e(As,{traceId:T,projectId:E,title:"Experiment Run Trace"}))})}}),e(Fe,{children:"View Trace"})]}));const _=o(G,{children:[o(pe,{children:[e(z,{variant:"default",className:"expand-button",size:"compact","aria-label":"View example run details",icon:e(L,{svg:e(D.ExpandOutline,{})}),onClick:H=>{H.preventDefault(),H.stopPropagation(),m.startTransition(()=>{d(e(Ly,{selectedExample:v.original,datasetId:a,experimentInfoById:r}))})}}),e(Fe,{children:"View run details"})]}),K]});return R?e(Wt,{controls:_,children:e(Iy,{...R,displayFullText:l,setDialog:d})}):e(cl,{})}})),[t,r,a,l]),g=m.useMemo(()=>[...u,...y,{id:"tail",minSize:500}],[u,y]),p=Te({columns:g,data:s,getCoreRowModel:De(),columnResizeMode:"onChange"}),f=Se.useMemo(()=>{const S=p.getFlatHeaders(),v={};for(let I=0;I<S.length;I++){const w=S[I];v[`--header-${w.id}-size`]=w.getSize(),v[`--col-${w.column.id}-size`]=w.column.getSize()}return v},[p.getState().columnSizingInfo,p.getState().columnSizing]),b=p.getRowModel().rows.length===0;return o("div",{css:Fy,children:[o("table",{css:S=>C(Je(S),Yl),style:{...f,width:p.getTotalSize(),minWidth:"100%"},children:[e("thead",{children:p.getHeaderGroups().map(S=>e("tr",{children:S.headers.map(v=>o("th",{style:{width:`calc(var(--header-${v==null?void 0:v.id}-size) * 1px)`},children:[e("div",{children:Z(v.column.columnDef.header,v.getContext())}),e("div",{onMouseDown:v.getResizeHandler(),onTouchStart:v.getResizeHandler(),className:`resizer ${v.column.getIsResizing()?"isResizing":""}`})]},v.id))},S.id))}),b?e(Ze,{}):p.getState().columnSizingInfo.isResizingColumn?e(Ty,{table:p}):e(ws,{table:p})]}),e(ae,{isDismissable:!0,type:"slideOver",onDismiss:()=>{d(null)},children:c})]})}function ws({table:n}){return e("tbody",{children:n.getRowModel().rows.map(a=>e("tr",{children:a.getVisibleCells().map(t=>e("td",{style:{width:`calc(var(--col-${t.column.id}-size) * 1px)`},children:Z(t.column.columnDef.cell,t.getContext())},t.id))},a.id))})}const Ty=Se.memo(ws,(n,a)=>n.table.options.data===a.table.options.data);function Dy(n){const{datasetId:a,exampleId:t}=n,l=ne();return e("div",{onClick:i=>{i.preventDefault(),i.stopPropagation()},children:e(Rn,{buttonSize:"compact",align:"end",onAction:i=>{switch(i){case"gotoExample":return l(`/datasets/${a}/examples/${t}`);default:ue()}},children:e(le,{children:o(h,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(L,{svg:e(D.ExternalLinkOutline,{})}),e(x,{children:"Go to example"})]})},"gotoExample")})})}function Iy(n){const{output:a,error:t,startTime:l,endTime:i,annotations:r,displayFullText:s,setDialog:c}=n;if(t)return e(_s,{error:t});const d=r!=null&&r.edges.length?r.edges.map(u=>u.annotation):[];return o(h,{direction:"column",gap:"size-100",height:"100%",justifyContent:"space-between",children:[e(zt,{children:e(Ca,{json:a,disableTitle:!0,space:s?2:0})}),o("ul",{css:C`
          display: flex;
          flex-direction: row;
          gap: var(--ac-global-dimension-static-size-100);
          align-items: center;
          flex-wrap: wrap;
        `,children:[e("li",{children:e(Rs,{startTime:l,endTime:i})},"run-latency"),d.map(u=>e("li",{children:e(Sa,{annotation:u,extra:u.trace&&e(F,{paddingTop:"size-100",children:o("div",{css:Ky,children:[e(L,{svg:e(D.InfoOutline,{})}),e("span",{children:"Click to view evaluator trace"})]})}),children:e(yn,{annotation:u,onClick:()=>{const y=u.trace;y&&m.startTransition(()=>{c(e(As,{traceId:y.traceId,projectId:y.projectId,title:`Evaluator Trace: ${u.name}`}))})}})})},u.id))]})]})}function _s({error:n}){return o(h,{direction:"row",gap:"size-50",alignItems:"center",children:[e(L,{svg:e(D.AlertCircleOutline,{}),color:"danger"}),e(x,{color:"danger",children:n})]})}function Rs({startTime:n,endTime:a}){const t=m.useMemo(()=>{let l=null;return n&&a&&(l=new Date(a).getTime()-new Date(n).getTime()),l},[n,a]);return t===null?null:e(Re,{latencyMs:t})}function cl(){return o(h,{direction:"row",gap:"size-50",children:[e(L,{svg:e(D.MinusCircleOutline,{}),color:"grey-800"}),e(x,{color:"text-700",children:"not run"})]})}function Py({getValue:n}){const a=n();return e(zt,{children:e(Ca,{json:a,space:2})})}function zt({children:n}){return e("div",{css:C`
        max-height: 300px;
        overflow-y: auto;
      `,children:n})}function Ly({selectedExample:n,datasetId:a,experimentInfoById:t}){return e(Y,{title:`Comparing Experiments for Example: ${n.id}`,size:"fullscreen",extra:e(Dy,{datasetId:a,exampleId:n.id}),children:o(tn,{direction:"vertical",autoSaveId:"example-compare-panel-group",children:[e(he,{defaultSize:100,children:e("div",{css:C`
              overflow-y: auto;
              height: 100%;
            `,children:e(F,{overflow:"hidden",padding:"size-200",children:o(h,{direction:"row",gap:"size-200",flex:"1 1 auto",children:[e(F,{width:"50%",children:e(q,{title:"Input",...ct,bodyStyle:{padding:0,maxHeight:"300px",overflowY:"auto"},extra:e(se,{text:JSON.stringify(n.input)}),children:e(nn,{value:JSON.stringify(n.input,null,2)})})}),e(F,{width:"50%",children:e(q,{title:"Reference Output",...ct,extra:e(se,{text:JSON.stringify(n.referenceOutput)}),bodyStyle:{padding:0,maxHeight:"300px",overflowY:"auto"},children:e(nn,{value:JSON.stringify(n.referenceOutput,null,2)})})})]})})})}),e(an,{css:fn}),e(he,{defaultSize:200,children:o(h,{direction:"column",height:"100%",children:[e(F,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderBottomColor:"dark",borderBottomWidth:"thin",flex:"none",children:e(ge,{level:2,children:"Experiments"})}),e("div",{css:C`
                overflow-y: auto;
                height: 100%;
                padding: var(--ac-global-dimension-static-size-200);
              `,children:e("ul",{css:C`
                  display: flex;
                  flex-direction: column;
                  gap: var(--ac-global-dimension-static-size-200);
                `,children:n.runComparisonItems.map(l=>{const i=t[l.experimentId];return e("li",{children:e(q,{...ct,title:i==null?void 0:i.name,titleExtra:e(Ga,{sequenceNumber:(i==null?void 0:i.sequenceNumber)||0}),children:e("ul",{children:l.runs.map((r,s)=>{var c;return e("li",{children:o(h,{direction:"row",children:[e(F,{flex:!0,children:r.error?e(F,{padding:"size-200",children:e(_s,{error:r.error})}):e(nn,{value:JSON.stringify(r.output,null,2)})}),o(xn,{width:"size-3000",children:[e(Rs,{startTime:r.startTime,endTime:r.endTime}),e("ul",{css:C`
                                      margin-top: var(
                                        --ac-global-dimension-static-size-100
                                      );
                                      display: flex;
                                      flex-direction: column;
                                      justify-content: flex-start;
                                      align-items: flex-end;
                                      gap: var(
                                        --ac-global-dimension-static-size-100
                                      );
                                    `,children:(c=r.annotations)==null?void 0:c.edges.map(d=>e("li",{children:e(yn,{annotation:d.annotation})},d.annotation.id))})]})]})},s)})})})},l.experimentId)})})})]})})]})})}function As({traceId:n,projectId:a,title:t}){const l=ne();return e(Y,{title:t,size:"fullscreen",extra:e(z,{variant:"default",onClick:()=>l(`/projects/${a}/traces/${n}`),children:"View Trace in Project"}),children:e(Nt,{traceId:n,projectId:a})})}const Ms={argumentDefinitions:[],kind:"Fragment",metadata:null,name:"ExperimentMultiSelector__experiments",selections:[{alias:null,args:null,concreteType:"ExperimentConnection",kind:"LinkedField",name:"experiments",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"experiment",args:null,concreteType:"Experiment",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"sequenceNumber",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Dataset",abstractKey:null};Ms.hash="1aa376b1e9425f49268ac231dc2c0412";function Ey(n){const{dataset:a,selectedExperimentIds:t,onChange:l,label:i,validationState:r,description:s,errorMessage:c,...d}=n,u=P.useFragment(Ms,a),y=m.useMemo(()=>u.experiments.edges.map(f=>f.experiment),[u]),g=y.length===0,p=m.useMemo(()=>{if(g)return"No experiments";const f=t.length;return f>0?`${f} experiment${f>1?"s":""}`:"No experiments selected"},[t,g]);return e(Mn,{label:i,isDisabled:g,validationState:r,description:s,errorMessage:c,children:e(vt,{isDisabled:g,...d,menu:e(Qa,{selectionMode:"multiple",onSelectionChange:f=>{l(Array.from(f))},selectedKeys:new Set(t),children:y.map(f=>e(le,{textValue:f.name,children:o(h,{direction:"column",gap:"size-50",children:[o(h,{direction:"row",gap:"size-100",children:[e(Ga,{sequenceNumber:f.sequenceNumber}),e(x,{children:f.name})]}),e(x,{textSize:"small",color:"text-700",children:new Date(f.createdAt).toLocaleString()})]})},f.id))}),triggerProps:{placement:"bottom start"},children:p})})}function C1(){const n=_n(),[a,t]=m.useState(!1),[l,i]=fa(),r=l.getAll("experimentId"),s=r.length>0;return o("main",{css:C`
        height: 100%;
        display: flex;
        flex-direction: column;
        overflow: hidden;
      `,children:[e(F,{padding:"size-200",borderBottomColor:"dark",borderBottomWidth:"thin",flex:"none",children:o(h,{direction:"column",gap:"size-100",children:[e(ge,{level:1,children:"Compare Experiments"}),o(h,{direction:"row",justifyContent:"space-between",alignItems:"end",children:[e(Ey,{dataset:n.dataset,selectedExperimentIds:r,label:"experiments",onChange:c=>{m.startTransition(()=>{l.delete("experimentId"),c.forEach(d=>{l.append("experimentId",d)}),i(l)})}}),e(Gn,{onChange:c=>{t(c)},defaultSelected:!1,labelPlacement:"start",children:"Full Text"})]})]})}),s?e(m.Suspense,{fallback:e(ye,{}),children:e(xy,{datasetId:n.dataset.id,experimentIds:r,displayFullText:a})}):e(F,{padding:"size-200",children:e(ce,{variant:"info",title:"No Experiment Selected",children:"Please select one or more experiments."})})]})}const Ns=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"experimentCompareLoaderQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"InlineFragment",selections:[l,{args:null,kind:"FragmentSpread",name:"ExperimentMultiSelector__experiments"}],type:"Dataset",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"experimentCompareLoaderQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t,{kind:"InlineFragment",selections:[l,{alias:null,args:null,concreteType:"ExperimentConnection",kind:"LinkedField",name:"experiments",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"experiment",args:null,concreteType:"Experiment",kind:"LinkedField",name:"node",plural:!1,selections:[t,l,{alias:null,args:null,kind:"ScalarField",name:"sequenceNumber",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Dataset",abstractKey:null}],storageKey:null}]},params:{cacheID:"7e89f99f940098a21985137aae870de7",id:null,metadata:{},name:"experimentCompareLoaderQuery",operationKind:"query",text:`query experimentCompareLoaderQuery(
  $id: GlobalID!
) {
  dataset: node(id: $id) {
    __typename
    id
    ... on Dataset {
      id
      name
      ...ExperimentMultiSelector__experiments
    }
  }
}

fragment ExperimentMultiSelector__experiments on Dataset {
  experiments {
    edges {
      experiment: node {
        id
        name
        sequenceNumber
        createdAt
      }
    }
  }
}
`}}}();Ns.hash="fa02088830fd16688f0f2fba9a0009eb";async function F1(n){const{datasetId:a}=n.params;return await P.fetchQuery(Ne,Ns,{id:a}).toPromise()}const zs=function(){var n={defaultValue:null,kind:"LocalArgument",name:"description"},a={defaultValue:null,kind:"LocalArgument",name:"expiresAt"},t={defaultValue:null,kind:"LocalArgument",name:"name"},l=[{fields:[{kind:"Variable",name:"description",variableName:"description"},{kind:"Variable",name:"expiresAt",variableName:"expiresAt"},{kind:"Variable",name:"name",variableName:"name"}],kind:"ObjectValue",name:"input"}],i={alias:null,args:null,kind:"ScalarField",name:"jwt",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},s={alias:null,args:null,concreteType:"SystemApiKey",kind:"LinkedField",name:"apiKey",plural:!1,selections:[r],storageKey:null};return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"APIKeysCardCreateSystemAPIKeyMutation",selections:[{alias:null,args:l,concreteType:"CreateSystemApiKeyMutationPayload",kind:"LinkedField",name:"createSystemApiKey",plural:!1,selections:[i,{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"SystemAPIKeysTableFragment"}],storageKey:null},s],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[t,n,a],kind:"Operation",name:"APIKeysCardCreateSystemAPIKeyMutation",selections:[{alias:null,args:l,concreteType:"CreateSystemApiKeyMutationPayload",kind:"LinkedField",name:"createSystemApiKey",plural:!1,selections:[i,{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:null,args:null,concreteType:"SystemApiKey",kind:"LinkedField",name:"systemApiKeys",plural:!0,selections:[r,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null}],storageKey:null}],storageKey:null},s],storageKey:null}]},params:{cacheID:"799e8f0a627c6ae06e2a87c051d299d0",id:null,metadata:{},name:"APIKeysCardCreateSystemAPIKeyMutation",operationKind:"mutation",text:`mutation APIKeysCardCreateSystemAPIKeyMutation(
  $name: String!
  $description: String = null
  $expiresAt: DateTime = null
) {
  createSystemApiKey(input: {name: $name, description: $description, expiresAt: $expiresAt}) {
    jwt
    query {
      ...SystemAPIKeysTableFragment
    }
    apiKey {
      id
    }
  }
}

fragment SystemAPIKeysTableFragment on Query {
  systemApiKeys {
    id
    name
    description
    createdAt
    expiresAt
  }
}
`}}}();zs.hash="a6f84fa9e14f363d2e7317d3d6507590";const Vs=function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},a={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},t={alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null};return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"APIKeysCardQuery",selections:[{args:null,kind:"FragmentSpread",name:"SystemAPIKeysTableFragment"},{args:null,kind:"FragmentSpread",name:"UserAPIKeysTableFragment"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"APIKeysCardQuery",selections:[{alias:null,args:null,concreteType:"SystemApiKey",kind:"LinkedField",name:"systemApiKeys",plural:!0,selections:[n,a,t,l,i],storageKey:null},{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"userApiKeys",plural:!0,selections:[n,a,t,l,i,{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"a8cfba9eaaac34bc497efaacbff45c05",id:null,metadata:{},name:"APIKeysCardQuery",operationKind:"query",text:`query APIKeysCardQuery {
  ...SystemAPIKeysTableFragment
  ...UserAPIKeysTableFragment
}

fragment SystemAPIKeysTableFragment on Query {
  systemApiKeys {
    id
    name
    description
    createdAt
    expiresAt
  }
}

fragment UserAPIKeysTableFragment on Query {
  userApiKeys {
    id
    name
    description
    createdAt
    expiresAt
    user {
      email
    }
  }
}
`}}}();Vs.hash="ad967afd45af0d5976982c70eaadb330";const $s=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"DeleteApiKeyMutationPayload",kind:"LinkedField",name:"deleteSystemApiKey",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"apiKeyId",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SystemAPIKeysTableDeleteAPIKeyMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SystemAPIKeysTableDeleteAPIKeyMutation",selections:a},params:{cacheID:"a8c45c42b5becca8efa65334285a2f97",id:null,metadata:{},name:"SystemAPIKeysTableDeleteAPIKeyMutation",operationKind:"mutation",text:`mutation SystemAPIKeysTableDeleteAPIKeyMutation(
  $input: DeleteApiKeyInput!
) {
  deleteSystemApiKey(input: $input) {
    __typename
    apiKeyId
  }
}
`}}}();$s.hash="55ab8200b5bfda0aa73594ad5cfce96f";const Os={fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"SystemAPIKeysTableQuery",selections:[{args:null,kind:"FragmentSpread",name:"SystemAPIKeysTableFragment"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"SystemAPIKeysTableQuery",selections:[{alias:null,args:null,concreteType:"SystemApiKey",kind:"LinkedField",name:"systemApiKeys",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null}],storageKey:null}]},params:{cacheID:"94e06b8cd5879701a5d73bee083ad614",id:null,metadata:{},name:"SystemAPIKeysTableQuery",operationKind:"query",text:`query SystemAPIKeysTableQuery {
  ...SystemAPIKeysTableFragment
}

fragment SystemAPIKeysTableFragment on Query {
  systemApiKeys {
    id
    name
    description
    createdAt
    expiresAt
  }
}
`}};Os.hash="de0fc04de739f0adfcbdeaff28b16265";const Qs={argumentDefinitions:[],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:[],operation:Os}},name:"SystemAPIKeysTableFragment",selections:[{alias:null,args:null,concreteType:"SystemApiKey",kind:"LinkedField",name:"systemApiKeys",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null}],storageKey:null}],type:"Query",abstractKey:null};Qs.hash="de0fc04de739f0adfcbdeaff28b16265";function wy({query:n}){const[a,t]=P.useRefetchableFragment(Qs,n),l=be(),i=ve(),[r]=P.useMutation($s),s=m.useCallback(p=>{r({variables:{input:{id:p}},onCompleted:()=>{i({title:"System key deleted",message:"The system key has been deleted and is no longer active."}),m.startTransition(()=>{t({},{fetchPolicy:"network-only"})})},onError:f=>{l({title:"Error deleting system key",message:f.message})}})},[r,l,i,t]),c=m.useMemo(()=>[...a.systemApiKeys],[a]),d=m.useMemo(()=>[{header:"Name",accessorKey:"name"},{header:"Description",accessorKey:"description",cell:Ke},{header:"Created At",accessorKey:"createdAt",cell:_e},{header:"Expires At",accessorKey:"expiresAt",cell:_e},{header:"",accessorKey:"id",size:10,cell:({row:f})=>e(h,{direction:"row",justifyContent:"end",width:"100%",children:e(It,{handleDelete:()=>{s(f.original.id)}})}),meta:{textAlign:"right"}}],[s]),u=Te({columns:d,data:c,getCoreRowModel:De()}),y=u.getRowModel().rows,g=u.getRowModel().rows.length===0;return o("table",{css:Je,children:[e("thead",{children:u.getHeaderGroups().map(p=>e("tr",{children:p.headers.map(f=>e("th",{colSpan:f.colSpan,children:f.isPlaceholder?null:o("div",{className:f.column.getCanSort()?"cursor-pointer":"",onClick:f.column.getToggleSortingHandler(),style:{left:f.getStart(),width:f.getSize()},children:[Z(f.column.columnDef.header,f.getContext()),f.column.getIsSorted()?e(L,{className:"sort-icon",svg:f.column.getIsSorted()==="asc"?e(D.ArrowUpFilled,{}):e(D.ArrowDownFilled,{})}):null]})},f.id))},p.id))}),g?e(Ze,{message:"No Keys"}):e("tbody",{children:y.map(p=>e("tr",{children:p.getVisibleCells().map(f=>e("td",{children:Z(f.column.columnDef.cell,f.getContext())},f.id))},p.id))})]})}const js=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"DeleteApiKeyMutationPayload",kind:"LinkedField",name:"deleteUserApiKey",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"apiKeyId",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"UserAPIKeysTableDeleteAPIKeyMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"UserAPIKeysTableDeleteAPIKeyMutation",selections:a},params:{cacheID:"d137498515ff43864f5525b3c1847376",id:null,metadata:{},name:"UserAPIKeysTableDeleteAPIKeyMutation",operationKind:"mutation",text:`mutation UserAPIKeysTableDeleteAPIKeyMutation(
  $input: DeleteApiKeyInput!
) {
  deleteUserApiKey(input: $input) {
    __typename
    apiKeyId
  }
}
`}}}();js.hash="9b1d898d1d9858016bed85000ce3906e";const qs={fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"UserAPIKeysTableQuery",selections:[{args:null,kind:"FragmentSpread",name:"UserAPIKeysTableFragment"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"UserAPIKeysTableQuery",selections:[{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"userApiKeys",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null},{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"e70d413b072841dff8565a332590a549",id:null,metadata:{},name:"UserAPIKeysTableQuery",operationKind:"query",text:`query UserAPIKeysTableQuery {
  ...UserAPIKeysTableFragment
}

fragment UserAPIKeysTableFragment on Query {
  userApiKeys {
    id
    name
    description
    createdAt
    expiresAt
    user {
      email
    }
  }
}
`}};qs.hash="c2b3a579bcb0ba915523ecb35cae3b44";const Us={argumentDefinitions:[],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:[],operation:qs}},name:"UserAPIKeysTableFragment",selections:[{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"userApiKeys",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null},{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null};Us.hash="c2b3a579bcb0ba915523ecb35cae3b44";const ul=70;function _y({query:n}){const[a,t]=P.useRefetchableFragment(Us,n),l=be(),i=ve(),[r]=P.useMutation(js),s=m.useCallback(p=>{r({variables:{input:{id:p}},onCompleted:()=>{i({title:"User key deleted",message:"The user key has been deleted and is no longer active."}),m.startTransition(()=>{t({},{fetchPolicy:"network-only"})})},onError:f=>{l({title:"Error deleting user key",message:f.message})}})},[r,l,i,t]),c=m.useMemo(()=>[...a.userApiKeys],[a]),d=m.useMemo(()=>[{header:"Name",accessorKey:"name",size:100,cell:Ke},{header:"Description",accessorKey:"description",cell:Ke},{header:"Created At",accessorKey:"createdAt",size:ul,cell:_e},{header:"Expires At",accessorKey:"expiresAt",size:ul,cell:_e},{header:"User",size:120,accessorKey:"user.email",cell:Ke},{header:"",accessorKey:"id",size:10,cell:({row:f})=>e(h,{direction:"row",justifyContent:"end",width:"100%",children:e(It,{handleDelete:()=>{s(f.original.id)}})}),meta:{textAlign:"right"}}],[s]),u=Te({columns:d,data:c,getCoreRowModel:De()}),y=u.getRowModel().rows,g=u.getRowModel().rows.length===0;return o("table",{css:Je,children:[e("thead",{children:u.getHeaderGroups().map(p=>e("tr",{children:p.headers.map(f=>e("th",{colSpan:f.colSpan,children:f.isPlaceholder?null:o("div",{className:f.column.getCanSort()?"cursor-pointer":"",onClick:f.column.getToggleSortingHandler(),style:{left:f.getStart(),width:f.getSize()},children:[Z(f.column.columnDef.header,f.getContext()),f.column.getIsSorted()?e(L,{className:"sort-icon",svg:f.column.getIsSorted()==="asc"?e(D.ArrowUpFilled,{}):e(D.ArrowDownFilled,{})}):null]})},f.id))},p.id))}),g?e(Ze,{message:"No Keys"}):e("tbody",{children:y.map(p=>e("tr",{children:p.getVisibleCells().map(f=>e("td",{children:Z(f.column.columnDef.cell,f.getContext())},f.id))},p.id))})]})}function Ry(){const n=P.useLazyLoadQuery(Vs,{},{fetchPolicy:"network-only"});return o($e,{children:[e(X,{title:"System Keys",name:"System Keys",children:e(wy,{query:n})}),e(X,{title:"User Keys",name:"User Keys",children:e(_y,{query:n})})]})}function Ay(){const[n,a]=m.useState(null),t=be(),l=d=>{a(e(Xl,{jwt:d}))},[i,r]=P.useMutation(zs),s=m.useCallback(d=>{i({variables:{...d,expiresAt:d.expiresAt||null},onCompleted:u=>{l(u.createSystemApiKey.jwt)},onError:u=>{t({title:"Error creating system key",message:u.message})}})},[i,t]),c=()=>{a(e(ei,{onSubmit:s,isCommitting:r,defaultName:"System"}))};return o("div",{children:[e(bt,{title:"API Keys",variant:"compact",extra:e(z,{variant:"default",size:"compact",icon:e(L,{svg:e(D.PlusCircleOutline,{})}),onClick:c,children:"System Key"}),children:e(m.Suspense,{fallback:e(F,{padding:"size-100",children:e(ye,{})}),children:e(Ry,{})})}),e(ae,{onDismiss:()=>{a(null)},children:n})]})}const Bs={fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"UsersCardQuery",selections:[{args:null,kind:"FragmentSpread",name:"UsersTable_users"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"UsersCardQuery",selections:[{alias:null,args:null,concreteType:"UserConnection",kind:"LinkedField",name:"users",plural:!1,selections:[{alias:null,args:null,concreteType:"UserEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"user",args:null,concreteType:"User",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"authMethod",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null},{alias:null,args:null,concreteType:"UserRole",kind:"LinkedField",name:"role",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"926faf98cad4bc437a919677347e277c",id:null,metadata:{},name:"UsersCardQuery",operationKind:"query",text:`query UsersCardQuery {
  ...UsersTable_users
}

fragment UsersTable_users on Query {
  users {
    edges {
      user: node {
        id
        email
        username
        createdAt
        authMethod
        profilePictureUrl
        role {
          name
        }
      }
    }
  }
}
`}};Bs.hash="2b3e260c950dd1a6a1a6883ff6fb78c4";const Hs=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"UserMutationPayload",kind:"LinkedField",name:"createUser",plural:!1,selections:[{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"NewUserDialogMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"NewUserDialogMutation",selections:a},params:{cacheID:"a9bf3794a5355d9d0e0a3acebe7f3809",id:null,metadata:{},name:"NewUserDialogMutation",operationKind:"mutation",text:`mutation NewUserDialogMutation(
  $input: CreateUserInput!
) {
  createUser(input: $input) {
    user {
      id
      email
    }
  }
}
`}}}();Hs.hash="97d1aefa41e8831e57b6bb0d1a078a7c";function My({onNewUserCreated:n,onNewUserCreationError:a,onDismiss:t}){const[l,i]=P.useMutation(Hs),r=m.useCallback(s=>{l({variables:{input:{email:s.email,username:s.username,password:s.password,role:s.role}},onCompleted:c=>{n(c.createUser.user.email)},onError:c=>{a(c)}})},[l,n,a]);return e(ae,{onDismiss:t,isDismissable:!0,type:"modal",isKeyboardDismissDisabled:!0,children:e(Y,{title:"Add user",children:e(gc,{onSubmit:r,isSubmitting:i})})})}const Gs={fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"UsersTableQuery",selections:[{args:null,kind:"FragmentSpread",name:"UsersTable_users"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"UsersTableQuery",selections:[{alias:null,args:null,concreteType:"UserConnection",kind:"LinkedField",name:"users",plural:!1,selections:[{alias:null,args:null,concreteType:"UserEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"user",args:null,concreteType:"User",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"authMethod",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null},{alias:null,args:null,concreteType:"UserRole",kind:"LinkedField",name:"role",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"d3f85064b63f026a47a8ef139638b933",id:null,metadata:{},name:"UsersTableQuery",operationKind:"query",text:`query UsersTableQuery {
  ...UsersTable_users
}

fragment UsersTable_users on Query {
  users {
    edges {
      user: node {
        id
        email
        username
        createdAt
        authMethod
        profilePictureUrl
        role {
          name
        }
      }
    }
  }
}
`}};Gs.hash="acd5e44c43deb927fea733697593c97d";const Ws={argumentDefinitions:[],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:[],operation:Gs}},name:"UsersTable_users",selections:[{alias:null,args:null,concreteType:"UserConnection",kind:"LinkedField",name:"users",plural:!1,selections:[{alias:null,args:null,concreteType:"UserEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"user",args:null,concreteType:"User",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"authMethod",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null},{alias:null,args:null,concreteType:"UserRole",kind:"LinkedField",name:"role",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null};Ws.hash="acd5e44c43deb927fea733697593c97d";const Js=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],kind:"ScalarField",name:"deleteUsers",storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"DeleteUserDialogMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"DeleteUserDialogMutation",selections:a},params:{cacheID:"00d3d0f3855e92e529bc446d0f426123",id:null,metadata:{},name:"DeleteUserDialogMutation",operationKind:"mutation",text:`mutation DeleteUserDialogMutation(
  $input: DeleteUsersInput!
) {
  deleteUsers(input: $input)
}
`}}}();Js.hash="a718ceab0ec0a7d461f6cd5e5b178a1f";function Ny({userId:n,onDeleted:a,onClose:t}){const[l,i]=P.useMutation(Js),r=ve(),s=be(),c=m.useCallback(()=>{l({variables:{input:{userIds:[n]}},onCompleted:()=>{r({title:"User deleted",message:"User has been deleted."}),a(),t()},onError:d=>{s({title:"Failed to delete user",message:d.message})}})},[l,s,r,t,a,n]);return o(Y,{title:"Delete User",isDismissable:!0,onDismiss:t,children:[e(F,{padding:"size-200",children:e(x,{color:"danger",children:"Are you sure you want to delete this user? This action cannot be undone."})}),e(F,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:o(h,{direction:"row",justifyContent:"end",gap:"size-100",children:[e(z,{variant:"default",onClick:t,children:"Cancel"}),e(z,{variant:"danger",onClick:()=>{c()},disabled:i,children:"Delete user"})]})})]})}const Zs=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"UserMutationPayload",kind:"LinkedField",name:"patchUser",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ResetPasswordDialogMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ResetPasswordDialogMutation",selections:a},params:{cacheID:"6ccff8dd53d97eeb41f656bcd2758da1",id:null,metadata:{},name:"ResetPasswordDialogMutation",operationKind:"mutation",text:`mutation ResetPasswordDialogMutation(
  $input: PatchUserInput!
) {
  patchUser(input: $input) {
    __typename
  }
}
`}}}();Zs.hash="85b22da61ec094c28e97db2759622b69";const sa=4;function zy({userId:n,onClose:a}){const t=be(),l=ve(),[i,r]=P.useMutation(Zs),{control:s,handleSubmit:c,formState:{isDirty:d}}=je({defaultValues:{newPassword:"",confirmPassword:""}}),u=m.useCallback(y=>{i({variables:{input:{userId:n,newPassword:y.newPassword}},onCompleted:()=>{l({title:"Password reset",message:"Users password has been reset."}),a()},onError:g=>{t({title:"Failed to reset password",message:g.message})}})},[i,t,l,a,n]);return e(Y,{title:"Reset Password",isDismissable:!0,onDismiss:a,children:e(we,{children:o(F,{padding:"size-200",children:[e(W,{name:"newPassword",control:s,rules:{required:"Password is required",minLength:{value:sa,message:`Password must be at least ${sa} characters`}},render:({field:{name:y,onChange:g,onBlur:p,value:f},fieldState:{invalid:k,error:b}})=>e(ee,{label:"New Password",type:"password",isRequired:!0,description:`Password must be at least ${sa} characters`,name:y,errorMessage:b==null?void 0:b.message,validationState:k?"invalid":"valid",onChange:g,onBlur:p,defaultValue:f})}),e(W,{name:"confirmPassword",control:s,rules:{required:"Password is required",minLength:{value:sa,message:`Password must be at least ${sa} characters`},validate:(y,g)=>y===g.newPassword||"Passwords do not match"},render:({field:{name:y,onChange:g,onBlur:p,value:f},fieldState:{invalid:k,error:b}})=>e(ee,{label:"Confirm Password",isRequired:!0,type:"password",description:"Confirm the new password",name:y,errorMessage:b==null?void 0:b.message,validationState:k?"invalid":"valid",onChange:g,onBlur:p,defaultValue:f})}),e(F,{paddingTop:"size-200",children:e(h,{direction:"row",gap:"size-100",justifyContent:"end",children:e(z,{variant:d?"primary":"default",type:"submit",disabled:r,onClick:c(u),children:r?"Resetting...":"Reset Password"})})})]})})})}function Vy(n){return n==="LOCAL"}function $y(n){const{userId:a,onUserDeleted:t,authMethod:l}=n,[i,r]=m.useState(null),s=m.useCallback(()=>{r(e(Ny,{userId:a,onClose:()=>r(null),onDeleted:()=>{t(),r(null)}}))},[a,t]),c=m.useCallback(()=>{r(e(zy,{userId:a,onClose:()=>r(null)}))},[a]),d=m.useMemo(()=>{const u=e(le,{children:o(h,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(L,{svg:e(D.TrashOutline,{})}),e(x,{children:"Delete"})]})},"deleteUser"),y=e(le,{children:o(h,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(L,{svg:e(D.Refresh,{})}),e(x,{children:"Reset Password"})]})},"resetPassword"),g=[u];return Vy(l)&&g.push(y),g},[l]);return o("div",{onClick:u=>{u.preventDefault(),u.stopPropagation()},children:[e(Rn,{align:"end","aria-label":"User Actions",buttonSize:"compact",onAction:u=>{switch(u){case"deleteUser":s();break;case"resetPassword":c();break}},children:d}),e(ae,{type:"modal",isDismissable:!0,onDismiss:()=>r(null),children:i})]})}const Ys=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"UserMutationPayload",kind:"LinkedField",name:"patchUser",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"UserRoleChangeDialogMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"UserRoleChangeDialogMutation",selections:a},params:{cacheID:"44e970c967f83a0b7a6bd1cbafc3a936",id:null,metadata:{},name:"UserRoleChangeDialogMutation",operationKind:"mutation",text:`mutation UserRoleChangeDialogMutation(
  $input: PatchUserInput!
) {
  patchUser(input: $input) {
    __typename
  }
}
`}}}();Ys.hash="468eff05b42e39b55f9aa5b9a7d2c483";function Oy({userId:n,email:a,currentRole:t,newRole:l,onRoleChanged:i,onClose:r}){const[s,c]=P.useMutation(Ys),d=ve(),u=be(),y=m.useCallback(()=>{s({variables:{input:{userId:n,newRole:l}},onCompleted:()=>{d({title:"Role Changed",message:"Users role has been changed."}),i(),r()},onError:g=>{u({title:"Failed to delete user",message:g.message})}})},[s,l,u,d,r,i,n]);return o(Y,{title:"Confirm role change",children:[e(F,{padding:"size-200",children:o(x,{children:[`Are you sure you want to change the role for ${a} from `," ",e("b",{children:pt(t)})," to"," ",e("b",{children:pt(l)}),"?"]})}),e(F,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:o(h,{direction:"row",justifyContent:"end",gap:"size-100",children:[e(z,{variant:"default",onClick:r,children:"Cancel"}),e(z,{variant:"primary",onClick:()=>{y()},disabled:c,children:"Change role"})]})})]})}const Qy=55,jy=C`
  text-decoration: none;
  color: var(--ac-global-color-grey-600);
  font-size: 12px;
  &:hover {
    text-decoration: underline;
  }
`,qy=C`
  height: ${Qy}px;
`,ml=n=>n.email==="admin@localhost"||n.username==="admin";function Uy({query:n}){const[a,t]=m.useState(null),[l,i]=P.useRefetchableFragment(Ws,n),r=m.useMemo(()=>l.users.edges.map(({user:g})=>({id:g.id,email:g.email,username:g.username,profilePictureUrl:g.profilePictureUrl,createdAt:g.createdAt,role:g.role.name,authMethod:g.authMethod})),[l]),s=m.useCallback(()=>{m.startTransition(()=>{i({},{fetchPolicy:"network-only"})})},[i]),c=m.useMemo(()=>[{header:"user",accessorKey:"username",cell:({row:g})=>o(h,{direction:"row",gap:"size-50",alignItems:"center",children:[e(ni,{name:g.original.username,profilePictureUrl:g.original.profilePictureUrl,size:20}),e("span",{children:g.original.username}),e("a",{href:`mailto:${g.original.email}`,css:jy,children:g.original.email})]})},{header:"method",accessorKey:"authMethod",size:10,cell:({row:g})=>g.original.authMethod.toLowerCase()},{header:"role",accessorKey:"role",cell:({row:g})=>ml(g.original)?pt(g.original.role):e(yc,{includeLabel:!1,onChange:p=>{p!==g.original.role&&t(e(Oy,{onClose:()=>t(null),onRoleChanged:s,currentRole:g.original.role,newRole:p,email:g.original.email,userId:g.original.id}))},role:pc(g.original.role)?g.original.role:void 0})},{header:"created at",accessorKey:"createdAt",cell:_e},{header:"",accessorKey:"id",size:10,cell:({row:g})=>ml(g.original)?null:e(h,{direction:"row",justifyContent:"end",width:"100%",children:e($y,{userId:g.original.id,onUserDeleted:s,authMethod:g.original.authMethod})}),meta:{textAlign:"right"}}],[s]),d=Te({columns:c,data:r,getCoreRowModel:De(),getSortedRowModel:Un()}),u=d.getRowModel().rows,y=d.getRowModel().rows.length===0;return o("table",{css:Je,children:[e("thead",{children:d.getHeaderGroups().map(g=>e("tr",{children:g.headers.map(p=>e("th",{colSpan:p.colSpan,children:p.isPlaceholder?null:o("div",{className:p.column.getCanSort()?"cursor-pointer":"",onClick:p.column.getToggleSortingHandler(),style:{left:p.getStart(),width:p.getSize()},children:[Z(p.column.columnDef.header,p.getContext()),p.column.getIsSorted()?e(L,{className:"sort-icon",svg:p.column.getIsSorted()==="asc"?e(D.ArrowUpFilled,{}):e(D.ArrowDownFilled,{})}):null]})},p.id))},g.id))}),y?e(Ze,{}):e("tbody",{children:u.map(g=>e("tr",{css:qy,children:g.getVisibleCells().map(p=>e("td",{children:Z(p.column.columnDef.cell,p.getContext())},p.id))},g.id))}),e(ae,{onDismiss:()=>t(null),isDismissable:!0,type:"modal",children:a})]})}function By(){const[n,a]=m.useState(0),[t,l]=m.useState(null),i=ve(),r=be(),s=P.useLazyLoadQuery(Bs,{},{fetchKey:n,fetchPolicy:"store-and-network"});return o(q,{title:"Users",variant:"compact",bodyStyle:{padding:0,overflowX:"auto"},extra:e(z,{onClick:()=>{l(e(My,{onDismiss:()=>{l(null)},onNewUserCreated:c=>{l(null),i({title:"User added",message:`User ${c} has been added.`}),a(d=>d+1)},onNewUserCreationError:c=>{r({title:"Error adding user",message:c.message})}}))},variant:"default",size:"compact",icon:e(L,{svg:e(D.PlusCircleOutline,{})}),children:"Add User"}),children:[e(m.Suspense,{fallback:e(F,{padding:"size-200",children:e(ye,{})}),children:e(Uy,{query:s})}),e(ae,{onDismiss:()=>{l(null)},children:t})]})}const Hy=C`
  overflow-y: auto;
`,Gy=C`
  padding: var(--ac-global-dimension-size-400);
  max-width: 1000px;
  min-width: 500px;
  box-sizing: border-box;
  width: 100%;
  margin-left: auto;
  margin-right: auto;
`,Wy=C`
  .ac-field {
    // Hacky solution to make the text fields fill the remaining space
    width: calc(100% - var(--ac-global-dimension-size-600));
  }
`;function K1(){return e("main",{css:Hy,children:e("div",{css:Gy,children:o(h,{direction:"column",gap:"size-200",width:"100%",children:[e(q,{title:"Platform Settings",variant:"compact",children:o("form",{css:Wy,children:[o(h,{direction:"row",gap:"size-100",alignItems:"end",children:[e(ee,{label:"Hostname",value:gt,isReadOnly:!0,description:"Connect to Phoenix over HTTP"}),e(ut,{text:gt})]}),o(h,{direction:"row",gap:"size-100",alignItems:"end",children:[e(ee,{label:"Platform Version",isReadOnly:!0,value:Pa,description:"The version of the Phoenix server"}),e(ut,{text:Pa})]}),o(h,{direction:"row",gap:"size-100",alignItems:"end",justifyContent:"center",children:[e(ee,{label:"Python Version",isReadOnly:!0,value:`pip install 'arize-phoenix==${Pa}'`,description:"The version of the Python client library to use to connect to this Phoenix"}),e(ut,{text:Pa})]})]})}),e(Jl,{children:o(G,{children:[e(Ay,{}),e(By,{})]})})]})})})}function ut(n){return e(F,{paddingBottom:"19px",children:e(se,{text:n.text,size:"default"})})}const gl=window.Config.basename,pl={width:"100%",height:"100%",border:"none",backgroundColor:"white"};function x1(){return o("div",{css:C`
        display: flex;
        flex-direction: column;
        flex: 1 1 auto;
        height: 100%;
        .ac-tabs {
          flex: 1 1 auto;
        }
        .ac-tabs__pane-container,
        .ac-tabs__pane-container > div {
          flex: 1 1 auto;
          height: 100%;
        }
      `,children:[e(ce,{variant:"info",banner:!0,icon:e(L,{svg:e(D.InfoFilled,{})}),children:"These APIs are under active development and are subject to change."}),o($e,{children:[e(X,{name:"REST",children:({isSelected:n})=>n&&e("iframe",{src:`${gl}/docs`,style:pl})}),e(X,{name:"GraphQL",children:({isSelected:n})=>n&&e("iframe",{src:`${gl}/graphql`,style:pl})})]})]})}function Ja({children:n}){return o("main",{css:C`
        padding-top: 200px;
        width: 100%;
        height: 100vh;
        overflow: hidden;
        background: radial-gradient(
          90% 60% at 50% 30%,
          rgba(5, 145, 193, 0.4) 0%,
          transparent 100%
        );
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        box-sizing: border-box;
      `,children:[e(F,{borderColor:"light",borderWidth:"thin",width:"size-5000",padding:"size-400",backgroundColor:"dark",marginStart:"auto",marginEnd:"auto",borderRadius:"medium",overflow:"auto",children:n}),o("footer",{css:C`
          display: flex;
          justify-content: center;
          padding: var(--ac-global-dimension-size-400);
          gap: var(--ac-global-dimension-size-200);
          a {
            color: var(--ac-global-text-color-700);
            transition: color 0.2s ease-in-out;
            text-decoration: none;
            &:hover {
              color: var(--ac-global-text-color-900);
              text-decoration: underline;
            }
          }
        `,children:[e("a",{href:"https://docs.arize.com/phoenix",children:"Documentation"}),"|",e("a",{href:"https://join.slack.com/t/arize-ai/shared_invite/zt-1px8dcmlf-fmThhDFD_V_48oU7ALan4Q",children:"Community"}),"|",e("a",{href:"https://twitter.com/ArizePhoenix",children:"Social"}),"|",e("a",{href:"https://github.com/Arize-ai/phoenix",children:"GitHub"}),"|",e("a",{href:"https://github.com/Arize-ai/phoenix/releases",children:`arize-phoenix v${window.Config.platformVersion}`})]})]})}function Jy(n){const a=ne(),{initialError:t,onSubmit:l}=n,[i,r]=m.useState(t),[s,c]=m.useState(!1),d=m.useCallback(async g=>{l==null||l(),r(null),c(!0);try{const f=await fetch(ba("/auth/login"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(g)});if(!f.ok){const k=f.status===429?"Too many requests. Please try again later.":"Invalid login";r(k);return}}catch{r("Invalid login");return}finally{c(()=>!1)}const p=fc();a(p)},[a,l,r]),{control:u,handleSubmit:y}=je({defaultValues:{email:"",password:""}});return o(G,{children:[i?o(F,{paddingBottom:"size-100",children:[e(ce,{variant:"danger",children:i})," "]}):null,o(we,{children:[e(W,{name:"email",control:u,render:({field:{onChange:g,value:p}})=>e(ee,{label:"Email",name:"email",isRequired:!0,type:"email",onChange:g,value:p,placeholder:"your email address"})}),o("div",{css:C`
            position: relative;
            a {
              position: absolute;
              float: right;
              right: 0;
              top: var(--ac-global-dimension-size-50);
              font-size: 12px;
            }
          `,children:[e(W,{name:"password",control:u,render:({field:{onChange:g,value:p}})=>e(ee,{label:"Password",name:"password",type:"password",isRequired:!0,onChange:g,value:p,placeholder:"your password",onKeyDown:f=>{f.key==="Enter"&&y(d)()}})}),e(cn,{to:"/forgot-password",children:"Forgot your password?"})]}),e("div",{css:C`
            margin-top: var(--ac-global-dimension-size-200);
            margin-bottom: var(--ac-global-dimension-size-50);
            button {
              width: 100%;
            }
          `,children:e(z,{variant:"primary",loading:s,onClick:y(d),children:"Login"})})]})]})}const Zy=C`
  button {
    width: 100%;
  }
  i {
    display: block;
    width: 20px;
    height: 20px;
    padding-right: var(--ac-global-dimension-size-50);
  }
  &[data-provider^="aws"],
  &[data-provider^="google"] {
    button {
      background-color: white;
      color: black;
      &:hover {
        background-color: #ececec !important;
      }
    }
  }
`;function Yy({idpName:n,idpDisplayName:a,returnUrl:t}){return e("form",{action:ba(`/oauth2/${n}/login${t?`?returnUrl=${t}`:""}`),method:"post",css:Zy,"data-provider":n,children:o(z,{variant:"default",type:"submit",icon:e(Xy,{idpName:n}),children:["Login with ",a]})})}function Xy({idpName:n}){return n==="github"||n==="google"||n==="microsoft_entra_id"||n.startsWith("aws")?e("i",{children:e("div",{css:C`
          display: inline-block;
          width: 20px;
          height: 20px;
          position: relative;
          background-size: contain;
          background-repeat: no-repeat;
          background-position: 50%;
          &[data-provider^="github"] {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg width='20' height='20' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M10 0C4.477 0 0 4.36 0 9.74c0 4.304 2.865 7.955 6.839 9.243.5.09.682-.211.682-.47 0-.23-.008-.843-.013-1.656-2.782.588-3.369-1.306-3.369-1.306-.454-1.125-1.11-1.425-1.11-1.425-.908-.604.069-.592.069-.592 1.003.069 1.531 1.004 1.531 1.004.892 1.488 2.341 1.059 2.91.81.092-.63.35-1.06.636-1.303-2.22-.245-4.555-1.081-4.555-4.814 0-1.063.39-1.933 1.029-2.613-.103-.247-.446-1.238.098-2.578 0 0 .84-.262 2.75.998A9.818 9.818 0 0 1 10 4.71c.85.004 1.705.112 2.504.328 1.909-1.26 2.747-.998 2.747-.998.546 1.34.203 2.331.1 2.578.64.68 1.028 1.55 1.028 2.613 0 3.742-2.339 4.566-4.566 4.807.359.3.678.895.678 1.804 0 1.301-.012 2.352-.012 2.671 0 .261.18.564.688.47C17.137 17.69 20 14.042 20 9.74 20 4.36 15.522 0 10 0z' fill='%23161514' fill-rule='evenodd'/%3E%3C/svg%3E");
          }

          &[data-provider^="google"] {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 48 48'%3E%3Cdefs%3E%3Cpath id='a' d='M44.5 20H24v8.5h11.8C34.7 33.9 30.1 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 11.8 2 2 11.8 2 24s9.8 22 22 22c11 0 21-8 21-22 0-1.3-.2-2.7-.5-4z'/%3E%3C/defs%3E%3CclipPath id='b'%3E%3Cuse xlink:href='%23a' overflow='visible'/%3E%3C/clipPath%3E%3Cpath clip-path='url(%23b)' fill='%23FBBC05' d='M0 37V11l17 13z'/%3E%3Cpath clip-path='url(%23b)' fill='%23EA4335' d='M0 11l17 13 7-6.1L48 14V0H0z'/%3E%3Cpath clip-path='url(%23b)' fill='%2334A853' d='M0 37l30-23 7.9 1L48 0v48H0z'/%3E%3Cpath clip-path='url(%23b)' fill='%234285F4' d='M48 48L17 24l-4-3 35-10z'/%3E%3C/svg%3E");
          }
          &[data-provider^="microsoft"] {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='21' height='21'%3E%3Cpath fill='%23f25022' d='M1 1h9v9H1z'/%3E%3Cpath fill='%2300a4ef' d='M1 11h9v9H1z'/%3E%3Cpath fill='%237fba00' d='M11 1h9v9h-9z'/%3E%3Cpath fill='%23ffb900' d='M11 11h9v9h-9z'/%3E%3C/svg%3E");
          }
          &[data-provider^="aws"] {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg width='400' height='334' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M236.578 94.824c-9.683.765-20.854 1.502-32.021 3.006-17.12 2.211-34.24 5.219-48.386 11.907-27.544 11.208-46.163 35.053-46.163 70.114 0 44.018 28.298 66.354 64.026 66.354 11.93 0 21.606-1.466 30.522-3.71 14.156-4.481 26.07-12.67 40.209-27.596 8.192 11.205 10.413 16.428 24.575 28.338 3.725 1.502 7.448 1.502 10.413-.742 8.932-7.458 24.561-20.873 32.773-28.33 3.71-3.012 2.955-7.463.739-11.204-8.198-10.435-16.381-19.401-16.381-39.506V96.324c0-28.359 2.214-54.453-18.614-73.822C261.147 6.815 234.34.86 213.5.86h-8.947c-37.965 2.247-78.169 18.635-87.122 65.629-1.462 5.955 3.012 8.198 5.989 8.962l41.677 5.224c4.471-.773 6.691-4.491 7.432-8.233 3.74-16.388 17.136-24.583 32.024-26.087h2.998c8.905 0 18.586 3.743 23.813 11.168 5.932 8.965 5.21 20.904 5.21 31.339v5.961h.004v.001zm0 43.278c0 17.162.723 30.571-8.195 45.461-5.208 10.437-14.141 17.154-23.827 19.4-1.481 0-3.698.766-5.947.766-16.371 0-26.077-12.673-26.077-31.334 0-23.856 14.159-35.056 32.023-40.277 9.687-2.241 20.86-2.982 32.021-2.982v8.966h.002z'/%3E%3Cpath d='M373.71 315.303c18.201-15.398 25.89-43.349 26.29-57.939v-2.44c0-3.255-.803-5.661-1.6-6.88-3.646-4.445-30.369-8.523-53.402-1.627-6.468 2.045-12.146 4.865-17.396 8.507-4.051 2.854-3.238 6.464.802 6.08 4.447-.823 10.126-1.208 16.594-2.048 14.159-1.18 30.742-1.592 34.784 3.662 5.642 6.87-6.468 36.868-11.749 49.838-1.593 4.065 2.03 5.696 5.677 2.847z' fill='%23FE9900'/%3E%3Cpath d='M2.008 257.364c52.17 47.404 120.925 75.775 197.791 75.775 47.725 0 102.727-13.381 145.199-38.899 5.676-3.27 11.316-6.912 16.565-10.952 7.286-5.25.817-13.38-6.463-10.147-3.229 1.215-6.873 2.857-10.103 4.066-46.539 18.248-95.441 26.76-140.762 26.76-72.008 0-141.56-19.87-197.786-52.684-5.259-2.822-8.907 2.428-4.441 6.081z' fill='%23FE9900'/%3E%3C/svg%3E");
          }
        `,"data-provider":n})}):null}function Vt(){return o("svg",{width:"253",height:"63",viewBox:"0 0 682 169",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[o("g",{clipPath:"url(#clip0_290_1904)",children:[e("path",{d:"M147.458 105.593C147.022 103.63 146.028 101.824 144.492 100.222C143.901 99.6064 143.244 99.0233 142.529 98.4978C142.184 98.2432 141.815 98.005 141.437 97.7669C140.969 97.4712 140.484 97.192 139.95 96.921C137.995 95.9191 136.328 94.909 134.866 93.825C134.274 93.3897 133.699 92.9299 133.157 92.4535C131.851 91.312 130.972 90.3348 130.315 89.3C130.102 88.9715 129.913 88.6102 129.732 88.2653C129.658 88.1175 129.543 87.9943 129.412 87.8957C129.173 87.7233 128.869 87.6494 128.565 87.6986C128.097 87.789 127.736 88.1667 127.678 88.6431C127.637 89.0126 127.637 89.4068 127.687 89.8092C127.719 90.0474 127.588 90.2773 127.366 90.3758C127.317 90.4005 127.259 90.4087 127.21 90.4169C126.898 90.4498 126.619 90.6222 126.438 90.885C126.257 91.1478 126.208 91.4681 126.282 91.7719C126.348 92.0347 126.438 92.2236 126.512 92.3714L126.578 92.5028C126.627 92.5931 126.676 92.6917 126.726 92.782C126.873 93.0612 127.021 93.3405 127.202 93.6033C127.547 94.1042 127.933 94.6052 128.393 95.1389C128.541 95.3114 128.565 95.5578 128.459 95.7549C128.352 95.952 128.13 96.0669 127.908 96.0341C125.321 95.681 122.996 95.0979 120.836 94.3013C120.59 94.211 120.335 94.1206 120.097 94.0221C118.158 93.2009 121.658 89.7189 123.259 87.247C130.282 76.4479 131.736 64.0802 131.794 51.5647C131.851 39.4681 130.545 27.5357 128.138 15.7593V15.7429C126.569 5.87173 125.239 2.168 124.401 0.796558C124.22 0.435219 124.023 0.205276 123.818 0.0985162C123.588 -0.0575166 123.465 0.0163937 123.465 0.0163937C123.013 0.0328182 122.495 0.435219 121.871 1.08399C119.251 3.83509 119.399 7.11178 120.122 10.5363C123.432 26.0903 125.921 41.7346 124.787 57.7157C124.007 68.7365 121.953 79.3468 114.248 87.9779C113.789 88.4952 113.287 88.9798 112.786 89.4725C112.211 90.0391 111.316 91.1396 110.651 90.6797C109.764 90.0638 110.552 88.7991 110.831 88.1421C115.341 77.5729 116.639 66.5275 115.949 55.1453C115.932 54.8825 115.908 54.6197 115.891 54.3569V54.3405C115.883 54.1269 115.858 53.9298 115.842 53.7245C115.727 52.2217 115.587 50.7189 115.398 49.2242C113.46 31.1655 111.127 29.9911 111.127 29.9911C110.971 29.8515 110.782 29.7448 110.528 29.6955C109.304 29.4409 108.638 30.5167 108.096 31.3297C105.648 34.9924 106.733 38.8932 107.521 42.753C110.289 56.2703 110.33 69.6645 105.583 82.8124C105.147 84.0113 104.63 85.1775 104.08 86.3272C103.496 87.5508 103.119 89.0783 101.131 88.4213C99.2662 87.8054 99.7918 86.3929 100.03 85.1036C100.654 81.8269 101.155 78.542 101.467 75.2489V75.2653C101.509 74.9368 101.525 74.6247 101.55 74.3127C101.599 73.746 101.632 73.1712 101.665 72.6045C101.689 72.1282 101.714 71.6601 101.739 71.2002C101.747 70.9621 101.763 70.7321 101.763 70.494C102.141 60.0562 100.383 55.3095 99.7179 53.9052C99.644 53.7328 99.5619 53.5767 99.4715 53.4371C98.7815 52.4024 97.6398 52.5256 96.6541 53.5028C94.8388 55.2931 93.8367 57.4118 94.2967 60.0808C95.6438 67.8496 94.8552 75.5445 93.4096 83.1983C93.2124 84.2249 92.7524 86.0973 90.5593 85.6127C89.0644 85.2842 88.7194 84.6437 88.6372 83.3461C88.6537 82.3689 88.6372 81.3916 88.6044 80.4144C88.6044 80.3897 88.6044 80.3651 88.6044 80.3405C88.6044 80.2009 88.588 80.0612 88.588 79.9299C88.588 79.8559 88.5797 79.7902 88.5715 79.7245C88.5058 78.3942 88.399 77.0556 88.2347 75.717C88.2183 75.5856 88.1937 75.4624 88.1773 75.331C87.3394 67.7921 86.247 67.0612 86.247 67.0612C85.5488 66.1497 84.4563 66.3057 83.5117 67.2419C81.6964 69.0322 80.7764 71.1427 81.1543 73.8199C81.4336 75.7745 81.3596 75.175 81.5568 76.8831C81.7128 77.7618 81.8771 79.3632 81.8935 79.8724C81.8525 80.324 81.7375 80.7182 81.4582 81.0139C80.53 82.0076 79.0351 80.9892 77.9015 80.5211C55.9209 71.4302 37.1108 58.6683 20.691 42.523C14.2513 35.945 3.25273 22.6329 3.25273 22.6329C2.84203 22.1566 2.33276 21.8856 1.55243 22.2223C0.114982 22.8383 0.156052 24.6778 0.0246278 26.2217C-0.23822 29.3177 1.42101 31.5597 3.21987 33.662C28.0179 62.5856 58.2783 83.3708 94.8059 93.7675L101.377 95.5085C101.451 95.5249 101.533 95.5496 101.607 95.566C101.624 95.566 101.632 95.566 101.64 95.5742L107.299 97.077L107.456 97.1181C107.267 97.1756 107.061 97.2167 106.839 97.2577C100.613 98.4895 88.2923 96.223 78.3944 93.9153C73.4988 92.8888 68.6854 91.6405 63.9788 90.1541C63.7653 90.0884 63.642 90.0556 63.642 90.0556C45.3577 84.2331 28.6093 74.7972 13.9556 60.4093C12.5674 59.0461 11.286 57.5761 10.0211 56.0897C8.86289 54.71 6.47262 51.8275 5.643 50.8338C5.55265 50.7024 5.45408 50.5875 5.35551 50.4807C5.10909 50.2261 4.80517 50.0619 4.36983 50.1604C3.3513 50.3986 3.05559 51.4498 2.86667 52.3367C2.1192 55.9008 3.25273 58.8983 5.65122 61.5755C20.6582 78.3942 39.4929 89.1358 60.6439 96.1819C72.6528 100.181 85.0067 102.612 97.6069 104.164C90.0911 106.595 82.3617 107.334 74.5667 107.137C59.4775 106.759 45.3248 103.138 32.0264 96.6746C27.1226 94.1535 22.5556 91.3449 21.3564 90.5894C20.6664 90.1213 19.9518 89.8338 19.2454 90.3758C17.9229 91.4024 18.8347 93.2009 19.2618 94.6051C20.075 97.307 21.956 99.1712 24.3956 100.46C46.0641 111.917 68.9401 116.499 93.2946 112.434C95.7588 112.023 98.0998 111.572 100.679 110.701C96.6048 114.224 91.89 116.524 86.9369 118.339C71.6835 123.915 56.5287 123.693 41.4314 119.915C36.5851 118.618 30.9668 116.507 30.9668 116.507C30.1536 116.154 29.3486 116.031 28.7243 116.926C27.6237 118.503 28.5847 120.145 29.5375 121.632C31.7882 125.138 36.1416 125.483 39.5832 126.674C40.7578 127.052 37.5544 129.187 36.5276 129.975C31.5335 133.794 26.6462 137.284 21.6767 140.98L18.424 143.378C17.8654 143.764 17.3726 144.199 17.6272 145.004C17.9229 145.915 18.8675 146.08 19.7875 146.268C23.3442 147.008 26.3833 145.825 29.1925 143.723C35.2134 139.214 41.3493 134.837 47.2387 130.156C49.4811 128.374 51.5182 128.522 54.582 129.31C46.9183 135.083 39.7475 140.495 32.5685 145.899C25.2827 151.376 17.9969 156.854 10.711 162.323L5.89764 165.888C5.82371 165.937 5.758 165.986 5.69229 166.044L5.61836 166.093C5.20766 166.421 4.90374 166.791 4.9941 167.267C5.19123 168.351 6.4644 168.622 7.50758 168.803C11.8117 169.542 14.4813 167.924 17.4219 165.715C32.1496 154.661 46.9266 143.682 61.5721 132.521C64.8577 130.016 68.2337 128.604 72.9731 129.138C68.9401 132.152 65.0631 135.051 61.2436 137.908L50.8611 145.587C50.7871 145.636 50.7132 145.694 50.6475 145.751C50.0972 146.186 49.7111 146.695 49.9247 147.451C50.3189 148.822 51.97 148.987 53.3745 149.2C55.9537 149.586 58.1387 148.675 60.1675 147.164C61.3339 146.293 62.5085 145.439 63.6831 144.593L79.5361 132.004C79.5361 132.004 83.2817 129.327 87.6187 126.871C88.0048 126.633 88.3908 126.387 88.7851 126.148C88.9494 126.075 89.3601 125.886 89.9843 125.59C90.4525 125.352 90.9207 125.114 91.3807 124.892C92.0625 124.547 92.851 124.128 93.7381 123.644C96.2927 122.584 103.611 119.168 109.657 112.73C112.532 110.512 116.581 107.613 119.735 106.217H119.752C119.99 106.111 120.228 106.012 120.458 105.93C120.458 105.93 120.475 105.93 120.483 105.922C120.639 105.864 120.787 105.815 120.935 105.766L121.337 105.61C122.479 105.289 124.335 105.166 124.582 107.679C124.623 108.295 124.615 108.927 124.541 109.593C124.491 110.093 124.393 110.627 124.319 111.054C124.245 111.465 124.417 111.876 124.746 112.122C124.795 112.163 124.853 112.196 124.91 112.22C125.346 112.434 125.871 112.335 126.2 111.974C126.323 111.834 126.446 111.703 126.569 111.572C128.122 109.937 129.699 108.804 131.375 108.114C133.822 107.104 136.303 107.096 138.94 108.106C140.197 108.582 141.379 109.239 142.554 110.102C143.055 110.471 143.556 110.882 144.057 111.334C144.353 111.605 144.648 111.9 144.911 112.163L144.952 112.204L145.166 112.418C145.166 112.418 145.248 112.491 145.289 112.524C145.536 112.705 145.856 112.779 146.168 112.713C146.529 112.631 146.825 112.376 146.957 112.032C146.981 111.966 147.006 111.9 147.031 111.834C147.778 109.617 147.934 107.581 147.499 105.593H147.458Z",fill:"url(#paint0_linear_290_1904)"}),e("path",{d:"M120.113 94.0303C120.195 94.0632 120.269 94.096 120.351 94.1207C120.269 94.0878 120.187 94.0632 120.113 94.0303Z",fill:"#FEDBB5"}),e("path",{d:"M111.283 87.1238C111.283 87.1238 111.267 87.1567 111.267 87.1731C111.267 87.1567 111.283 87.1402 111.283 87.1238Z",fill:"#FEDBB5"}),e("path",{d:"M123.383 87.1074C123.383 87.1074 123.358 87.1487 123.341 87.1652C123.358 87.1487 123.366 87.1239 123.383 87.1074Z",fill:"#FEDBB5"}),e("path",{d:"M104.104 86.3354C103.965 86.6229 103.841 86.9267 103.71 87.2142C103.85 86.9267 103.973 86.6229 104.104 86.3354Z",fill:"#FEDBB5"}),e("path",{d:"M89.0233 84.7422C89.0233 84.7422 89.0233 84.7505 89.0316 84.7588C89.0316 84.7588 89.0316 84.7505 89.0233 84.7422Z",fill:"#FEDBB5"}),e("path",{d:"M89.0644 84.7998C89.1876 84.964 89.3437 85.1118 89.5408 85.235C89.3437 85.1118 89.1876 84.9722 89.0644 84.7998ZM89.0644 84.7833C89.0644 84.7833 89.0644 84.7833 89.0644 84.7915C89.0644 84.7915 89.0644 84.7915 89.0644 84.7833ZM89.0562 84.7751C89.0562 84.7751 89.0562 84.7751 89.0562 84.7833C89.0562 84.7833 89.0562 84.7833 89.0562 84.7751ZM88.6947 83.3626C88.6947 83.3626 88.6947 83.3708 88.6947 83.379C88.6947 83.379 88.6947 83.3708 88.6947 83.3626ZM79.1665 81.0878C79.1665 81.0878 79.1829 81.0878 79.1829 81.096C79.6429 81.2931 80.1029 81.4492 80.53 81.4492C80.7107 81.4492 80.8832 81.4245 81.0393 81.3588C80.875 81.4245 80.7025 81.4492 80.53 81.4492C80.0947 81.4492 79.6265 81.2849 79.1665 81.0878ZM88.629 79.6507C88.629 79.6507 88.629 79.6507 88.629 79.6589C88.629 79.6589 88.629 79.6589 88.629 79.6507Z",fill:"#E5B4A6"}),e("path",{d:"M120.36 94.1206C120.36 94.1206 120.434 94.1535 120.475 94.1617C120.475 94.1617 120.401 94.1289 120.36 94.1206ZM110.273 89.8749C110.273 90.187 110.38 90.4662 110.684 90.6797C110.79 90.7536 110.905 90.7865 111.029 90.7865C111.209 90.7865 111.398 90.7126 111.595 90.5894C111.406 90.7126 111.218 90.7865 111.029 90.7865C110.905 90.7865 110.79 90.7536 110.684 90.6797C110.38 90.4744 110.273 90.187 110.273 89.8749ZM110.914 88.0189C110.914 88.0189 110.881 88.1011 110.864 88.1421C110.881 88.1011 110.897 88.06 110.914 88.0189ZM111.226 87.2798C111.127 87.5262 111.02 87.7726 110.914 88.0189C111.02 87.7726 111.119 87.5262 111.226 87.2798ZM111.267 87.1731C111.267 87.1731 111.234 87.2388 111.226 87.2798C111.242 87.247 111.259 87.2141 111.267 87.1731ZM123.341 87.1731C123.341 87.1731 123.341 87.1813 123.333 87.1895C123.333 87.1895 123.333 87.1813 123.341 87.1731ZM123.391 87.0992C123.391 87.0992 123.391 87.1074 123.382 87.1156C123.382 87.1156 123.382 87.1074 123.391 87.0992ZM111.308 87.0992C111.308 87.0992 111.3 87.132 111.291 87.1402C111.291 87.1238 111.3 87.1074 111.308 87.0992ZM99.8001 86.7707C99.8001 87.4769 100.079 88.0928 101.155 88.446C101.484 88.5527 101.771 88.602 102.026 88.602C102.93 88.602 103.365 87.9615 103.71 87.2306C103.357 87.9697 102.921 88.602 102.026 88.602C101.78 88.602 101.492 88.5527 101.155 88.446C100.088 88.0928 99.8001 87.4769 99.8001 86.7707ZM92.7689 84.9886C92.4486 85.4074 91.9722 85.7195 91.2575 85.7195C91.1836 85.7195 91.1097 85.7195 91.0358 85.7113C91.1097 85.7113 91.1836 85.7195 91.2575 85.7195C91.9722 85.7195 92.4486 85.4157 92.7689 84.9886ZM106.651 79.7081C106.651 79.7081 106.651 79.7081 106.642 79.7081C106.322 80.7511 105.985 81.8023 105.616 82.8452C105.993 81.8023 106.338 80.7593 106.659 79.7081M94.1571 79.1251C93.9846 80.2748 93.7875 81.4163 93.5739 82.566C93.7875 81.4245 93.9846 80.2748 94.1571 79.1251ZM122.191 73.6311C120.623 78.7884 118.175 83.65 114.29 88.0025C113.83 88.5199 113.329 89.0044 112.828 89.4972C113.329 89.0126 113.821 88.5199 114.29 88.0025C118.175 83.65 120.623 78.7884 122.2 73.6311",fill:"#E5B4A6"}),e("path",{opacity:"0.4",d:"M2.20136 22.0745C2.00423 22.0745 1.79066 22.1238 1.55246 22.2223C0.53392 22.6658 0.254644 23.7252 0.139648 24.8503C5.61017 32.0196 27.213 58.4548 61.1943 76.5875C61.1943 76.5875 94.4692 94.1453 127.933 96.0423C125.346 95.6892 123.021 95.1061 120.861 94.3095C120.729 94.2602 120.606 94.2192 120.475 94.1699C108.318 91.542 97.9519 88.2571 90.6168 85.6292C90.7565 85.662 90.8961 85.6784 91.0193 85.6949C90.8879 85.6867 90.7401 85.662 90.5922 85.6292C90.1486 85.5306 89.8037 85.4074 89.5408 85.2432C83.7417 83.1244 80.0454 81.4984 79.1583 81.096C78.7312 80.9153 78.3123 80.6936 77.9344 80.5376C55.9538 71.4466 37.1437 58.6848 20.7239 42.5395C14.2513 35.945 3.25275 22.633 3.25275 22.633C2.97348 22.3045 2.6367 22.0745 2.20136 22.0745Z",fill:"url(#paint1_linear_290_1904)"}),e("path",{opacity:"0.4",d:"M4.62448 50.1358C4.55056 50.1358 4.46842 50.144 4.37806 50.1687C3.35953 50.4068 3.06382 51.458 2.8749 52.3449C2.84204 52.5009 2.80919 52.6652 2.78455 52.8212C19.7711 75.832 42.5732 85.235 42.5732 85.235C65.3341 95.952 84.0128 98.12 95.3892 98.12C100.096 98.12 103.554 97.7505 105.533 97.463C104.63 97.5616 103.636 97.6109 102.568 97.6109C95.8984 97.6109 86.362 95.7795 78.4026 93.9235C73.5071 92.897 68.6937 91.6488 63.987 90.1623C63.7735 90.0966 63.6503 90.0638 63.6503 90.0638C45.3659 84.2413 28.6176 74.8054 13.9638 60.4175C12.5756 59.0543 11.2942 57.5843 10.0293 56.0979C8.87112 54.7182 6.48084 51.8357 5.65123 50.8421C5.56088 50.7107 5.46231 50.5957 5.36374 50.4889C5.16661 50.2836 4.9284 50.1358 4.62448 50.1358Z",fill:"url(#paint2_linear_290_1904)"}),e("path",{opacity:"0.4",d:"M20.0669 90.1049C19.7958 90.1049 19.5247 90.187 19.2537 90.4005C18.1037 91.2874 18.6458 92.7738 19.0812 94.0632C27.5991 99.2287 47.132 109.289 70.2626 109.289C79.0023 109.289 88.243 107.86 97.607 104.189C90.8469 106.382 83.9061 107.195 76.9077 107.195C76.1274 107.195 75.3471 107.186 74.5667 107.162C59.4776 106.784 45.3249 103.162 32.0264 96.6993C27.1227 94.1781 22.5557 91.3695 21.3565 90.614C20.9293 90.3266 20.5022 90.1049 20.0669 90.1049Z",fill:"url(#paint3_linear_290_1904)"}),e("path",{opacity:"0.4",d:"M99.1759 111.949C95.4632 114.791 91.2987 116.762 86.937 118.355C78.7559 121.344 70.5994 122.666 62.4675 122.666C55.4363 122.666 48.4298 121.681 41.4315 119.932C36.5852 118.634 30.9668 116.524 30.9668 116.524C30.6136 116.368 30.2604 116.261 29.9237 116.261C29.4883 116.261 29.0776 116.442 28.7326 116.951C28.2234 117.682 28.1577 118.429 28.3219 119.168C33.6939 121.665 45.2181 126.099 59.2723 126.099C71.4536 126.099 85.5406 122.765 99.1759 111.949Z",fill:"url(#paint4_linear_290_1904)"}),e("path",{opacity:"0.4",d:"M62.9356 129.368C49.7358 129.368 39.7557 126.699 38.4908 126.346C38.8604 126.452 39.2218 126.567 39.5833 126.69C40.7579 127.068 37.5544 129.203 36.5276 129.992C32.8396 132.817 29.2008 135.461 25.5537 138.138H36.7576C40.2897 135.527 43.8052 132.907 47.2387 130.172C48.5119 129.154 49.7275 128.768 51.0993 128.768C52.1342 128.768 53.2678 128.99 54.582 129.335C46.9184 135.108 39.7475 140.52 32.5685 145.924C28.3711 149.077 24.1738 152.231 19.9764 155.384H31.246C41.3821 147.804 51.51 140.216 61.5721 132.546C63.8967 130.78 66.2623 129.557 69.1208 129.179C67.0016 129.318 64.9316 129.376 62.9439 129.376L62.9356 129.368Z",fill:"url(#paint5_linear_290_1904)"}),e("path",{opacity:"0.4",d:"M60.5782 138.409H71.47L79.5115 132.02C79.5115 132.02 83.2571 129.343 87.5941 126.888C87.9801 126.649 88.3662 126.403 88.7605 126.165C88.9248 126.091 89.3354 125.902 89.9597 125.606C90.4279 125.368 90.8961 125.13 91.3561 124.908C92.0625 124.547 92.8921 124.112 93.8121 123.603C86.0499 126.855 78.0987 128.44 70.739 129.056C70.8375 129.056 70.9443 129.056 71.0429 129.056C71.6589 129.056 72.2996 129.088 72.965 129.162C68.9319 132.176 65.0549 135.075 61.2354 137.933L60.5782 138.418V138.409Z",fill:"url(#paint6_linear_290_1904)"}),e("path",{opacity:"0.4",d:"M88.6701 83.3544C88.6865 82.3771 88.6701 81.3999 88.6373 80.4226V80.3487C88.6373 80.2091 88.6208 80.0695 88.6208 79.9381L88.6044 79.7328C88.5633 78.9115 88.4976 78.0903 88.4237 77.2609C85.8281 76.1687 83.3803 74.7726 81.1215 73.1301C81.1379 73.3601 81.1461 73.59 81.179 73.8364C81.4582 75.7909 81.3843 75.1914 81.5814 76.8995C81.7375 77.7783 81.9018 79.3797 81.9182 79.8888C81.8771 80.3405 81.7621 80.7347 81.4829 81.0303C81.1954 81.3342 80.8586 81.4491 80.4972 81.4491C80.0619 81.4491 79.5937 81.2849 79.1337 81.0878C79.9961 81.4738 83.7007 83.108 89.5408 85.2432C88.9165 84.8572 88.7194 84.2742 88.6619 83.3626L88.6701 83.3544Z",fill:"url(#paint7_linear_290_1904)"}),e("path",{opacity:"0.4",d:"M131.022 64.885C128.59 68.2685 125.6 71.2331 122.175 73.6146C120.606 78.7719 118.158 83.6336 114.273 87.9861C113.813 88.5035 113.312 88.988 112.811 89.4807C112.326 89.9488 111.628 90.8029 111.02 90.8029C110.897 90.8029 110.782 90.77 110.675 90.6961C109.788 90.0802 110.577 88.8155 110.856 88.1585C112.31 84.7505 113.427 81.2931 114.257 77.7865C111.825 78.698 109.271 79.3386 106.634 79.6999C106.314 80.7429 105.977 81.794 105.607 82.837C105.172 84.036 104.655 85.2021 104.104 86.3518C103.62 87.3702 103.275 88.602 102.018 88.602C101.771 88.602 101.484 88.5527 101.147 88.446C99.2827 87.83 99.8084 86.4175 100.047 85.1282C100.367 83.4201 100.663 81.7119 100.909 79.9956C98.5927 79.9217 96.3256 79.626 94.1325 79.1168C93.9271 80.4883 93.6889 81.8515 93.4261 83.2148C93.2536 84.1263 92.8675 85.7113 91.2412 85.7113C91.044 85.7113 90.8305 85.6867 90.6005 85.6374C97.9356 88.2735 108.293 91.5584 120.458 94.1863C120.335 94.1371 120.22 94.096 120.105 94.0467C118.167 93.2255 121.666 89.7435 123.268 87.2716C127.777 80.3323 129.987 72.7523 131.005 64.8932L131.022 64.885Z",fill:"url(#paint8_linear_290_1904)"}),e("path",{opacity:"0.5",d:"M129.206 102.497C127.687 102.497 126.151 102.645 124.647 102.916C124.36 102.965 124.081 102.99 123.818 102.99C123.391 102.99 122.988 102.924 122.61 102.809C122.668 102.883 122.734 102.957 122.791 103.039C123.448 103.959 123.793 104.961 123.925 106.004C124.089 106.184 124.229 106.406 124.344 106.694C124.344 106.694 124.344 106.694 124.344 106.71C124.344 106.71 124.344 106.71 124.344 106.718C124.344 106.718 124.344 106.718 124.344 106.726C124.344 106.726 124.344 106.726 124.344 106.735C124.344 106.735 124.344 106.735 124.344 106.743C124.344 106.743 124.344 106.743 124.344 106.751C124.344 106.751 124.344 106.751 124.344 106.759C124.344 106.759 124.344 106.759 124.344 106.768V106.784C124.344 106.784 124.344 106.784 124.344 106.792C124.344 106.792 124.344 106.792 124.344 106.8C124.344 106.8 124.344 106.8 124.344 106.809C124.344 106.809 124.344 106.809 124.344 106.817C124.344 106.817 124.344 106.817 124.344 106.825C124.344 106.825 124.344 106.833 124.344 106.841C124.344 106.841 124.344 106.841 124.344 106.858C124.344 106.858 124.344 106.858 124.344 106.866C124.344 106.866 124.344 106.866 124.344 106.874C124.344 106.874 124.344 106.874 124.344 106.882C124.344 106.882 124.344 106.883 124.344 106.891C124.344 106.891 124.344 106.891 124.344 106.899C124.344 106.899 124.344 106.899 124.344 106.907C124.344 106.907 124.344 106.907 124.344 106.915C124.344 106.915 124.344 106.915 124.344 106.924C124.344 106.924 124.344 106.924 124.344 106.932C124.344 106.932 124.344 106.932 124.344 106.94C124.344 106.94 124.344 106.94 124.344 106.948C124.344 106.948 124.344 106.948 124.344 106.965C124.344 106.965 124.344 106.973 124.344 106.981C124.344 106.981 124.344 106.989 124.344 106.997V107.014C124.344 107.014 124.344 107.022 124.344 107.03C124.344 107.03 124.344 107.039 124.344 107.047C124.344 107.047 124.344 107.055 124.344 107.063C124.344 107.063 124.344 107.071 124.344 107.08C124.344 107.08 124.344 107.088 124.344 107.096C124.344 107.096 124.344 107.104 124.344 107.112C124.344 107.112 124.344 107.121 124.344 107.129C124.344 107.145 124.344 107.162 124.344 107.178C124.344 107.178 124.344 107.186 124.344 107.195C124.344 107.195 124.344 107.227 124.344 107.244C124.344 107.244 124.344 107.252 124.344 107.26V107.277C124.344 107.277 124.344 107.301 124.344 107.31C124.344 107.31 124.344 107.318 124.344 107.326V107.342V107.359C124.36 107.597 124.368 107.843 124.368 108.09C124.368 108.476 124.344 108.87 124.302 109.272C124.253 109.773 124.155 110.307 124.081 110.734C124.072 110.8 124.064 110.865 124.064 110.923C124.064 111.268 124.229 111.588 124.508 111.793L124.672 111.892C124.828 111.966 124.992 112.007 125.157 112.007C125.461 112.007 125.748 111.884 125.962 111.654C126.085 111.514 126.208 111.383 126.331 111.251C127.884 109.617 129.461 108.484 131.136 107.794C132.369 107.285 133.601 107.03 134.857 107.03C136.114 107.03 137.387 107.285 138.702 107.786C139.958 108.262 141.141 108.919 142.316 109.781C142.817 110.151 143.318 110.562 143.819 111.013C144.115 111.284 144.41 111.58 144.673 111.843L144.714 111.884L144.928 112.097L145.051 112.204C145.232 112.335 145.453 112.409 145.675 112.418C144.632 110.192 143.318 108.123 141.461 106.513C137.946 103.466 133.51 102.177 129.001 102.177",fill:"url(#paint9_linear_290_1904)"}),e("path",{opacity:"0.4",d:"M128.779 87.6905L128.582 87.7069C128.114 87.7972 127.752 88.175 127.695 88.6513C127.654 89.0208 127.654 89.415 127.703 89.8174C127.72 89.9488 127.687 90.072 127.629 90.1706C129.51 92.9627 133.584 97.9065 139.769 99.7789C139.769 99.7789 149.331 104.78 146.916 112.032L146.99 111.834C147.737 109.617 147.893 107.581 147.458 105.593C147.022 103.63 146.029 101.824 144.492 100.222C143.901 99.6064 143.244 99.0234 142.529 98.4978C142.184 98.2432 141.815 98.0051 141.437 97.7669C140.969 97.4713 140.484 97.192 139.95 96.921C137.995 95.9191 136.328 94.909 134.866 93.825C134.274 93.3898 133.699 92.9299 133.157 92.4536C131.851 91.3121 130.972 90.3348 130.315 89.3001C130.102 88.9716 129.913 88.6102 129.732 88.2653C129.658 88.1175 129.543 87.9943 129.412 87.8958C129.231 87.7562 129.001 87.6823 128.763 87.6823",fill:"url(#paint10_linear_290_1904)"}),e("path",{opacity:"0.5",d:"M116.647 107.893L118.586 106.768L126.734 95.8535C126.734 95.8535 122.274 95.0076 120.122 94.0303C120.122 94.0303 117.887 104.222 109.632 112.738L112.672 110.488C113.887 109.634 114.988 108.903 116.647 107.893Z",fill:"url(#paint11_linear_290_1904)"}),e("path",{d:"M209.416 49.9962H230.197C245.221 49.9962 252.104 57.7157 252.104 73.5818V81.4409C252.104 97.307 245.221 105.027 230.197 105.027H218.123V148.264H209.416V49.9962ZM230.197 97.0196C239.323 97.0196 243.397 92.9463 243.397 81.8598V73.0152C243.397 62.0682 239.323 57.8553 230.197 57.8553H218.123V97.0196H230.197Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M284.114 49.9962H292.821V93.0941H319.64V49.9962H328.346V148.256H319.64V100.953H292.821V148.256H284.114V49.9962Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M362.451 125.656V72.5963C362.451 57.0177 370.312 48.5919 384.497 48.5919C398.683 48.5919 406.544 57.0177 406.544 72.5963V125.656C406.544 141.234 398.683 149.66 384.497 149.66C370.312 149.66 362.451 141.234 362.451 125.656ZM397.829 126.214V72.0297C397.829 61.5016 393.056 56.451 384.489 56.451C375.922 56.451 371.15 61.5016 371.15 72.0297V126.214C371.15 136.742 375.922 141.653 384.489 141.653C393.056 141.653 397.829 136.742 397.829 126.214Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M440.796 49.9962H480.108V57.8553H449.503V93.0859H474.638V100.945H449.503V140.249H480.108V148.248H440.796V49.9962Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M511.56 49.9962H523.076L548.629 125.935V49.9962H556.769V148.256H547.504L519.56 64.458V148.256H511.56V49.9962Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M592.007 49.9962H600.714V148.256H592.007V49.9962Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M651.674 98.1447L632.437 49.9962H641.702L657.144 89.0209L672.726 49.9962H681.154L661.917 98.1447L681.992 148.256H672.726L656.438 106.989L640.01 148.256H631.591L651.666 98.1447H651.674Z",fill:"var(--ac-global-text-color-900)"})]}),o("defs",{children:[o("linearGradient",{id:"paint0_linear_290_1904",x1:"22.0956",y1:"10.3474",x2:"97.4433",y2:"140.879",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#14BAB6"}),e("stop",{offset:"0.5",stopColor:"#00ADEE"}),e("stop",{offset:"1",stopColor:"#0095C4"})]}),o("linearGradient",{id:"paint1_linear_290_1904",x1:"95.422",y1:"114.807",x2:"31.8741",y2:"4.70214",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#FDFDFE",stopOpacity:"0"}),e("stop",{offset:"0.11",stopColor:"#FDFDFE",stopOpacity:"0.17"}),e("stop",{offset:"0.3",stopColor:"#FDFDFE",stopOpacity:"0.42"}),e("stop",{offset:"0.47",stopColor:"#FDFDFE",stopOpacity:"0.63"}),e("stop",{offset:"0.64",stopColor:"#FDFDFE",stopOpacity:"0.79"}),e("stop",{offset:"0.78",stopColor:"#FDFDFE",stopOpacity:"0.9"}),e("stop",{offset:"0.91",stopColor:"#FDFDFE",stopOpacity:"0.97"}),e("stop",{offset:"1",stopColor:"#FDFDFE"})]}),o("linearGradient",{id:"paint2_linear_290_1904",x1:"76.6695",y1:"114.126",x2:"30.8746",y2:"34.7951",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#FDFDFE",stopOpacity:"0"}),e("stop",{offset:"0.11",stopColor:"#FDFDFE",stopOpacity:"0.17"}),e("stop",{offset:"0.3",stopColor:"#FDFDFE",stopOpacity:"0.42"}),e("stop",{offset:"0.47",stopColor:"#FDFDFE",stopOpacity:"0.63"}),e("stop",{offset:"0.64",stopColor:"#FDFDFE",stopOpacity:"0.79"}),e("stop",{offset:"0.78",stopColor:"#FDFDFE",stopOpacity:"0.9"}),e("stop",{offset:"0.91",stopColor:"#FDFDFE",stopOpacity:"0.97"}),e("stop",{offset:"1",stopColor:"#FDFDFE"})]}),o("linearGradient",{id:"paint3_linear_290_1904",x1:"70.3612",y1:"119.915",x2:"44.7991",y2:"75.6384",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#FDFDFE",stopOpacity:"0"}),e("stop",{offset:"0.11",stopColor:"#FDFDFE",stopOpacity:"0.17"}),e("stop",{offset:"0.3",stopColor:"#FDFDFE",stopOpacity:"0.42"}),e("stop",{offset:"0.47",stopColor:"#FDFDFE",stopOpacity:"0.63"}),e("stop",{offset:"0.64",stopColor:"#FDFDFE",stopOpacity:"0.79"}),e("stop",{offset:"0.78",stopColor:"#FDFDFE",stopOpacity:"0.9"}),e("stop",{offset:"0.91",stopColor:"#FDFDFE",stopOpacity:"0.97"}),e("stop",{offset:"1",stopColor:"#FDFDFE"})]}),o("linearGradient",{id:"paint4_linear_290_1904",x1:"71.4208",y1:"128.85",x2:"55.5071",y2:"101.279",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#FDFDFE",stopOpacity:"0"}),e("stop",{offset:"0.11",stopColor:"#FDFDFE",stopOpacity:"0.17"}),e("stop",{offset:"0.3",stopColor:"#FDFDFE",stopOpacity:"0.42"}),e("stop",{offset:"0.47",stopColor:"#FDFDFE",stopOpacity:"0.63"}),e("stop",{offset:"0.64",stopColor:"#FDFDFE",stopOpacity:"0.79"}),e("stop",{offset:"0.78",stopColor:"#FDFDFE",stopOpacity:"0.9"}),e("stop",{offset:"0.91",stopColor:"#FDFDFE",stopOpacity:"0.97"}),e("stop",{offset:"1",stopColor:"#FDFDFE"})]}),o("linearGradient",{id:"paint5_linear_290_1904",x1:"44.5363",y1:"126.346",x2:"44.5363",y2:"155.384",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#231F20"}),e("stop",{offset:"0.03",stopColor:"#231F20",stopOpacity:"0.9"}),e("stop",{offset:"0.22",stopColor:"#231F20",stopOpacity:"0.4"}),e("stop",{offset:"0.42",stopColor:"#231F20",stopOpacity:"0.1"}),e("stop",{offset:"0.65",stopColor:"#231F20",stopOpacity:"0"})]}),o("linearGradient",{id:"paint6_linear_290_1904",x1:"77.1952",y1:"123.603",x2:"77.1952",y2:"138.409",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#231F20"}),e("stop",{offset:"1",stopColor:"#231F20",stopOpacity:"0"})]}),o("linearGradient",{id:"paint7_linear_290_1904",x1:"84.3413",y1:"85.235",x2:"84.3413",y2:"73.1301",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#231F20"}),e("stop",{offset:"0.03",stopColor:"#231F20",stopOpacity:"0.95"}),e("stop",{offset:"0.51",stopColor:"#231F20",stopOpacity:"0.26"}),e("stop",{offset:"0.81",stopColor:"#231F20",stopOpacity:"0"})]}),o("linearGradient",{id:"paint8_linear_290_1904",x1:"110.815",y1:"94.1699",x2:"110.815",y2:"64.885",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#231F20"}),e("stop",{offset:"0.18",stopColor:"#231F20",stopOpacity:"0.48"}),e("stop",{offset:"0.38",stopColor:"#231F20",stopOpacity:"0.12"}),e("stop",{offset:"0.58",stopColor:"#231F20",stopOpacity:"0"})]}),o("linearGradient",{id:"paint9_linear_290_1904",x1:"138.077",y1:"117.246",x2:"127.969",y2:"99.7278",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#231F20"}),e("stop",{offset:"1",stopColor:"#231F20",stopOpacity:"0"})]}),o("linearGradient",{id:"paint10_linear_290_1904",x1:"146.226",y1:"112.434",x2:"131.084",y2:"86.1931",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#FDFDFE",stopOpacity:"0"}),e("stop",{offset:"0.11",stopColor:"#FDFDFE",stopOpacity:"0.17"}),e("stop",{offset:"0.3",stopColor:"#FDFDFE",stopOpacity:"0.42"}),e("stop",{offset:"0.47",stopColor:"#FDFDFE",stopOpacity:"0.63"}),e("stop",{offset:"0.64",stopColor:"#FDFDFE",stopOpacity:"0.79"}),e("stop",{offset:"0.78",stopColor:"#FDFDFE",stopOpacity:"0.9"}),e("stop",{offset:"0.91",stopColor:"#FDFDFE",stopOpacity:"0.97"}),e("stop",{offset:"1",stopColor:"#FDFDFE"})]}),o("linearGradient",{id:"paint11_linear_290_1904",x1:"106.889",y1:"107.999",x2:"128.941",y2:"95.2581",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#231F20"}),e("stop",{offset:"0.31",stopColor:"#231F20",stopOpacity:"0.5"}),e("stop",{offset:"0.67",stopColor:"#231F20",stopOpacity:"0.13"}),e("stop",{offset:"1",stopColor:"#231F20",stopOpacity:"0"})]}),e("clipPath",{id:"clip0_290_1904",children:e("rect",{width:"682",height:"169",fill:"white"})})]})]})}const ef=C`
  text-align: center;
  margin-top: var(--ac-global-dimension-size-200);
  margin-bottom: var(--ac-global-dimension-size-200);
  color: var(--ac-global-text-color-700);
`,nf=C`
  display: flex;
  flex-direction: column;
  gap: var(--ac-global-dimension-size-100);
  flex-wrap: wrap;
  justify-content: center;
`;function T1(){const n=window.Config.oAuth2Idps,a=n.length>0,[t,l]=fa(),i=t.get("returnUrl"),r=t.get("message");return o(Ja,{children:[e(h,{direction:"column",gap:"size-200",alignItems:"center",children:e(F,{paddingBottom:"size-200",children:e(Vt,{})})}),r&&e(F,{paddingBottom:"size-100",children:e(ce,{variant:"success",children:r})}),e(Jy,{initialError:t.get("error"),onSubmit:()=>{l(s=>{const c=new URLSearchParams(s);return c.delete("message"),c.delete("error"),c})}}),a&&o(G,{children:[e("div",{css:ef,children:"or"}),e("ul",{css:nf,children:n.map(s=>e("li",{children:e(Yy,{idpName:s.name,idpDisplayName:s.displayName,returnUrl:i},s.name)},s.name))})]})]})}const Xs=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"UserMutationPayload",kind:"LinkedField",name:"patchViewer",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ResetPasswordFormMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ResetPasswordFormMutation",selections:a},params:{cacheID:"d09af5e3a2a3d10f117373e25bef11e6",id:null,metadata:{},name:"ResetPasswordFormMutation",operationKind:"mutation",text:`mutation ResetPasswordFormMutation(
  $input: PatchViewerInput!
) {
  patchViewer(input: $input) {
    __typename
  }
}
`}}}();Xs.hash="f8f5c30b0e00c17cdda7557c73c3c2d3";const oa=4;function af(){const n=ne(),a=be(),[t,l]=P.useMutation(Xs),{control:i,handleSubmit:r}=je({defaultValues:{currentPassword:"",newPassword:"",confirmPassword:""}}),s=m.useCallback(c=>{t({variables:{input:{currentPassword:c.currentPassword,newPassword:c.newPassword}},onCompleted:()=>{const d=ai({path:"/login",searchParams:{message:"Password has been reset."}});n(d)},onError:d=>{a({title:"Failed to reset password",message:d.message})}})},[t,n,a]);return o(we,{onSubmit:r(s),children:[e(W,{name:"currentPassword",control:i,rules:{required:"the current is required"},render:({field:{name:c,onChange:d,onBlur:u,value:y},fieldState:{invalid:g,error:p}})=>e(ee,{label:"Old Password",type:"password",name:c,isRequired:!0,description:"The current password",errorMessage:p==null?void 0:p.message,validationState:g?"invalid":"valid",onChange:d,onBlur:u,value:y})}),e(W,{name:"newPassword",control:i,rules:{required:"Password is required",minLength:{value:oa,message:`Password must be at least ${oa} characters`},validate:(c,d)=>c!==d.currentPassword||"New password must be different"},render:({field:{name:c,onChange:d,onBlur:u,value:y},fieldState:{invalid:g,error:p}})=>e(ee,{label:"New Password",type:"password",isRequired:!0,description:`Password must be at least ${oa} characters`,name:c,errorMessage:p==null?void 0:p.message,validationState:g?"invalid":"valid",onChange:d,onBlur:u,defaultValue:y})}),e(W,{name:"confirmPassword",control:i,rules:{required:"Password is required",minLength:{value:oa,message:`Password must be at least ${oa} characters`},validate:(c,d)=>c===d.newPassword||"Passwords do not match"},render:({field:{name:c,onChange:d,onBlur:u,value:y},fieldState:{invalid:g,error:p}})=>e(ee,{label:"Confirm Password",isRequired:!0,type:"password",description:"Confirm the new password",name:c,errorMessage:p==null?void 0:p.message,validationState:g?"invalid":"valid",onChange:d,onBlur:u,defaultValue:y})}),e(F,{paddingTop:"size-200",children:o("div",{css:C`
            display: flex;
            flex-direction: row;
            gap: var(--ac-global-dimension-size-200);
            & > * {
              width: 50%;
            }
          `,children:[e(z,{variant:"default",onClick:()=>{n(-1)},children:"Cancel"}),e(z,{variant:"primary",type:"submit",disabled:l,children:l?"Resetting...":"Reset Password"})]})})]})}function D1(){return o(Ja,{children:[e(h,{direction:"column",gap:"size-200",alignItems:"center",children:e(F,{paddingBottom:"size-200",children:e(Vt,{})})}),e(af,{})]})}const da=4,tf="An error occurred. Please try resetting again.";function lf({resetToken:n}){const a=ne(),[t,l]=m.useState(null),[i,r]=m.useState(!1),s=m.useCallback(async({resetToken:y,newPassword:g})=>{l(null),r(!0);try{const p=await fetch(ba("/auth/password-reset"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token:y,password:g})});if(!p.ok){const f=await p.text();l(f);return}}catch{l(tf);return}finally{r(()=>!1)}a(`/login?message=${encodeURIComponent("Password has been reset.")}`)},[l,a]),{control:c,handleSubmit:d,formState:{isDirty:u}}=je({defaultValues:{resetToken:n,newPassword:"",confirmPassword:""}});return o(G,{children:[t?e(F,{paddingBottom:"size-100",children:e(ce,{variant:"danger",children:t})}):null,o(we,{onSubmit:d(s),children:[e(W,{name:"newPassword",control:c,rules:{required:"Password is required",minLength:{value:da,message:`Password must be at least ${da} characters`}},render:({field:{name:y,onChange:g,onBlur:p,value:f},fieldState:{invalid:k,error:b}})=>e(ee,{label:"New Password",type:"password",isRequired:!0,description:`Password must be at least ${da} characters`,name:y,errorMessage:b==null?void 0:b.message,validationState:k?"invalid":"valid",onChange:g,onBlur:p,defaultValue:f})}),e(W,{name:"confirmPassword",control:c,rules:{required:"Password is required",minLength:{value:da,message:`Password must be at least ${da} characters`},validate:(y,g)=>y===g.newPassword||"Passwords do not match"},render:({field:{name:y,onChange:g,onBlur:p,value:f},fieldState:{invalid:k,error:b}})=>e(ee,{label:"Confirm Password",isRequired:!0,type:"password",description:"Confirm the new password",name:y,errorMessage:b==null?void 0:b.message,validationState:k?"invalid":"valid",onChange:g,onBlur:p,defaultValue:f})}),e("div",{css:C`
            margin-top: var(--ac-global-dimension-size-200);
            margin-bottom: var(--ac-global-dimension-size-50);
            button {
              width: 100%;
            }
          `,children:e(z,{variant:u?"primary":"default",type:"submit",disabled:i,children:i?"Resetting...":"Reset Password"})})]})]})}function I1(){const n=ne(),[a]=fa(),t=a.get("token");return t?o(Ja,{children:[e(h,{direction:"column",gap:"size-200",alignItems:"center",children:e(F,{paddingBottom:"size-200",children:e(Vt,{})})}),e(lf,{resetToken:t}),e(F,{paddingTop:"size-200",children:e(h,{direction:"column",alignItems:"center",justifyContent:"center",children:e(cn,{to:"/login",children:"Back to Login"})})})]}):(n("/login"),null)}const eo=function(){var n=[{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"viewer",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"resetPasswordLoaderQuery",selections:n,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"resetPasswordLoaderQuery",selections:n},params:{cacheID:"c97389cd896f3e1746d0adf67c759462",id:null,metadata:{},name:"resetPasswordLoaderQuery",operationKind:"query",text:`query resetPasswordLoaderQuery {
  viewer {
    id
    email
  }
}
`}}}();eo.hash="ccd75708c3ba7c1b283f7858dfa8d20e";async function P1(){const n=await P.fetchQuery(Ne,eo,{}).toPromise();return n!=null&&n.viewer?n:Ma("/login")}function rf({onResetSent:n}){const[a,t]=m.useState(null),[l,i]=m.useState(!1),r=m.useCallback(async d=>{t(null),i(!0);try{const u=await fetch(ba("/auth/password-reset-email"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(d)});if(!u.ok){const y=await u.text();t(y);return}n()}finally{i(()=>!1)}},[n,t]),{control:s,handleSubmit:c}=je({defaultValues:{email:""}});return o(G,{children:[a?e(F,{paddingBottom:"size-100",children:e(ce,{variant:"danger",children:a})}):null,o(we,{onSubmit:c(r),children:[e(W,{name:"email",control:s,render:({field:{onChange:d,value:u}})=>e(ee,{label:"Email",name:"email",isRequired:!0,type:"email",onChange:d,value:u,placeholder:"your email address",description:"Enter the email address associated with your account."})}),e("div",{css:C`
            margin-top: var(--ac-global-dimension-size-200);
            margin-bottom: var(--ac-global-dimension-size-50);
            button {
              width: 100%;
            }
          `,children:e(z,{variant:"primary",type:"submit",loading:l,children:"Send"})})]})]})}function L1(){const[n,a]=m.useState(!1),t=n?o(h,{direction:"column",alignItems:"center",justifyContent:"center",gap:"size-100",children:[e(ge,{level:1,children:"Check your email"}),e("p",{children:"Thanks! If an account with that email address exists, we sent you a link to reset your password."})]}):o(G,{children:[o(h,{direction:"column",alignItems:"center",justifyContent:"center",gap:"size-100",children:[e(ge,{level:1,children:"Forgot Password"}),e("p",{children:`Enter the email address associated with your account and we'll send you
        a link to reset your password.`})]}),e(rf,{onResetSent:()=>a(!0)})]});return e(Ja,{children:o("div",{css:C`
          & a {
            text-align: center;
            width: 100%;
            display: block;
            text-align: center;
            padding-top: var(--ac-global-dimension-size-200);
          }
        `,children:[t,e(h,{direction:"column",alignItems:"center",justifyContent:"center",gap:"size-200",children:e(cn,{to:"/login",children:"Back to Login"})})]})})}const no=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{kind:"Variable",name:"input",variableName:"input"}],t={alias:null,args:null,kind:"ScalarField",name:"jwt",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ViewerAPIKeysCreateUserAPIKeyMutation",selections:[{alias:null,args:a,concreteType:"CreateUserApiKeyMutationPayload",kind:"LinkedField",name:"createUserApiKey",plural:!1,selections:[t,{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"apiKey",plural:!1,selections:[l,{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"APIKeysTableFragment"}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ViewerAPIKeysCreateUserAPIKeyMutation",selections:[{alias:null,args:a,concreteType:"CreateUserApiKeyMutationPayload",kind:"LinkedField",name:"createUserApiKey",plural:!1,selections:[t,{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"apiKey",plural:!1,selections:[l,{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"apiKeys",plural:!0,selections:[l,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null}],storageKey:null},l],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"572bf0f64678128defccf833e6a5d4ce",id:null,metadata:{},name:"ViewerAPIKeysCreateUserAPIKeyMutation",operationKind:"mutation",text:`mutation ViewerAPIKeysCreateUserAPIKeyMutation(
  $input: CreateUserApiKeyInput!
) {
  createUserApiKey(input: $input) {
    jwt
    apiKey {
      id
      user {
        ...APIKeysTableFragment
      }
    }
  }
}

fragment APIKeysTableFragment on User {
  apiKeys {
    id
    name
    description
    createdAt
    expiresAt
  }
  id
}
`}}}();no.hash="28061ae008e197468be6fd5f2775ccb0";const ao=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{kind:"Variable",name:"input",variableName:"input"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"apiKeyId",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"APIKeysTableDeleteAPIKeyMutation",selections:[{alias:null,args:a,concreteType:"DeleteApiKeyMutationPayload",kind:"LinkedField",name:"deleteUserApiKey",plural:!1,selections:[t,l,{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"UserAPIKeysTableFragment"}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"APIKeysTableDeleteAPIKeyMutation",selections:[{alias:null,args:a,concreteType:"DeleteApiKeyMutationPayload",kind:"LinkedField",name:"deleteUserApiKey",plural:!1,selections:[t,l,{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"userApiKeys",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null},{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"f28a00e7a6eb2e18b1f8b31c8231c2b7",id:null,metadata:{},name:"APIKeysTableDeleteAPIKeyMutation",operationKind:"mutation",text:`mutation APIKeysTableDeleteAPIKeyMutation(
  $input: DeleteApiKeyInput!
) {
  deleteUserApiKey(input: $input) {
    __typename
    apiKeyId
    query {
      ...UserAPIKeysTableFragment
    }
  }
}

fragment UserAPIKeysTableFragment on Query {
  userApiKeys {
    id
    name
    description
    createdAt
    expiresAt
    user {
      email
    }
  }
}
`}}}();ao.hash="3a505d9d13944798a57fc873ddf0992d";const to=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"APIKeysTableQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"APIKeysTableFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"APIKeysTableQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},t,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"apiKeys",plural:!0,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null}],storageKey:null}],type:"User",abstractKey:null}],storageKey:null}]},params:{cacheID:"e677b5974fa137ac3a26acde353767d8",id:null,metadata:{},name:"APIKeysTableQuery",operationKind:"query",text:`query APIKeysTableQuery(
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...APIKeysTableFragment
    __isNode: __typename
    id
  }
}

fragment APIKeysTableFragment on User {
  apiKeys {
    id
    name
    description
    createdAt
    expiresAt
  }
  id
}
`}}}();to.hash="6c32098d55e4cba859dcec73f3ccd28c";const lo=function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{argumentDefinitions:[],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:["node"],operation:to,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"APIKeysTableFragment",selections:[{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"apiKeys",plural:!0,selections:[n,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null}],storageKey:null},n],type:"User",abstractKey:null}}();lo.hash="6c32098d55e4cba859dcec73f3ccd28c";const yl=70;function sf({query:n}){const[a,t]=P.useRefetchableFragment(lo,n),l=ve(),[i]=P.useMutation(ao),r=m.useCallback(g=>{i({variables:{input:{id:g}},onCompleted:()=>{l({title:"API key deleted",message:"The key has been deleted and is no longer active."}),m.startTransition(()=>{t({},{fetchPolicy:"network-only"})})}})},[i,l,t]),s=m.useMemo(()=>[...a.apiKeys],[a]),c=m.useMemo(()=>[{header:"Name",accessorKey:"name",size:100,cell:Ke},{header:"Description",accessorKey:"description",cell:Ke},{header:"Created At",accessorKey:"createdAt",size:yl,cell:_e},{header:"Expires At",accessorKey:"expiresAt",size:yl,cell:_e},{header:"",accessorKey:"id",size:10,cell:({row:p})=>e(h,{direction:"row",justifyContent:"end",width:"100%",children:e(It,{handleDelete:()=>{r(p.original.id)}})}),meta:{textAlign:"right"}}],[r]),d=Te({columns:c,data:s,getCoreRowModel:De()}),u=d.getRowModel().rows,y=d.getRowModel().rows.length===0;return o("table",{css:Je,children:[e("thead",{children:d.getHeaderGroups().map(g=>e("tr",{children:g.headers.map(p=>e("th",{colSpan:p.colSpan,children:p.isPlaceholder?null:o("div",{className:p.column.getCanSort()?"cursor-pointer":"",onClick:p.column.getToggleSortingHandler(),style:{left:p.getStart(),width:p.getSize()},children:[Z(p.column.columnDef.header,p.getContext()),p.column.getIsSorted()?e(L,{className:"sort-icon",svg:p.column.getIsSorted()==="asc"?e(D.ArrowUpFilled,{}):e(D.ArrowDownFilled,{})}):null]})},p.id))},g.id))}),y?e(Ze,{message:"No Keys"}):e("tbody",{children:u.map(g=>e("tr",{children:g.getVisibleCells().map(p=>e("td",{children:Z(p.column.columnDef.cell,p.getContext())},p.id))},g.id))})]})}function of({viewer:n}){const[a,t]=m.useState(null),l=be(),[i,r]=P.useMutation(no),s=m.useCallback(c=>{i({variables:{input:{...c,expiresAt:c.expiresAt||null}},onCompleted:d=>{t(e(Xl,{jwt:d.createUserApiKey.jwt}))},onError:d=>{l({title:"Error creating API key",message:d.message})}})},[i,l]);return o(q,{title:"API Keys",variant:"compact",bodyStyle:{padding:0},extra:e(z,{variant:"default",size:"compact",icon:e(L,{svg:e(D.PlusCircleOutline,{})}),onClick:()=>t(e(ei,{onSubmit:s,isCommitting:r})),children:"New Key"}),children:[e(sf,{query:n}),e(ae,{onDismiss:()=>{t(null)},children:a})]})}const io=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"UserMutationPayload",kind:"LinkedField",name:"patchViewer",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ViewerProfileCardMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ViewerProfileCardMutation",selections:a},params:{cacheID:"03f161df42c71b5924a8ee665e01cdce",id:null,metadata:{},name:"ViewerProfileCardMutation",operationKind:"mutation",text:`mutation ViewerProfileCardMutation(
  $input: PatchViewerInput!
) {
  patchViewer(input: $input) {
    __typename
  }
}
`}}}();io.hash="4a11ca65151d84fe95f636763c91dc68";function df(){const{viewer:n,refetchViewer:a}=ti(),t=be(),l=ve(),[i,r]=P.useMutation(io),s=ne(),{control:c,handleSubmit:d,formState:{isDirty:u},reset:y}=je({defaultValues:{username:(n==null?void 0:n.username)||""}}),g=m.useCallback(p=>{i({variables:{input:{newUsername:p.username}},onCompleted:()=>{l({title:"Profile updated",message:"Your profile has been updated"}),y({username:p.username}),a()},onError:f=>{t({title:"Failed update profile",message:f.message})}})},[i,l,y,a,t]);return n?o(q,{title:"Profile",variant:"compact",bodyStyle:{padding:0},extra:n.authMethod==="LOCAL"&&e(z,{variant:"default",size:"compact",onClick:()=>{s("/reset-password")},children:"Reset Password"}),children:[e(F,{paddingTop:"size-200",paddingStart:"size-200",paddingEnd:"size-200",children:o(h,{direction:"row",gap:"size-200",alignItems:"center",children:[e(ni,{name:n.username||n.email,profilePictureUrl:n.profilePictureUrl}),o(h,{direction:"column",gap:"size-50",children:[e(ge,{level:2,weight:"heavy",children:n.username||n.email}),e(x,{children:n.role.name.toLocaleLowerCase()})]})]})}),e(F,{children:o(we,{onSubmit:d(g),children:[o(F,{padding:"size-200",children:[e(ee,{label:"Email",value:n.email,isReadOnly:!0}),e(W,{name:"username",control:c,rules:{required:"A username is required as it needs to be unique"},render:({field:{name:p,onChange:f,onBlur:k,value:b},fieldState:{invalid:S,error:v}})=>e(ee,{label:"Username",isRequired:!0,description:"A unique username",name:p,errorMessage:v==null?void 0:v.message,validationState:S?"invalid":"valid",onChange:f,onBlur:k,defaultValue:b})})]}),e(F,{paddingTop:"size-100",paddingBottom:"size-100",paddingStart:"size-200",paddingEnd:"size-200",borderTopColor:"dark",borderTopWidth:"thin",children:e(h,{direction:"row",gap:"size-100",justifyContent:"end",children:e(z,{variant:u?"primary":"default",size:"compact",disabled:!u,onClick:()=>{d(g)()},children:r?"Saving...":"Save"})})})]})})]}):null}const cf=C`
  overflow-y: auto;
`,uf=C`
  padding: var(--ac-global-dimension-size-400);
  max-width: 800px;
  min-width: 500px;
  box-sizing: border-box;
  width: 100%;
  margin-left: auto;
  margin-right: auto;
`;function E1(){const{viewer:n}=ti();return n?e("main",{css:cf,children:e("div",{css:uf,children:o(h,{direction:"column",gap:"size-200",children:[e(df,{}),e(of,{viewer:n})]})})}):null}const ro=function(){var n=[{alias:null,args:null,concreteType:"GenerativeProvider",kind:"LinkedField",name:"modelProviders",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dependenciesInstalled",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dependencies",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"PlaygroundQuery",selections:n,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"PlaygroundQuery",selections:n},params:{cacheID:"f19ebe151a3a9794fa2566c66751d259",id:null,metadata:{},name:"PlaygroundQuery",operationKind:"query",text:`query PlaygroundQuery {
  modelProviders {
    name
    dependenciesInstalled
    dependencies
  }
}
`}}}();ro.hash="9802d9d44657ca300abc1be4d0938560";const $t=m.createContext(null);function mf({children:n,...a}){const[t]=m.useState(()=>hc(a));return e($t.Provider,{value:t,children:n})}function O(n,a){const t=Se.useContext($t);if(!t)throw new Error("Missing PlaygroundContext.Provider in the tree");return ya(t,n,a)}function so(){const n=Se.useContext($t);if(!n)throw new Error("Missing PlaygroundContext.Provider in the tree");return n}const gf=`
The playground is not available until an LLM provider client is installed on the server.
`,pf=n=>`
# Installing one or more of the clients will enable the playground
${Array.from(n.reduce((a,t)=>(t.dependencies.forEach(l=>a.add(l)),a),new Set)).map(a=>`pip install ${a}`).join(`
`)}
`,yf=n=>e(F,{height:"100%",width:"100%",children:o(h,{direction:"column",alignItems:"center",justifyContent:"center",gap:"size-200",children:[e(Al,{message:gf,graphicKey:"not found",size:"L"}),e(x,{children:"The following clients are supported:"}),e(kc,{value:pf(n.availableProviders)})]})}),ff={OPENAI:"OPENAI_API_KEY",ANTHROPIC:"ANTHROPIC_API_KEY",AZURE_OPENAI:"AZURE_OPENAI_API_KEY",GEMINI:"GEMINI_API_KEY"};function hf(){const n=O(s=>Array.from(new Set(s.instances.map(c=>c.model.provider)))),a=O(s=>s.instances.some(c=>c.activeRunId!=null)),t=Va(s=>s.setCredential),l=Va(s=>s),[i,r]=m.useState(!1);return e("div",{css:C`
        .ac-dropdown-button {
          min-width: 0px;
        }
      `,children:o(Bn,{placement:"bottom",isOpen:i,onOpenChange:s=>{r(s)},children:[e(St,{size:"compact",isDisabled:a,children:"API Keys"}),e(Oa,{children:e(F,{padding:"size-200",children:o(we,{onSubmit:s=>{s.preventDefault(),r(!1)},children:[e(ge,{level:2,weight:"heavy",children:"API Keys"}),e(x,{color:"text-700",children:"API keys are stored in your browser and used to communicate with their respective API's."}),e(h,{direction:"column",gap:"size-100",children:n.map(s=>{const c=ff[s];return e(ee,{label:c,type:"password",isRequired:!0,onChange:d=>{t({provider:s,value:d})},value:l[s],description:`Alternatively, you can set the "${c}" environment variable on the phoenix server.`},s)})})]})})})]})})}const fl=30,kf=C`
  display: flex;
  direction: row;
  align-items: center;
  .ac-dropdown > button {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
    height: ${fl}px;
  }
  .ac-button {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
    border-left: none;
    height: ${fl}px;
  }
`;function bf(){const n=ne(),{datasetId:a}=Ue(),t=a??"";return o("div",{css:kf,children:[e(Ol,{size:"compact",placeholder:"Test over a dataset",selectedKey:t,onSelectionChange:l=>{if(t!==null&&l===t){n("/playground");return}n(`/playground/datasets/${l}`)}}),e(z,{size:"compact",variant:"default",icon:e(L,{svg:e(D.CloseOutline,{})}),onClick:()=>{n("/playground")}})]})}const oo=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"datasetId"}],a=[{kind:"Variable",name:"id",variableName:"datasetId"}],t={kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"exampleCount",storageKey:null}],type:"Dataset",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"PlaygroundDatasetSectionQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"PlaygroundDatasetSectionQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t,{kind:"TypeDiscriminator",abstractKey:"__isNode"},{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"c36833ac260163836d9810cf8e137380",id:null,metadata:{},name:"PlaygroundDatasetSectionQuery",operationKind:"query",text:`query PlaygroundDatasetSectionQuery(
  $datasetId: GlobalID!
) {
  dataset: node(id: $datasetId) {
    __typename
    ... on Dataset {
      name
      exampleCount
    }
    __isNode: __typename
    id
  }
}
`}}}();oo.hash="38aaf5a39c06500e51a82c91a9e27408";const co=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"ChatCompletionOverDatasetMutationPayload",kind:"LinkedField",name:"chatCompletionOverDataset",plural:!1,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"experimentId",storageKey:null},{alias:null,args:null,concreteType:"ChatCompletionOverDatasetMutationExamplePayload",kind:"LinkedField",name:"examples",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"datasetExampleId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"experimentRunId",storageKey:null},{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"result",plural:!1,selections:[a,{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"message",storageKey:null}],type:"ChatCompletionMutationError",abstractKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"content",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"errorMessage",storageKey:null},{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"span",plural:!1,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null},{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[t],storageKey:null},{alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"ChatCompletionToolCall",kind:"LinkedField",name:"toolCalls",plural:!0,selections:[t,{alias:null,args:null,concreteType:"ChatCompletionFunctionCall",kind:"LinkedField",name:"function",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"arguments",storageKey:null}],storageKey:null}],storageKey:null}],type:"ChatCompletionMutationPayload",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"PlaygroundDatasetExamplesTableMutation",selections:l,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"PlaygroundDatasetExamplesTableMutation",selections:l},params:{cacheID:"4697f7aaa22729dbf83970ce9ae6475b",id:null,metadata:{},name:"PlaygroundDatasetExamplesTableMutation",operationKind:"mutation",text:`mutation PlaygroundDatasetExamplesTableMutation(
  $input: ChatCompletionOverDatasetInput!
) {
  chatCompletionOverDataset(input: $input) {
    __typename
    experimentId
    examples {
      datasetExampleId
      experimentRunId
      result {
        __typename
        ... on ChatCompletionMutationError {
          message
        }
        ... on ChatCompletionMutationPayload {
          content
          errorMessage
          span {
            id
            tokenCountCompletion
            tokenCountPrompt
            tokenCountTotal
            latencyMs
            project {
              id
            }
            context {
              traceId
            }
          }
          toolCalls {
            id
            function {
              name
              arguments
            }
          }
        }
      }
    }
  }
}
`}}}();co.hash="c15f93fe1380986536971620c3bf3a11";const uo=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a={alias:null,args:null,kind:"ScalarField",name:"datasetExampleId",storageKey:null},t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l=[t],i=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:null,kind:"LinkedField",name:"chatCompletionOverDataset",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"content",storageKey:null},a],type:"TextChunk",abstractKey:null},{kind:"InlineFragment",selections:[t,a,{alias:null,args:null,concreteType:"FunctionCallChunk",kind:"LinkedField",name:"function",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"arguments",storageKey:null}],storageKey:null}],type:"ToolCallChunk",abstractKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"Experiment",kind:"LinkedField",name:"experiment",plural:!1,selections:l,storageKey:null}],type:"ChatCompletionSubscriptionExperiment",abstractKey:null},{kind:"InlineFragment",selections:[a,{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"span",plural:!1,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null},{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"ExperimentRun",kind:"LinkedField",name:"experimentRun",plural:!1,selections:l,storageKey:null}],type:"ChatCompletionSubscriptionResult",abstractKey:null},{kind:"InlineFragment",selections:[a,{alias:null,args:null,kind:"ScalarField",name:"message",storageKey:null}],type:"ChatCompletionSubscriptionError",abstractKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"PlaygroundDatasetExamplesTableSubscription",selections:i,type:"Subscription",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"PlaygroundDatasetExamplesTableSubscription",selections:i},params:{cacheID:"3759bfb17a93aa0cf227c4ef7fa6cd30",id:null,metadata:{},name:"PlaygroundDatasetExamplesTableSubscription",operationKind:"subscription",text:`subscription PlaygroundDatasetExamplesTableSubscription(
  $input: ChatCompletionOverDatasetInput!
) {
  chatCompletionOverDataset(input: $input) {
    __typename
    ... on TextChunk {
      content
      datasetExampleId
    }
    ... on ToolCallChunk {
      id
      datasetExampleId
      function {
        name
        arguments
      }
    }
    ... on ChatCompletionSubscriptionExperiment {
      experiment {
        id
      }
    }
    ... on ChatCompletionSubscriptionResult {
      datasetExampleId
      span {
        id
        tokenCountCompletion
        tokenCountPrompt
        tokenCountTotal
        latencyMs
        project {
          id
        }
        context {
          traceId
        }
      }
      experimentRun {
        id
      }
    }
    ... on ChatCompletionSubscriptionError {
      datasetExampleId
      message
    }
  }
}
`}}}();uo.hash="f1df5c75f1a62acde69f3f5d676f9213";const mo=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:null,kind:"LocalArgument",name:"datasetVersionId"},{defaultValue:20,kind:"LocalArgument",name:"first"},{defaultValue:null,kind:"LocalArgument",name:"id"}],a=[{kind:"Variable",name:"id",variableName:"id"}],t=[{kind:"Variable",name:"after",variableName:"after"},{kind:"Variable",name:"datasetVersionId",variableName:"datasetVersionId"},{kind:"Variable",name:"first",variableName:"first"}],l={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"PlaygroundDatasetExamplesTableRefetchQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:t,kind:"FragmentSpread",name:"PlaygroundDatasetExamplesTableFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"PlaygroundDatasetExamplesTableRefetchQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[l,{kind:"TypeDiscriminator",abstractKey:"__isNode"},i,{kind:"InlineFragment",selections:[{alias:null,args:t,concreteType:"DatasetExampleConnection",kind:"LinkedField",name:"examples",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetExampleEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"example",args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[i,{alias:null,args:null,concreteType:"DatasetExampleRevision",kind:"LinkedField",name:"revision",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"input",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[l],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:t,filters:["datasetVersionId"],handle:"connection",key:"PlaygroundDatasetExamplesTable_examples",kind:"LinkedHandle",name:"examples"}],type:"Dataset",abstractKey:null}],storageKey:null}]},params:{cacheID:"fc176d05790f6c690eead96a6ece1c50",id:null,metadata:{},name:"PlaygroundDatasetExamplesTableRefetchQuery",operationKind:"query",text:`query PlaygroundDatasetExamplesTableRefetchQuery(
  $after: String = null
  $datasetVersionId: GlobalID
  $first: Int = 20
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...PlaygroundDatasetExamplesTableFragment_4a6F8Z
    __isNode: __typename
    id
  }
}

fragment PlaygroundDatasetExamplesTableFragment_4a6F8Z on Dataset {
  examples(datasetVersionId: $datasetVersionId, first: $first, after: $after) {
    edges {
      example: node {
        id
        revision {
          input
          output
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();mo.hash="ae68770500a29b14f7108d56c146fb99";const go=function(){var n=["examples"],a={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"after"},{defaultValue:null,kind:"LocalArgument",name:"datasetVersionId"},{defaultValue:20,kind:"LocalArgument",name:"first"}],kind:"Fragment",metadata:{connection:[{count:"first",cursor:"after",direction:"forward",path:n}],refetch:{connection:{forward:{count:"first",cursor:"after"},backward:null,path:n},fragmentPathInResult:["node"],operation:mo,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"PlaygroundDatasetExamplesTableFragment",selections:[{alias:"examples",args:[{kind:"Variable",name:"datasetVersionId",variableName:"datasetVersionId"}],concreteType:"DatasetExampleConnection",kind:"LinkedField",name:"__PlaygroundDatasetExamplesTable_examples_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetExampleEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"example",args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[a,{alias:null,args:null,concreteType:"DatasetExampleRevision",kind:"LinkedField",name:"revision",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"input",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},a],type:"Dataset",abstractKey:null}}();go.hash="ae68770500a29b14f7108d56c146fb99";const po=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"datasetId"}],a=[{kind:"Variable",name:"id",variableName:"datasetId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i=[{kind:"Literal",name:"first",value:20}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"PlaygroundDatasetExamplesTableQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"PlaygroundDatasetExamplesTableFragment"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"PlaygroundDatasetExamplesTableQuery",selections:[{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"TypeDiscriminator",abstractKey:"__isNode"},l,{kind:"InlineFragment",selections:[{alias:null,args:i,concreteType:"DatasetExampleConnection",kind:"LinkedField",name:"examples",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetExampleEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"example",args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[l,{alias:null,args:null,concreteType:"DatasetExampleRevision",kind:"LinkedField",name:"revision",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"input",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"node",plural:!1,selections:[t],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:"examples(first:20)"},{alias:null,args:i,filters:["datasetVersionId"],handle:"connection",key:"PlaygroundDatasetExamplesTable_examples",kind:"LinkedHandle",name:"examples"}],type:"Dataset",abstractKey:null}],storageKey:null}]},params:{cacheID:"795ea41682593e1fedd5ced3252f7602",id:null,metadata:{},name:"PlaygroundDatasetExamplesTableQuery",operationKind:"query",text:`query PlaygroundDatasetExamplesTableQuery(
  $datasetId: GlobalID!
) {
  dataset: node(id: $datasetId) {
    __typename
    ...PlaygroundDatasetExamplesTableFragment
    __isNode: __typename
    id
  }
}

fragment PlaygroundDatasetExamplesTableFragment on Dataset {
  examples(first: 20) {
    edges {
      example: node {
        id
        revision {
          input
          output
        }
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
  id
}
`}}}();po.hash="f809b3d539d0032d9681a4a4450b1d6f";const Sf=n=>typeof n=="object"&&n!==null&&typeof n.message=="string",vf=/['"']message['"']:\s*['"']([^'"']+)['"']/g,yo=n=>{if(!Sf(n))return null;const a=n.message;if(typeof a!="string")return null;const t=[...a.matchAll(vf)].map(l=>l[1]);return t.length>0?t:null},Cf=n=>{const a=n;return typeof a=="object"&&a!==null&&typeof a.source=="object"&&a.source!==null&&Array.isArray(a.source.errors)&&a.source.errors.every(t=>typeof t=="object"&&t!==null&&typeof t.message=="string")},Ff=n=>Array.isArray(n)&&n.every(a=>typeof a=="object"&&a!==null&&typeof a.message=="string"),fo=n=>Cf(n)?n.source.errors.map(a=>a.message):Ff(n)?n.map(a=>a.message):null,Kf=()=>{const n=(a,t)=>({exampleResponsesMap:{},updateExampleData:({instanceId:l,exampleId:i,patch:r})=>{const s=t().exampleResponsesMap,c=s[l]??{},d=c[i]??{};a({exampleResponsesMap:{...s,[l]:{...c,[i]:{...d,...r}}}})},appendExampleDataTextChunk:({instanceId:l,exampleId:i,textChunk:r})=>{const s=t().exampleResponsesMap,c=s[l]??{},d=c[i]??{},u=d.content??"";a({exampleResponsesMap:{...s,[l]:{...c,[i]:{...d,content:u+r}}}})},appendExampleDataToolCallChunk:({instanceId:l,exampleId:i,toolCallChunk:r})=>{var k;const s=t().exampleResponsesMap,c=s[l]??{},d=c[i]??{},u=d.toolCalls??{},{id:y,function:g}=r,p=u[y],f={...p,id:y,function:{name:((k=p==null?void 0:p.function)==null?void 0:k.name)??g.name,arguments:(p==null?void 0:p.function.arguments)!=null?p.function.arguments+g.arguments:g.arguments}};a({exampleResponsesMap:{...s,[l]:{...c,[i]:{...d,toolCalls:{...u,[y]:f}}}}})},setExampleDataForInstance:({instanceId:l,data:i})=>{const r=t().exampleResponsesMap;a({exampleResponsesMap:{...r,[l]:i}})},resetExampleData:()=>{a({exampleResponsesMap:{}})}});return Sl()(n)},ho=Se.createContext(null);function xf({children:n}){const[a]=m.useState(()=>Kf());return e(ho.Provider,{value:a,children:n})}function On(n,a){const t=Se.useContext(ho);if(!t)throw new Error("Missing PlaygroundDatasetExamplesTableContext.Provider in the tree");return ya(t,n,a)}function Ot({children:n}){return o(h,{direction:"row",gap:"size-50",alignItems:"center",children:[e(L,{svg:e(D.AlertCircleOutline,{}),color:"danger"}),e(x,{color:"danger",children:n})]})}const ko=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"runId"}],a=[{kind:"Variable",name:"id",variableName:"runId"}],t={alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i={kind:"InlineFragment",selections:[t,{alias:null,args:null,kind:"ScalarField",name:"startTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"endTime",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"error",storageKey:null},{alias:null,args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"example",plural:!1,selections:[l,{alias:null,args:null,concreteType:"DatasetExampleRevision",kind:"LinkedField",name:"revision",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"input",storageKey:null},t],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"ExperimentRunAnnotationConnection",kind:"LinkedField",name:"annotations",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunAnnotationEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"annotation",args:null,concreteType:"ExperimentRunAnnotation",kind:"LinkedField",name:"node",plural:!1,selections:[l,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"ExperimentRun",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"PlaygroundExperimentRunDetailsDialogQuery",selections:[{alias:"run",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[i],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"PlaygroundExperimentRunDetailsDialogQuery",selections:[{alias:"run",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i,{kind:"TypeDiscriminator",abstractKey:"__isNode"},l],storageKey:null}]},params:{cacheID:"1e3277995e47da369d84557def1a62bf",id:null,metadata:{},name:"PlaygroundExperimentRunDetailsDialogQuery",operationKind:"query",text:`query PlaygroundExperimentRunDetailsDialogQuery(
  $runId: GlobalID!
) {
  run: node(id: $runId) {
    __typename
    ... on ExperimentRun {
      output
      startTime
      endTime
      error
      example {
        id
        revision {
          input
          output
        }
      }
      annotations {
        edges {
          annotation: node {
            id
            name
            label
            score
            explanation
            annotatorKind
          }
        }
      }
    }
    __isNode: __typename
    id
  }
}
`}}}();ko.hash="2eee337b0f8c4e738dd6580efa1e3c96";function Tf({runId:n}){var c,d,u;const t=P.useLazyLoadQuery(ko,{runId:n}).run,l=(c=t.example)==null?void 0:c.id,i=(d=t.example)==null?void 0:d.revision,r=i==null?void 0:i.input,s=i==null?void 0:i.output;return e(Y,{title:`Experiment Run for Example: ${l}`,size:"fullscreen",children:o(tn,{direction:"vertical",autoSaveId:"example-compare-panel-group",children:[e(he,{defaultSize:33,children:e(F,{overflow:"auto",height:"100%",padding:"size-200",children:o(h,{direction:"row",gap:"size-200",flex:"1 1 auto",children:[e(F,{width:"50%",children:e(q,{title:"Input",...hl,bodyStyle:{padding:0,maxHeight:"300px",overflowY:"auto"},extra:e(se,{text:JSON.stringify(r)}),children:e(nn,{value:JSON.stringify(r,null,2)})})}),e(F,{width:"50%",children:e(q,{title:"Reference Output",...hl,extra:e(se,{text:JSON.stringify(s)}),bodyStyle:{padding:0,maxHeight:"300px",overflowY:"auto"},children:e(nn,{value:JSON.stringify(s,null,2)})})})]})})}),e(an,{css:fn}),e(he,{defaultSize:67,children:o(h,{direction:"column",height:"100%",children:[e(F,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderBottomColor:"dark",borderBottomWidth:"thin",flex:"none",children:e(ge,{level:2,children:"Experiment Run Output"})}),e("div",{css:C`
                overflow-y: auto;
                height: 100%;
                padding: var(--ac-global-dimension-static-size-200);
              `,children:o(h,{direction:"row",children:[e(F,{flex:!0,children:t.error?e(F,{padding:"size-200",children:e(If,{error:t.error})}):e(nn,{value:JSON.stringify(t.output,null,2)})}),o(xn,{width:"size-3000",children:[t.startTime&&t.endTime&&e(Df,{startTime:t.startTime,endTime:t.endTime}),e("ul",{css:C`
                      margin-top: var(--ac-global-dimension-static-size-100);
                      display: flex;
                      flex-direction: column;
                      justify-content: flex-start;
                      align-items: flex-end;
                      gap: var(--ac-global-dimension-static-size-100);
                    `,children:(u=t.annotations)==null?void 0:u.edges.map(y=>e("li",{children:e(yn,{annotation:y.annotation})},y.annotation.id))})]})]})})]})})]})})}function Df({startTime:n,endTime:a}){const t=m.useMemo(()=>{let l=null;return n&&a&&(l=new Date(a).getTime()-new Date(n).getTime()),l},[n,a]);return t===null?null:e(Re,{latencyMs:t})}function If({error:n}){return o(h,{direction:"row",gap:"size-50",alignItems:"center",children:[e(L,{svg:e(D.AlertCircleOutline,{}),color:"danger"}),e(x,{color:"danger",children:n})]})}const hl={backgroundColor:"light",borderColor:"light",variant:"compact",collapsible:!0,bodyStyle:{padding:0}};function bo({traceId:n,projectId:a,title:t}){const l=ne();return e(Y,{title:t,size:"fullscreen",extra:e(z,{variant:"default",onClick:()=>l(`/projects/${a}/traces/${n}`),children:"View Trace in Project"}),children:e(Nt,{traceId:n,projectId:a})})}const Pf=n=>{const a=n;return Wn(a.function)?typeof a.function.arguments=="string":!1};function So({toolCall:n}){const a=m.useMemo(()=>{const{provider:t,validatedToolCall:l}=bc(n);switch(t){case"OPENAI":case"AZURE_OPENAI":return{name:l.function.name,input:l.function.arguments};case"ANTHROPIC":return{name:l.name,input:l.input};case"UNKNOWN":{if(!Pf(n))return null;const{json:i}=Me(n.function.arguments);return{name:n.function.name??"",input:Wn(i)?i:n.function.arguments}}default:return ue()}},[n]);return a==null?o(x,{children:["Invalid tool call format: ",JSON.stringify(n)]}):o("pre",{css:C`
        text-wrap: wrap;
        margin: var(--ac-global-dimension-static-size-100) 0;
      `,children:[a.name,"(",typeof a.input=="string"?a.input:JSON.stringify(a.input,null,2),")"]})}const Lf=10,Ef=n=>n.examples.reduce((a,t)=>{const{datasetExampleId:l,result:i,experimentRunId:r}=t,s={experimentRunId:r};switch(i.__typename){case"ChatCompletionMutationError":return{...a,[l]:{...s,errorMessage:i.message}};case"ChatCompletionMutationPayload":{const{errorMessage:c,content:d,span:u,toolCalls:y}=i;return{...a,[l]:{...s,span:u,content:d,errorMessage:c,toolCalls:y.reduce((g,p)=>(g[p.id]=p,g),{})}}}case"%other":return a;default:ue()}},{}),wf=C`
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: center;
  height: 100%;
  min-height: 75px;
  padding: var(--ac-global-dimension-static-size-200);
  .controls {
    transition: opacity 0.2s ease-in-out;
    opacity: 0;
    display: none;
    z-index: 1;
  }
  &:hover .controls {
    opacity: 1;
    display: flex;
    // make them stand out
    .ac-button {
      border-color: var(--ac-global-color-primary);
    }
  }
`,_f=C`
  position: absolute;
  top: -4px;
  right: var(--ac-global-dimension-static-size-100);
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-static-size-100);
`;function vo(n){return o("div",{css:wf,children:[n.children,e("div",{css:_f,className:"controls",children:n.controls})]})}function Co({children:n}){return e("div",{css:C`
        max-height: 300px;
        overflow-y: auto;
        padding: var(--ac-global-dimension-static-size-100)
          var(--ac-global-dimension-static-size-200);
      `,children:n})}function Rf({getValue:n,collapseSingleKey:a}){const t=n();return e(Co,{children:e(Ca,{json:t,space:2,collapseSingleKey:a})})}function Af({isRunning:n,instanceVariables:a,datasetExampleInput:t}){const l=m.useMemo(()=>{const i=Wn(t)?t:{};return a.filter(r=>i[r]==null)},[t,a]);return n?e(ye,{}):l.length===0?null:e(Ot,{children:`Missing input for variable${l.length>1?"s":""}: ${l.join(", ")}`})}function Mf({exampleData:n,setDialog:a}){const{span:t,content:l,toolCalls:i,errorMessage:r,experimentRunId:s}=n,c=t!=null,d=s!=null,u=m.useMemo(()=>{if(c||d)return o(G,{children:[d&&o(pe,{children:[e(z,{variant:"default",size:"compact","aria-label":"View experiment run details",icon:e(L,{svg:e(D.ExpandOutline,{})}),onClick:y=>{y.preventDefault(),y.stopPropagation(),m.startTransition(()=>{a(e(Tf,{runId:s}))})}}),e(Fe,{children:"View run details"})]}),c&&e(G,{children:o(pe,{children:[e(z,{variant:"default",size:"compact","aria-label":"View run trace",icon:e(L,{svg:e(D.Trace,{})}),onClick:y=>{y.preventDefault(),y.stopPropagation(),m.startTransition(()=>{a(e(bo,{traceId:t.context.traceId,projectId:t.project.id,title:"Experiment Run Trace"}))})}}),e(Fe,{children:"View Trace"})]})})]})},[s,d,c,a,t]);return e(vo,{controls:u,children:o(h,{direction:"column",gap:"size-200",children:[r!=null?e(Ot,{children:r}):null,e(x,{children:l}),i!=null?Object.values(i).map(y=>y==null?null:e(So,{toolCall:y},y.id)):null,c?e(zf,{span:t}):null]})})}const Nf=m.memo(function({isRunning:a,instanceId:t,exampleId:l,setDialog:i,instanceVariables:r,datasetExampleInput:s}){const c=On(d=>{var u;return(u=d.exampleResponsesMap[t])==null?void 0:u[l]});return c==null?e(Af,{isRunning:a,instanceVariables:r,datasetExampleInput:s}):e(Mf,{exampleData:c,setDialog:i})});function zf({span:n}){return o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(va,{tokenCountTotal:n.tokenCountTotal||0,tokenCountPrompt:n.tokenCountPrompt||0,tokenCountCompletion:n.tokenCountCompletion||0}),e(Re,{latencyMs:n.latencyMs||0})]})}function Fo({table:n}){return e("tbody",{children:n.getRowModel().rows.map(a=>e("tr",{children:a.getVisibleCells().map(t=>e("td",{style:{padding:0,height:1,width:`calc(var(--col-${t.column.id}-size) * 1px)`,wordBreak:"break-all"},children:Z(t.column.columnDef.cell,t.getContext())},t.id))},a.id))})}const Vf=Se.memo(Fo,(n,a)=>n.table.options.data===a.table.options.data);function $f({datasetId:n}){const a=P.useRelayEnvironment(),t=O($=>$.instances),l=O($=>$.templateLanguage),i=O($=>$.updateInstance),r=On($=>$.updateExampleData),s=On($=>$.setExampleDataForInstance),c=On($=>$.resetExampleData),d=On($=>$.appendExampleDataToolCallChunk),u=On($=>$.appendExampleDataTextChunk),[y,g]=m.useState(null),p=ne(),f=t.some($=>$.activeRunId!==null),k=Va($=>$),b=O($=>$.markPlaygroundInstanceComplete),S=so(),v=be(),I=m.useCallback($=>re=>{var fe;if(re==null)return;const J=re.chatCompletionOverDataset;switch(J.__typename){case"ChatCompletionSubscriptionExperiment":i({instanceId:$,patch:{experimentId:J.experiment.id}});break;case"ChatCompletionSubscriptionResult":if(J.datasetExampleId==null)return;r({instanceId:$,exampleId:J.datasetExampleId,patch:{span:J.span,experimentRunId:(fe=J.experimentRun)==null?void 0:fe.id}});break;case"ChatCompletionSubscriptionError":if(J.datasetExampleId==null)return;r({instanceId:$,exampleId:J.datasetExampleId,patch:{errorMessage:J.message}});break;case"TextChunk":if(J.datasetExampleId==null)return;u({instanceId:$,exampleId:J.datasetExampleId,textChunk:J.content});break;case"ToolCallChunk":{if(J.datasetExampleId==null)return;d({instanceId:$,exampleId:J.datasetExampleId,toolCallChunk:J});break}case"%other":return;default:return ue()}},[u,d,r,i]),[w]=P.useMutation(co),R=m.useCallback($=>(re,J)=>{if(b($),J){v({title:"Chat completion failed",message:J[0].message});return}i({instanceId:$,patch:{experimentId:re.chatCompletionOverDataset.experimentId}}),s({instanceId:$,data:Ef(re.chatCompletionOverDataset)})},[b,v,s,i]);m.useEffect(()=>{if(!f)return;const{instances:$,streaming:re,updateInstance:J}=S.getState();if(c(),re){const fe=[];for(const Ce of $){const{activeRunId:Za}=Ce;if(J({instanceId:Ce.id,patch:{experimentId:null}}),Za===null)continue;const Ya={input:Yt({credentials:k,instanceId:Ce.id,playgroundStore:S,datasetId:n})},Xa={subscription:uo,variables:Ya,onNext:I(Ce.id),onCompleted:()=>{b(Ce.id)},onError:Nn=>{b(Ce.id);const et=fo(Nn);et!=null&&et.length>0?v({title:"Failed to get output",message:et.join(`
`),expireMs:1e4}):v({title:"Failed to get output",message:Nn.message,expireMs:1e4})}},Da=ht.requestSubscription(a,Xa);fe.push(Da)}return()=>{for(const Ce of fe)Ce.dispose()}}else{const fe=[];for(const Ce of $){const{activeRunId:Za}=Ce;if(Za===null)continue;J({instanceId:Ce.id,patch:{experimentId:null}});const Ya={input:Yt({credentials:k,instanceId:Ce.id,playgroundStore:S,datasetId:n})},Xa=w({variables:Ya,onCompleted:R(Ce.id),onError(Da){b(Ce.id);const Nn=yo(Da);Nn!=null&&Nn.length>0?v({title:"Failed to get output",message:Nn.join(`
`),expireMs:1e4}):v({title:"Failed to get output",message:Da.message,expireMs:1e4})}});fe.push(Xa)}return()=>{for(const Ce of fe)Ce.dispose()}}},[k,n,a,w,f,b,v,R,I,S,c]);const{dataset:K}=P.useLazyLoadQuery(po,{datasetId:n}),T=m.useRef(null),{data:E,loadNext:_,hasNext:j,isLoadingNext:V}=P.usePaginationFragment(go,K),H=m.useMemo(()=>E.examples.edges.map($=>{const re=$.example,J=re.revision;return{id:re.id,input:J.input,output:J.output}}),[E]),te=m.useMemo(()=>t.map(($,re)=>{const J=yi({instance:$,templateLanguage:l});return{id:`instance-${$.id}`,header:()=>o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(Pt,{index:re}),e("span",{children:"Output"})]}),cell:({row:fe})=>e(Nf,{instanceId:$.id,exampleId:fe.original.id,isRunning:f,setDialog:g,instanceVariables:J,datasetExampleInput:fe.original.input}),size:500}}),[f,t,l]),oe=[{header:"input",accessorKey:"input",cell:({row:$})=>e(vo,{controls:o(pe,{children:[e(z,{variant:"default",size:"compact","aria-label":"View example details",icon:e(L,{svg:e(D.ExpandOutline,{})}),onClick:()=>{p(`/playground/datasets/${n}/examples/${$.original.id}`)}}),e(Fe,{children:"View Example"})]}),children:e(Co,{children:e(Ca,{json:$.original.input,disableTitle:!0,space:2,collapseSingleKey:!1})})}),size:200},{header:"reference output",accessorKey:"output",cell:$=>Rf({...$,collapseSingleKey:!0}),size:200},...te],N=Te({columns:oe,data:H,getCoreRowModel:De(),columnResizeMode:"onChange"}),M=N.getRowModel().rows.length===0,U=m.useCallback($=>{if($){const{scrollHeight:re,scrollTop:J,clientHeight:fe}=$;re-J-fe<300&&!V&&j&&_(Lf)}},[j,V,_]),ie=Se.useMemo(()=>{const $=N.getFlatHeaders(),re={};for(let J=0;J<$.length;J++){const fe=$[J];re[`--header-${fe.id}-size`]=fe.getSize(),re[`--col-${fe.column.id}-size`]=fe.column.getSize()}return re},[N.getState().columnSizingInfo,N.getState().columnSizing,oe.length]);return o("div",{css:C`
        flex: 1 1 auto;
        overflow: auto;
        height: 100%;
      `,ref:T,onScroll:$=>U($.target),children:[o("table",{css:$=>C(Je($),Yl),style:{...ie,width:N.getTotalSize(),minWidth:"100%"},children:[e("thead",{children:N.getHeaderGroups().map($=>e("tr",{children:$.headers.map(re=>o("th",{style:{width:`calc(var(--header-${re==null?void 0:re.id}-size) * 1px)`},children:[e("div",{children:Z(re.column.columnDef.header,re.getContext())}),e("div",{onMouseDown:re.getResizeHandler(),onTouchStart:re.getResizeHandler(),className:`resizer ${re.column.getIsResizing()?"isResizing":""}`})]},re.id))},$.id))}),M?e(Ze,{}):N.getState().columnSizingInfo.isResizingColumn?e(Vf,{table:N}):e(Fo,{table:N})]}),e(ae,{isDismissable:!0,type:"slideOver",onDismiss:()=>{g(null)},children:y})]})}function Of(){return o("span",{css:C`
        color: var(--ac-global-text-color-700);
        display: inline-flex;
        .dots {
          display: inline-block;
          width: 3ch;
          overflow: hidden;
        }

        .dots::after {
          content: "...";
          display: inline-block;
          animation: dots 1.5s steps(4) infinite;
        }

        @keyframes dots {
          0% {
            content: "";
          }
          25% {
            content: ".";
          }
          50% {
            content: "..";
          }
          75% {
            content: "...";
          }
        }
      `,children:["Run in progress",e("span",{className:"dots"})]})}function Qf({datasetId:n}){const a=O(s=>s.instances),t=a.some(s=>s.activeRunId!=null),l=m.useMemo(()=>a.map(s=>s.experimentId).filter(s=>s!=null),[a]),i=ne(),r=P.useLazyLoadQuery(oo,{datasetId:n});return o(h,{direction:"column",height:"100%",children:[e(F,{backgroundColor:"dark",paddingX:"size-200",paddingY:"size-100",borderBottomColor:"light",borderBottomWidth:"thin",children:o(h,{justifyContent:"space-between",alignItems:"center",children:[o(h,{gap:"size-100",children:[o(x,{children:[r.dataset.name??"Dataset"," results"]}),r.dataset.exampleCount!=null?o(x,{fontStyle:"italic",color:"text-700",children:[r.dataset.exampleCount," examples"]}):null]}),o(h,{gap:"size-100",alignItems:"center",children:[t&&e(Of,{}),l.length>0&&e(z,{size:"compact",variant:"default",disabled:t,loading:t,icon:e(L,{svg:e(D.ExperimentOutline,{})}),onClick:()=>{i(`/datasets/${n}/compare?experimentId=${l.join("&experimentId=")}`)},children:o(h,{gap:"size-100",alignItems:"center",children:["View Experiment",a.length>1?"s":""]})})]})]})}),e(xf,{children:e($f,{datasetId:n})})]})}const jf=()=>{const n=O(r=>r.input),a=O(r=>r.instances),t=O(r=>r.templateLanguage),{variableKeys:l,variablesMap:i}=m.useMemo(()=>fi({instances:a,templateLanguage:t,input:n}),[n,a,t]);return{variableKeys:l,variablesMap:i}},qf={lineNumbers:!1,highlightActiveLine:!1,foldGutter:!1,highlightActiveLineGutter:!1,bracketMatching:!1,syntaxHighlighting:!1},Uf=[oi.lineWrapping],Bf=({label:n,value:a,onChange:t})=>{const{theme:l}=Zn();return e(Mn,{label:n,children:e(Ye,{width:"100%",children:e(Ka,{theme:l==="light"?Oc:xa,basicSetup:qf,value:a,extensions:Uf,onChange:t})})})};function Hf(){const{variableKeys:n,variablesMap:a}=jf(),t=O(i=>i.setVariableValue),l=O(i=>i.templateLanguage);if(n.length===0){let i="";switch(l){case"F_STRING":{i="{input name}";break}case"MUSTACHE":{i="{{input name}}";break}case"NONE":return null;default:ue()}return e(F,{padding:"size-100",children:e(h,{direction:"column",justifyContent:"center",alignItems:"center",children:o(x,{color:"text-700",children:["Add variable inputs to your prompt using"," ",e(x,{color:"text-900",children:i})," within your prompt template."]})})})}return e(h,{direction:"column",gap:"size-200",width:"100%",children:n.map((i,r)=>e(Bf,{label:i,value:a[i],onChange:s=>t(i,s)},r))})}const Ko=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},t=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"ChatCompletionMutationPayload",kind:"LinkedField",name:"chatCompletion",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"content",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"errorMessage",storageKey:null},{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"span",plural:!1,selections:[a],storageKey:null},{alias:null,args:null,concreteType:"ChatCompletionToolCall",kind:"LinkedField",name:"toolCalls",plural:!0,selections:[a,{alias:null,args:null,concreteType:"ChatCompletionFunctionCall",kind:"LinkedField",name:"function",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"arguments",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"PlaygroundOutputMutation",selections:t,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"PlaygroundOutputMutation",selections:t},params:{cacheID:"9dc63d3e40081b276c1cbd5f21405c6f",id:null,metadata:{},name:"PlaygroundOutputMutation",operationKind:"mutation",text:`mutation PlaygroundOutputMutation(
  $input: ChatCompletionInput!
) {
  chatCompletion(input: $input) {
    __typename
    content
    errorMessage
    span {
      id
    }
    toolCalls {
      id
      function {
        name
        arguments
      }
    }
  }
}
`}}}();Ko.hash="085e7cb2bebd2c6c6e44b511364c6dd9";const xo=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},t=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:null,kind:"LinkedField",name:"chatCompletion",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"content",storageKey:null}],type:"TextChunk",abstractKey:null},{kind:"InlineFragment",selections:[a,{alias:null,args:null,concreteType:"FunctionCallChunk",kind:"LinkedField",name:"function",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"arguments",storageKey:null}],storageKey:null}],type:"ToolCallChunk",abstractKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"span",plural:!1,selections:[a],storageKey:null}],type:"ChatCompletionSubscriptionResult",abstractKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"message",storageKey:null}],type:"ChatCompletionSubscriptionError",abstractKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"PlaygroundOutputSubscription",selections:t,type:"Subscription",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"PlaygroundOutputSubscription",selections:t},params:{cacheID:"aca7bf342ad2dc5db66b07e236a68268",id:null,metadata:{},name:"PlaygroundOutputSubscription",operationKind:"subscription",text:`subscription PlaygroundOutputSubscription(
  $input: ChatCompletionInput!
) {
  chatCompletion(input: $input) {
    __typename
    ... on TextChunk {
      content
    }
    ... on ToolCallChunk {
      id
      function {
        name
        arguments
      }
    }
    ... on ChatCompletionSubscriptionResult {
      span {
        id
      }
    }
    ... on ChatCompletionSubscriptionError {
      message
    }
  }
}
`}}}();xo.hash="bb5936a61a0e99dbb4a298a6e552a01c";const Gf=({instance:n,outputContent:a,toolCalls:t,cleanupOutput:l})=>{const i=n.id,r=O(s=>s.updateInstance);return o(pe,{delay:500,offset:10,children:[e(z,{variant:"default",size:"compact",icon:e(L,{svg:e(D.PlusCircleOutline,{})}),"aria-label":"Move the output message to the end of the prompt",onClick:s=>{if(s.stopPropagation(),n.template.__type!=="chat")return;const c=Array.isArray(a)?a:a?[{id:ma(),role:za("ai"),content:a}]:[];t.length>0&&c.push({id:ma(),role:za("ai"),toolCalls:li({provider:n.model.provider,toolCalls:t.map(d=>{var u;return{...d,function:{...d.function,arguments:((u=Me(d.function.arguments))==null?void 0:u.json)??d.function.arguments}}})})}),r({instanceId:i,patch:{template:{__type:"chat",messages:[...n.template.messages,...c]}}}),l()},children:"Prompt"}),e(Fe,{children:"Move the output message to the end of the prompt"})]})},To=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"spanId"}],a=[{kind:"Variable",name:"id",variableName:"spanId"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[t],storageKey:null},{alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"spanId",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null}],type:"Span",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"RunMetadataFooterQuery",selections:[{alias:"span",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,l],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"RunMetadataFooterQuery",selections:[{alias:"span",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t,l],storageKey:null}]},params:{cacheID:"bee4b51bd781a58c87fd283a966776f6",id:null,metadata:{},name:"RunMetadataFooterQuery",operationKind:"query",text:`query RunMetadataFooterQuery(
  $spanId: GlobalID!
) {
  span: node(id: $spanId) {
    __typename
    id
    ... on Span {
      project {
        id
      }
      context {
        traceId
        spanId
      }
      tokenCountCompletion
      tokenCountPrompt
      tokenCountTotal
      latencyMs
    }
  }
}
`}}}();To.hash="c89cb87e785645bbf42e3eadbacc4fc0";function Wf({spanId:n}){const[a,t]=m.useState(null),l=P.useLazyLoadQuery(To,{spanId:n});if(!l.span||!l.span.project||!l.span.context)return null;const{project:i,context:{traceId:r}}=l.span;return o(F,{borderTopColor:"light",borderTopWidth:"thin",paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",children:[o(h,{direction:"row",gap:"size-200",justifyContent:"space-between",children:[o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(va,{tokenCountTotal:l.span.tokenCountTotal||0,tokenCountPrompt:l.span.tokenCountPrompt||0,tokenCountCompletion:l.span.tokenCountCompletion||0}),e(Re,{latencyMs:l.span.latencyMs||0})]}),o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(z,{size:"compact",variant:"default",icon:e(L,{svg:e(D.EditOutline,{})}),onClick:()=>t(e(Vl,{spanNodeId:n,projectId:i.id})),children:"Annotate"}),e(z,{size:"compact",variant:"default",icon:e(L,{svg:e(D.Trace,{})}),onClick:()=>{m.startTransition(()=>{t(e(m.Suspense,{children:e(bo,{traceId:r,projectId:i.id,title:"Playground Trace"})}))})},children:"View Trace"})]})]}),e(ae,{type:"slideOver",isDismissable:!0,onDismiss:()=>t(null),children:a})]})}function Jf({index:n,title:a}){return o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(Pt,{index:n}),e("span",{children:a})]})}const Zf=n=>Wn(n)&&(typeof n.id=="string"||typeof n.id=="number")?n.id:JSON.stringify(n);function kl({message:n}){const{role:a,content:t,toolCalls:l}=n,i=Mt(a),{mode:r}=Sc();return o(q,{title:a,...i,variant:"compact",extra:e(He,{}),children:[t!=null&&!Array.isArray(t)&&e(h,{direction:"column",alignItems:"start",children:r==="text"?t:e(F,{overflow:"auto",maxWidth:"100%",children:e(na,{children:t})})}),l&&l.length>0?l.map(s=>e(So,{toolCall:s},Zf(s))):null]})}function Yf({content:n,partialToolCalls:a}){return _u(n)?n.map((t,l)=>e(kl,{message:t},l)):typeof n=="string"||a.length>0?e(kl,{message:{id:ma(),content:n,role:"ai",toolCalls:a}}):"click run to see output"}function Xf(n){const a=n.playgroundInstanceId,t=O(V=>V.instances),l=O(V=>V.streaming),i=Va(V=>V),r=O(V=>V.instances.findIndex(H=>H.id===a)),s=t.find(V=>V.id===a),c=O(V=>V.updateInstance),[d,u]=m.useState(null),y=O(V=>V.markPlaygroundInstanceComplete),g=P.useRelayEnvironment(),p=so();if(!s)throw new Error(`No instance found for id ${a}`);if(s.template.__type!=="chat")throw new Error("We only support chat templates for now");const[f,k]=m.useState(!1),[b]=P.useMutation(Ko),S=(s==null?void 0:s.activeRunId)!=null,v=be(),I=m.useCallback(({title:V,message:H,...te})=>{u({title:V,message:H}),v({title:V,message:H,...te})},[v]),[w,R]=m.useState(s.output),[K,T]=m.useState([]),E=m.useCallback(({chatCompletion:V})=>{if(k(!1),V.__typename==="TextChunk"){const H=V.content;R(te=>te!=null?te+H:H);return}else if(V.__typename==="ToolCallChunk"){T(H=>{let te=!1;const oe=H.map(N=>N.id===V.id?(te=!0,{...N,function:{...N.function,arguments:N.function.arguments+V.function.arguments}}):N);return te||oe.push({id:V.id,function:{name:V.function.name,arguments:V.function.arguments}}),oe});return}if(V.__typename==="ChatCompletionSubscriptionResult"&&V.span!=null){c({instanceId:a,patch:{spanId:V.span.id}});return}V.__typename==="ChatCompletionSubscriptionError"&&(y(n.playgroundInstanceId),V.message!=null&&I({title:"Chat completion failed",message:V.message}))},[a,y,I,n.playgroundInstanceId,c]),_=m.useCallback((V,H)=>{if(k(!1),y(n.playgroundInstanceId),c({instanceId:a,patch:{spanId:V.chatCompletion.span.id}}),H){I({title:"Chat completion failed",message:H[0].message});return}if(V.chatCompletion.errorMessage!=null){I({title:"Chat completion failed",message:V.chatCompletion.errorMessage});return}R(V.chatCompletion.content??void 0),T(V.chatCompletion.toolCalls)},[a,y,I,n.playgroundInstanceId,c]),j=m.useCallback(()=>{R(void 0),T([]),u(null),c({instanceId:a,patch:{spanId:null}})},[a,c]);return m.useEffect(()=>{if(!S){k(!1);return}k(!0),j();const V=$u({playgroundStore:p,instanceId:a,credentials:i});if(l){const te={subscription:xo,variables:{input:V},onNext:N=>{N&&E(N)},onCompleted:()=>{k(!1),y(n.playgroundInstanceId)},onError:N=>{k(!1),y(n.playgroundInstanceId);const Q=fo(N);Q!=null&&Q.length>0?I({title:"Failed to get output",message:Q.join(`
`)}):I({title:"Failed to get output",message:N.message})}};return ht.requestSubscription(g,te).dispose}return b({variables:{input:V},onCompleted:_,onError(te){k(!1),y(n.playgroundInstanceId);const oe=yo(te);oe!=null&&oe.length>0?I({title:"Failed to get output",message:oe.join(`
`)}):I({title:"Failed to get output",message:te.message})}}).dispose},[j,i,g,b,S,a,y,I,_,E,p,n.playgroundInstanceId,l,c]),e(q,{title:e(Jf,{index:r,title:"Output"}),extra:w!=null||(K==null?void 0:K.length)>0?e(Gf,{outputContent:w,toolCalls:K,instance:s,cleanupOutput:j}):null,titleSeparator:!0,collapsible:!0,variant:"compact",bodyStyle:{padding:0},children:f?e(F,{padding:"size-200",children:e(ye,{message:"Running..."})}):d?e(F,{padding:"size-200",children:e(Ot,{children:d.message})}):o(G,{children:[e(F,{padding:"size-200",children:e(Qe,{children:e(Yf,{content:w,partialToolCalls:K})})}),e(m.Suspense,{children:s.spanId?e(Wf,{spanId:s.spanId}):null})]})})}function eh(){const n=O(l=>l.runPlaygroundInstances),a=O(l=>l.cancelPlaygroundInstances),t=O(l=>l.instances.some(i=>i.activeRunId!=null));return e(z,{variant:"primary",icon:t?e("div",{css:C`
              margin-right: var(--ac-global-dimension-static-size-50);
              & > * {
                height: 1em;
                width: 1em;
                font-size: 1.3rem;
              }
            `,children:e(ye,{size:"S"})}):e(L,{svg:e(D.PlayCircleOutline,{})}),size:"compact",onClick:()=>{t?a():n()},children:t?"Cancel":"Run"})}function nh(){const n=O(i=>i.streaming),a=O(i=>i.setStreaming),t=Ae(i=>i.setPlaygroundStreamingEnabled),l=O(i=>i.instances.some(r=>r.activeRunId!=null));return window.Config.websocketsEnabled===!1?null:e(Gn,{labelPlacement:"start",isSelected:n,onChange:()=>{a(!n),t(!n)},isDisabled:l,children:"Stream"})}const Do=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"providerKey"}],a=[{kind:"Variable",name:"providerKey",variableName:"providerKey"}],t={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ModelConfigButtonDialogQuery",selections:[{args:null,kind:"FragmentSpread",name:"ModelProviderPickerFragment"},{args:a,kind:"FragmentSpread",name:"ModelPickerFragment"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ModelConfigButtonDialogQuery",selections:[{alias:null,args:null,concreteType:"GenerativeProvider",kind:"LinkedField",name:"modelProviders",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"key",storageKey:null},t,{alias:null,args:null,kind:"ScalarField",name:"dependenciesInstalled",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dependencies",storageKey:null}],storageKey:null},{alias:null,args:[{fields:a,kind:"ObjectValue",name:"input"}],concreteType:"GenerativeModel",kind:"LinkedField",name:"models",plural:!0,selections:[t],storageKey:null}]},params:{cacheID:"312c7daf378370f2936ee987869d155d",id:null,metadata:{},name:"ModelConfigButtonDialogQuery",operationKind:"query",text:`query ModelConfigButtonDialogQuery(
  $providerKey: GenerativeProviderKey!
) {
  ...ModelProviderPickerFragment
  ...ModelPickerFragment_3rERSq
}

fragment ModelPickerFragment_3rERSq on Query {
  models(input: {providerKey: $providerKey}) {
    name
  }
}

fragment ModelProviderPickerFragment on Query {
  modelProviders {
    key
    name
    dependenciesInstalled
    dependencies
  }
}
`}}}();Do.hash="c9b38e766093b2378047d22b01ef0fbf";function ah({defaultValue:n,onChange:a,label:t,errorMessage:l}){const[i,r]=m.useState(n==null?"":Pl(n).json??""),s=m.useCallback(c=>{r(c);const{json:d}=Me(c);d==null&&c!==""||a(d)},[a]);return e("div",{css:C`
        & .ac-view {
          width: 100%;
        }
      `,children:e(Mn,{label:t,errorMessage:l,validationState:l?"invalid":void 0,children:e(Ye,{children:e(Ee,{value:i,onChange:s,optionalLint:!0})})})})}const th=({field:n,value:a,onChange:t,errors:l,control:i})=>{var g;const r=n.invocationName;if(!r)throw new Error("Invocation name is required");const s=(g=l[r])==null?void 0:g.message,c=n.required?`${n.label||r} is required`:void 0,d=n.minValue!=null?`${n.label||r} must be at least ${n.minValue}`:void 0,u=n.maxValue!=null?`${n.label||r} must be at most ${n.maxValue}`:void 0,{__typename:y}=n;switch(y){case"InvocationParameterBase":return null;case"BoundedFloatInvocationParameter":return typeof a!="number"&&a!==void 0?null:e(cd,{label:n.label,isRequired:n.required,defaultValue:a,step:.1,minValue:n.minValue,maxValue:n.maxValue,onChange:p=>t(p)});case"FloatInvocationParameter":case"IntInvocationParameter":return e(W,{control:i,name:r,rules:{required:c,min:d,max:u},render:({field:{onBlur:p}})=>e(ee,{label:n.label,isRequired:n.required,value:(a==null?void 0:a.toString())||"",type:"number",onBlur:p,onChange:f=>{if(f===""){t(void 0);return}t(Number(f))},errorMessage:s,validationState:s?"invalid":"valid"})});case"StringListInvocationParameter":return!Array.isArray(a)&&a!==void 0?null:e(W,{control:i,name:r,rules:{required:c},render:({field:{onBlur:p}})=>e(ee,{label:n.label,isRequired:n.required,defaultValue:(a==null?void 0:a.join(", "))??"",onBlur:p,onChange:f=>{if(f===""){t(void 0);return}t(f.split(/, */g))},description:"A comma separated list of strings",errorMessage:s})});case"StringInvocationParameter":return e(W,{control:i,name:r,rules:{required:c},render:({field:{onBlur:p}})=>e(ee,{label:n.label,isRequired:n.required,defaultValue:(a==null?void 0:a.toString())||"",type:"text",onBlur:p,onChange:f=>{if(f===""){t(void 0);return}t(f)},errorMessage:s})});case"BooleanInvocationParameter":return e(Gn,{onChange:t,defaultSelected:!!a,children:n.label});case"JSONInvocationParameter":return e(W,{control:i,name:r,rules:{required:c},render:()=>e(ah,{defaultValue:a,onChange:t,label:n.label??n.invocationName??"",errorMessage:s})});default:return null}},lh=(n,a)=>{if(n.invocationInputField===void 0)throw new Error("Invocation input field is required");return a[Wa(n.invocationInputField)]},ih=(n,a)=>{if(n.invocationName===void 0)throw new Error("Invocation name is required");if(n.invocationInputField===void 0)throw new Error("Invocation input field is required");return{invocationName:n.invocationName,canonicalName:n.canonicalName,[Wa(n.invocationInputField)]:a}},rh=({instanceId:n})=>{const a=O(f=>f.instances.find(k=>k.id===n));if(!a)throw new Error("Instance not found");const{model:t}=a,l=O(f=>f.upsertInvocationParameterInput),i=O(f=>f.deleteInvocationParameterInput),r=a.model.supportedInvocationParameters,s=a.model.invocationParameters,c=m.useCallback((f,k)=>{if(!f.invocationName)throw new Error("Invocation name is required");k===void 0?i({instanceId:n,invocationParameterInputInvocationName:f.invocationName}):l({instanceId:n,invocationParameterInput:ih(f,k)})},[n,l,i]),d=m.useMemo(()=>r.filter(f=>!(f.canonicalName!=null&&Xc.includes(f.canonicalName))).reduce((f,k)=>{const b=s.find(v=>En(v,k)),S=b?lh(k,b):void 0;return{...f,[k.invocationName]:S??null}},{}),[s,r]),u=je({values:d,mode:"onBlur",delayError:0,shouldFocusError:!1,resetOptions:{keepErrors:!0}}),y=u.trigger,g=m.useMemo(()=>Bo.debounce(y,250),[y]);return m.useEffect(()=>{g()},[d,g]),t.provider!=="AZURE_OPENAI"&&t.modelName===null?null:Object.entries(d).map(([f,k])=>{const b=r.find(v=>v.invocationName===f);if(!b)return null;const S=`${t.provider??"model"}-${b.invocationName}`;return e(th,{field:b,value:k,onChange:v=>c(b,v),control:u.control,errors:u.formState.errors},S)})},Io={argumentDefinitions:[{defaultValue:"OPENAI",kind:"LocalArgument",name:"providerKey"}],kind:"Fragment",metadata:null,name:"ModelPickerFragment",selections:[{alias:null,args:[{fields:[{kind:"Variable",name:"providerKey",variableName:"providerKey"}],kind:"ObjectValue",name:"input"}],concreteType:"GenerativeModel",kind:"LinkedField",name:"models",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],storageKey:null}],type:"Query",abstractKey:null};Io.hash="1e660ad77ce19db1c1bbe8698a661b4f";function sh({query:n,onChange:a,...t}){const l=P.useFragment(Io,n);return e(ha,{label:"Model","data-testid":"model-picker",selectedKey:t.modelName??"","aria-label":"model picker",placeholder:"Select a model",onSelectionChange:i=>{typeof i=="string"&&a(i)},width:"100%",...t,children:l.models.map(({name:i})=>e(le,{children:i},i))})}const Po={argumentDefinitions:[],kind:"Fragment",metadata:null,name:"ModelProviderPickerFragment",selections:[{alias:null,args:null,concreteType:"GenerativeProvider",kind:"LinkedField",name:"modelProviders",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"key",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dependenciesInstalled",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dependencies",storageKey:null}],storageKey:null}],type:"Query",abstractKey:null};Po.hash="1d4ba7f81a958c9a17bd45dce0456ddb";function oh(n){return n==="OPENAI"||n==="AZURE_OPENAI"||n==="ANTHROPIC"||n==="GEMINI"}function dh({onChange:n,query:a,...t}){var c,d;const l=P.useFragment(Po,a),i=l.modelProviders.filter(u=>u.dependenciesInstalled),r=i.length!==l.modelProviders.length,s=t.provider&&!i.some(u=>u.key===t.provider);return o(h,{direction:"row",gap:"size-100",children:[e(ha,{label:"Provider","data-testid":"model-provider-picker",selectedKey:t.provider??void 0,"aria-label":"Model Provider",placeholder:"Select a provider",onSelectionChange:u=>{const y=u;oh(y)&&n(y)},width:"100%",...t,children:l.modelProviders.map(u=>e(le,{children:u.name},u.key))}),s?o(pe,{delay:0,offset:5,children:[e("span",{children:e(Oe,{children:e(L,{color:"red-700",svg:e(D.InfoOutline,{})})})}),o(Fe,{children:["The selected provider is not installed. Install"," ",((d=(c=l.modelProviders.find(u=>u.key===t.provider))==null?void 0:c.dependencies)==null?void 0:d.join(", "))??"the dependencies"," ","to use its models in Playground."]})]}):r?o(pe,{delay:0,offset:5,children:[e("span",{children:e(Oe,{children:e(L,{svg:e(D.InfoOutline,{})})})}),o(Fe,{children:["Some providers are missing dependencies. Install them to use their models in Playground.",e("br",{}),e("br",{}),"Missing providers:",e("br",{}),l.modelProviders.filter(u=>!u.dependenciesInstalled).map(u=>{var y;return o(G,{children:[((y=u.dependencies)==null?void 0:y.join(", "))??u.name,e("br",{})]})})]})]}):null]})}const ch=150,uh=C`
  display: flex;
  flex-direction: column;
  gap: var(--ac-global-dimension-size-200);
  .ac-field,
  .ac-dropdown,
  .ac-dropdown-button,
  .ac-slider {
    width: 100%;
  }
  // Makes the filled slider track blue
  .ac-slider-controls > .ac-slider-track:first-child::before {
    background: var(--ac-global-color-primary);
  }
  padding: var(--ac-global-dimension-size-200);
  overflow: auto;
`;function mh({instance:n}){const a=O(i=>i.updateModel),t=m.useCallback(({configKey:i,value:r})=>{a({instanceId:n.id,patch:{...n.model,[i]:r}})},[n.id,n.model,a]),l=m.useMemo(()=>Ho(i=>{t({configKey:"modelName",value:i})},250),[t]);return o(G,{children:[e(ee,{label:"Deployment Name",defaultValue:n.model.modelName??"",onChange:i=>{l(i)}}),e(ee,{label:"Endpoint",defaultValue:n.model.endpoint??"",onChange:i=>{t({configKey:"endpoint",value:i})}}),e(ha,{label:"API Version",defaultSelectedKey:n.model.apiVersion??void 0,"aria-label":"api version picker",placeholder:"Select an AzureOpenAI API Version",onSelectionChange:i=>{typeof i=="string"&&t({configKey:"apiVersion",value:i})},children:vc.map(i=>e(le,{children:i},i))})]})}function gh(n){const[a,t]=m.useState(null),l=O(c=>c.instances.find(d=>d.id===n.playgroundInstanceId));if(!l)throw new Error(`Playground instance ${n.playgroundInstanceId} not found`);const i=l.model.supportedInvocationParameters,r=l.model.invocationParameters,s=bi(r,i);return o(m.Fragment,{children:[e(z,{variant:"default",size:"compact",onClick:()=>{m.startTransition(()=>{t(e(ph,{...n}))})},title:`${Na[l.model.provider]} ${l.model.modelName||"--"}`,children:o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(x,{weight:"heavy",children:Na[l.model.provider]}),e("div",{css:C`
              max-width: ${ch}px;
              text-overflow: ellipsis;
              overflow: hidden;
              white-space: nowrap;
            `,children:e(x,{children:l.model.modelName||"--"})}),s?null:o(pe,{delay:0,offset:5,children:[e("span",{children:e(Oe,{children:e(L,{color:"danger",svg:e(D.InfoOutline,{})})})}),e(Fe,{children:"Some required invocation parameters are not configured."})]})]})}),e(ae,{type:"slideOver",isDismissable:!0,onDismiss:()=>{t(null)},children:a})]})}function ph(n){const a=O(r=>r.instances.find(s=>s.id===n.playgroundInstanceId));if(!a)throw new Error(`Playground instance ${n.playgroundInstanceId} not found`);const t=Ae(r=>r.setModelConfigForProvider),l=ve(),i=m.useCallback(()=>{const{supportedInvocationParameters:r,...s}=a.model;t({provider:a.model.provider,modelConfig:s}),l({title:"Model Configuration Saved",message:`${Na[a.model.provider]} model configuration saved as default for later use.`,expireMs:3e3})},[a.model,l,t]);return e(Y,{title:"Model Configuration",size:"M",extra:o(pe,{delay:0,offset:5,children:[e(z,{size:"compact",variant:"default",onClick:i,icon:e(L,{svg:e(D.SaveOutline,{})}),children:"Save as Default"}),o(Fe,{children:["Saves the current configuration as the default for"," ",Na[a.model.provider]??"this provider","."]})]}),children:e(m.Suspense,{children:e(yh,{...n})})})}function yh(n){const{playgroundInstanceId:a}=n,t=O(g=>g.instances.find(p=>p.id===a));if(!t)throw new Error(`Playground instance ${n.playgroundInstanceId} not found`);const l=Ae(g=>g.modelConfigByProvider),i=O(g=>g.updateProvider),r=O(g=>g.updateModel),s=t.model.supportedInvocationParameters,c=t.model.invocationParameters,d=bi(c,s),u=P.useLazyLoadQuery(Do,{providerKey:t.model.provider}),y=m.useCallback(g=>{r({instanceId:a,patch:{modelName:g}})},[a,r]);return o("form",{css:uh,children:[d?null:o(h,{direction:"row",gap:"size-100",children:[e(L,{color:"danger",svg:e(D.InfoOutline,{})}),e(x,{color:"danger",children:"Some required invocation parameters are not configured."})]}),e(dh,{provider:t.model.provider,query:u,onChange:g=>{i({instanceId:a,provider:g,modelConfigByProvider:l})}}),t.model.provider==="AZURE_OPENAI"?e(mh,{instance:t}):e(sh,{modelName:t.model.modelName,provider:t.model.provider,query:u,onChange:y}),e(m.Suspense,{children:e(rh,{instanceId:a})})]})}const Lo=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a={alias:null,args:null,kind:"ScalarField",name:"invocationInputField",storageKey:null},t={alias:"floatDefaultValue",args:null,kind:"ScalarField",name:"defaultValue",storageKey:null},l=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:null,kind:"LinkedField",name:"modelInvocationParameters",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"invocationName",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"canonicalName",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"required",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null}],type:"InvocationParameterBase",abstractKey:"__isInvocationParameterBase"},{kind:"InlineFragment",selections:[{alias:"booleanDefaultValue",args:null,kind:"ScalarField",name:"defaultValue",storageKey:null},a],type:"BooleanInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:[t,a,{alias:null,args:null,kind:"ScalarField",name:"minValue",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"maxValue",storageKey:null}],type:"BoundedFloatInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:[t,a],type:"FloatInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:[{alias:"intDefaultValue",args:null,kind:"ScalarField",name:"defaultValue",storageKey:null},a],type:"IntInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:[{alias:"jsonDefaultValue",args:null,kind:"ScalarField",name:"defaultValue",storageKey:null},a],type:"JSONInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:[{alias:"stringDefaultValue",args:null,kind:"ScalarField",name:"defaultValue",storageKey:null},a],type:"StringInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:[{alias:"stringListDefaultValue",args:null,kind:"ScalarField",name:"defaultValue",storageKey:null},a],type:"StringListInvocationParameter",abstractKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ModelSupportedParamsFetcherQuery",selections:l,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ModelSupportedParamsFetcherQuery",selections:l},params:{cacheID:"8f18509b17f3f97c2413ef8b6557d972",id:null,metadata:{},name:"ModelSupportedParamsFetcherQuery",operationKind:"query",text:`query ModelSupportedParamsFetcherQuery(
  $input: ModelsInput!
) {
  modelInvocationParameters(input: $input) {
    __typename
    ... on InvocationParameterBase {
      __isInvocationParameterBase: __typename
      invocationName
      canonicalName
      required
      label
    }
    ... on BooleanInvocationParameter {
      booleanDefaultValue: defaultValue
      invocationInputField
    }
    ... on BoundedFloatInvocationParameter {
      floatDefaultValue: defaultValue
      invocationInputField
      minValue
      maxValue
    }
    ... on FloatInvocationParameter {
      floatDefaultValue: defaultValue
      invocationInputField
    }
    ... on IntInvocationParameter {
      intDefaultValue: defaultValue
      invocationInputField
    }
    ... on JSONInvocationParameter {
      jsonDefaultValue: defaultValue
      invocationInputField
    }
    ... on StringInvocationParameter {
      stringDefaultValue: defaultValue
      invocationInputField
    }
    ... on StringListInvocationParameter {
      stringListDefaultValue: defaultValue
      invocationInputField
    }
  }
}
`}}}();Lo.hash="8bf1a32724929bdc4a02d32809ba59d7";const fh=({instanceId:n})=>{const a=O(s=>{var c;return(c=s.instances.find(d=>d.id===n))==null?void 0:c.model.provider}),t=O(s=>{var c;return(c=s.instances.find(d=>d.id===n))==null?void 0:c.model.modelName}),l=Ae(s=>s.modelConfigByProvider),i=O(s=>s.updateModelSupportedInvocationParameters),{modelInvocationParameters:r}=P.useLazyLoadQuery(Lo,{input:{providerKey:a,modelName:t}});return m.useEffect(()=>{i({instanceId:n,supportedInvocationParameters:r})},[r,n,i,l]),null};function hh({playgroundInstanceId:n,toolCalls:a,templateMessages:t,messageId:l}){const i=O(p=>p.updateInstance),r=O(p=>p.instances.find(f=>f.id===n));if(r==null)throw new Error(`Playground instance ${n} not found`);const[s,c]=m.useState(()=>JSON.stringify(a,null,2)),[d,u]=m.useState(a);m.useEffect(()=>{JSON.stringify(a)!==JSON.stringify(d)&&(c(JSON.stringify(a,null,2)),u(a))},[d,a]);const y=m.useCallback(p=>{c(p);const{json:f}=Me(p);if(f==null)return;const{success:k}=Cc.safeParse(f);k&&(u(f),i({instanceId:n,patch:{template:{__type:"chat",messages:t.map(b=>l===b.id?{...b,toolCalls:f}:b)}}}))},[l,n,t,i]),g=m.useMemo(()=>{switch(r.model.provider){case"OPENAI":case"AZURE_OPENAI":return Kc;case"ANTHROPIC":return Fc;case"GEMINI":return null}},[r.model.provider]);return e(Ee,{value:s,jsonSchema:g,onChange:y})}function kh(n){return n==="text"||n==="toolCalls"}function bh({messageMode:n,onChange:a}){return o(xl,{defaultValue:n,variant:"inline-button",size:"compact",onChange:t=>{if(kh(t))a(t);else throw new Error(`Unknown message mode: ${t}`)},children:[e(ca,{label:"text input",value:"text",children:o(pe,{placement:"top",delay:0,offset:10,children:[e(Oe,{children:e(L,{svg:e(D.MessageSquareOutline,{})})}),e(Fe,{children:"Text input"})]})}),e(ca,{label:"tool calling",value:"toolCalls",children:o(pe,{placement:"top",delay:0,offset:10,children:[e(Oe,{children:e(L,{svg:e(D.Code,{})})}),e(Fe,{children:"Tool calling"})]})})]})}const Sh=C`
  .ac-field-label {
    display: none;
  }
`;function vh({role:n,includeLabel:a=!0,onChange:t}){return o(ha,{selectedKey:n,css:a?void 0:Sh,label:"Role","data-testid":"messages-role-picker","aria-label":"Role for the chat message",size:"compact",onSelectionChange:l=>{if(!gi(l))throw new Error(`Invalid chat message role: ${l}`);t(l)},children:[e(le,{children:"System"},"system"),e(le,{children:"User"},"user"),e(le,{children:"AI"},"ai"),e(le,{children:"Tool"},"tool")]})}const Ch=32;function Fh({instanceId:n,hasResponseFormat:a}){const t=O(y=>y.instances),l=O(y=>y.updateInstance),i=O(y=>y.upsertInvocationParameterInput),r=t.find(y=>y.id===n);if(!r)throw new Error(`Playground instance ${n} not found`);const{template:s}=r;if(s.__type!=="chat")throw new Error(`Invalid template type ${s.__type}`);const c=r.model.supportedInvocationParameters,d=c==null?void 0:c.some(y=>En(y,{canonicalName:Ln,invocationName:Dn})),u=c==null?void 0:c.some(y=>En(y,{canonicalName:ua,invocationName:_a}));return o(h,{direction:"row",justifyContent:"end",gap:"size-100",minHeight:Ch,children:[d?e(z,{variant:"default",size:"compact","aria-label":"output schema",icon:e(L,{svg:e(D.PlusOutline,{})}),disabled:a,onClick:()=>{i({instanceId:n,invocationParameterInput:{valueJson:xc(),invocationName:Dn,canonicalName:Ln}})},children:"Output Schema"}):null,u?e(z,{variant:"default","aria-label":"add tool",size:"compact",icon:e(L,{svg:e(D.PlusOutline,{})}),onClick:()=>{[...r.tools,Zt({provider:r.model.provider,toolNumber:r.tools.length+1})],r.tools.length,l({instanceId:n,patch:{tools:[...r.tools,Zt({provider:r.model.provider,toolNumber:r.tools.length+1})]}})},children:"Tool"}):null,e(z,{variant:"default","aria-label":"add message",size:"compact",icon:e(L,{svg:e(D.PlusOutline,{})}),onClick:()=>{l({instanceId:n,patch:{template:{__type:"chat",messages:[...s.messages,{id:ma(),role:"user",content:""}]}}})},children:"Message"})]})}const Kh=400;function xh({playgroundInstanceId:n}){const a=O(d=>d.deleteInvocationParameterInput),t=O(d=>d.instances.find(u=>u.id===n)),l=O(d=>d.upsertInvocationParameterInput);if(!t)throw new Error(`Instance ${n} not found`);const i=t.model.invocationParameters.find(d=>d.invocationName===Dn||d.canonicalName===Ln),[r,s]=m.useState(JSON.stringify((i==null?void 0:i.valueJson)??{},null,2)),c=m.useCallback(d=>{s(d);const{json:u}=Me(d);if(u==null)return;const{success:y}=Rt.safeParse(u);y&&l({instanceId:n,invocationParameterInput:{invocationName:Dn,valueJson:u,canonicalName:Ln}})},[n,l]);return e(qe,{arrowPosition:"start",children:e(ke,{id:"response-format",title:"Output Schema",children:e(F,{padding:"size-200",children:e(q,{variant:"compact",title:"Schema",bodyStyle:{padding:0},extra:o(h,{direction:"row",gap:"size-100",children:[e(se,{text:r}),e(z,{"aria-label":"Delete Output Schema",icon:e(L,{svg:e(D.TrashOutline,{})}),variant:"default",size:"compact",onClick:()=>{a({instanceId:n,invocationParameterInputInvocationName:Dn})}})]}),children:e(ii,{preInitializationMinHeight:Kh,children:e(Ee,{value:r,onChange:c,jsonSchema:ku})})})})})})}const Th=400;function Dh({playgroundInstanceId:n,toolId:a}){const t=O(f=>f.updateInstance),l=O(f=>f.instances.find(k=>k.id===n));if(l==null)throw new Error(`Playground instance ${n} not found`);const i=l.tools,r=i.find(f=>f.id===a);if(r==null)throw new Error(`Tool ${a} not found`);const[s,c]=m.useState(JSON.stringify(r.definition,null,2)),[d,u]=m.useState(r.definition);m.useEffect(()=>{JSON.stringify(r.definition)!==JSON.stringify(d)&&(u(r.definition),c(JSON.stringify(r.definition,null,2)))},[r.definition,d]);const y=m.useCallback(f=>{c(f);const{json:k}=Me(f);if(k==null)return;const{success:b}=Il.safeParse(k);b&&(u(k),t({instanceId:n,patch:{tools:i.map(S=>S.id===r.id?{...S,definition:k}:S)}}))},[i,n,r.id,t]),g=m.useMemo(()=>Ra(r),[r]),p=m.useMemo(()=>{switch(l.model.provider){case"OPENAI":case"AZURE_OPENAI":return Dc;case"ANTHROPIC":return Tc;case"GEMINI":return null}},[l.model.provider]);return e(q,{collapsible:!0,backgroundColor:"yellow-100",borderColor:"yellow-700",variant:"compact",title:o(h,{direction:"row",gap:"size-100",children:[e(Dt,{spanKind:"tool"}),e(x,{children:g??"Tool"})]}),bodyStyle:{padding:0},extra:o(h,{direction:"row",gap:"size-100",children:[e(se,{text:s}),e(z,{"aria-label":"Delete tool",icon:e(L,{svg:e(D.TrashOutline,{})}),variant:"default",size:"compact",onClick:()=>{const f=i.filter(v=>v.id!==r.id),k=Ra(r),b=typeof l.toolChoice=="object"&&k!=null&&l.toolChoice.function.name===Ra(r);let S=l.toolChoice;f.length===0?S=void 0:b&&(S="auto"),t({instanceId:n,patch:{tools:f,toolChoice:S}})}})]}),children:e(ii,{preInitializationMinHeight:Th,children:e(Ee,{value:s,onChange:y,jsonSchema:p})})})}function Ih(n){const a=n.playgroundInstanceId,t=O(s=>s.instances.find(c=>c.id===n.playgroundInstanceId)),l=O(s=>s.updateInstance);if(t==null)throw new Error(`Playground instance ${a} not found`);const{tools:i}=t;if(i==null)throw new Error(`Playground instance ${a} does not have tools`);const r=m.useMemo(()=>i.map(s=>Ra(s)).filter(s=>s!=null),[i]);return e(qe,{arrowPosition:"start",children:e(ke,{id:"tools",title:"Tools",titleExtra:e(Be,{variant:"light",children:i.length}),children:e(F,{padding:"size-200",children:o(h,{direction:"column",children:[e(we,{children:e(Ic,{choice:t.toolChoice,onChange:s=>{l({instanceId:a,patch:{toolChoice:s}})},toolNames:r})}),e(h,{direction:"column",gap:"size-200",children:i.map(s=>e(Dh,{playgroundInstanceId:a,toolId:s.id},s.id))})]})})})})}const Eo=1,Ph=Eo+1;function Lh(n){const a=n.playgroundInstanceId,t=O(y=>y.templateLanguage),l=O(y=>y.instances),i=O(y=>y.updateInstance),r=l.find(y=>y.id===a);if(!r)throw new Error(`Playground instance ${a} not found`);const s=r.tools.length>0,c=r.model.invocationParameters.find(y=>En(y,{canonicalName:Ln,invocationName:Dn}))!=null,{template:d}=r;if(d.__type!=="chat")throw new Error(`Invalid template type ${d.__type}`);const u=Go(Qt(ad),Qt(nd,{coordinateGetter:ed}));return o(Zo,{sensors:u,onDragEnd:({active:y,over:g})=>{if(!g||y.id===g.id)return;const p=d.messages.findIndex(b=>b.id===y.id),f=d.messages.findIndex(b=>b.id===g.id),k=Wo(d.messages,p,f);i({instanceId:a,patch:{template:{__type:"chat",messages:k}}})},children:[e(Jo,{items:d.messages,children:e("ul",{css:C`
            display: flex;
            flex-direction: column;
            gap: var(--ac-global-dimension-size-200);
            padding: var(--ac-global-dimension-size-200);
          `,children:d.messages.map((y,g)=>e(wh,{playgroundInstanceId:a,instance:r,templateLanguage:t,template:d,message:y,index:g},y.id))})}),e(F,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderColor:"dark",borderTopWidth:"thin",borderBottomWidth:s||c?"thin":void 0,children:e(Fh,{instanceId:a,hasResponseFormat:c})}),s?e(Ih,{...n}):null,c?e(xh,{...n}):null]})}function Eh({message:n,updateMessage:a,templateLanguage:t,playgroundInstanceId:l,template:i,messageMode:r}){if(r==="toolCalls")return e(F,{paddingTop:"size-100",paddingStart:"size-250",paddingEnd:"size-250",paddingBottom:"size-200",children:e(Mn,{label:"Tool Calls",children:e(Ye,{width:"100%",children:e(hh,{playgroundInstanceId:l,toolCalls:n.toolCalls,templateMessages:i.messages,messageId:n.id})})})});if(n.role==="tool"){const s=ki(n.content);return o(we,{onSubmit:c=>{c.preventDefault()},children:[e(F,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-200",paddingBottom:"size-200",borderColor:"yellow-700",borderBottomWidth:"thin",children:e(ee,{value:n.toolCallId,onChange:c=>a({toolCallId:c}),"aria-label":"Tool Call ID",addonBefore:"Tool Call ID"})}),e(Ee,{value:s,"aria-label":"tool message content",height:"100%",onChange:c=>a({content:c}),onBlur:()=>{if(n.content!=null&&typeof n.content=="string"){const{json:c}=Me(n.content);a({content:JSON.stringify(c,null,2)})}}})]})}return e("div",{css:C`
        & .cm-content {
          padding-left: var(--ac-global-dimension-size-250);
          padding-right: var(--ac-global-dimension-size-250);
        }
        & .cm-line {
          padding-left: 0;
          padding-right: 0;
        }
      `,children:e(Lc,{height:"100%",value:typeof n.content=="string"?n.content:JSON.stringify(n.content,null,2),"aria-label":"Message content",templateLanguage:t,onChange:s=>a({content:s})})})}function wh({playgroundInstanceId:n,templateLanguage:a,template:t,message:l,instance:i}){const r=O(E=>E.updateInstance),{attributes:s,listeners:c,setNodeRef:d,transform:u,transition:y,setActivatorNodeRef:g,isDragging:p}=Yo({id:l.id}),f=Mt(l.role),k={transform:Xo.Translate.toString(u),transition:y,zIndex:p?Ph:Eo},b=l.toolCalls!=null&&l.toolCalls.length>0,[S,v]=m.useState(b?"toolCalls":"text"),I=m.useCallback(E=>{r({instanceId:n,patch:{template:{__type:"chat",messages:t.messages.map(_=>_.id===l.id?{..._,...E}:_)}}})},[l.id,n,t.messages,r]),[w,R]=m.useState(l.content),[K,T]=m.useState(l.toolCalls);return e("li",{ref:d,style:k,children:e(q,{collapsible:!0,variant:"compact",bodyStyle:{padding:0},...f,title:e(vh,{includeLabel:!1,role:l.role,onChange:E=>{let _=l.toolCalls;E!=="ai"&&(_=void 0,v("text")),r({instanceId:n,patch:{template:{__type:"chat",messages:t.messages.map(j=>j.id===l.id?{...j,role:E,toolCalls:_}:j)}}})}}),extra:o(h,{direction:"row",gap:"size-100",children:[l.role==="ai"?e(bh,{messageMode:S,onChange:E=>{switch(v(E),E){case"text":T(l.toolCalls),I({content:w,toolCalls:void 0});break;case"toolCalls":R(l.content),I({content:"",toolCalls:K!=null?li({toolCalls:K,provider:i.model.provider}):[Nu(i.model.provider)]});break;default:ue()}}}):null,e(se,{text:S==="toolCalls"?JSON.stringify(l.toolCalls):ki(l.content)}),e(z,{"aria-label":"Delete message",icon:e(L,{svg:e(D.TrashOutline,{})}),variant:"default",size:"compact",onClick:()=>{r({instanceId:n,patch:{template:{__type:"chat",messages:t.messages.filter(E=>E.id!==l.id)}}})}}),e(Pc,{ref:g,listeners:c,attributes:s})]}),children:e("div",{children:e(Eh,{message:l,messageMode:S,playgroundInstanceId:n,template:t,templateLanguage:a,updateMessage:I})})})})}function _h(n){const a=n.playgroundInstanceId,t=O(s=>s.instances),l=t.find(s=>s.id===a),i=t.findIndex(s=>s.id===a);if(!l)throw new Error(`Playground instance ${a} not found`);const{template:r}=l;return e(q,{title:o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(Pt,{index:i}),e("span",{children:"Prompt"})]}),collapsible:!0,variant:"compact",bodyStyle:{padding:0},extra:o(h,{direction:"row",gap:"size-100",children:[e(m.Suspense,{fallback:e("div",{children:e(ye,{size:"S"})}),children:e(fh,{instanceId:a})}),e(gh,{...n}),t.length>1?e(Rh,{...n}):null]}),children:r.__type==="chat"?e(m.Suspense,{children:e(Lh,{...n})}):"Completion Template"})}function Rh(n){const a=O(t=>t.deleteInstance);return o(pe,{children:[e(Oe,{children:e(z,{variant:"default",size:"compact",icon:e(L,{svg:e(D.TrashOutline,{})}),onClick:()=>{a(n.playgroundInstanceId)}})}),e(Fe,{children:e(An,{children:"Delete this instance of the playground"})})]})}function Ah(){const n=O(t=>t.templateLanguage),a=O(t=>t.setTemplateLanguage);return e("div",{css:C`
        & * {
          white-space: nowrap;
        }
      `,children:o(xl,{value:n,variant:"inline-button","aria-label":"Template Language",size:"compact",onChange:t=>{Ec(t)&&a(t)},children:[e(ca,{label:"None",value:Tn.NONE,children:"None"}),e(ca,{label:"Mustache",value:Tn.Mustache,children:"Mustache"}),e(ca,{label:"F-String",value:Tn.FString,children:"F-String"})]})})}const Mh=C`
  display: flex;
  overflow: hidden;
  flex-direction: column;
  height: 100%;
`;function wo(n){const{modelProviders:a}=P.useLazyLoadQuery(ro,{}),t=Ae(d=>d.modelConfigByProvider),l=Ae(d=>d.playgroundStreamingEnabled),[,i]=fa(),r=a.some(d=>d.dependenciesInstalled);m.useEffect(()=>{i(d=>(d.delete("selectedSpanNodeId"),d),{replace:!0})},[i]);const s=window.Config.websocketsEnabled?l:!1,c=window.Config.websocketsEnabled;return r?o(mf,{...n,streaming:s,modelConfigByProvider:t,children:[o("div",{css:Mh,children:[e(F,{borderBottomColor:"dark",borderBottomWidth:"thin",padding:"size-200",flex:"none",children:o(h,{direction:"row",justifyContent:"space-between",alignItems:"center",children:[e(ge,{level:1,children:"Playground"}),o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[c?e(nh,{}):null,e(bf,{}),e(hf,{}),e(eh,{})]})]})}),e(Qh,{})]}),e(m.Suspense,{children:e(Ve,{})})]}):e(yf,{availableProviders:a})}function Nh(){const n=O(i=>i.addInstance),a=O(i=>i.instances),t=a.length,l=a.some(i=>i.activeRunId!=null);return e("div",{onClick:i=>{i.stopPropagation()},children:e(z,{variant:"default",size:"compact","aria-label":"add prompt",icon:e(L,{svg:e(D.PlusCircleOutline,{})}),disabled:t>=Qc||l,onClick:()=>{n()},children:"Compare"})})}const zh=C`
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  & > .ac-accordion {
    display: flex;
    flex-direction: column;
    height: 100%;
    overflow: hidden;
    flex: 1 1 auto;
    & > .ac-accordion-item {
      height: 100%;
      display: flex;
      flex-direction: column;
      overflow-x: hidden;
      overflow-y: auto;
      flex: 1 1 auto;
      // prevent the accordion item header from growing to fill the accordion item
      // using two selectors as fallback just incase the component lib changes subtly
      & > [role="button"],
      & > #prompts-heading {
        flex: 0 0 auto;
      }
      .ac-accordion-itemContent {
        height: 100%;
        overflow: hidden;
        flex: 1 1 auto;
      }
    }
  }
`,Vh=C`
  padding: var(--ac-global-dimension-size-200);
  scrollbar-gutter: stable;
  height: 100%;
  flex: 1 1 auto;
  overflow: auto;
  box-sizing: border-box;
`,$h=C`
  height: 100%;
  overflow: auto;
`,Oh=475;function Qh(){const n=O(u=>u.instances),a=O(u=>u.templateLanguage),{datasetId:t}=Ue(),l=t!=null,r=n.length===1,s=n.some(u=>u.activeRunId!=null),c=m.useCallback(({currentLocation:u,nextLocation:y})=>s&&u.pathname!==y.pathname,[s]),d=td(c);return m.useEffect(()=>{const u=y=>{s&&(y.preventDefault(),y.returnValue=!0)};return window.addEventListener("beforeunload",u),()=>window.removeEventListener("beforeunload",u)},[s]),o(G,{children:[o(tn,{direction:r&&!l?"horizontal":"vertical",autoSaveId:r?"playground-horizontal":"playground-vertical",children:[e(he,{children:e("div",{css:zh,children:e(qe,{arrowPosition:"start",size:"L",children:e(ke,{title:"Prompts",id:"prompts",extra:o(h,{direction:"row",gap:"size-100",alignItems:"center",children:[e(Ah,{}),e(Nh,{})]}),children:e("div",{css:Vh,children:e(h,{direction:"row",gap:"size-200",maxWidth:"100%",children:n.map(u=>e(F,{flex:"1 1 0px",minWidth:Oh,children:e(_h,{playgroundInstanceId:u.id},u.id)},u.id))})})})})})}),e(an,{css:fn}),e(he,{children:l?e(m.Suspense,{fallback:e(ye,{}),children:e(Qf,{datasetId:t})}):e("div",{css:$h,children:o(qe,{arrowPosition:"start",size:"L",children:[a!==Tn.NONE?e(ke,{title:"Inputs",id:"input",children:e(F,{padding:"size-200",height:"100%",children:e(Hf,{})})}):null,e(ke,{title:"Output",id:"output",children:e(F,{padding:"size-200",height:"100%",children:e(h,{direction:"row",gap:"size-200",children:n.map((u,y)=>e(F,{flex:"1 1 0px",children:e(Xf,{playgroundInstanceId:u.id},y)},y))})})})]})})})]}),d!=null&&e(wc,{blocker:d,message:"Playground run is still in progress, leaving the page may result in incomplete runs. Are you sure you want to leave?"})]})}function w1(){return e(wo,{})}function _1(){const n=_n(),a=m.useMemo(()=>n.span.__typename==="Span"?n.span:null,[n.span]);if(!a)throw new Error("Span not found");const{playgroundInstance:t,parsingErrors:l,playgroundInput:i}=m.useMemo(()=>wu(a),[a]),r=i!=null?{input:i}:{};return o(h,{direction:"column",height:"100%",children:[e(jh,{span:a,parsingErrors:l}),e(wo,{instances:[t],...r},a.id)]})}function jh({span:n,parsingErrors:a}){const t=ne(),l=a&&a.length>0,[i,r]=m.useState(!0),[s,c]=m.useState(l);return o(h,{direction:"column",gap:"size-50",children:[i&&e(ce,{variant:"info",title:"LLM Span Replay",banner:!0,dismissable:!0,onDismissClick:()=>{r(!1)},extra:e(z,{variant:"default",icon:e(L,{svg:e(D.ArrowBack,{})}),onClick:()=>{t(`/projects/${n.project.id}/traces/${n.context.traceId}?selectedSpanNodeId=${n.id}`)},children:"Back to Trace"}),children:`Replay and iterate on your LLM call from your ${n.project.name} project`}),s&&l&&e(ce,{variant:"warning",banner:!0,dismissable:!0,onDismissClick:()=>{c(!1)},title:"The following errors occurred when parsing span attributes:",children:e("ul",{children:a.map(d=>e("li",{children:d},d))})})]})}const _o=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"spanId"}],a=[{kind:"Variable",name:"id",variableName:"spanId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i={alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[l,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],storageKey:null},r={alias:null,args:null,concreteType:"SpanContext",kind:"LinkedField",name:"context",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"spanId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null}],storageKey:null},s={alias:null,args:null,kind:"ScalarField",name:"attributes",storageKey:null},c=[{alias:null,args:null,kind:"ScalarField",name:"invocationInputField",storageKey:null}],d={alias:null,args:null,concreteType:null,kind:"LinkedField",name:"invocationParameters",plural:!0,selections:[t,{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"invocationName",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"canonicalName",storageKey:null}],type:"InvocationParameterBase",abstractKey:"__isInvocationParameterBase"},{kind:"InlineFragment",selections:c,type:"BooleanInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:c,type:"StringInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:c,type:"BoundedFloatInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:c,type:"FloatInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:c,type:"IntInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:c,type:"JSONInvocationParameter",abstractKey:null},{kind:"InlineFragment",selections:c,type:"StringListInvocationParameter",abstractKey:null}],storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"spanPlaygroundPageLoaderQuery",selections:[{alias:"span",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"InlineFragment",selections:[l,i,r,s,d],type:"Span",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"spanPlaygroundPageLoaderQuery",selections:[{alias:"span",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"TypeDiscriminator",abstractKey:"__isNode"},l,{kind:"InlineFragment",selections:[i,r,s,d],type:"Span",abstractKey:null}],storageKey:null}]},params:{cacheID:"e6a9310252c290e00bfdc12151c88b3a",id:null,metadata:{},name:"spanPlaygroundPageLoaderQuery",operationKind:"query",text:`query spanPlaygroundPageLoaderQuery(
  $spanId: GlobalID!
) {
  span: node(id: $spanId) {
    __typename
    ... on Span {
      id
      project {
        id
        name
      }
      context {
        spanId
        traceId
      }
      attributes
      invocationParameters {
        __typename
        ... on InvocationParameterBase {
          __isInvocationParameterBase: __typename
          invocationName
          canonicalName
        }
        ... on BooleanInvocationParameter {
          invocationInputField
        }
        ... on StringInvocationParameter {
          invocationInputField
        }
        ... on BoundedFloatInvocationParameter {
          invocationInputField
        }
        ... on FloatInvocationParameter {
          invocationInputField
        }
        ... on IntInvocationParameter {
          invocationInputField
        }
        ... on JSONInvocationParameter {
          invocationInputField
        }
        ... on StringListInvocationParameter {
          invocationInputField
        }
      }
    }
    __isNode: __typename
    id
  }
}
`}}}();_o.hash="65ef72eb48726c70f00811d17ea6d82d";async function R1(n){const{spanId:a}=n.params;if(!a||typeof a!="string")throw new Error("Invalid spanId");return await P.fetchQuery(Ne,_o,{spanId:a}).toPromise()}function A1(){const n=_n();return e(_c,{query:n,children:e(Ve,{})})}const Ro=function(){var n={alias:null,args:null,kind:"ScalarField",name:"passwordNeedsReset",storageKey:null},a={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},t={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null};return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"authenticatedRootLoaderQuery",selections:[{args:null,kind:"FragmentSpread",name:"ViewerContext_viewer"},{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"viewer",plural:!1,selections:[n],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"authenticatedRootLoaderQuery",selections:[{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"viewer",plural:!1,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null},{alias:null,args:null,concreteType:"UserRole",kind:"LinkedField",name:"role",plural:!1,selections:[t],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"authMethod",storageKey:null},{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"apiKeys",plural:!0,selections:[a,t,{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null}],storageKey:null},n],storageKey:null}]},params:{cacheID:"d63c6184305079deb38a6f6235ba88e6",id:null,metadata:{},name:"authenticatedRootLoaderQuery",operationKind:"query",text:`query authenticatedRootLoaderQuery {
  ...ViewerContext_viewer
  viewer {
    passwordNeedsReset
  }
}

fragment APIKeysTableFragment on User {
  apiKeys {
    id
    name
    description
    createdAt
    expiresAt
  }
  id
}

fragment ViewerContext_viewer on Query {
  viewer {
    id
    username
    email
    profilePictureUrl
    role {
      name
    }
    authMethod
    ...APIKeysTableFragment
  }
}
`}}}();Ro.hash="d30a68846023740517243e9394be73a8";async function M1(){var a;const n=await P.fetchQuery(Ne,Ro,{}).toPromise();if((a=n==null?void 0:n.viewer)!=null&&a.passwordNeedsReset){const t=ai({path:"/reset-password"});return Ma(t)}return n}export{A1 as A,F1 as B,C1 as C,l1 as D,d1 as E,L1 as F,w1 as G,Xh as H,R1 as I,x1 as J,K1 as K,T1 as L,c1 as M,Zh as N,Jh as O,E1 as P,D1 as R,_1 as S,ua as T,En as a,I1 as b,M1 as c,Yh as d,n1 as e,i1 as f,a1 as g,e1 as h,t1 as i,m1 as j,g1 as k,u1 as l,Wh as m,s1 as n,r1 as o,o1 as p,p1 as q,P1 as r,f1 as s,y1 as t,nm as u,v1 as v,S1 as w,b1 as x,k1 as y,h1 as z};
