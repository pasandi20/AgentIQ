import{r as p,R as G,j as e,n as yt,a as Le,e as Ge,s as gn,b as je,c as Ce,d as kn,f as Y1,g as de,h as ea,i as na,k as Sn,l as s,m as ta,o as be,C as qe,p as Ve,q as ze,t as R,u as aa,v as ia,L as vt,w as kt,x as St,y as ee,z as S,A as en,B as wt,D as h,E as xt,F as Tt,N as ra,G as Mt,H as la,$ as P,I as It,J as At,K as ke,M as nn,O as oa,P as sa,Q as ca,S as da,T as Gn,U as J,V as ua,W as ma,X as pa,Y as Qn,Z as ga,_ as ha,a0 as fa,a1 as hn,a2 as Mn,a3 as La,a4 as Ca,a5 as ba,a6 as ya,a7 as va,a8 as ka,a9 as Sa,aa as wa,ab as xa,ac as Te,ad as z,ae as Ta,af as Ma,ag as Ia,ah as Aa,ai as Ea,aj as Da,ak as Pa,al as Oa}from"./vendor-Cdrqqth8.js";import{m as _a,T as Fa,a as Un,u as Na}from"./pages-Cmqh2i4E.js";import{u as Va,A as za,I,a as T,_ as Et,b as y,c as x,d as b,e as F,f as Y,T as Z,g as Ra,t as Dt,h as Ka,R as q,i as Re,j as ae,k as $a,l as he,m as N,F as Pt,n as K,o as Ha,p as Ba,P as In,q as Za,r as Ga,L as me,s as ie,v as re,w as Me,x as Ke,E as Ot,y as Qa,z as Ua,B as An,C as _t,D as fe,G as tn,H as an,J as ja,K as Wa,M as jn,N as qa}from"./vendor-arizeai-BSCL03yQ.js";import{L as Ft,a as Nt,l as wn,j as Vt,h as Xa,b as Ja,c as Ya,d as ei,e as ni,f as ti,s as ai,R as $e,g as zt,n as He,i as Rt,E as Kt,p as ii,k as ri}from"./vendor-codemirror-Utqu7Snw.js";import{V as li}from"./vendor-three-DwGkEfCM.js";const $t=function(){var n={defaultValue:null,kind:"LocalArgument",name:"clusters"},t={defaultValue:null,kind:"LocalArgument",name:"dataQualityMetricColumnName"},a={defaultValue:null,kind:"LocalArgument",name:"fetchDataQualityMetric"},i={defaultValue:null,kind:"LocalArgument",name:"fetchPerformanceMetric"},r={defaultValue:null,kind:"LocalArgument",name:"performanceMetric"},l=[{alias:null,args:null,kind:"ScalarField",name:"primaryValue",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"referenceValue",storageKey:null}],o=[{alias:null,args:[{kind:"Variable",name:"clusters",variableName:"clusters"}],concreteType:"Cluster",kind:"LinkedField",name:"clusters",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"eventIds",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"driftRatio",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"primaryToCorpusRatio",storageKey:null},{condition:"fetchDataQualityMetric",kind:"Condition",passingValue:!0,selections:[{alias:null,args:[{fields:[{kind:"Variable",name:"columnName",variableName:"dataQualityMetricColumnName"},{kind:"Literal",name:"metric",value:"mean"}],kind:"ObjectValue",name:"metric"}],concreteType:"DatasetValues",kind:"LinkedField",name:"dataQualityMetric",plural:!1,selections:l,storageKey:null}]},{condition:"fetchPerformanceMetric",kind:"Condition",passingValue:!0,selections:[{alias:null,args:[{fields:[{kind:"Variable",name:"metric",variableName:"performanceMetric"}],kind:"ObjectValue",name:"metric"}],concreteType:"DatasetValues",kind:"LinkedField",name:"performanceMetric",plural:!1,selections:l,storageKey:null}]}],storageKey:null}];return{fragment:{argumentDefinitions:[n,t,a,i,r],kind:"Fragment",metadata:null,name:"pointCloudStore_clusterMetricsQuery",selections:o,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,a,t,i,r],kind:"Operation",name:"pointCloudStore_clusterMetricsQuery",selections:o},params:{cacheID:"86666967012812887ac0a0149d2d2535",id:null,metadata:{},name:"pointCloudStore_clusterMetricsQuery",operationKind:"query",text:`query pointCloudStore_clusterMetricsQuery(
  $clusters: [ClusterInput!]!
  $fetchDataQualityMetric: Boolean!
  $dataQualityMetricColumnName: String
  $fetchPerformanceMetric: Boolean!
  $performanceMetric: PerformanceMetric!
) {
  clusters(clusters: $clusters) {
    id
    eventIds
    driftRatio
    primaryToCorpusRatio
    dataQualityMetric(metric: {metric: mean, columnName: $dataQualityMetricColumnName}) @include(if: $fetchDataQualityMetric) {
      primaryValue
      referenceValue
    }
    performanceMetric(metric: {metric: $performanceMetric}) @include(if: $fetchPerformanceMetric) {
      primaryValue
      referenceValue
    }
  }
}
`}}}();$t.hash="dbfc8c02ba1ec4f2ba0317b371854d9b";const Ht=function(){var n={defaultValue:null,kind:"LocalArgument",name:"clusterMinSamples"},t={defaultValue:null,kind:"LocalArgument",name:"clusterSelectionEpsilon"},a={defaultValue:null,kind:"LocalArgument",name:"coordinates"},i={defaultValue:null,kind:"LocalArgument",name:"dataQualityMetricColumnName"},r={defaultValue:null,kind:"LocalArgument",name:"eventIds"},l={defaultValue:null,kind:"LocalArgument",name:"fetchDataQualityMetric"},o={defaultValue:null,kind:"LocalArgument",name:"fetchPerformanceMetric"},d={defaultValue:null,kind:"LocalArgument",name:"minClusterSize"},c={defaultValue:null,kind:"LocalArgument",name:"performanceMetric"},u=[{alias:null,args:null,kind:"ScalarField",name:"primaryValue",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"referenceValue",storageKey:null}],m=[{alias:null,args:[{kind:"Variable",name:"clusterMinSamples",variableName:"clusterMinSamples"},{kind:"Variable",name:"clusterSelectionEpsilon",variableName:"clusterSelectionEpsilon"},{kind:"Variable",name:"coordinates3d",variableName:"coordinates"},{kind:"Variable",name:"eventIds",variableName:"eventIds"},{kind:"Variable",name:"minClusterSize",variableName:"minClusterSize"}],concreteType:"Cluster",kind:"LinkedField",name:"hdbscanClustering",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"eventIds",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"driftRatio",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"primaryToCorpusRatio",storageKey:null},{condition:"fetchDataQualityMetric",kind:"Condition",passingValue:!0,selections:[{alias:null,args:[{fields:[{kind:"Variable",name:"columnName",variableName:"dataQualityMetricColumnName"},{kind:"Literal",name:"metric",value:"mean"}],kind:"ObjectValue",name:"metric"}],concreteType:"DatasetValues",kind:"LinkedField",name:"dataQualityMetric",plural:!1,selections:u,storageKey:null}]},{condition:"fetchPerformanceMetric",kind:"Condition",passingValue:!0,selections:[{alias:null,args:[{fields:[{kind:"Variable",name:"metric",variableName:"performanceMetric"}],kind:"ObjectValue",name:"metric"}],concreteType:"DatasetValues",kind:"LinkedField",name:"performanceMetric",plural:!1,selections:u,storageKey:null}]}],storageKey:null}];return{fragment:{argumentDefinitions:[n,t,a,i,r,l,o,d,c],kind:"Fragment",metadata:null,name:"pointCloudStore_clustersQuery",selections:m,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[r,a,d,n,t,l,i,o,c],kind:"Operation",name:"pointCloudStore_clustersQuery",selections:m},params:{cacheID:"a1a02d970d255935edfcdd797e4ca80d",id:null,metadata:{},name:"pointCloudStore_clustersQuery",operationKind:"query",text:`query pointCloudStore_clustersQuery(
  $eventIds: [ID!]!
  $coordinates: [InputCoordinate3D!]!
  $minClusterSize: Int!
  $clusterMinSamples: Int!
  $clusterSelectionEpsilon: Float!
  $fetchDataQualityMetric: Boolean!
  $dataQualityMetricColumnName: String
  $fetchPerformanceMetric: Boolean!
  $performanceMetric: PerformanceMetric!
) {
  hdbscanClustering(eventIds: $eventIds, coordinates3d: $coordinates, minClusterSize: $minClusterSize, clusterMinSamples: $clusterMinSamples, clusterSelectionEpsilon: $clusterSelectionEpsilon) {
    id
    eventIds
    driftRatio
    primaryToCorpusRatio
    dataQualityMetric(metric: {metric: mean, columnName: $dataQualityMetricColumnName}) @include(if: $fetchDataQualityMetric) {
      primaryValue
      referenceValue
    }
    performanceMetric(metric: {metric: $performanceMetric}) @include(if: $fetchPerformanceMetric) {
      primaryValue
      referenceValue
    }
  }
}
`}}}();Ht.hash="b26f299a862a3bc4f5487ace49db1d43";const Bt=function(){var n={defaultValue:null,kind:"LocalArgument",name:"corpusEventIds"},t={defaultValue:null,kind:"LocalArgument",name:"primaryEventIds"},a={defaultValue:null,kind:"LocalArgument",name:"referenceEventIds"},i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null},o={alias:null,args:null,kind:"ScalarField",name:"value",storageKey:null},d={alias:null,args:null,concreteType:"EventMetadata",kind:"LinkedField",name:"eventMetadata",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"predictionId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"predictionLabel",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"predictionScore",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"actualLabel",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"actualScore",storageKey:null}],storageKey:null},c={alias:null,args:null,concreteType:"PromptResponse",kind:"LinkedField",name:"promptAndResponse",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"prompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"response",storageKey:null}],storageKey:null},u={alias:null,args:null,kind:"ScalarField",name:"documentText",storageKey:null},m=[i,{alias:null,args:null,concreteType:"DimensionWithValue",kind:"LinkedField",name:"dimensions",plural:!0,selections:[{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"dimension",plural:!1,selections:[r,l],storageKey:null},o],storageKey:null},d,c,u],g=[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"primaryInferences",plural:!1,selections:[{alias:null,args:[{kind:"Variable",name:"eventIds",variableName:"primaryEventIds"}],concreteType:"Event",kind:"LinkedField",name:"events",plural:!0,selections:m,storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"referenceInferences",plural:!1,selections:[{alias:null,args:[{kind:"Variable",name:"eventIds",variableName:"referenceEventIds"}],concreteType:"Event",kind:"LinkedField",name:"events",plural:!0,selections:[i,{alias:null,args:null,concreteType:"DimensionWithValue",kind:"LinkedField",name:"dimensions",plural:!0,selections:[{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"dimension",plural:!1,selections:[i,r,l],storageKey:null},o],storageKey:null},d,c,u],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"corpusInferences",plural:!1,selections:[{alias:null,args:[{kind:"Variable",name:"eventIds",variableName:"corpusEventIds"}],concreteType:"Event",kind:"LinkedField",name:"events",plural:!0,selections:m,storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[n,t,a],kind:"Fragment",metadata:null,name:"pointCloudStore_eventsQuery",selections:g,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[t,a,n],kind:"Operation",name:"pointCloudStore_eventsQuery",selections:g},params:{cacheID:"388c28f19a685a131b1dfd4bac80cb7c",id:null,metadata:{},name:"pointCloudStore_eventsQuery",operationKind:"query",text:`query pointCloudStore_eventsQuery(
  $primaryEventIds: [ID!]!
  $referenceEventIds: [ID!]!
  $corpusEventIds: [ID!]!
) {
  model {
    primaryInferences {
      events(eventIds: $primaryEventIds) {
        id
        dimensions {
          dimension {
            name
            type
          }
          value
        }
        eventMetadata {
          predictionId
          predictionLabel
          predictionScore
          actualLabel
          actualScore
        }
        promptAndResponse {
          prompt
          response
        }
        documentText
      }
    }
    referenceInferences {
      events(eventIds: $referenceEventIds) {
        id
        dimensions {
          dimension {
            id
            name
            type
          }
          value
        }
        eventMetadata {
          predictionId
          predictionLabel
          predictionScore
          actualLabel
          actualScore
        }
        promptAndResponse {
          prompt
          response
        }
        documentText
      }
    }
    corpusInferences {
      events(eventIds: $corpusEventIds) {
        id
        dimensions {
          dimension {
            name
            type
          }
          value
        }
        eventMetadata {
          predictionId
          predictionLabel
          predictionScore
          actualLabel
          actualScore
        }
        promptAndResponse {
          prompt
          response
        }
        documentText
      }
    }
  }
}
`}}}();Bt.hash="00a957322684d9186fdf16d33a75b931";const Zt=function(){var n={defaultValue:null,kind:"LocalArgument",name:"getDimensionCategories"},t={defaultValue:null,kind:"LocalArgument",name:"getDimensionMinMax"},a={defaultValue:null,kind:"LocalArgument",name:"id"},i=[{kind:"Variable",name:"id",variableName:"id"}],r={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={condition:"getDimensionMinMax",kind:"Condition",passingValue:!0,selections:[{alias:"min",args:[{kind:"Literal",name:"metric",value:"min"}],kind:"ScalarField",name:"dataQualityMetric",storageKey:'dataQualityMetric(metric:"min")'},{alias:"max",args:[{kind:"Literal",name:"metric",value:"max"}],kind:"ScalarField",name:"dataQualityMetric",storageKey:'dataQualityMetric(metric:"max")'}]},o={condition:"getDimensionCategories",kind:"Condition",passingValue:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"categories",storageKey:null}]};return{fragment:{argumentDefinitions:[n,t,a],kind:"Fragment",metadata:null,name:"pointCloudStore_dimensionMetadataQuery",selections:[{kind:"RequiredField",field:{alias:"dimension",args:i,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[r,l,o],type:"Dimension",abstractKey:null}],storageKey:null},action:"THROW",path:"dimension"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,t,n],kind:"Operation",name:"pointCloudStore_dimensionMetadataQuery",selections:[{alias:"dimension",args:i,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},r,{kind:"InlineFragment",selections:[l,o],type:"Dimension",abstractKey:null}],storageKey:null}]},params:{cacheID:"79c15606d5694bd068270b42ed2fe74c",id:null,metadata:{},name:"pointCloudStore_dimensionMetadataQuery",operationKind:"query",text:`query pointCloudStore_dimensionMetadataQuery(
  $id: GlobalID!
  $getDimensionMinMax: Boolean!
  $getDimensionCategories: Boolean!
) {
  dimension: node(id: $id) {
    __typename
    ... on Dimension {
      id
      min: dataQualityMetric(metric: min) @include(if: $getDimensionMinMax)
      max: dataQualityMetric(metric: max) @include(if: $getDimensionMinMax)
      categories @include(if: $getDimensionCategories)
    }
    __isNode: __typename
    id
  }
}
`}}}();Zt.hash="e8fa488a0d466b5e40fdadc1e5227a57";const oi=30,Wn=5,qn=100,si=0,Xn=0,Jn=.99,ci=500,Yn=300,et=1e5,di=10,nt=1,ui=2,mi=1,pi=0;var E=(n=>(n.inferences="inferences",n.correctness="correctness",n.dimension="dimension",n))(E||{}),we=(n=>(n.list="list",n.gallery="gallery",n))(we||{}),Se=(n=>(n.small="small",n.medium="medium",n.large="large",n))(Se||{}),D=(n=>(n.primary="primary",n.reference="reference",n.corpus="corpus",n))(D||{}),$=(n=>(n.correct="correct",n.incorrect="incorrect",n.unknown="unknown",n))($||{});const gi=["#05fbff","#cb8afd"],hi=["#00add0","#4500d9"],ne="#a5a5a5",ye=ne;var X=(n=>(n.primary="primary",n.reference="reference",n.corpus="corpus",n))(X||{});function O(n){throw new Error("Unreachable")}function En(n){return typeof n=="number"||n===null}function fi(n){return typeof n=="string"||n===null}function h2(n){return Array.isArray(n)?n.every(t=>typeof t=="string"):!1}function Dn(n){return typeof n=="object"&&n!==null}function f2(n){return Dn(n)&&Object.keys(n).every(t=>typeof t=="string")}const L2=()=>n=>n,Pn=p.createContext(null);function rn(){const n=G.useContext(Pn);if(n===null)throw new Error("useInferences must be used within a InferencesProvider");return n}function C2(n){return e(Pn.Provider,{value:{primaryInferences:n.primaryInferences,referenceInferences:n.referenceInferences,corpusInferences:n.corpusInferences,getInferencesNameByRole:t=>{var a,i;switch(t){case X.primary:return n.primaryInferences.name;case X.reference:return((a=n.referenceInferences)==null?void 0:a.name)??"reference";case X.corpus:return((i=n.corpusInferences)==null?void 0:i.name)??"corpus";default:O()}}},children:n.children})}const On=p.createContext(null);function b2({children:n,...t}){const[a]=p.useState(()=>Ni(t));return e(On.Provider,{value:a,children:n})}function v(n,t){const a=p.useContext(On);if(!a)throw new Error("Missing PointCloudContext.Provider in the tree");return yt(a,n,t)}var j=(n=>(n.last_hour="Last Hour",n.last_day="Last Day",n.last_week="Last Week",n.last_month="Last Month",n.last_3_months="Last 3 Months",n.first_hour="First Hour",n.first_day="First Day",n.first_week="First Week",n.first_month="First Month",n.all="All",n))(j||{});const Gt=p.createContext(null);function Li(){const n=p.useContext(Gt);if(n===null)throw new Error("useTimeRange must be used within a TimeRangeProvider");return n}function Ci(n,t){return p.useMemo(()=>{switch(n){case"Last Hour":{const i=Le(na(t.end),{roundingMethod:"ceil"});return{start:Sn(i,1),end:i}}case"Last Day":{const i=Le(ea(t.end),{roundingMethod:"ceil"});return{start:de(i,1),end:i}}case"Last Week":{const i=Le(Ge(t.end),{roundingMethod:"ceil"});return{start:de(i,7),end:i}}case"Last Month":{const i=Le(Ge(t.end),{roundingMethod:"ceil"});return{start:de(i,30),end:i}}case"Last 3 Months":{const i=Le(Ge(t.end),{roundingMethod:"ceil"});return{start:de(i,90),end:i}}case"First Hour":{const i=kn(t.start);return{start:i,end:Y1(i,1)}}case"First Day":{const i=Ce(t.start);return{start:i,end:je(i,1)}}case"First Week":{const i=gn(t.start);return{start:i,end:je(i,7)}}case"First Month":{const i=gn(t.start);return{start:i,end:je(i,30)}}case"All":{const i=Le(Ge(t.end),{roundingMethod:"floor"});return{start:gn(t.start),end:i}}default:O()}},[n,t])}function y2(n){const[t,a]=p.useState("Last Month"),i=Ci(t,n.timeRangeBounds),r=p.useCallback(l=>{p.startTransition(()=>{a(l)})},[]);return e(Gt.Provider,{value:{timeRange:i,timePreset:t,setTimePreset:r},children:n.children})}const Qt=p.createContext(null);function v2({children:n}){const[t,a]=Va({style:{zIndex:1e3}}),i=p.useCallback(l=>{t({variant:"danger",...l})},[t]),r=p.useCallback(l=>{t({variant:"success",...l})},[t]);return s(Qt.Provider,{value:{notify:t,notifyError:i,notifySuccess:r},children:[n,a]})}function Ut(){const n=p.useContext(Qt);if(n===null)throw new Error("useGlobalNotification must be used within a NotificationProvider");return n}function k2(){return Ut().notifyError}function ln(){return Ut().notifySuccess}const jt="arize-phoenix-theme";function Wt(){return localStorage.getItem(jt)==="light"?"light":"dark"}const _n=p.createContext(null);function Q(){const n=p.useContext(_n);if(n===null)throw new Error("useTheme must be used within a ThemeProvider");return n}function S2(n){const[t,a]=p.useState(Wt()),i=p.useCallback(r=>{localStorage.setItem(jt,r),a(r)},[]);return e(_n.Provider,{value:{theme:t,setTheme:i},children:n.children})}function bi(n){return n.endsWith("/")?n.slice(0,-1):n}const qt=bi(window.Config.basename),yi=window.location.protocol==="https:",Be=`${window.location.protocol}//${window.location.host}${qt}`,vi=`${yi?"wss":"ws"}://${window.location.host}${qt}`,w2=window.Config.platformVersion,_e="returnUrl";function tt(n,t){const a=new URL(n,window.location.origin);return t.forEach((i,r)=>{a.searchParams.append(r,i)}),a.pathname+a.search}function ki(){const n=window.Config.basename,t=n==null||n===""||n==="/",a=n!=null&&n.startsWith("/")&&!n.endsWith("/");if(!(t||a))throw new Error(`Invalid basename: ${n}`);const i=window.location.pathname,r=window.location.origin,l=new URLSearchParams(window.location.search);if(t){const o=new URL("/login",r);return o.searchParams.set(_e,tt(i,l)),o.pathname+o.search}if(i.startsWith(n)){const o=i.slice(n.length);if(o===""||o.startsWith("/")){const c=new URL(n+"/login",r);return c.searchParams.set(_e,tt(o,l)),c.pathname+c.search}}return n+"/login"}function x2(n){const t=window.Config.basename,a=t==null||t===""||t==="/",i=t!=null&&t.startsWith("/")&&!t.endsWith("/");if(!(a||i))throw new Error(`Invalid basename: ${t}`);return a?n:t+n}const T2=({path:n,searchParams:t})=>{const i=new URL(window.location.href).searchParams.get(_e),r=new URLSearchParams(t||{});i&&r.set(_e,i);const l=r.toString();return`${n}${l?`?${l}`:""}`},Si=n=>!(typeof n!="string"||!n.startsWith("/")||n.replace(/\\/g,"/").startsWith("//")),wi=n=>Si(n)?n:"/",M2=()=>{const n=new URL(window.location.href);return wi(n.searchParams.get(_e))},xi=Be+"/auth/refresh";class at extends Error{constructor(){super("Unauthorized")}}async function Ti(n,t){try{return await fetch(n,t).then(a=>{if(a.status===401)throw new at;return a})}catch(a){if(a instanceof at)return await Mi(),fetch(n,t);if(a instanceof Error&&a.name==="AbortError")throw a}throw new Error("An unexpected error occurred while fetching data")}let Ee=null;async function Mi(){return Ee||(Ee=fetch(xi,{method:"POST"}).then(n=>(n.ok||(window.location.href=ki()),Ee=null,n)),Ee)}const Ii=Be+"/graphql",Ai=window.Config.authenticationEnabled?Ti:fetch;function Ei(n,t,a){return be.Observable.create(i=>{const r=new AbortController;return Ai(n,{...t,signal:r.signal}).then(l=>l.json()).then(l=>{const o=a==null?void 0:a(l);if(o)throw o;i.next(l),i.complete()}).catch(l=>{l.name==="AbortError"?i.complete():i.error(l)}),()=>{r.abort()}})}const Di=(n,t,a)=>Ei(Ii,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:n.text,variables:t})},i=>{if(!(!Dn(i)||!("errors"in i))&&Array.isArray(i.errors))return new Error(`Error fetching GraphQL query '${n.name}' with variables '${JSON.stringify(t)}': ${JSON.stringify(i.errors)}`)}),Pi=ta({url:`${vi}/graphql`}),Oi=(n,t)=>be.Observable.create(a=>Pi.subscribe({operationName:n.name,query:n.text,variables:t},a)),Ze=new be.Environment({network:be.Network.create(Di,Oi),store:new be.Store(new be.RecordSource,{gcReleaseBufferSize:10})});function Xt(n){return n.includes("PRIMARY")?X.primary:n.includes("CORPUS")?X.corpus:X.reference}function Fn(n){const t=[],a=[],i=[];return n.forEach(r=>{const l=Xt(r);l==X.primary?t.push(r):l==X.corpus?i.push(r):a.push(r)}),{primaryEventIds:t,referenceEventIds:a,corpusEventIds:i}}const Xe=10,Pe="unknown",Jt=ia,Yt=aa,_i=n=>Yt[n],Fi=n=>Jt(n/Xe);var xe=(n=>(n.move="move",n.select="select",n))(xe||{}),Nn=(n=>(n.default="default",n.highlight="highlight",n))(Nn||{});const ve=()=>Wt()==="light"?hi:gi;function I2(){const n=ve();return{coloringStrategy:E.inferences,pointGroupVisibility:{[D.primary]:!0,[D.reference]:!0},pointGroupColors:{[D.primary]:n[0],[D.reference]:n[1],[D.corpus]:ne},metric:{type:"drift",metric:"euclideanDistance"}}}function A2(){const n=ve();return{coloringStrategy:E.inferences,pointGroupVisibility:{[D.primary]:!0,[D.corpus]:!0},pointGroupColors:{[D.primary]:n[0],[D.corpus]:ne},metric:{type:"retrieval",metric:"queryDistance"},clusterSort:{dir:"desc",column:"primaryMetricValue"}}}function E2(){return{coloringStrategy:E.correctness,pointGroupVisibility:{[$.correct]:!0,[$.incorrect]:!0,[$.unknown]:!0},pointGroupColors:{[$.correct]:qe.Discrete2.LightBlueOrange[0],[$.incorrect]:qe.Discrete2.LightBlueOrange[1],[$.unknown]:ye},metric:{type:"performance",metric:"accuracyScore"},clusterSort:{dir:"asc",column:"primaryMetricValue"}}}const Ni=n=>{const t={loading:!1,errorMessage:null,points:[],eventIdToDataMap:new Map,clusters:[],clusterSort:{dir:"desc",column:"driftRatio"},pointData:null,selectedEventIds:new Set,hoveredEventId:null,highlightedClusterId:null,selectedClusterId:null,canvasMode:"move",pointSizeScale:1,clusterColorMode:"default",coloringStrategy:E.inferences,inferencesVisibility:{primary:!0,reference:!0,corpus:!0},pointGroupVisibility:{[D.primary]:!0,[D.reference]:!0,[D.corpus]:!0},pointGroupColors:{[D.primary]:ve()[0],[D.reference]:ve()[1],[D.corpus]:ne},eventIdToGroup:{},selectionDisplay:we.gallery,selectionGridSize:Se.large,dimension:null,dimensionMetadata:null,umapParameters:{minDist:si,nNeighbors:oi,nSamples:ci},hdbscanParameters:{minClusterSize:di,clusterMinSamples:mi,clusterSelectionEpsilon:pi},clustersLoading:!1,metric:{type:"drift",metric:"euclideanDistance"},selectionSearchText:""},a=(i,r)=>({...t,...n,setInitialData:async({points:l,clusters:o,retrievals:d})=>{const c=r(),u=new Map,m=d.reduce((L,C)=>{const{queryId:k}=C;return L[k]?L[k].push(C):L[k]=[C],L},{});l.forEach(L=>{L={...L,retrievals:m[L.eventId]??[]},u.set(L.eventId,L)});const g=o.map(rt).sort(Ln(c.clusterSort));i({loading:!1,points:l,eventIdToDataMap:u,clusters:g,clustersLoading:!1,selectedEventIds:new Set,selectedClusterId:null,pointData:null,eventIdToGroup:ce({points:l,coloringStrategy:c.coloringStrategy,pointsData:c.pointData??{},dimension:c.dimension||null,dimensionMetadata:c.dimensionMetadata})});const f=await Ri(l.map(L=>L.eventId)).catch(()=>i({errorMessage:"Failed to load the point events"}));f&&i({pointData:f,clusters:g,clustersLoading:!1,eventIdToGroup:ce({points:l,coloringStrategy:c.coloringStrategy,pointsData:f??{},dimension:c.dimension||null,dimensionMetadata:c.dimensionMetadata})})},setClusters:l=>{const o=r(),d=l.map(rt).sort(Ln(o.clusterSort));i({clusters:d,clustersLoading:!1,selectedClusterId:null,highlightedClusterId:null})},setClusterSort:l=>{const d=[...r().clusters].sort(Ln(l));i({clusterSort:l,clusters:d})},setSelectedEventIds:l=>i({selectedEventIds:l,selectionSearchText:""}),setHoveredEventId:l=>i({hoveredEventId:l}),setHighlightedClusterId:l=>i({highlightedClusterId:l}),setSelectedClusterId:l=>i({selectedClusterId:l,highlightedClusterId:null}),setPointSizeScale:l=>i({pointSizeScale:l}),setCanvasMode:l=>i({canvasMode:l}),setClusterColorMode:l=>i({clusterColorMode:l}),setColoringStrategy:l=>{const o=r();switch(i({coloringStrategy:l}),l){case E.correctness:i({pointGroupVisibility:{[$.correct]:!0,[$.incorrect]:!0,[$.unknown]:!0},pointGroupColors:{[$.correct]:qe.Discrete2.LightBlueOrange[0],[$.incorrect]:qe.Discrete2.LightBlueOrange[1],[$.unknown]:ye},dimension:null,dimensionMetadata:null,eventIdToGroup:ce({points:o.points,coloringStrategy:l,pointsData:o.pointData??{},dimension:o.dimension||null,dimensionMetadata:o.dimensionMetadata})});break;case E.inferences:{i({pointGroupVisibility:{[D.primary]:!0,[D.reference]:!0,[D.corpus]:!0},pointGroupColors:{[D.primary]:ve()[0],[D.reference]:ve()[1],[D.corpus]:ne},dimension:null,dimensionMetadata:null,eventIdToGroup:ce({points:o.points,coloringStrategy:l,pointsData:o.pointData??{},dimension:o.dimension||null,dimensionMetadata:o.dimensionMetadata})});break}case E.dimension:{i({pointGroupVisibility:{unknown:!0},pointGroupColors:{unknown:ye},dimension:null,dimensionMetadata:null,eventIdToGroup:ce({points:o.points,coloringStrategy:l,pointsData:o.pointData??{},dimension:o.dimension||null,dimensionMetadata:o.dimensionMetadata})});break}default:O()}},inferencesVisibility:{primary:!0,reference:!0,corpus:!0},setInferencesVisibility:l=>i({inferencesVisibility:l}),setPointGroupVisibility:l=>i({pointGroupVisibility:l}),selectionDisplay:we.gallery,setSelectionDisplay:l=>i({selectionDisplay:l}),setSelectionGridSize:l=>i({selectionGridSize:l}),reset:()=>{i({points:[],clusters:[],selectedEventIds:new Set,selectedClusterId:null,eventIdToGroup:{}})},setDimension:async l=>{const o=r();i({dimension:l,dimensionMetadata:null});const d=await zi(l).catch(()=>i({errorMessage:"Failed to load the dimension metadata"}));if(d){if(i({dimensionMetadata:d}),d.categories&&d.categories.length){const c=d.categories.length,m=c<=Yt.length?_i:g=>Jt(g/c);i({pointGroupVisibility:{...d.categories.reduce((g,f)=>({...g,[f]:!0}),{}),unknown:!0},pointGroupColors:{...d.categories.reduce((g,f,L)=>({...g,[f]:m(L)}),{}),unknown:ye},eventIdToGroup:ce({points:o.points,coloringStrategy:o.coloringStrategy,pointsData:o.pointData??{},dimension:l,dimensionMetadata:d})})}else if(d.interval!==null){const c=e1(d.interval);i({pointGroupVisibility:{...c.reduce((u,m)=>({...u,[m.name]:!0}),{}),unknown:!0},pointGroupColors:{...c.reduce((u,m,g)=>({...u,[m.name]:Fi(g)}),{}),unknown:ye},eventIdToGroup:ce({points:o.points,coloringStrategy:o.coloringStrategy,pointsData:o.pointData??{},dimension:l,dimensionMetadata:d})})}}},setDimensionMetadata:l=>i({dimensionMetadata:l}),setUMAPParameters:l=>i({umapParameters:l}),setHDBSCANParameters:async l=>{const o=r();i({hdbscanParameters:l,clustersLoading:!0});const d=await Ki({metric:o.metric,points:o.points,hdbscanParameters:l});o.setClusters(d)},getHDSCANParameters:()=>r().hdbscanParameters,getMetric:()=>r().metric,setErrorMessage:l=>i({errorMessage:l}),setLoading:l=>i({loading:l}),setMetric:async l=>{const o=r();i({metric:l,clustersLoading:!0});const d=await $i({metric:l,clusters:o.clusters,hdbscanParameters:o.hdbscanParameters});o.setClusters(d)},setSelectionSearchText:l=>i({selectionSearchText:l})});return Ve()(ze(a))},it=new Intl.NumberFormat([],{maximumFractionDigits:2});function Vi({min:n,max:t}){return`${it.format(n)} - ${it.format(t)}`}function e1({min:n,max:t}){const i=(t-n)/Xe,r=[];for(let l=0;l<Xe;l++){const o=n+l*i,d=n+(l+1)*i;r.push({min:o,max:d,name:Vi({min:o,max:d})})}return r}function fn({numericGroupIntervals:n,numericValue:t}){let a=Pe,i=n.findIndex(r=>t>=r.min&&t<r.max);return i=i===-1?Xe-1:i,a=n[i].name,a}function ce(n){const{points:t,coloringStrategy:a,pointsData:i,dimension:r,dimensionMetadata:l}=n,o={},d=t.map(c=>c.eventId);switch(a){case E.inferences:{const{primaryEventIds:c,referenceEventIds:u,corpusEventIds:m}=Fn(d);c.forEach(g=>{o[g]=D.primary}),u.forEach(g=>{o[g]=D.reference}),m.forEach(g=>{o[g]=D.corpus});break}case E.correctness:{t.forEach(c=>{let u=$.unknown;const{predictionLabel:m,actualLabel:g}=c.eventMetadata;m!==null&&g!==null&&(u=m===g?$.correct:$.incorrect),o[c.eventId]=u});break}case E.dimension:{let c;l&&(l==null?void 0:l.interval)!==null&&(c=e1(l.interval));const u=(r==null?void 0:r.type)==="prediction"&&(r==null?void 0:r.dataType)==="categorical",m=(r==null?void 0:r.type)==="prediction"&&(r==null?void 0:r.dataType)==="numeric",g=(r==null?void 0:r.type)==="actual"&&(r==null?void 0:r.dataType)==="categorical",f=(r==null?void 0:r.type)==="actual"&&(r==null?void 0:r.dataType)==="numeric";t.forEach(L=>{let C=Pe;const k=i[L.eventId];if(r!=null&&k!=null)if(u)C=k.eventMetadata.predictionLabel??Pe;else if(m){if(c==null)throw new Error("Cannot color by prediction score without numeric group intervals");const w=k.eventMetadata.predictionScore;typeof w=="number"&&(C=fn({numericGroupIntervals:c,numericValue:w}))}else if(f){if(c==null)throw new Error("Cannot color by actual score without numeric group intervals");const w=k.eventMetadata.actualScore;typeof w=="number"&&(C=fn({numericGroupIntervals:c,numericValue:w}))}else if(g)C=k.eventMetadata.actualLabel??Pe;else{const w=k.dimensions.find(H=>H.dimension.name===r.name);if(w!=null&&r.dataType==="categorical")C=w.value??Pe;else if(w!=null&&r.dataType==="numeric"&&c!=null){const H=typeof(w==null?void 0:w.value)=="string"?parseFloat(w.value):null;typeof H=="number"&&(C=fn({numericGroupIntervals:c,numericValue:H}))}}o[L.eventId]=C});break}default:O()}return o}async function zi(n){const t=await R.fetchQuery(Ze,Zt,{id:n.id,getDimensionMinMax:n.dataType==="numeric",getDimensionCategories:n.dataType==="categorical"}).toPromise(),a=t==null?void 0:t.dimension;if(!n)throw new Error("Dimension not found");let i=null;return typeof(a==null?void 0:a.min)=="number"&&typeof(a==null?void 0:a.max)=="number"&&(i={min:a.min,max:a.max}),{interval:i,categories:(a==null?void 0:a.categories)??null}}async function Ri(n){var u,m,g,f,L,C;const{primaryEventIds:t,referenceEventIds:a,corpusEventIds:i}=Fn([...n]),r=await R.fetchQuery(Ze,Bt,{primaryEventIds:t,referenceEventIds:a,corpusEventIds:i}).toPromise(),l=((m=(u=r==null?void 0:r.model)==null?void 0:u.primaryInferences)==null?void 0:m.events)??[],o=((f=(g=r==null?void 0:r.model)==null?void 0:g.referenceInferences)==null?void 0:f.events)??[],d=((C=(L=r==null?void 0:r.model)==null?void 0:L.corpusInferences)==null?void 0:C.events)??[];return[...l,...o,...d].reduce((k,_)=>(k[_.id]=_,k),{})}async function Ki({metric:n,points:t,hdbscanParameters:a}){const i=await R.fetchQuery(Ze,Ht,{eventIds:t.map(r=>r.eventId),coordinates:t.map(r=>({x:r.position[0],y:r.position[1],z:r.position[2]})),fetchDataQualityMetric:n.type==="dataQuality",dataQualityMetricColumnName:n.type==="dataQuality"?n.dimension.name:null,fetchPerformanceMetric:n.type==="performance",performanceMetric:n.type==="performance"?n.metric:"accuracyScore",...a},{fetchPolicy:"network-only"}).toPromise();return(i==null?void 0:i.hdbscanClustering)??[]}async function $i({metric:n,clusters:t,hdbscanParameters:a}){const i=await R.fetchQuery(Ze,$t,{clusters:t.map(r=>({id:r.id,eventIds:r.eventIds})),fetchDataQualityMetric:n.type==="dataQuality",dataQualityMetricColumnName:n.type==="dataQuality"?n.dimension.name:null,fetchPerformanceMetric:n.type==="performance",performanceMetric:n.type==="performance"?n.metric:"accuracyScore",...a},{fetchPolicy:"network-only"}).toPromise();return(i==null?void 0:i.clusters)??[]}const Ln=n=>(t,a)=>{const{dir:i,column:r}=n,l=i==="asc",o=t[r],d=a[r];return o==null?1:d==null?-1:o>d?l?1:-1:o<d?l?-1:1:0};function rt(n){let t=n.driftRatio,a=null;return n.dataQualityMetric?(t=n.dataQualityMetric.primaryValue,a=n.dataQualityMetric.referenceValue):n.performanceMetric?(t=n.performanceMetric.primaryValue,a=n.performanceMetric.referenceValue):n.primaryToCorpusRatio!=null&&(t=(n.primaryToCorpusRatio+1)/2*100),{...n,size:n.eventIds.length,primaryMetricValue:t,referenceMetricValue:a}}const D2=n=>{const t=a=>({...n,columnVisibility:{metadata:!1},annotationColumnVisibility:{},setColumnVisibility:i=>{a({columnVisibility:i})},setAnnotationColumnVisibility:i=>{a({annotationColumnVisibility:i})}});return Ve()(ze(t))},te={NONE:"NONE",FString:"F_STRING",Mustache:"MUSTACHE"},P2={OPENAI:"OpenAI",AZURE_OPENAI:"Azure OpenAI",ANTHROPIC:"Anthropic",GEMINI:"Gemini"},n1="OPENAI",Hi="gpt-4o",Bi="user",O2=["2024-10-01-preview","2024-09-01-preview","2024-08-01-preview","2024-07-01-preview","2024-06-01","2024-05-01-preview","2024-04-01-preview","2024-03-01-preview","2024-02-15-preview","2024-02-01","2023-10-01-preview","2023-09-01-preview","2023-08-01-preview","2023-07-01-preview","2023-06-01-preview","2023-05-15","2023-03-15-preview"],t1=({parser:n,text:t})=>{const a=n.parse(t),i=[],r=a.cursor();do r.name==="Variable"&&i.push(t.slice(r.node.from,r.node.to));while(r.next());return i},a1=({parser:n,text:t,variables:a,postFormat:i})=>{if(!t)return"";let r=t,l=n.parse(r),o=l.cursor();do if(o.name==="Variable"){const d=r.slice(o.node.from,o.node.to),c=o.node.parent;d in a&&(r=`${r.slice(0,c.from)}${a[d]}${r.slice(c.to)}`,l=n.parse(r),o=l.cursor())}while(o.next());return i&&(r=i(r)),r},Zi=vt.deserialize({version:14,states:"!WQQOPOOOcOQO'#C^OOOO'#Cb'#CbQQOPOOOOOO'#Cc'#CcOhOQO,58xOOOO-E6`-E6`OOOO-E6a-E6aOOOO1G.d1G.d",stateData:"v~ORPOXQOYQOZQO[QO~OSSO~OSSOTWO~OZRX[X~",goto:"iWPPXPPP]cTQORQRORURQTPRVT",nodeNames:"⚠ FStringTemplate Template LBrace Variable RBrace",maxTerm:12,skippedNodes:[0],repeatNodeCount:2,tokenData:"%[~RaXY!WYZ!W]^!Wpq!Wqr!Wrs!]sw!Wwx!bx#O!W#O#P!i#P#o!W#o#p$c#p#q!W#q#r$|#r;'S!W;'S;=`%U<%lO!W~!]OX~~!bO[~~!iOX~[~~!lYrs!W!P!Q!W#O#P!W#U#V!W#Y#Z!W#b#c!W#f#g!W#h#i!W#i#j#[#o#p$^~#_R!Q![#h!c!i#h#T#Z#h~#kR!Q![#t!c!i#t#T#Z#t~#wR!Q![$Q!c!i$Q#T#Z$Q~$TR!Q![!W!c!i!W#T#Z!W~$cOZ~~$jQR~X~#o#p$p#q#r$w~$wOZ~[~~$|OY~~%RPX~#q#r!]~%XP;=`<%l!W",tokenizers:[1,new kt("!p~RVO#Oh#O#P!P#P#qh#q#r!j#r;'Sh;'S;=`y<%lOh~mSS~O#qh#r;'Sh;'S;=`y<%lOh~|P;=`<%lh~!UTS~O#qh#q#r!e#r;'Sh;'S;=`y<%lOh~!jOS~~!oOT~~",77)],topRules:{FStringTemplate:[0,1]},tokenPrec:32}),Vn=Ft.define({parser:Zi.configure({props:[St({"Template/LBrace":ee.quote,"Template/RBrace":ee.quote,"Template/Variable":ee.variableName,"⚠":ee.invalid})]}),languageData:{}}),Gi=({text:n,variables:t})=>a1({parser:Vn.parser,text:n,variables:t,postFormat:a=>a.replaceAll("\\{","{").replaceAll("{{","{").replaceAll("}}","}")}),Qi=n=>t1({parser:Vn.parser,text:n});function Ui(){return new Nt(Vn)}const ji=vt.deserialize({version:14,states:"!WQQOPOOOcOQO'#C^OOOO'#Cb'#CbQQOPOOOOOO'#Cc'#CcOhOQO,58xOOOO-E6`-E6`OOOO-E6a-E6aOOOO1G.d1G.d",stateData:"v~ORPOXQOYQOZQO[QO~OSSO~OSSOTWO~OZRX[X~",goto:"iWPPXPPP]cTQORQRORURQTPRVT",nodeNames:"⚠ MustacheLikeTemplate Template LBrace Variable RBrace",maxTerm:12,skippedNodes:[0],repeatNodeCount:2,tokenData:"%W~RaXY!WYZ!W]^!Wpq!Wqr!Wrs!]sw!Wwx!bx#O!W#O#P!i#P#o!W#o#p$c#p#q!W#q#r!b#r;'S!W;'S;=`%Q<%lO!W~!]OX~~!bO[~~!iOX~[~~!lYrs!W!P!Q!W#O#P!W#U#V!W#Y#Z!W#b#c!W#f#g!W#h#i!W#i#j#[#o#p$^~#_R!Q![#h!c!i#h#T#Z#h~#kR!Q![#t!c!i#t#T#Z#t~#wR!Q![$Q!c!i$Q#T#Z$Q~$TR!Q![!W!c!i!W#T#Z!W~$cOZ~~$jPX~[~#o#p$m~$rPR~#q#r$u~$xP#q#r${~%QOY~~%TP;=`<%l!W",tokenizers:[1,new kt("#e~RVO#oh#o#p!P#p#qh#q#r#X#r;'Sh;'S;=`y<%lOh~mSS~O#qh#r;'Sh;'S;=`y<%lOh~|P;=`<%lh~!USS~O#q!b#r;'S!b;'S;=`#R<%lO!b~!gVS~O#O!b#O#P!b#P#q!b#q#r!|#r;'S!b;'S;=`#R<%lO!b~#ROS~~#UP;=`<%l!b~#[P#q#r#_~#dOT~~",112)],topRules:{MustacheLikeTemplate:[0,1]},tokenPrec:32}),zn=Ft.define({parser:ji.configure({props:[St({"Template/LBrace":ee.quote,"Template/RBrace":ee.quote,"Template/Variable":ee.variableName,"Template/⚠":ee.invalid})]}),languageData:{}}),Wi=({text:n,variables:t})=>a1({parser:zn.parser,text:n,variables:t,postFormat:a=>a.replaceAll("\\{{","{{")}),qi=n=>t1({parser:zn.parser,text:n});function Xi(){return new Nt(zn)}const _2=n=>{switch(n){case te.FString:return{format:Gi,extractVariables:Qi};case te.Mustache:return{format:Wi,extractVariables:qi};case te.NONE:return{format:({text:t})=>t,extractVariables:()=>[]};default:O()}},Ji=S.union([S.string(),S.number(),S.boolean(),S.null()]),Je=S.lazy(()=>S.union([Ji,S.array(Je),S.record(Je)])),i1=S.object({type:S.literal("object"),properties:S.record(S.object({type:S.enum(["string","number","boolean","object","array","null","integer"]).describe("The type of the parameter"),description:S.string().optional().describe("A description of the parameter"),enum:S.array(S.string()).optional().describe("The allowed values")}).passthrough()).describe("A map of parameter names to their definitions"),required:S.array(S.string()).optional().describe("The required parameters"),additionalProperties:S.boolean().optional().describe("Whether or not additional properties are allowed in the schema")}).passthrough(),on=S.object({type:S.literal("function").describe("The type of the tool"),function:S.object({name:S.string().describe("The name of the function"),description:S.string().optional().describe("A description of the function"),parameters:i1.extend({strict:S.boolean().optional().describe("Whether or not the arguments should exactly match the function definition, only supported for OpenAI models")}).describe("The parameters that the function accepts")}).passthrough().describe("The function definition")}).passthrough(),F2=en(on,{removeAdditionalStrategy:"passthrough"}),sn=S.object({name:S.string(),description:S.string(),input_schema:i1}),N2=en(sn,{removeAdditionalStrategy:"passthrough"}),Yi=sn.transform(n=>({type:"function",function:{name:n.name,description:n.description,parameters:n.input_schema}})),er=on.transform(n=>({name:n.function.name,description:n.function.description??n.function.name,input_schema:n.function.parameters})),V2=S.union([on,sn,Je]),nr=n=>{const{success:t,data:a}=on.safeParse(n);if(t)return{provider:"OPENAI",validatedToolDefinition:a};const{success:i,data:r}=sn.safeParse(n);return i?{provider:"ANTHROPIC",validatedToolDefinition:r}:{provider:"UNKNOWN",validatedToolDefinition:null}},lt=n=>{const{provider:t,validatedToolDefinition:a}=nr(n);switch(t){case"AZURE_OPENAI":case"OPENAI":return a;case"ANTHROPIC":return Yi.parse(a);case"UNKNOWN":return null;default:O()}},tr=({toolDefinition:n,targetProvider:t})=>{switch(t){case"AZURE_OPENAI":case"OPENAI":return n;case"ANTHROPIC":return er.parse(n);case"GEMINI":return n;default:O()}};function z2(n){return{type:"function",function:{name:`new_function_${n}`,description:"",parameters:{type:"object",properties:{new_arg:{type:"string"}},required:[]}}}}function R2(n){return{name:`new_function_${n}`,description:"",input_schema:{type:"object",properties:{new_arg:{type:"string"}},required:[]}}}const cn=S.object({id:S.string().describe("The ID of the tool call"),function:S.object({name:S.string().describe("The name of the function"),arguments:S.record(S.unknown()).describe("The arguments for the function")}).describe("The function that is being called").passthrough()}),ar=S.array(cn),K2=en(ar,{removeAdditionalStrategy:"passthrough"}),dn=S.object({id:S.string().describe("The ID of the tool call"),type:S.literal("tool_use"),name:S.string().describe("The name of the tool"),input:S.record(S.unknown()).describe("The input for the tool")}).passthrough(),ir=S.array(dn),$2=en(ir,{removeAdditionalStrategy:"passthrough"}),rr=dn.transform(n=>({id:n.id,function:{name:n.name,arguments:n.input}})),lr=cn.transform(n=>({id:n.id,type:"tool_use",name:n.function.name,input:typeof n.function.arguments=="string"?{[n.function.arguments]:n.function.arguments}:n.function.arguments??{}})),or=S.union([cn,dn,Je]),H2=S.array(or),sr=n=>{const{success:t,data:a}=cn.safeParse(n);if(t)return{provider:"OPENAI",validatedToolCall:a};const{success:i,data:r}=dn.safeParse(n);return i?{provider:"ANTHROPIC",validatedToolCall:r}:{provider:"UNKNOWN",validatedToolCall:null}},ot=n=>{const{provider:t,validatedToolCall:a}=sr(n);switch(t){case"AZURE_OPENAI":case"OPENAI":return a;case"ANTHROPIC":return rr.parse(a);case"UNKNOWN":return null;default:O()}},cr=({toolCall:n,targetProvider:t})=>{switch(t){case"AZURE_OPENAI":case"OPENAI":return n;case"ANTHROPIC":return lr.parse(n);case"GEMINI":return n;default:O()}};function B2(){return{id:"",function:{name:"",arguments:{}}}}function Z2(){return{id:"",type:"tool_use",name:"",input:{}}}function dr({str:n,excludePrimitives:t=!1,excludeArray:a=!1}){try{const i=JSON.parse(n);if(t&&typeof i!="object"||a&&Array.isArray(i))return!1}catch{return!1}return!0}function ur(n){return dr({str:n,excludeArray:!0,excludePrimitives:!0})}function G2(n){try{return{json:JSON.parse(n)}}catch(t){return{json:null,parseError:t}}}function Q2(...n){try{return{json:JSON.stringify(...n)}}catch(t){return{json:null,stringifyError:t}}}const mr=({instanceTools:n,provider:t})=>n.map(a=>{switch(t){case"OPENAI":case"AZURE_OPENAI":{const i=lt(a.definition);return{...a,definition:i??a.definition}}case"ANTHROPIC":{const i=lt(a.definition),r=i?tr({toolDefinition:i,targetProvider:t}):a.definition;return{...a,definition:r}}case"GEMINI":return a;default:O()}}),pr=({toolCalls:n,provider:t})=>{if(n!=null)return n.map(a=>{switch(t){case"OPENAI":case"AZURE_OPENAI":return ot(a)??a;case"ANTHROPIC":{const i=ot(a);return i!=null?cr({toolCall:i,targetProvider:t}):a}case"GEMINI":return a;default:O()}})};let gr=0,hr=0,fr=1,Lr=0;const r1=()=>gr++,st=()=>fr++,U2=()=>Lr++,Cr=()=>hr++,l1=()=>({__type:"chat",messages:[{id:st(),role:"system",content:"You are a chatbot"},{id:st(),role:"user",content:"{{question}}"}]}),br={__type:"text_completion",prompt:"{{question}}"};function yr(){return{id:r1(),template:l1(),model:{provider:n1,modelName:Hi,invocationParameters:[],supportedInvocationParameters:[]},tools:[],toolChoice:"auto",output:void 0,spanId:null,activeRunId:null}}function j2(){return{type:"json_schema",json_schema:{name:"response",schema:{type:"object",properties:{},required:[],additionalProperties:!1},strict:!0}}}function vr(n){if(n.instances!=null&&n.instances.length>0)return n.instances;const t=yr(),a=Object.values(n.modelConfigByProvider);if(!(a.length>0))return[t];const r=a.find(l=>l.provider===n1)??a[0];return t.model={...t.model,...r},[t]}const W2=n=>Ve(ze((a,i)=>({streaming:!0,operationType:"chat",inputMode:"manual",input:{variablesValueCache:{}},templateLanguage:te.Mustache,instances:vr(n),setInput:r=>{a({input:r})},setOperationType:r=>{a(r==="chat"?{instances:i().instances.map(l=>({...l,template:l1()}))}:{instances:i().instances.map(l=>({...l,template:br}))}),a({operationType:r})},addInstance:()=>{const r=i().instances,l=i().instances[0];l&&a({instances:[...r,{...l,id:r1(),activeRunId:null,experimentId:null,spanId:null}]})},updateModelSupportedInvocationParameters:({instanceId:r,supportedInvocationParameters:l})=>{const o=i().instances;a({instances:o.map(d=>d.id===r?{...d,model:{...d.model,supportedInvocationParameters:l,invocationParameters:_a(d.model.invocationParameters,l)},tools:l.find(c=>c.canonicalName===Fa)?d.tools:[]}:d)})},updateProvider:({instanceId:r,provider:l,modelConfigByProvider:o})=>{const d=i().instances,c=d.find(g=>g.id===r);if(!c||c.model.provider===l)return;const u=o[l],m={model:u?{...u,supportedInvocationParameters:[],provider:l}:{modelName:null,invocationParameters:[],supportedInvocationParameters:[],apiVersion:null,endpoint:null,provider:l},tools:mr({instanceTools:c.tools,provider:l})};c.template.__type==="chat"&&(m.template={__type:"chat",messages:c.template.messages.map(g=>({...g,toolCalls:pr({toolCalls:g.toolCalls,provider:l})}))}),a({instances:d.map(g=>g.id===r?{...g,...m}:g)})},updateModel:({instanceId:r,patch:l})=>{const o=i().instances;o.find(c=>c.id===r)&&a({instances:o.map(c=>c.id===r?{...c,model:{...c.model,...l}}:c)})},deleteInstance:r=>{const l=i().instances;a({instances:l.filter(o=>o.id!==r)})},addMessage:({playgroundInstanceId:r})=>{const l=i().instances;a({instances:l.map(o=>o.id===r&&(o!=null&&o.template)&&(o==null?void 0:o.template.__type)==="chat"?{...o,messages:[...o.template.messages,{role:Bi,content:"{question}"}]}:o)})},updateInstance:({instanceId:r,patch:l})=>{const o=i().instances;a({instances:o.map(d=>d.id===r?{...d,...l}:d)})},runPlaygroundInstances:()=>{const r=i().instances;a({instances:r.map(l=>({...l,activeRunId:Cr(),spanId:null}))})},cancelPlaygroundInstances:()=>{a({instances:i().instances.map(r=>({...r,activeRunId:null,spanId:null}))})},markPlaygroundInstanceComplete:r=>{const l=i().instances;a({instances:l.map(o=>o.id===r?{...o,activeRunId:null}:o)})},setTemplateLanguage:r=>{a({templateLanguage:r})},setVariableValue:(r,l)=>{const o=i().input;a({input:{...o,variablesValueCache:{...o.variablesValueCache,[r]:l}}})},setStreaming:r=>{a({streaming:r})},updateInstanceModelInvocationParameters:({instanceId:r,invocationParameters:l})=>{i().instances.find(d=>d.id===r)&&a({instances:i().instances.map(d=>d.id===r?{...d,model:{...d.model,invocationParameters:l}}:d)})},upsertInvocationParameterInput:({instanceId:r,invocationParameterInput:l})=>{const o=i().instances.find(c=>c.id===r);if(!o)return;const d=o.model.invocationParameters.find(c=>Un(c,l));a(d?{instances:i().instances.map(c=>c.id===r?{...c,model:{...c.model,invocationParameters:c.model.invocationParameters.map(u=>Un(u,l)?l:u)}}:c)}:{instances:i().instances.map(c=>c.id===r?{...c,model:{...c.model,invocationParameters:[...c.model.invocationParameters,l]}}:c)})},deleteInvocationParameterInput:({instanceId:r,invocationParameterInputInvocationName:l})=>{i().instances.find(d=>d.id===r)&&a({instances:i().instances.map(d=>d.id===r?{...d,model:{...d.model,invocationParameters:d.model.invocationParameters.filter(c=>c.invocationName!==l)}}:d)})},...n}))),q2=n=>{const t=a=>({setCredential:({provider:i,value:r})=>{a({[i]:r})},...n});return Ve()(wt(ze(t),{name:"arize-phoenix-credentials"}))},kr=n=>{const t=a=>({markdownDisplayMode:"text",setMarkdownDisplayMode:i=>{a({markdownDisplayMode:i})},traceStreamingEnabled:!0,setTraceStreamingEnabled:i=>{a({traceStreamingEnabled:i})},lastNTimeRangeKey:"7d",setLastNTimeRangeKey:i=>{a({lastNTimeRangeKey:i})},projectsAutoRefreshEnabled:!0,setProjectAutoRefreshEnabled:i=>{a({projectsAutoRefreshEnabled:i})},showSpanAside:!0,setShowSpanAside:i=>{a({showSpanAside:i})},showMetricsInTraceTree:!0,setShowMetricsInTraceTree:i=>{a({showMetricsInTraceTree:i})},modelConfigByProvider:{},setModelConfigForProvider:({provider:i,modelConfig:r})=>{a(l=>({modelConfigByProvider:{...l.modelConfigByProvider,[i]:r}}))},playgroundStreamingEnabled:!0,setPlaygroundStreamingEnabled:i=>{a({playgroundStreamingEnabled:i})},...n});return Ve()(wt(ze(t),{name:"arize-phoenix-preferences"}))},o1=p.createContext(null);function X2({children:n,...t}){const[a]=p.useState(()=>kr(t));return e(o1.Provider,{value:a,children:n})}function pe(n,t){const a=G.useContext(o1);if(!a)throw new Error("Missing PreferencesContext.Provider in the tree");return yt(a,n,t)}function s1(n){return e("div",{onClick:t=>t.stopPropagation(),css:h`
        display: inline-block;
      `,children:e(xt,{css:h`
          color: var(--ac-global-color-primary);
          &:not(:hover) {
            text-decoration: none;
          }
        `,...n})})}const Sr=h`
  display: inline-flex;
  align-items: center;
  background: none;
  color: var(--ac-global-color-primary);
  border: none;
  padding: 0;
  font: inherit;
  cursor: pointer;
  outline: inherit;
  &:hover {
    text-decoration: underline;
  }
`;function J2(n){const{children:t,onClick:a}=n;return s("button",{css:Sr,onClick:a,children:[t," ",e(I,{svg:e(za,{})})]})}function V({href:n,children:t}){return s("a",{href:n,target:"_blank",css:h`
        color: var(--ac-global-color-primary);
        text-decoration: none;
        position: relative;
        &:hover {
          text-decoration: underline;
        }
        .ac-icon-wrap {
          display: inline-block;
          margin-left: 0.1em;
          vertical-align: middle;
          font-size: 1em;
        }
      `,rel:"noreferrer",children:[t,e(I,{svg:e(T.ExternalLinkOutline,{})})]})}const Y2=()=>e("div",{css:h`
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: rgba(0, 0, 0, 0.2);
      `,children:e(Et,{isIndeterminate:!0,"aria-label":"loading"})}),wr=({message:n,size:t})=>s("div",{css:h`
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        width: 100%;
        height: 100%;
        gap: var(--ac-global-dimension-static-size-100);
      `,children:[e(Et,{isIndeterminate:!0,"aria-label":"loading",size:t}),n!=null?e(y,{children:n}):null]});function e0(n){const{width:t="size-1250"}=n;return e(b,{width:t,backgroundColor:"light",borderStartWidth:"thin",borderStartColor:"dark",padding:"size-200",flex:"none",children:e(x,{direction:"column",alignItems:"end",justifyContent:"center",height:"100%",children:n.children})})}const xr=2e3;function Rn({text:n,size:t="compact",disabled:a=!1}){const[i,r]=p.useState(!1),l=p.useCallback(()=>{Tt(n),r(!0),setTimeout(()=>{r(!1)},xr)},[n]);return e("div",{className:"copy-to-clipboard-button",children:s(Z,{delay:0,offset:5,children:[e(F,{variant:"default",disabled:a,icon:e(I,{svg:i?e(T.Checkmark,{}):e(T.ClipboardCopy,{})}),size:t,onClick:l}),e(Y,{children:"Copy"})]})})}h`
  width: var(--trigger-width);
  background-color: var(--ac-global-menu-background-color);
  border-radius: var(--ac-global-rounding-small);
  color: var(--ac-global-text-color-900);
  box-shadow: 0px 4px 10px var(--px-overlay-shadow-color);
  border: 1px solid var(--ac-global-menu-border-color);
  max-height: inherit;
  .react-aria-ListBox {
    display: block;
    width: unset;
    max-height: inherit;
    min-height: unset;
    border: none;
  }
`;h`
  outline: none;
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: var(--ac-global-text-color-900);
  padding: var(--ac-global-dimension-static-size-100)
    var(--ac-global-dimension-static-size-200);
  font-size: var(--ac-global-dimension-static-font-size-100);
  cursor: pointer;
  position: relative;
  & > .ac-icon-wrap.px-menu-item__selected-checkmark {
    height: var(--ac-global-dimension-static-size-200);
    width: var(--ac-global-dimension-static-size-200);
  }
  &[href] {
    text-decoration: none;
    cursor: pointer;
  }
  &[data-selected] {
    i {
      color: var(--ac-global-color-primary);
    }
  }
  &[data-focused],
  &[data-hovered] {
    background-color: var(--ac-global-menu-item-background-color-hover);
  }

  &[data-disabled] {
    cursor: not-allowed;
    color: var(--ac-global-color-text-30);
  }
  &[data-focus-visible] {
    outline: none;
  }
`;function Tr(n){const{size:t=28}=n;return s("svg",{xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",viewBox:"0 0 305.92 350.13",width:t,height:t,css:h`
        .cls-1 {
          fill: url(#linear-gradient);
        }

        .cls-2 {
          fill: url(#Fade_to_Black_2-2);
        }

        .cls-2,
        .cls-3 {
          opacity: 0.5;
        }

        .cls-4 {
          fill: #fedbb5;
        }

        .cls-5 {
          fill: #e5b4a6;
        }

        .cls-6 {
          fill: url(#Fade_to_Black_2);
        }

        .cls-6,
        .cls-7,
        .cls-8,
        .cls-9,
        .cls-10,
        .cls-11,
        .cls-12,
        .cls-13,
        .cls-14 {
          opacity: 0.4;
        }

        .cls-3 {
          fill: url(#linear-gradient-10);
        }

        .cls-7 {
          fill: url(#linear-gradient-6);
        }

        .cls-8 {
          fill: url(#linear-gradient-3);
        }

        .cls-9 {
          fill: url(#linear-gradient-4);
        }

        .cls-10 {
          fill: url(#linear-gradient-2);
        }

        .cls-11 {
          fill: url(#linear-gradient-7);
        }

        .cls-12 {
          fill: url(#linear-gradient-5);
        }

        .cls-13 {
          fill: url(#linear-gradient-8);
        }

        .cls-14 {
          fill: url(#linear-gradient-9);
        }
      `,children:[s("defs",{children:[s("linearGradient",{id:"linear-gradient",x1:"45.77",y1:"21.43",x2:"201.89",y2:"291.83",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#18bab6"}),e("stop",{offset:".5",stopColor:"#00adee"}),e("stop",{offset:"1",stopColor:"#0095c4"})]}),s("linearGradient",{id:"linear-gradient-2",x1:"197.65",y1:"237.84",x2:"65.97",y2:"9.77",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#fdfdfe",stopOpacity:"0"}),e("stop",{offset:".11",stopColor:"#fdfdfe",stopOpacity:".17"}),e("stop",{offset:".3",stopColor:"#fdfdfe",stopOpacity:".42"}),e("stop",{offset:".47",stopColor:"#fdfdfe",stopOpacity:".63"}),e("stop",{offset:".64",stopColor:"#fdfdfe",stopOpacity:".79"}),e("stop",{offset:".78",stopColor:"#fdfdfe",stopOpacity:".9"}),e("stop",{offset:".91",stopColor:"#fdfdfe",stopOpacity:".97"}),e("stop",{offset:"1",stopColor:"#fdfdfe"})]}),e("linearGradient",{id:"linear-gradient-3",x1:"158.8",y1:"236.43",x2:"63.93",y2:"72.09",xlinkHref:"#linear-gradient-2"}),e("linearGradient",{id:"linear-gradient-4",x1:"145.73",y1:"248.43",x2:"92.77",y2:"156.7",xlinkHref:"#linear-gradient-2"}),e("linearGradient",{id:"linear-gradient-5",x1:"147.93",y1:"266.95",x2:"114.95",y2:"209.83",xlinkHref:"#linear-gradient-2"}),s("linearGradient",{id:"linear-gradient-6",x1:"92.25",y1:"261.75",x2:"92.25",y2:"321.91",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#231f20"}),e("stop",{offset:".03",stopColor:"#231f20",stopOpacity:".9"}),e("stop",{offset:".22",stopColor:"#231f20",stopOpacity:".4"}),e("stop",{offset:".42",stopColor:"#231f20",stopOpacity:".1"}),e("stop",{offset:".65",stopColor:"#231f20",stopOpacity:"0"})]}),s("linearGradient",{id:"Fade_to_Black_2","data-name":"Fade to Black 2",x1:"159.88",y1:"256.07",x2:"159.88",y2:"286.75",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#231f20"}),e("stop",{offset:"1",stopColor:"#231f20",stopOpacity:"0"})]}),s("linearGradient",{id:"linear-gradient-7",x1:"174.69",y1:"176.58",x2:"174.69",y2:"151.5",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#231f20"}),e("stop",{offset:".03",stopColor:"#231f20",stopOpacity:".95"}),e("stop",{offset:".51",stopColor:"#231f20",stopOpacity:".26"}),e("stop",{offset:".81",stopColor:"#231f20",stopOpacity:"0"})]}),s("linearGradient",{id:"linear-gradient-8",x1:"229.53",y1:"195.1",x2:"229.53",y2:"134.41",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#231f20"}),e("stop",{offset:".18",stopColor:"#231f20",stopOpacity:".48"}),e("stop",{offset:".38",stopColor:"#231f20",stopOpacity:".12"}),e("stop",{offset:".58",stopColor:"#231f20",stopOpacity:"0"})]}),e("linearGradient",{id:"Fade_to_Black_2-2","data-name":"Fade to Black 2",x1:"286",y1:"242.89",x2:"265.05",y2:"206.61",xlinkHref:"#Fade_to_Black_2"}),e("linearGradient",{id:"linear-gradient-9",x1:"302.87",y1:"232.93",x2:"271.49",y2:"178.58",xlinkHref:"#linear-gradient-2"}),s("linearGradient",{id:"linear-gradient-10",x1:"221.39",y1:"223.73",x2:"267.07",y2:"197.36",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#231f20"}),e("stop",{offset:".31",stopColor:"#231f20",stopOpacity:".5"}),e("stop",{offset:".67",stopColor:"#231f20",stopOpacity:".13"}),e("stop",{offset:"1",stopColor:"#231f20",stopOpacity:"0"})]})]}),s("g",{id:"Layer_1-2","data-name":"Layer 1",children:[e("path",{className:"cls-1",d:"m305.42,218.76c-.9-4.06-2.96-7.8-6.14-11.13-1.22-1.28-2.59-2.48-4.07-3.58-.72-.53-1.48-1.03-2.26-1.52-.97-.6-1.98-1.19-3.07-1.75-4.05-2.08-7.5-4.17-10.53-6.41-1.23-.91-2.42-1.86-3.53-2.83-2.71-2.37-4.53-4.38-5.88-6.53-.44-.69-.83-1.44-1.2-2.14-.16-.31-.39-.57-.66-.77-.49-.36-1.12-.52-1.75-.4-.97.18-1.72.97-1.83,1.96-.09.76-.08,1.57.02,2.41.06.5-.2.96-.66,1.17-.11.05-.22.08-.33.09-.64.08-1.23.43-1.6.96-.37.54-.48,1.2-.33,1.83.14.55.32.93.48,1.24l.14.28c.1.19.2.39.31.58.3.57.62,1.15,1,1.71.71,1.04,1.52,2.07,2.46,3.18.3.35.35.86.13,1.27-.22.41-.68.64-1.14.58-5.37-.73-10.17-1.93-14.65-3.59-.51-.19-1.03-.37-1.53-.57-4.02-1.69,3.23-8.92,6.55-14.03,14.55-22.37,17.56-48,17.68-73.93.12-25.07-2.59-49.78-7.57-74.18v-.04c-3.25-20.44-6.01-28.12-7.74-30.97-.37-.76-.78-1.22-1.21-1.45-.48-.32-.73-.17-.73-.17-.93.03-2.01.87-3.3,2.22-5.42,5.71-5.12,12.49-3.62,19.58,6.85,32.22,12.01,64.63,9.66,97.75-1.61,22.83-5.87,44.82-21.82,62.69-.96,1.08-1.99,2.08-3.02,3.1-1.2,1.17-3.04,3.46-4.42,2.51-1.84-1.28-.2-3.9.37-5.25,9.35-21.89,12.04-44.77,10.6-68.36-.03-.55-.09-1.09-.13-1.63l.02-.03c-.04-.44-.08-.85-.12-1.28-.24-3.12-.53-6.23-.92-9.33-4.02-37.42-8.84-39.84-8.84-39.84h0c-.32-.28-.72-.51-1.25-.62-2.53-.53-3.92,1.7-5.04,3.39-5.07,7.6-2.83,15.67-1.19,23.67,5.73,28.01,5.82,55.75-4.02,83-.9,2.48-1.98,4.9-3.12,7.28-1.2,2.53-1.99,5.7-6.12,4.34-3.86-1.28-2.78-4.2-2.27-6.87,1.29-6.79,2.33-13.59,2.98-20.42l.02.04c.06-.67.1-1.32.16-1.98.1-1.18.17-2.36.24-3.54.06-.99.11-1.96.15-2.91.02-.49.04-.97.06-1.46.78-21.63-2.85-31.46-4.23-34.37-.15-.36-.32-.68-.51-.97h0s0,0,0,0c-1.43-2.14-3.8-1.89-5.84.13-3.76,3.72-5.84,8.1-4.88,13.62,2.8,16.09,1.16,32.03-1.84,47.9-.41,2.13-1.36,6-5.9,5.01-3.09-.68-3.81-2.01-3.99-4.69.03-2.03.01-4.05-.06-6.08,0-.05,0-.1,0-.15h0c-.01-.29-.03-.57-.04-.86v-.02c0-.14,0-.27-.02-.4-.13-2.76-.36-5.53-.7-8.3-.03-.27-.08-.53-.12-.79-1.74-15.62-4-17.13-4-17.13-1.45-1.88-3.71-1.57-5.67.38-3.76,3.72-5.67,8.08-4.88,13.62.57,4.06.43,2.81.84,6.34.33,1.82.66,5.13.69,6.19-.09.94-.32,1.76-.9,2.37-1.92,2.07-5.02-.05-7.37-1.02-45.52-18.84-84.49-45.28-118.5-78.71C29.51,74.47,6.74,46.89,6.74,46.89h0c-.84-.99-1.91-1.55-3.53-.85C.24,47.32.33,51.13.06,54.33c-.54,6.41,2.88,11.07,6.62,15.42,51.36,59.92,114.05,102.98,189.7,124.51l13.61,3.61c.16.04.32.08.48.12.03,0,.05.02.07.02l11.72,3.11.32.08c-.38.11-.82.2-1.28.28-12.9,2.55-38.42-2.14-58.91-6.92-10.15-2.13-20.1-4.71-29.85-7.79-.45-.13-.69-.2-.69-.2v-.02c-37.88-12.05-72.58-31.59-102.92-61.4-2.87-2.82-5.54-5.86-8.15-8.95-2.41-2.86-7.36-8.84-9.06-10.89-.19-.27-.39-.51-.6-.73h0s0,0,0,0c-.52-.53-1.14-.87-2.03-.66-2.12.49-2.72,2.67-3.11,4.51-1.55,7.39.8,13.59,5.76,19.15,31.09,34.84,70.09,57.1,113.9,71.7,24.88,8.29,50.46,13.32,76.57,16.54-15.56,5.04-31.58,6.57-47.72,6.17-31.26-.78-60.57-8.29-88.12-21.68-10.16-5.22-19.62-11.05-22.11-12.6-1.43-.98-2.9-1.57-4.36-.45-2.74,2.12-.85,5.85.03,8.76,1.69,5.6,5.58,9.47,10.63,12.14,44.88,23.74,92.26,33.22,142.71,24.8,5.11-.85,9.95-1.79,15.29-3.59-8.43,7.3-18.2,12.06-28.47,15.82-31.59,11.56-62.98,11.09-94.25,3.27-10.03-2.69-21.68-7.05-21.68-7.05h0c-1.68-.73-3.34-.99-4.64.87-2.28,3.27-.29,6.66,1.68,9.74,4.67,7.27,13.68,7.98,20.81,10.44,2.44.77-4.2,5.21-6.34,6.84-10.34,7.91-20.46,15.14-30.76,22.8l-6.74,4.97h0c-1.16.8-2.18,1.69-1.64,3.37.61,1.88,2.57,2.22,4.47,2.62,7.37,1.53,13.66-.92,19.48-5.27,12.48-9.35,25.18-18.41,37.39-28.11,4.64-3.7,8.86-3.39,15.21-1.74-15.88,11.97-30.73,23.17-45.6,34.36-15.08,11.35-30.18,22.7-45.28,34.03l-9.98,7.38c-.15.1-.29.21-.43.32l-.15.11h0c-.85.68-1.48,1.44-1.3,2.44.4,2.25,3.05,2.81,5.21,3.18,8.92,1.54,14.44-1.82,20.54-6.39,30.5-22.9,61.12-45.64,91.44-68.76,6.8-5.18,13.79-8.11,23.61-7.01-8.36,6.25-16.38,12.24-24.3,18.16l-21.51,15.92c-.15.11-.3.22-.45.33h-.02c-1.14.9-1.94,1.96-1.49,3.53.82,2.84,4.24,3.18,7.15,3.62,5.34.8,9.87-1.09,14.06-4.21,2.41-1.8,4.84-3.57,7.28-5.33h0s32.84-26.08,32.84-26.08c0,0,7.76-5.54,16.74-10.64.8-.5,1.61-1,2.41-1.49.34-.15,1.2-.54,2.48-1.16.97-.5,1.93-.99,2.89-1.44,1.41-.72,3.05-1.59,4.88-2.59,5.3-2.2,20.44-9.27,32.98-22.62,5.96-4.6,14.34-10.6,20.87-13.49h0s.04-.02.04-.02c.5-.22.98-.42,1.46-.6h0s.03,0,.06-.02c.32-.12.63-.23.93-.33l.84-.33c2.36-.67,6.22-.92,6.71,4.29.09,1.28.06,2.59-.08,3.97-.11,1.04-.3,2.14-.46,3.02-.15.85.2,1.71.88,2.21.11.08.22.15.34.21.9.44,1.99.24,2.66-.51.25-.28.51-.55.77-.83,3.22-3.38,6.47-5.73,9.95-7.16,5.07-2.1,10.2-2.11,15.68-.02,2.6.99,5.05,2.34,7.48,4.14,1.03.76,2.08,1.62,3.11,2.55.61.56,1.22,1.18,1.76,1.72l.09.09.44.45c.08.08.17.16.26.22.52.38,1.18.53,1.82.39.75-.16,1.37-.69,1.63-1.41.05-.14.1-.28.15-.41,1.56-4.59,1.87-8.82.97-12.93Z"}),e("path",{className:"cls-4",d:"m208.42,169.5c-.37,2.28-.76,4.55-1.19,6.82.43-2.27.82-4.55,1.19-6.82h0Z"}),e("path",{className:"cls-4",d:"m248.79,194.81c.16.07.33.13.5.19-.17-.06-.33-.13-.5-.19"}),e("path",{className:"cls-4",d:"m230.37,180.81s0,0,0,.01c0,0,0,0,0-.01"}),e("path",{className:"cls-4",d:"m230.5,180.5s-.03.06-.04.1c.01-.03.03-.07.04-.1"}),e("path",{className:"cls-4",d:"m255.55,180.46s-.05.08-.08.13c.03-.04.05-.08.08-.13"}),e("path",{className:"cls-4",d:"m215.62,178.85c-.28.59-.54,1.22-.82,1.82.28-.59.54-1.22.82-1.82"}),e("path",{className:"cls-4",d:"m188.53,177.51s.01,0,.02,0c0,0-.01,0-.02,0"}),e("polyline",{className:"cls-4",points:"184.47 175.68 184.47 175.69 184.47 175.68"}),e("polyline",{className:"cls-4",points:"184.45 175.66 184.46 175.66 184.45 175.66"}),e("polyline",{className:"cls-4",points:"184.43 175.62 184.44 175.64 184.43 175.62"}),e("path",{className:"cls-4",d:"m184.42,175.6s0,0,0,.01c0,0,0,0,0-.01"}),e("path",{className:"cls-4",d:"m184.39,175.57s.01.02.02.03c0-.01-.01-.02-.02-.03"}),e("path",{className:"cls-4",d:"m183.65,172.72s0,.01,0,.02c0,0,0-.01,0-.02"}),e("path",{className:"cls-4",d:"m193.79,171c-.08.46-.17.91-.26,1.37.09-.46.17-.91.26-1.37"}),e("path",{className:"cls-4",d:"m168.79,167.86c-.3.32-.63.54-.99.68.35-.14.68-.36.99-.68"}),e("path",{className:"cls-5",d:"m184.47,175.69c.25.35.57.64.99.9h0c-.42-.25-.74-.55-.99-.9m-.02-.03s0,.01.01.02c0,0,0-.01-.01-.02m-.02-.02v.02s0-.01,0-.02m-.01-.02s0,0,0,0c0,0,0,0,0,0m-.01-.01s0,0,0,0c0,0,0,0,0,0m-.02-.04s0,0,0,0c0,0,0,0,0,0m-.74-2.82s0,.01,0,.01c0,0,0,0,0-.01m0-.06h0s0,.03,0,.04c0-.01,0-.02,0-.04m-19.74-4.71s.03.01.04.02c.95.41,1.9.74,2.79.74.37,0,.73-.06,1.06-.19-.34.13-.69.19-1.06.19-.9,0-1.87-.34-2.83-.75m19.61-2.97s0,.01,0,.02c0,0,0-.01,0-.02"}),e("path",{className:"cls-5",d:"m249.29,195c.08.03.16.06.24.09h0c-.08-.03-.16-.06-.24-.09m-18.14-7.32s0,0-.01,0c0,0,.01,0,.01,0m-2.75-1.47c0,.64.22,1.23.85,1.66.23.16.47.23.71.23.38,0,.77-.16,1.17-.41-.4.25-.79.41-1.17.41-.25,0-.49-.07-.72-.23-.63-.43-.85-1.02-.85-1.66m1.33-3.84c-.04.08-.07.17-.11.25.04-.08.07-.17.11-.25m.64-1.54c-.21.51-.42,1.02-.64,1.53.22-.51.43-1.02.64-1.53m.09-.23c-.03.07-.06.14-.09.22.03-.07.06-.14.09-.22m25.01-.01s-.01.02-.02.03c0-.01.01-.02.02-.03m.1-.16s-.01.02-.02.03c0-.01.01-.02.02-.03m-25.03-.01s-.03.06-.04.09c.01-.03.02-.06.04-.09m-23.84-.69c0,1.46.59,2.74,2.81,3.47.68.23,1.28.33,1.8.33,1.87,0,2.77-1.32,3.5-2.85-.73,1.53-1.62,2.85-3.5,2.85-.52,0-1.11-.1-1.8-.33-2.22-.73-2.8-2.01-2.81-3.47m-18.18-2.21h.01-.01m3.63-1.49c-.67.87-1.65,1.51-3.14,1.51-.15,0-.3,0-.46-.02.16.01.31.02.46.02,1.48,0,2.47-.63,3.14-1.51m28.75-10.95s-.01,0-.02,0c-.66,2.17-1.35,4.33-2.13,6.49-.9,2.48-1.98,4.9-3.12,7.28h0c1.13-2.38,2.22-4.8,3.12-7.28.78-2.16,1.5-4.33,2.16-6.49m-25.9-1.2c-.36,2.38-.76,4.75-1.2,7.12.44-2.37.84-4.75,1.2-7.12h0m58.07-11.39s0,0,0,0c-3.26,10.69-8.32,20.76-16.37,29.77-.96,1.08-1.99,2.08-3.02,3.1h0c1.03-1.01,2.06-2.02,3.02-3.1,8.05-9.02,13.12-19.09,16.38-29.78"}),e("path",{className:"cls-10",d:"m4.56,45.73c-.4,0-.85.09-1.34.31-2.11.91-2.68,3.11-2.93,5.45,11.33,14.85,56.07,69.62,126.46,107.18,0,0,68.91,36.38,138.24,40.31-5.37-.73-10.17-1.93-14.65-3.59-.26-.1-.53-.19-.8-.29h0c-25.19-5.44-46.66-12.25-61.84-17.7.29.06.57.1.84.13-.28-.03-.57-.07-.88-.14-.92-.2-1.62-.46-2.17-.79-12.01-4.39-19.66-7.76-21.51-8.59-.88-.38-1.75-.83-2.53-1.15-45.52-18.84-84.49-45.28-118.5-78.71C29.51,74.47,6.74,46.89,6.74,46.89h0c-.58-.68-1.28-1.16-2.18-1.16"}),e("path",{className:"cls-8",d:"m9.57,103.87c-.16,0-.33.02-.51.06-2.12.49-2.72,2.67-3.11,4.51-.07.33-.13.66-.18.99,35.19,47.67,82.41,67.15,82.41,67.15,47.15,22.21,85.84,26.69,109.4,26.69,9.75,0,16.91-.77,21.01-1.37-1.87.21-3.93.31-6.14.31-13.81,0-33.56-3.79-50.06-7.64-10.15-2.13-20.1-4.71-29.85-7.79-.45-.13-.69-.2-.69-.2v-.02c-37.88-12.05-72.58-31.59-102.92-61.4-2.87-2.82-5.54-5.86-8.15-8.95-2.41-2.86-7.36-8.84-9.06-10.89-.19-.27-.39-.51-.6-.73h0s0,0,0,0c-.41-.42-.9-.72-1.53-.72"}),e("path",{className:"cls-9",d:"m41.57,186.66c-.56,0-1.13.18-1.69.61-2.39,1.85-1.26,4.91-.35,7.6,17.64,10.71,58.1,31.53,106.02,31.53,18.09,0,37.24-2.97,56.64-10.57-14,4.54-28.37,6.23-42.87,6.23-1.61,0-3.23-.02-4.85-.06-31.26-.78-60.57-8.29-88.12-21.68-10.16-5.22-19.62-11.05-22.11-12.6-.88-.6-1.78-1.06-2.68-1.06"}),e("path",{className:"cls-12",d:"m205.41,231.93c-7.68,5.89-16.32,9.97-25.34,13.27-16.95,6.2-33.84,8.94-50.68,8.94-14.56,0-29.08-2.05-43.57-5.67-10.03-2.69-21.68-7.05-21.68-7.05h0c-.74-.32-1.47-.55-2.17-.55-.9,0-1.74.38-2.47,1.42-1.06,1.52-1.2,3.07-.85,4.6,11.13,5.17,35,14.36,64.11,14.36,25.24,0,54.41-6.9,82.66-29.31"}),e("path",{className:"cls-7",d:"m130.35,268.02c-27.34,0-48.01-5.54-50.62-6.27.77.23,1.52.46,2.26.71,2.44.77-4.2,5.21-6.34,6.84-7.65,5.85-15.17,11.32-22.73,16.88h23.2c7.31-5.4,14.6-10.84,21.72-16.5,2.65-2.11,5.15-2.91,7.99-2.91,2.15,0,4.48.46,7.22,1.17-15.88,11.97-30.73,23.17-45.6,34.36-8.69,6.54-17.39,13.07-26.09,19.61h23.34c20.99-15.71,41.97-31.42,62.82-47.32,4.81-3.67,9.71-6.2,15.64-6.98-4.39.29-8.67.41-12.8.41Z"}),e("path",{className:"cls-6",d:"m125.47,286.75h22.55l16.66-13.24s7.76-5.54,16.74-10.64c.8-.5,1.61-1,2.41-1.49.34-.15,1.2-.54,2.48-1.16.97-.5,1.93-.99,2.89-1.44,1.46-.75,3.18-1.65,5.09-2.71-16.08,6.73-32.54,10.02-47.79,11.29.21,0,.42,0,.63,0,1.28,0,2.61.07,3.99.23-8.36,6.25-16.38,12.24-24.3,18.16l-1.36,1Z"}),e("path",{className:"cls-11",d:"m183.65,172.69c.03-2.03.01-4.05-.06-6.08v-.15s0,0,0,0c-.01-.29-.03-.57-.04-.86v-.02s-.02-.4-.02-.4c-.08-1.7-.21-3.41-.37-5.12-5.38-2.26-10.45-5.15-15.12-8.56.03.48.05.96.12,1.46.57,4.06.43,2.81.84,6.34.33,1.82.66,5.13.69,6.19-.09.94-.32,1.76-.9,2.37-.59.63-1.29.87-2.05.87-.9,0-1.87-.34-2.83-.75,1.78.8,9.45,4.19,21.55,8.61-1.3-.79-1.69-2.01-1.81-3.9Z"}),e("path",{className:"cls-13",d:"m271.38,134.41c-5.03,7.01-11.24,13.15-18.32,18.08-3.26,10.69-8.32,20.76-16.37,29.77-.96,1.08-1.99,2.08-3.02,3.1-1,.97-2.45,2.73-3.7,2.73-.25,0-.49-.07-.72-.23-1.84-1.28-.2-3.9.37-5.25,3.02-7.06,5.33-14.23,7.04-21.49-5.04,1.89-10.33,3.22-15.79,3.96-.66,2.17-1.35,4.33-2.13,6.49-.9,2.48-1.98,4.9-3.12,7.28-1,2.11-1.72,4.67-4.32,4.67-.52,0-1.11-.1-1.8-.33-3.86-1.28-2.78-4.2-2.27-6.87.67-3.54,1.27-7.08,1.79-10.63-4.8-.15-9.49-.77-14.03-1.82-.43,2.83-.92,5.67-1.46,8.49-.36,1.89-1.16,5.17-4.53,5.17-.4,0-.85-.05-1.33-.15,15.19,5.45,36.66,12.26,61.84,17.71h0c-.25-.1-.5-.19-.74-.29-4.02-1.69,3.23-8.92,6.55-14.03,9.35-14.37,13.92-30.09,16.03-46.36Z"}),e("path",{className:"cls-2",d:"m267.61,212.35c-3.15,0-6.32.3-9.44.88-.59.11-1.17.16-1.72.16-.89,0-1.72-.13-2.5-.37.13.16.25.3.37.47,1.37,1.9,2.08,3.98,2.35,6.14.34.37.63.84.86,1.43h0s0,.02.01.03c0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,0,0,.01,0,0,0,0,0,.01,0,0,0,.01,0,.01,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,0,0,0v.02s0,0,0,.01c0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.02,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,.01,0,.02,0,.03,0,0,0,0,0,0,0,0,0,0,0,.01t0,0s0,.02,0,.03c0,0,0,0,0,0,0,0,0,.02,0,.03,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,0,0,.02,0,0,0,.01,0,.02,0,0,0,.01,0,.01,0,0,0,.01,0,.01,0,0,0,.01,0,.02,0,0,0,.01,0,.01,0,0,0,0,0,.02s0,.01,0,.02c0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,.01,0,.01s0,.01,0,.01c0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.02,0,.03,0,0,0,0,0,0,0,0,0,.02,0,.03,0,0,0,0,0,0,0,0,0,.02,0,.02,0,0,0,0,0,0,0,.01,0,.02,0,.03,0,0,0,0,0,0,0,0,0,.02,0,.03,0,0,0,0,0,0,0,0,0,.02,0,.03h0s0,.03,0,.04h0s0,.02,0,.03h0s0,.03,0,.03h0s0,.03,0,.04h0s0,.02,0,.03h0s0,.02,0,.03h0s0,.02,0,.03h0s0,.02,0,.04c0,0,0,0,0,0,0,.03.01.07.01.1h0s0,.03,0,.04h0s0,.07.01.11h0s0,.02,0,.04h0s0,.03,0,.04h0s0,.05,0,.07h0s0,.02,0,.04h0s0,.03,0,.04h0s0,.03,0,.04h0c.03.5.05,1,.05,1.52,0,.8-.04,1.61-.13,2.46-.11,1.04-.3,2.14-.46,3.02-.02.13-.04.27-.04.4,0,.71.34,1.39.92,1.81l.34.21c.32.16.66.23,1,.23.62,0,1.23-.26,1.67-.74.25-.28.51-.55.77-.83,3.22-3.38,6.47-5.73,9.95-7.16,2.54-1.05,5.1-1.58,7.71-1.58s5.24.52,7.96,1.56c2.6.99,5.05,2.34,7.48,4.14,1.03.76,2.08,1.62,3.11,2.55.61.56,1.22,1.18,1.76,1.72l.09.09.44.45.26.22c.38.28.83.43,1.3.44-2.15-4.61-4.88-8.9-8.73-12.24-7.28-6.31-16.46-8.98-25.8-8.98"}),e("path",{className:"cls-14",d:"m266.74,181.67l-.41.04c-.97.18-1.72.97-1.83,1.96-.09.76-.08,1.57.02,2.41.03.26-.03.52-.16.73,3.89,5.78,12.33,16.03,25.15,19.91,0,0,19.81,10.36,14.8,25.38h0l.15-.41c1.56-4.59,1.87-8.82.97-12.93-.9-4.06-2.96-7.8-6.14-11.13-1.22-1.28-2.59-2.48-4.07-3.58-.72-.53-1.48-1.03-2.26-1.52-.97-.6-1.98-1.19-3.07-1.75-4.05-2.08-7.5-4.17-10.53-6.41-1.23-.91-2.42-1.86-3.53-2.83-2.71-2.37-4.53-4.38-5.88-6.53-.44-.69-.83-1.44-1.2-2.14-.16-.31-.39-.57-.66-.77-.38-.28-.85-.44-1.34-.44"}),e("path",{className:"cls-3",d:"m241.61,223.53l4.01-2.33,16.87-22.61s-9.24-1.75-13.7-3.78c0,0-4.64,21.12-21.73,38.76l6.3-4.67c2.51-1.76,4.79-3.29,8.24-5.37Z"})]})]})}const Mr=h`
  padding: var(--ac-global-dimension-static-size-100)
    var(--ac-global-dimension-static-size-100)
    var(--ac-global-dimension-static-size-100) 12px;
  border-bottom: 1px solid var(--ac-global-color-grey-200);
  flex: none;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
`,Ir=h`
  padding: var(--ac-global-dimension-static-size-200)
    var(--ac-global-dimension-static-size-100);
  flex: none;
  display: flex;
  flex-direction: column;
  background-color: var(--ac-global-color-grey-75);
  border-right: 1px solid var(--ac-global-color-grey-200);
  box-sizing: border-box;
  height: 100vh;
  position: fixed;
  width: var(--px-nav-collapsed-width);
  z-index: 2; // Above the content
  transition:
    width 0.15s cubic-bezier(0, 0.57, 0.21, 0.99),
    box-shadow 0.15s cubic-bezier(0, 0.57, 0.21, 0.99);
  &[data-expanded="true"] {
    width: var(--px-nav-expanded-width);
    box-shadow: 0 0 30px 0 rgba(0, 0, 0, 0.2);
  }
`,un=h`
  width: 100%;
  color: var(--ac-global-color-grey-500);
  background-color: transparent;
  border-radius: var(--ac-global-rounding-small);
  display: flex;
  flex-direction: row;
  align-items: center;
  overflow: hidden;
  transition:
    color 0.2s ease-in-out,
    background-color 0.2s ease-in-out;
  text-decoration: none;

  &.active {
    color: var(--ac-global-color-grey-1200);
    background-color: var(--ac-global-color-primary-300);
  }
  &:hover:not(.active) {
    color: var(--ac-global-color-grey-1200);
    background-color: var(--ac-global-color-grey-200);
  }
  & > .ac-icon-wrap {
    padding: var(--ac-global-dimension-size-50);
    display: inline-block;
  }
  .ac-text {
    white-space: nowrap;
  }
`,Ar=n=>h`
  color: var(--ac-global-text-color-900);
  font-size: ${n.typography.sizes.large.fontSize}px;
  text-decoration: none;
  margin: 0 0 var(--ac-global-dimension-static-size-200) 0;
`,Er=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 24 24",children:s("g",{"data-name":"Layer 2",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M12 1A10.89 10.89 0 0 0 1 11.77 10.79 10.79 0 0 0 8.52 22c.55.1.75-.23.75-.52v-1.83c-3.06.65-3.71-1.44-3.71-1.44a2.86 2.86 0 0 0-1.22-1.58c-1-.66.08-.65.08-.65a2.31 2.31 0 0 1 1.68 1.11 2.37 2.37 0 0 0 3.2.89 2.33 2.33 0 0 1 .7-1.44c-2.44-.27-5-1.19-5-5.32a4.15 4.15 0 0 1 1.11-2.91 3.78 3.78 0 0 1 .11-2.84s.93-.29 3 1.1a10.68 10.68 0 0 1 5.5 0c2.1-1.39 3-1.1 3-1.1a3.78 3.78 0 0 1 .11 2.84A4.15 4.15 0 0 1 19 11.2c0 4.14-2.58 5.05-5 5.32a2.5 2.5 0 0 1 .75 2v2.95c0 .35.2.63.75.52A10.8 10.8 0 0 0 23 11.77 10.89 10.89 0 0 0 12 1","data-name":"github"})]})});function c1(n){return s("a",{href:n.href,target:"_blank",css:un,rel:"noreferrer",children:[n.icon,e(y,{children:n.text})]})}function n0(){return e(c1,{href:"https://github.com/arize-ai/phoenix",icon:e(I,{svg:e(Er,{})}),text:"Repository"})}function t0(){return e(c1,{href:"https://docs.arize.com/phoenix",icon:e(I,{svg:e(T.BookOutline,{})}),text:"Documentation"})}function a0(){const{theme:n,setTheme:t}=Q(),a=n==="dark";return s("button",{css:un,onClick:()=>t(a?"light":"dark"),className:"button--reset",children:[e(I,{svg:a?e(T.MoonOutline,{}):e(T.SunOutline,{})}),e(y,{children:a?"Dark":"Light"})]})}function i0(){return e(xt,{to:"/",css:Ar,title:`version: ${window.Config.platformVersion}`,children:e(Tr,{})})}function r0({children:n}){return e("nav",{css:Mr,children:n})}function l0({children:n}){const[t,a]=p.useState(!1);return e("nav",{"data-expanded":t,css:Ir,onMouseOver:()=>{a(!0)},onMouseOut:()=>{a(!1)},children:n})}function o0(n){return s(ra,{to:n.to,css:un,children:[n.icon,e(y,{children:n.text})]})}function s0(n){return s("button",{className:"button--reset",css:un,onClick:n.onClick,children:[n.icon,e(y,{children:n.text})]})}function Dr(n){var t;return typeof n.handle=="object"&&typeof((t=n.handle)==null?void 0:t.crumb)=="function"}function c0(){const n=Mt(),a=la().filter(Dr);return e(Ra,{onAction:i=>{n(a[Number(i)].pathname)},children:a.map((i,r)=>e(P,{children:i.handle.crumb(i.data)},r))})}function Pr(n){var g;const{theme:t}=Q(),{jsonSchema:a,optionalLint:i,...r}=n,l=t==="light"?zt:He,[o,d]=G.useState(0);p.useEffect(()=>{d(f=>f+1)},[a]);const c=(g=n.value)==null?void 0:g.length,u=!i||c&&c>0,m=p.useMemo(()=>{const f=[Rt(),Kt.lineWrapping];return u&&f.push(wn(Vt())),a&&f.push(wn(Ja(),{needsRefresh:Xa}),Ya.data.of({autocomplete:ei()}),ni(ti()),ai(a)),f},[a,u]);return e($e,{value:n.value,extensions:m,editable:!0,theme:l,...r},o)}const Kn=h`
  .cm-content {
    padding: var(--ac-global-dimension-static-size-200) 0;
  }
  .cm-editor,
  .cm-gutters {
    background-color: transparent;
  }
`,d1=h`
  position: relative;
  .copy-to-clipboard-button {
    position: absolute;
    top: var(--ac-global-dimension-size-100);
    right: var(--ac-global-dimension-size-100);
    z-index: 1;
  }
`;function Or(n){const{theme:t}=Q(),a=t==="light"?void 0:He;return e($e,{value:n.value,extensions:[Rt(),Kt.lineWrapping,wn(Vt())],editable:!1,theme:a,...n,basicSetup:{lineNumbers:!0,foldGutter:!0,bracketMatching:!0,syntaxHighlighting:!0,highlightActiveLine:!1,highlightActiveLineGutter:!1},css:Kn})}function _r(n){const{theme:t}=Q(),a=t==="light"?void 0:He;return e($e,{value:n.value,extensions:[ii()],editable:!1,theme:a,...n,basicSetup:{lineNumbers:!1,foldGutter:!1,bracketMatching:!0,syntaxHighlighting:!0,highlightActiveLine:!1,highlightActiveLineGutter:!1},css:Kn})}function W(n){const{value:t}=n;return s("div",{className:"python-code-block",css:d1,children:[e(Rn,{text:t}),e(_r,{value:t})]})}function B({children:n,...t}){return e(b,{borderColor:"light",borderWidth:"thin",borderRadius:"small",...t,children:n})}function Fr(n){const{theme:t}=Q(),a=t==="light"?void 0:He;return e($e,{value:n.value,extensions:[ri({typescript:!0})],editable:!1,theme:a,...n,basicSetup:{lineNumbers:!1,foldGutter:!0,bracketMatching:!0,syntaxHighlighting:!0,highlightActiveLine:!1,highlightActiveLineGutter:!1},css:Kn})}const Nr=h`
  &.is-hovered {
    border: 1px solid var(--ac-global-input-field-border-color-active);
  }
  &.is-focused {
    border: 1px solid var(--ac-global-input-field-border-color-active);
  }
  &.is-invalid {
    border: 1px solid var(--ac-global-color-danger);
  }
  border-radius: ${Dt.borderRadius.medium}px;
  border: 1px solid var(--ac-global-input-field-border-color);
  width: 100%;
  .cm-gutters,
  .cm-content,
  .cm-editor {
    border-radius: var(--ac-global-rounding-small);
  }
  box-sizing: border-box;
  .cm-focused {
    outline: none;
  }
  transition: all 0.2s ease-in-out;
`;function Vr({children:n,validationState:t,...a}){const[i,r]=p.useState(!1),[l,o]=p.useState(!1),d=t==="invalid";return e(Ka,{...a,validationState:d?"invalid":"valid",children:e("div",{className:It("json-editor-wrap",{"is-hovered":l,"is-focused":i,"is-invalid":d}),onFocus:()=>r(!0),onBlur:()=>r(!1),onMouseEnter:()=>o(!0),onMouseLeave:()=>o(!1),css:Nr,children:n})})}function d0({language:n,onChange:t}){return s(Re,{defaultValue:n,variant:"inline-button",size:"compact",onChange:a=>{if(a==="Python"||a==="TypeScript")t(a);else throw new Error(`Unknown language: ${a}`)},children:[e(q,{label:"Python",value:"Python",children:"Python"}),e(q,{label:"TypeScript",value:"TypeScript",children:"TypeScript"})]})}const u0=h`
  transition: 250ms linear all;
  background-color: var(--ac-global-color-grey-200);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1.8px;
  --px-resize-handle-size: 8px;
  --px-resize-icon-width: 24px;
  --px-resize-icon-height: 2px;
  outline: none;
  &[data-panel-group-direction="vertical"] {
    height: var(--px-resize-handle-size);
    flex-direction: column;
    &:before,
    &:after {
      width: var(--px-resize-icon-width);
      height: var(--px-resize-icon-height);
    }
  }
  &[data-panel-group-direction="horizontal"] {
    width: var(--px-resize-handle-size);
    flex-direction: row;
    &:before,
    &:after {
      width: var(--px-resize-icon-height);
      height: var(--px-resize-icon-width);
    }
  }

  &:hover {
    background-color: var(--ac-global-color-grey-300);
    border-radius: 4px;
    &:before,
    &:after {
      background-color: var(--ac-global-color-primary);
    }
  }

  &:before,
  &:after {
    content: "";
    color: var(--color-solid-resize-bar);
    flex: 0 0 1rem;
    border-radius: 6px;
    background-color: var(--ac-global-color-grey-300);
    flex: none;
  }
`,m0=n=>h`
  transition: 250ms linear all;
  background-color: var(--ac-global-color-grey-200);
  --px-resize-handle-size: 4px;
  outline: none;
  &[data-panel-group-direction="vertical"] {
    height: var(--px-resize-handle-size);
  }
  &[data-panel-group-direction="horizontal"] {
    width: var(--px-resize-handle-size);
  }

  &:hover {
    background-color: ${n.colors.arizeLightBlue};
  }
`;function zr({color:n}){return e("span",{css:h`
        background-color: ${n};
        display: inline-block;
        width: 0.6rem;
        height: 0.6rem;
        border-radius: 2px;
      `})}const u1=n=>p.useMemo(()=>{const a=n.charCodeAt(0);return At(a%26/26)},[n]);function Rr({annotationName:n}){const t=u1(n);return e(zr,{color:t})}function m1(n){return Math.abs(n)<1e6?ke(",")(n):ke("0.2s")(n)}function ge(n){const t=Math.abs(n);return t===0?"0.00":t<.01?ke(".2e")(n):t<1e3?ke("0.2f")(n):ke("0.2s")(n)}function Kr(n){return ke(".2f")(n)+"%"}function xn(n){return Number.isInteger(n)?m1(n):ge(n)}function mn(n){return t=>typeof t!="number"?"--":n(t)}const $r=mn(m1),p1=mn(ge),ct=mn(xn),Hr=mn(Kr),Br=h`
  border-radius: var(--ac-global-dimension-size-50);
  border: 1px solid var(--ac-global-color-grey-400);
  padding: var(--ac-global-dimension-size-50)
    var(--ac-global-dimension-size-100);
  transition: background-color 0.2s;
  &:hover {
    background-color: var(--ac-global-color-grey-300);
  }
  .ac-icon-wrap {
    font-size: 12px;
  }
`,dt=h`
  display: flex;
  align-items: center;
  .ac-text {
    display: inline-block;
    max-width: 9rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`,Zr=(n,t)=>{switch(t){case"label":return n.label||typeof n.score=="number"&&ge(n.score)||"n/a";case"score":return typeof n.score=="number"&&ge(n.score)||n.label||"n/a";default:O()}};function p0({annotation:n,onClick:t,annotationDisplayPreference:a="score"}){const i=typeof t=="function",r=Zr(n,a);return e("div",{role:i?"button":void 0,css:h(Br,i&&"cursor: pointer;"),"aria-label":i?"Click to view the annotation trace":`Annotation: ${n.name}`,onClick:l=>{l.stopPropagation(),l.preventDefault(),t&&t()},children:s(x,{direction:"row",gap:"size-100",alignItems:"center",children:[e(Rr,{annotationName:n.name}),e("div",{css:dt,children:e(y,{weight:"heavy",textSize:"small",color:"inherit",children:n.name})}),e("div",{css:h(dt,h`
              margin-left: var(--ac-global-dimension-100);
            `),children:e(y,{textSize:"small",children:r})}),i?e(I,{svg:e(T.ArrowIosForwardOutline,{})}):null]})})}function g0({annotation:n,children:t,extra:a,layout:i="vertical",width:r}){return s(Z,{delay:500,offset:3,children:[e(ae,{children:t}),e($a,{UNSAFE_style:{minWidth:r},children:s(x,{direction:i==="horizontal"?"row":"column",alignItems:"center",children:[s(b,{children:[e(y,{weight:"heavy",color:"inherit",textSize:"large",elementType:"h3",children:n.name}),s(b,{paddingTop:"size-50",minWidth:"150px",children:[s(x,{direction:"row",justifyContent:"space-between",children:[e(y,{weight:"heavy",color:"inherit",children:"label"}),e(y,{color:"inherit",children:n.label||"--"})]}),s(x,{direction:"row",justifyContent:"space-between",children:[e(y,{weight:"heavy",color:"inherit",children:"score"}),e(y,{color:"inherit",children:p1(n.score)})]}),n.annotatorKind?s(x,{direction:"row",justifyContent:"space-between",children:[e(y,{weight:"heavy",color:"inherit",children:"annotator kind"}),e(y,{color:"inherit",children:n.annotatorKind})]}):null]}),n.explanation?e(b,{paddingTop:"size-50",children:s(x,{direction:"column",children:[e(y,{weight:"heavy",color:"inherit",children:"explanation"}),e(b,{maxHeight:"300px",overflow:"auto",children:e(y,{color:"inherit",children:n.explanation})})]})}):null]}),a]})})]})}const g1=n=>h`
  font-size: ${n.typography.sizes.medium.fontSize}px;
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  thead {
    position: sticky;
    top: 0;
    z-index: 1;
    tr {
      th {
        padding: ${n.spacing.margin4}px ${n.spacing.margin16}px;
        background-color: var(--ac-global-color-grey-100);
        position: relative;
        text-align: left;
        user-select: none;
        border-bottom: 1px solid var(--ac-global-border-color-default);
        &:not(:last-of-type) {
          border-right: 1px solid var(--ac-global-border-color-default);
        }
        .cursor-pointer {
          cursor: pointer;
        }
        .sort-icon {
          margin-left: ${n.spacing.margin4}px;
          font-size: ${n.typography.sizes.small.fontSize}px;
          vertical-align: middle;
          display: inline-block;
        }
        &:hover .resizer {
          background: var(--ac-global-color-grey-300);
        }
        div.resizer {
          display: inline-block;

          width: 2px;
          height: 100%;
          position: absolute;
          right: 0;
          top: 0;
          cursor: grab;
          z-index: 4;
          touch-action: none;
          &.isResizing,
          &:hover {
            background: var(--ac-global-color-primary);
          }
        }
        // Style action menu buttons in the header
        .ac-button[data-size="compact"][data-childless="true"] {
          padding: 0;
          border: none;
          background-color: transparent;
        }
      }
    }
  }
  tbody:not(.is-empty) {
    tr {
      &:not(:last-of-type) {
        & > td {
          border-bottom: 1px solid var(--ac-global-border-color-default);
        }
      }
      &:hover {
        background-color: rgba(var(--ac-global-color-grey-300-rgb), 0.3);
      }
      & > td {
        padding: ${n.spacing.margin8}px ${n.spacing.margin16}px;
      }
    }
  }
`,h0=h`
  tbody:not(.is-empty) {
    tr {
      & > td {
        border-bottom: 1px solid var(--ac-global-border-color-default);
      }
      & > td:not(:last-of-type) {
        border-right: 1px solid var(--ac-global-border-color-default);
      }
    }
  }
`,f0=n=>h(g1(n),h`
      tbody:not(.is-empty) {
        tr {
          cursor: pointer;
        }
      }
    `),Gr=n=>h`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  padding: ${n.spacing.margin8}px;
  gap: ${n.spacing.margin4}px;
  border-top: 1px solid var(--ac-global-color-grey-300);
`,ut=100;function Qr(n){return n.length>ut?`${n.slice(0,ut)}...`:n}function L0({getValue:n}){const t=n(),a=t!=null&&typeof t=="string"?Qr(t):"--";return e("span",{title:String(t),children:a})}function C0({getValue:n}){const t=n(),a=t!=null&&typeof t=="string"?t:"--";return e("pre",{style:{whiteSpace:"pre-wrap"},children:a})}function b0({getValue:n}){const t=n();if(!fi(t))throw new Error("TimestampCell only supports number or null values.");const a=t!=null?new Date(t).toLocaleString([],{year:"numeric",month:"numeric",day:"numeric",hour:"2-digit",minute:"2-digit"}):"--";return e("time",{title:t!=null?String(t):"",children:a})}function Ur({latencyMs:n,textSize:t="medium",showIcon:a=!0}){const i=p.useMemo(()=>n<3e3?"green-1200":n<8e3?"yellow-1200":n<12e3?"orange-1200":"red-1200",[n]),r=p.useMemo(()=>n<10?ge(n)+"ms":ge(n/1e3)+"s",[n]);return s(x,{direction:"row",alignItems:"center",justifyContent:"start",gap:"size-50",children:[a?e(y,{color:i,textSize:t,children:e(I,{svg:e(T.ClockOutline,{})})}):null,e(y,{color:i,textSize:t,children:r})]})}function y0(n){return s("div",{role:"toolbar",css:h`
        padding: var(--ac-global-dimension-static-size-50)
          var(--ac-global-dimension-static-size-200);
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        gap: var(--ac-global-dimension-static-size-100);
        border-bottom: 1px solid var(--ac-global-border-color-dark);
        flex: none;
        min-height: 29px;
        .toolbar__main {
          display: flex;
          flex-direction: row;
          gap: var(--ac-global-dimension-static-size-100);
        }
      `,children:[e("div",{"data-testid":"toolbar-main",className:"toolbar__main",children:n.children}),n.extra?e("div",{"data-testid":"toolbar-extra",children:n.extra}):null]})}const Tn=nn("%x %H:%M:%S %p");nn("%H:%M %p");function v0(n){const{timeRange:t,timePreset:a,setTimePreset:i}=Li(),{primaryInferences:{name:r}}=rn(),l=r.slice(0,10);return e(Pt,{color:"designationTurquoise",children:s(Z,{delay:0,placement:"bottom right",children:[e(ae,{children:s(he,{label:"primary inferences",defaultSelectedKey:a,"data-testid":"inferences-time-range","aria-label":"Time range for the primary inferences",addonBefore:l,onSelectionChange:o=>{o!==a&&i(o)},children:[e(P,{children:"All"},j.all),e(P,{children:"Last Hour"},j.last_hour),e(P,{children:"Last Day"},j.last_day),e(P,{children:"Last Week"},j.last_week),e(P,{children:"Last Month"},j.last_month),e(P,{children:"Last 3 Months"},j.last_3_months),e(P,{children:"First Hour"},j.first_hour),e(P,{children:"First Day"},j.first_day),e(P,{children:"First Week"},j.first_week),e(P,{children:"First Month"},j.first_month)]})}),e(Y,{children:s("section",{css:h`
              h4 {
                margin-bottom: 0.5rem;
              }
            `,children:[e(N,{level:4,children:"primary inferences time range"}),s("div",{children:["start: ",Tn(t.start)]}),s("div",{children:["end: ",Tn(t.end)]})]})})]})})}const mt=nn("%x %X");function k0({timeRange:n}){const{referenceInferences:t}=rn(),i=((t==null?void 0:t.name)??"reference").slice(0,10);return e("div",{css:h`
        .ac-textfield {
          min-width: 371px;
        }
      `,children:e(Pt,{color:"designationPurple",children:s(Z,{children:[e(ae,{children:e(K,{label:"reference inferences",isReadOnly:!0,"aria-label":"reference inferences time range",value:`${mt(n.start)} - ${mt(n.end)}`,addonBefore:i})}),e(Y,{children:"The static time range of the reference inferences"})]})})})}const h1=function(){var n=[{defaultValue:50,kind:"LocalArgument",name:"count"},{defaultValue:null,kind:"LocalArgument",name:"cursor"},{defaultValue:null,kind:"LocalArgument",name:"endTime"},{defaultValue:null,kind:"LocalArgument",name:"startTime"}],t=[{kind:"Variable",name:"after",variableName:"cursor"},{kind:"Variable",name:"first",variableName:"count"}],a={fields:[{kind:"Variable",name:"end",variableName:"endTime"},{kind:"Variable",name:"start",variableName:"startTime"}],kind:"ObjectValue",name:"timeRange"};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ModelSchemaTableDimensionsQuery",selections:[{args:[{kind:"Variable",name:"count",variableName:"count"},{kind:"Variable",name:"cursor",variableName:"cursor"},{kind:"Variable",name:"endTime",variableName:"endTime"},{kind:"Variable",name:"startTime",variableName:"startTime"}],kind:"FragmentSpread",name:"ModelSchemaTable_dimensions"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ModelSchemaTableDimensionsQuery",selections:[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:t,concreteType:"DimensionConnection",kind:"LinkedField",name:"dimensions",plural:!1,selections:[{alias:null,args:null,concreteType:"DimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"dimension",args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dataType",storageKey:null},{alias:"cardinality",args:[{kind:"Literal",name:"metric",value:"cardinality"},a],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"percentEmpty",args:[{kind:"Literal",name:"metric",value:"percentEmpty"},a],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"min",args:[{kind:"Literal",name:"metric",value:"min"},a],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"mean",args:[{kind:"Literal",name:"metric",value:"mean"},a],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"max",args:[{kind:"Literal",name:"metric",value:"max"},a],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"psi",args:[{kind:"Literal",name:"metric",value:"psi"},a],kind:"ScalarField",name:"driftMetric",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:t,filters:null,handle:"connection",key:"ModelSchemaTable_dimensions",kind:"LinkedHandle",name:"dimensions"}],storageKey:null}]},params:{cacheID:"0f5ec2a75c6234eefab01cbd1181c564",id:null,metadata:{},name:"ModelSchemaTableDimensionsQuery",operationKind:"query",text:`query ModelSchemaTableDimensionsQuery(
  $count: Int = 50
  $cursor: String = null
  $endTime: DateTime!
  $startTime: DateTime!
) {
  ...ModelSchemaTable_dimensions_4sIU9C
}

fragment ModelSchemaTable_dimensions_4sIU9C on Query {
  model {
    dimensions(first: $count, after: $cursor) {
      edges {
        dimension: node {
          id
          name
          type
          dataType
          cardinality: dataQualityMetric(metric: cardinality, timeRange: {start: $startTime, end: $endTime})
          percentEmpty: dataQualityMetric(metric: percentEmpty, timeRange: {start: $startTime, end: $endTime})
          min: dataQualityMetric(metric: min, timeRange: {start: $startTime, end: $endTime})
          mean: dataQualityMetric(metric: mean, timeRange: {start: $startTime, end: $endTime})
          max: dataQualityMetric(metric: max, timeRange: {start: $startTime, end: $endTime})
          psi: driftMetric(metric: psi, timeRange: {start: $startTime, end: $endTime})
        }
        cursor
        node {
          __typename
        }
      }
      pageInfo {
        endCursor
        hasNextPage
      }
    }
  }
}
`}}}();h1.hash="fb4c57e0ea77548c4e96ceb418e06614";const f1=function(){var n=["model","dimensions"],t={fields:[{kind:"Variable",name:"end",variableName:"endTime"},{kind:"Variable",name:"start",variableName:"startTime"}],kind:"ObjectValue",name:"timeRange"};return{argumentDefinitions:[{defaultValue:50,kind:"LocalArgument",name:"count"},{defaultValue:null,kind:"LocalArgument",name:"cursor"},{defaultValue:null,kind:"LocalArgument",name:"endTime"},{defaultValue:null,kind:"LocalArgument",name:"startTime"}],kind:"Fragment",metadata:{connection:[{count:"count",cursor:"cursor",direction:"forward",path:n}],refetch:{connection:{forward:{count:"count",cursor:"cursor"},backward:null,path:n},fragmentPathInResult:[],operation:h1}},name:"ModelSchemaTable_dimensions",selections:[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:"dimensions",args:null,concreteType:"DimensionConnection",kind:"LinkedField",name:"__ModelSchemaTable_dimensions_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"DimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"dimension",args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dataType",storageKey:null},{alias:"cardinality",args:[{kind:"Literal",name:"metric",value:"cardinality"},t],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"percentEmpty",args:[{kind:"Literal",name:"metric",value:"percentEmpty"},t],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"min",args:[{kind:"Literal",name:"metric",value:"min"},t],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"mean",args:[{kind:"Literal",name:"metric",value:"mean"},t],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"max",args:[{kind:"Literal",name:"metric",value:"max"},t],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"psi",args:[{kind:"Literal",name:"metric",value:"psi"},t],kind:"ScalarField",name:"driftMetric",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null}}();f1.hash="fb4c57e0ea77548c4e96ceb418e06614";function jr(n){const{message:t="No Data"}=n;return e("tbody",{className:"is-empty",children:e("tr",{children:e("td",{colSpan:100,css:a=>h`
            text-align: center;
            padding: ${a.spacing.margin24}px ${a.spacing.margin24}px !important;
          `,children:t})})})}function L1({columns:n,data:t}){const a=oa({columns:n,data:t,getCoreRowModel:sa(),getPaginationRowModel:ca(),getSortedRowModel:da()}),i=a.getRowModel().rows,l=i.length>0?e("tbody",{children:i.map(o=>e("tr",{children:o.getVisibleCells().map(d=>e("td",{children:Gn(d.column.columnDef.cell,d.getContext())},d.id))},o.id))}):e(jr,{});return s(J,{children:[s("table",{css:g1,children:[e("thead",{children:a.getHeaderGroups().map(o=>e("tr",{children:o.headers.map(d=>e("th",{colSpan:d.colSpan,children:d.isPlaceholder?null:e("div",{children:Gn(d.column.columnDef.header,d.getContext())})},d.id))},o.id))}),l]}),s("div",{css:Gr,children:[e(F,{variant:"default",size:"compact",onClick:a.previousPage,disabled:!a.getCanPreviousPage(),"aria-label":"Previous Page",icon:e(I,{svg:e(T.ArrowIosBackOutline,{})})}),e(F,{variant:"default",size:"compact",onClick:a.nextPage,disabled:!a.getCanNextPage(),"aria-label":"Next Page",icon:e(I,{svg:e(T.ArrowIosForwardOutline,{})})})]})]})}function Oe({getValue:n}){const t=n();if(!En(t))throw new Error("IntCell only supports number or null values.");return e("span",{title:t!=null?String(t):"",children:p1(t)})}const Wr=h`
  float: right;
`;function qr({getValue:n}){const t=n();if(!En(t))throw new Error("IntCell only supports number or null values.");return e("span",{title:t!=null?String(t):"",css:Wr,children:$r(t)})}function Xr({getValue:n}){const t=n();if(!En(t))throw new Error("IntCell only supports number or null values.");return e("span",{title:t!=null?String(t):"",children:Hr(t)})}const Jr=h`
  margin: 0;
  white-space: pre-wrap;
  word-wrap: break-word;
`;function pt(n,t){return n.length>t?`${n.slice(0,t)}...`:n}function Yr({json:n,maxLength:t,space:a=0,disableTitle:i=!1,collapseSingleKey:r=!0}){const l=typeof t=="number",o=p.useMemo(()=>JSON.stringify(n,null,a),[n,a]),d=p.useMemo(()=>JSON.stringify(n,null,2),[n]),c=i?void 0:d;if(!Dn(n))return console.warn("JSONText component received a non-object value",n),e("span",{title:c,children:String(n)});const u=n;if(Object.keys(u).length===0)return e("span",{title:c,children:"--"});if(Object.keys(u).length===1&&r){const L=Object.keys(u)[0],C=u[L];if(typeof C=="string"){const k=l?pt(C,t):C;return e("span",{title:c,children:k})}}const m=l?pt(o,t):o;return e(l?"span":"pre",{title:c,css:l?void 0:Jr,children:m})}const el=100;function S0({getValue:n}){const t=n();return e(Yr,{json:t,maxLength:el})}const nl=h`
  position: relative;
  min-height: 75px;
  .controls {
    transition: opacity 0.2s ease-in-out;
    opacity: 0;
    display: none;
    z-index: 1;
  }
  &:hover .controls {
    opacity: 1;
    display: flex;
    // make them stand out
    .ac-button {
      border-color: var(--ac-global-color-primary);
    }
  }
`,tl=h`
  position: absolute;
  top: -23px;
  right: 0px;
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-static-size-100);
`;function w0(n){return s("div",{css:nl,children:[n.children,e("div",{css:tl,className:"controls",children:n.controls})]})}function x0(n){const{data:t}=R.usePaginationFragment(f1,n.model),a=p.useMemo(()=>t.model.dimensions.edges.map(({dimension:r})=>({...r})),[t]),i=G.useMemo(()=>[{header:"name",accessorKey:"name",cell:l=>e(s1,{to:`dimensions/${l.row.original.id}`,children:l.renderValue()})},{header:"type",accessorKey:"type"},{header:"data type",accessorKey:"dataType"},{header:"cardinality",accessorKey:"cardinality",cell:qr},{header:"% empty",accessorKey:"percentEmpty",cell:Xr},{header:"min",accessorKey:"min",cell:Oe},{header:"mean",accessorKey:"mean",cell:Oe},{header:"max",accessorKey:"max",cell:Oe},{header:"PSI",accessorKey:"psi",cell:Oe}],[]);return e(L1,{columns:i,data:a})}const C1=function(){var n=[{defaultValue:50,kind:"LocalArgument",name:"count"},{defaultValue:null,kind:"LocalArgument",name:"cursor"},{defaultValue:null,kind:"LocalArgument",name:"endTime"},{defaultValue:null,kind:"LocalArgument",name:"startTime"}],t=[{kind:"Variable",name:"after",variableName:"cursor"},{kind:"Variable",name:"first",variableName:"count"}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ModelEmbeddingsTableEmbeddingDimensionsQuery",selections:[{args:[{kind:"Variable",name:"count",variableName:"count"},{kind:"Variable",name:"cursor",variableName:"cursor"},{kind:"Variable",name:"endTime",variableName:"endTime"},{kind:"Variable",name:"startTime",variableName:"startTime"}],kind:"FragmentSpread",name:"ModelEmbeddingsTable_embeddingDimensions"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ModelEmbeddingsTableEmbeddingDimensionsQuery",selections:[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:t,concreteType:"EmbeddingDimensionConnection",kind:"LinkedField",name:"embeddingDimensions",plural:!1,selections:[{alias:null,args:null,concreteType:"EmbeddingDimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"embedding",args:null,concreteType:"EmbeddingDimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:"euclideanDistance",args:[{kind:"Literal",name:"metric",value:"euclideanDistance"},{fields:[{kind:"Variable",name:"end",variableName:"endTime"},{kind:"Variable",name:"start",variableName:"startTime"}],kind:"ObjectValue",name:"timeRange"}],kind:"ScalarField",name:"driftMetric",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"EmbeddingDimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:t,filters:null,handle:"connection",key:"ModelEmbeddingsTable_embeddingDimensions",kind:"LinkedHandle",name:"embeddingDimensions"}],storageKey:null}]},params:{cacheID:"d0057a41a1d9795383a58de89e72ad76",id:null,metadata:{},name:"ModelEmbeddingsTableEmbeddingDimensionsQuery",operationKind:"query",text:`query ModelEmbeddingsTableEmbeddingDimensionsQuery(
  $count: Int = 50
  $cursor: String = null
  $endTime: DateTime!
  $startTime: DateTime!
) {
  ...ModelEmbeddingsTable_embeddingDimensions_4sIU9C
}

fragment ModelEmbeddingsTable_embeddingDimensions_4sIU9C on Query {
  model {
    embeddingDimensions(first: $count, after: $cursor) {
      edges {
        embedding: node {
          id
          name
          euclideanDistance: driftMetric(metric: euclideanDistance, timeRange: {start: $startTime, end: $endTime})
        }
        cursor
        node {
          __typename
        }
      }
      pageInfo {
        endCursor
        hasNextPage
      }
    }
  }
}
`}}}();C1.hash="fb7f125f75d1d33a555c16e198dbcbf8";const b1=function(){var n=["model","embeddingDimensions"];return{argumentDefinitions:[{defaultValue:50,kind:"LocalArgument",name:"count"},{defaultValue:null,kind:"LocalArgument",name:"cursor"},{defaultValue:null,kind:"LocalArgument",name:"endTime"},{defaultValue:null,kind:"LocalArgument",name:"startTime"}],kind:"Fragment",metadata:{connection:[{count:"count",cursor:"cursor",direction:"forward",path:n}],refetch:{connection:{forward:{count:"count",cursor:"cursor"},backward:null,path:n},fragmentPathInResult:[],operation:C1}},name:"ModelEmbeddingsTable_embeddingDimensions",selections:[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:"embeddingDimensions",args:null,concreteType:"EmbeddingDimensionConnection",kind:"LinkedField",name:"__ModelEmbeddingsTable_embeddingDimensions_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"EmbeddingDimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"embedding",args:null,concreteType:"EmbeddingDimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:"euclideanDistance",args:[{kind:"Literal",name:"metric",value:"euclideanDistance"},{fields:[{kind:"Variable",name:"end",variableName:"endTime"},{kind:"Variable",name:"start",variableName:"startTime"}],kind:"ObjectValue",name:"timeRange"}],kind:"ScalarField",name:"driftMetric",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"EmbeddingDimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null}}();b1.hash="fb7f125f75d1d33a555c16e198dbcbf8";function T0(n){const{data:t}=R.usePaginationFragment(b1,n.model),a=p.useMemo(()=>t.model.embeddingDimensions.edges.map(({embedding:r})=>({...r})),[t]),i=G.useMemo(()=>[{header:"name",accessorKey:"name",cell:({row:l,renderValue:o})=>e(s1,{to:`embeddings/${l.original.id}`,children:o()})},{header:"euclidean distance",accessorKey:"euclideanDistance",cell:Oe}],[]);return e(L1,{columns:i,data:a})}const y1=p.createContext(null),al=()=>{const n=p.useContext(y1);if(n===null)throw new Error("useTimeSlice must be used within a TimeSliceProvider");return n},M0=({initialTimestamp:n,children:t})=>{const[a,i]=p.useState(n),r=l=>{p.startTransition(()=>{i(l)})};return e(y1.Provider,{value:{selectedTimestamp:a,setSelectedTimestamp:r},children:t})};function il(){const n=v(a=>a.setPointSizeScale),t=v(a=>a.pointSizeScale);return s(In,{placement:"bottom left",children:[e(F,{variant:"default",size:"compact",icon:e(I,{svg:e(T.OptionsOutline,{})}),"aria-label":"Display Settings"}),e(Ba,{children:e(b,{padding:"size-100",children:e(x,{direction:"column",gap:"size-100",children:e(Ha,{label:"Point Scale",minValue:0,maxValue:3,step:.1,value:t,onChange:n})})})})]})}const gt=h`
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-static-size-50);
`;function rl(n){return typeof n=="string"&&n in xe}function ll(n){return s(Re,{defaultValue:n.mode,variant:"inline-button",size:"compact",onChange:t=>{if(rl(t))n.onChange(t);else throw new Error(`Unknown canvas mode: ${t}`)},children:[e(q,{label:"Move",value:xe.move,children:s(Z,{placement:"top",delay:0,offset:10,children:[e(ae,{children:s("div",{css:gt,children:[e(I,{svg:e(T.MoveFilled,{})})," Move"]})}),e(Y,{children:"Move around the canvas using orbital controls"})]})}),e(q,{label:"Select",value:xe.select,children:s(Z,{placement:"top",delay:0,offset:10,children:[e(ae,{children:s("div",{css:gt,children:[e(I,{svg:e(T.LassoOutline,{})})," Select"]})}),e(Y,{children:"Select points using the lasso tool"})]})})]})}function ol({radius:n}){const t=v(c=>c.eventIdToDataMap),a=v(c=>c.highlightedClusterId),i=v(c=>c.selectedClusterId),r=v(c=>c.clusters),{theme:l}=Q(),o=v(c=>c.clusterColorMode),d=p.useMemo(()=>r.map(c=>{const{eventIds:u}=c,m=u.map(g=>{var L;return{position:(L=t.get(g))==null?void 0:L.position}}).filter(g=>g.position!==null);return{...c,data:m}}).filter(c=>c.data.length>0),[r,t]);return e(J,{children:d.map((c,u)=>{const m=cl({selected:c.id===i,highlighted:c.id===a,clusterColorMode:o});return e(ua,{data:c.data,opacity:m,wireframe:!0,pointRadius:n,color:sl({theme:l,clusterColorMode:o,index:u,clusterCount:d.length})},`${c.id}__opacity_${String(m)}`)})})}function sl({theme:n,clusterColorMode:t,index:a,clusterCount:i}){return t===Nn.default?n==="dark"?"#999999":"#bbbbbb":At(a/i)}function cl({selected:n,highlighted:t,clusterColorMode:a}){return a===Nn.highlight?1:n?.7:t?.5:0}const dl=2;function ul({pointRadius:n}){const t=v(u=>u.hoveredEventId),a=v(u=>u.pointSizeScale),i=v(u=>u.eventIdToDataMap),r=v(u=>u.pointGroupColors),l=v(u=>u.eventIdToGroup);if(t==null||i==null)return null;const o=i.get(t),d=l[t],c=r[d];return o==null?null:e(ma,{position:o.position,args:[n*dl],scale:[a,a,a],children:e("meshMatcapMaterial",{color:c,opacity:.7,transparent:!0})})}const ht=1;function ml(){const n=v(r=>r.hoveredEventId),t=v(r=>r.eventIdToDataMap),a=p.useRef(null);pa((r,l)=>{a.current&&a.current.children.forEach(o=>o.children[0].material.uniforms.dashOffset.value-=l*5)});const i=p.useMemo(()=>{if(n==null)return[];const r=t.get(n);if(r==null)return[];const l=r.retrievals??[];return(l==null?void 0:l.length)===0?[]:l.map(d=>{const c=t.get(d.documentId);return c==null?null:[r.position,c.position]}).filter(d=>d!=null)},[t,n]);return e("group",{ref:a,children:i.map((r,l)=>s("group",{children:[e(Qn,{start:r[0],end:r[1],color:16777215,opacity:1,transparent:!0,dashed:!0,dashScale:50,gapSize:20,linewidth:ht}),e(Qn,{start:r[0],end:r[1],color:16777215,linewidth:ht/2,transparent:!0,opacity:.8})]},l))})}const pl=.5,gl=.5,hl=100,ft=1.7;function Lt(n,t){return typeof t=="function"?t(n):t}function fl({primaryData:n,referenceData:t,corpusData:a,color:i,radius:r}){const l=v(A=>A.inferencesVisibility),o=v(A=>A.coloringStrategy),{theme:d}=Q(),c=v(A=>A.setSelectedEventIds),u=v(A=>A.selectedEventIds),m=v(A=>A.setSelectedClusterId),g=v(A=>A.setHoveredEventId),f=v(A=>A.pointSizeScale),L=p.useMemo(()=>ga(g,hl),[g]),C=p.useMemo(()=>o!==E.inferences?"cube":"sphere",[o]),k=p.useMemo(()=>o!==E.inferences?"octahedron":"sphere",[o]),_=p.useMemo(()=>d==="dark"?ha(pl):fa(gl),[d]),w=p.useMemo(()=>typeof i=="function"?A=>_(i(A)):_(i),[i,_]),H=p.useCallback(A=>!u.has(A.metaData.id)&&u.size>0?Lt(A,w):Lt(A,i),[u,i,w]),le=l.reference&&t,Ie=l.corpus&&a,oe=p.useCallback(A=>{p.startTransition(()=>{c(new Set([A.metaData.id])),m(null)})},[m,c]),se=p.useCallback(A=>{A==null||A.metaData==null||L(A.metaData.id)},[L]),Ae=p.useCallback(()=>{L(null)},[L]);return s(J,{children:[l.primary?e(hn,{data:n,pointProps:{color:H,radius:r,scale:f},onPointClicked:oe,onPointHovered:se,onPointerLeave:Ae}):null,le?e(hn,{data:t,pointProps:{color:H,radius:r,size:r?r*ft:void 0,scale:f},onPointHovered:se,onPointerLeave:Ae,pointShape:C,onPointClicked:oe}):null,Ie?e(hn,{data:a,pointProps:{color:H,radius:r,size:r?r*ft:void 0,scale:f},onPointHovered:se,onPointerLeave:Ae,pointShape:k,onPointClicked:oe}):null]})}const Ll=/\.(mp4|mov|webm|ogg)(\?|$)/i,Cl=/\.(mp3|wav)(\?|$)/i;function bl(n){return Ll.test(n)}function yl(n){return Cl.test(n)}var ue=(n=>(n.square="square",n.circle="circle",n.diamond="diamond",n))(ue||{});const vl=()=>e("svg",{width:"12px",height:"12px",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("rect",{width:"12",height:"12",rx:"1",fill:"currentColor"})}),kl=()=>e("svg",{width:"12px",height:"12px",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("circle",{cx:"6",cy:"6",r:"6",fill:"currentColor"})}),Sl=()=>e("svg",{width:"12px",height:"12px",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{d:"M6 0L12 6L6 12L0 6L6 0Z",fill:"currentColor"})});function v1(n){const{shape:t,color:a}=n,i=p.useMemo(()=>{switch(t){case"square":return e(vl,{});case"circle":return e(kl,{});case"diamond":return e(Sl,{});default:O()}},[t]);return e("i",{className:"shape-icon",style:{color:a},css:h`
        display: flex;
        flex-direction: row;
        align-items: center;
      `,"aria-hidden":!0,children:i})}function wl(n){const{rawData:t,linkToData:a,promptAndResponse:i,documentText:r}=n;return r!=null?"document":i!=null?"prompt_response":a!=null?bl(a)?"video":yl(a)?"audio":"image":t!=null?"raw":"event_metadata"}function xl(n,t){const{rawData:a}=t;switch(n){case"document":return null;case"prompt_response":return null;case"image":return a!=null?"raw":null;case"video":return a!=null?"raw":null;case"audio":return a!=null?"raw":null;case"raw":return"event_metadata";case"event_metadata":return null;default:O()}}function Tl(n){const{onClick:t,onMouseOver:a,onMouseOut:i,color:r,size:l,inferencesName:o,group:d}=n,c=wl(n),u=l==="large"?xl(c,n):null;return s("div",{"data-testid":"event-item",role:"button","data-size":l,css:h`
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        border-style: solid;
        border-radius: 4px;
        overflow: hidden;

        display: flex;
        flex-direction: column;
        cursor: pointer;
        overflow: hidden;

        border-width: 1px;
        border-color: ${r};
        border-radius: var(--ac-global-rounding-medium);
        transition: border-color 0.2s ease-in-out;
        transition: transform 0.2s ease-in-out;
        &:hover {
          transform: scale(1.04);
        }
        &[data-size="small"] {
          border-width: 2px;
        }
      `,onClick:t,onMouseOver:a,onMouseOut:i,children:[s("div",{className:"event-item__preview-wrap","data-size":l,css:h`
          display: flex;
          flex-direction: row;
          flex: 1 1 auto;
          overflow: hidden;
          & > *:nth-child(1) {
            flex: 1 1 auto;
            overflow: hidden;
          }
          & > *:nth-child(2) {
            flex: none;
            width: 43%;
          }
          &[data-size="large"] {
            & > *:nth-child(1) {
              margin: var(--ac-global-dimension-static-size-100);
              border-radius: 8px;
            }
          }
        `,children:[e(Ct,{previewType:c,...n}),u!=null&&e(Ct,{previewType:u,...n})]}),l!=="small"&&e(_l,{color:r,group:d,inferencesName:o,showInferences:l==="large"})]})}function Ct(n){const{previewType:t}=n;let a=null;switch(t){case"document":{a=e(Dl,{...n});break}case"prompt_response":{a=e(El,{...n});break}case"image":{a=e(Ml,{...n});break}case"video":{a=e(Il,{...n});break}case"audio":{a=e(Al,{...n});break}case"raw":{a=e(Pl,{...n});break}case"event_metadata":{a=e(Ol,{...n});break}default:O()}return a}function Ml(n){return e("img",{src:n.linkToData||"[error] unexpected missing url",css:h`
        min-height: 0;
        // Maintain aspect ratio while having normalized height
        object-fit: contain;
        transition: background-color 0.2s ease-in-out;
        background-color: ${Mn(.85,n.color)};
      `})}function Il(n){return e("video",{src:n.linkToData||"[error] unexpected missing url",css:h`
        min-height: 0;
        // Maintain aspect ratio while having normalized height
        object-fit: contain;
        transition: background-color 0.2s ease-in-out;
        background-color: ${Mn(.85,n.color)};
      `})}function Al(n){return e("audio",{src:n.linkToData||"[error] unexpected missing url",autoPlay:n.autoPlay,controls:!0})}function El(n){var t,a;return s("div",{"data-size":n.size,css:h`
        --prompt-response-preview-background-color: var(
          --ac-global-color-grey-200
        );
        background-color: var(--prompt-response-preview-background-color);
        &[data-size="small"] {
          display: flex;
          flex-direction: column;
          padding: var(--ac-global-dimension-static-size-50);
          font-size: var(--ac-global-dimension-static-font-size-75);
          section {
            flex: 1 1 0;
            overflow: hidden;
            header {
              display: none;
            }
          }
        }
        &[data-size="medium"] {
          display: flex;
          flex-direction: column;
          gap: var(--ac-global-dimension-static-size-50);
          padding: var(--ac-global-dimension-static-size-100);
          section {
            flex: 1 1 0;
            overflow: hidden;
          }
        }
        &[data-size="large"] {
          display: flex;
          flex-direction: row;
          section {
            padding: var(--ac-global-dimension-static-size-50);
            flex: 1 1 0;
          }
        }
        & > section {
          position: relative;

          header {
            font-weight: bold;
            margin-bottom: var(--ac-global-dimension-static-size-50);
          }
          &:before {
            content: "";
            width: 100%;
            height: 100%;
            position: absolute;
            left: 0;
            top: 0;
            background: linear-gradient(
              transparent 80%,
              var(--prompt-response-preview-background-color) 100%
            );
          }
        }
      `,children:[s("section",{children:[e("header",{children:"prompt"}),(t=n.promptAndResponse)==null?void 0:t.prompt]}),s("section",{children:[e("header",{children:"response"}),(a=n.promptAndResponse)==null?void 0:a.response]})]})}function Dl(n){return e("p",{"data-size":n.size,css:h`
        flex: 1 1 auto;
        padding: var(--ac-global-dimension-static-size-100);
        margin-block-start: 0;
        margin-block-end: 0;
        position: relative;
        --text-preview-background-color: var(--ac-global-color-grey-100);
        background-color: var(--text-preview-background-color);

        &[data-size="small"] {
          padding: var(--ac-global-dimension-static-size-50);
          box-sizing: border-box;
        }
        &:before {
          content: "";
          width: 100%;
          height: 100%;
          position: absolute;
          left: 0;
          top: 0;
          background: linear-gradient(
            transparent 90%,
            var(--text-preview-background-color) 98%,
            var(--text-preview-background-color) 100%
          );
        }
      `,children:n.documentText})}function Pl(n){return e("p",{"data-size":n.size,css:h`
        flex: 1 1 auto;
        padding: var(--ac-global-dimension-static-size-100);
        margin-block-start: 0;
        margin-block-end: 0;
        position: relative;
        --text-preview-background-color: var(--ac-background-color-light);
        background-color: var(--text-preview-background-color);

        &[data-size="small"] {
          padding: var(--ac-global-dimension-static-size-50);
          font-size: var(--ac-global-color-gray-600);
          box-sizing: border-box;
        }
        &:before {
          content: "";
          width: 100%;
          height: 100%;
          position: absolute;
          left: 0;
          top: 0;
          background: linear-gradient(
            transparent 90%,
            var(--text-preview-background-color) 98%,
            var(--text-preview-background-color) 100%
          );
        }
      `,children:n.rawData})}function Ol(n){return s("dl",{css:h`
        margin: 0;
        padding: var(--ac-global-dimension-static-size-200);
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: var(--ac-global-dimension-static-size-100);

        dt {
          font-weight: bold;
        }
        dd {
          margin-inline-start: var(--ac-global-dimension-static-size-100);
        }
      `,children:[s("div",{children:[e("dt",{children:"prediction label"}),e("dd",{children:n.predictionLabel||"--"})]}),s("div",{children:[e("dt",{children:"actual label"}),e("dd",{children:n.actualLabel||"--"})]})]})}function _l({color:n,group:t,showInferences:a,inferencesName:i}){return s("footer",{css:h`
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        padding: var(--ac-global-dimension-static-size-50)
          var(--ac-global-dimension-static-size-100)
          var(--ac-global-dimension-static-size-50) 7px;
        border-top: 1px solid var(--ac-global-border-color-dark);
      `,children:[s("div",{css:h`
          display: flex;
          flex-direction: row;
          align-items: center;
          gap: var(--ac-global-dimension-static-size-50);
        `,children:[e(v1,{shape:ue.circle,color:n}),t]}),a?e("div",{title:"the inferences the point belongs to",children:i}):null]})}const De=200,Qe=10,Fl=new li,Nl=()=>{const{getInferencesNameByRole:n}=rn(),t=v(f=>f.hoveredEventId),a=v(f=>f.eventIdToDataMap),i=v(f=>f.pointData),r=v(f=>f.pointGroupColors),l=v(f=>f.eventIdToGroup);if(t==null||i==null||i==null)return null;const o=a.get(t),d=i[t];if(o==null||d==null)return null;const c=l[t],u=r[l[t]],m=Xt(t),g=n(m);return e(La,{position:o.position,pointerEvents:"none",zIndexRange:[0,1],calculatePosition:(f,L,C)=>{const k=Fl.setFromMatrixPosition(f.matrixWorld);k.project(L);const _=C.width/2,w=C.height/2;return[Math.min(C.width-De-Qe,Math.max(0,k.x*_+_+Qe)),Math.min(C.height-De-Qe,Math.max(0,-(k.y*w)+w+Qe))]},children:e("div",{css:h`
          --grid-item-min-width: ${De}px;
          width: ${De}px;
          height: ${De}px;
          background-color: var(--ac-global-background-color-dark);
          border-radius: var(--ac-global-rounding-medium);
        `,children:e(Tl,{rawData:o.embeddingMetadata.rawData,linkToData:o.embeddingMetadata.linkToData,predictionLabel:o.eventMetadata.predictionLabel,actualLabel:o.eventMetadata.actualLabel,promptAndResponse:d.promptAndResponse,documentText:d.documentText,inferencesName:g,group:c,color:u,size:"medium",autoPlay:!0})})})},Vl=300,zl=3,Rl=.2,Kl=function(){const{selectedTimestamp:t}=al(),a=v(c=>c.points),i=v(c=>c.hdbscanParameters),r=v(c=>c.umapParameters),[l,o,d]=p.useMemo(()=>{const{primaryEventIds:c,referenceEventIds:u,corpusEventIds:m}=Fn(a.map(g=>g.eventId));return[c.length,u.length,m.length]},[a]);return t?s("section",{css:h`
        width: 300px;
        padding: var(--ac-global-dimension-static-size-100);
      `,children:[s("dl",{css:Cn,children:[s("div",{children:[e("dt",{children:"Timestamp"}),e("dd",{children:Tn(t)})]}),s("div",{children:[e("dt",{children:"primary points"}),e("dd",{children:l})]}),o>0?s("div",{children:[e("dt",{children:"reference points"}),e("dd",{children:o})]}):null,d>0?s("div",{children:[e("dt",{children:"corpus points"}),e("dd",{children:d})]}):null]}),e("br",{}),e(N,{level:4,weight:"heavy",children:"Clustering Parameters"}),s("dl",{css:Cn,children:[s("div",{children:[e("dt",{children:"min cluster size"}),e("dd",{children:i.minClusterSize})]}),s("div",{children:[e("dt",{children:"cluster min samples"}),e("dd",{children:i.clusterMinSamples})]}),s("div",{children:[e("dt",{children:"cluster selection epsilon"}),e("dd",{children:i.clusterSelectionEpsilon})]})]}),e("br",{}),e(N,{level:4,weight:"heavy",children:"UMAP Parameters"}),s("dl",{css:Cn,children:[s("div",{children:[e("dt",{children:"min distance"}),e("dd",{children:r.minDist})]}),s("div",{children:[e("dt",{children:"n neighbors"}),e("dd",{children:r.nNeighbors})]}),s("div",{children:[e("dt",{children:"n samples per inferences"}),e("dd",{children:r.nSamples})]})]})]}):null},Cn=h`
  margin: 0;
  padding: 0;
  div {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    gap: var(--ac-global-dimension-static-size-50);
  }
`;function $l(){const n=v(a=>a.canvasMode),t=v(a=>a.setCanvasMode);return s("div",{css:h`
        position: absolute;
        left: var(--ac-global-dimension-static-size-100);
        top: var(--ac-global-dimension-static-size-100);
        z-index: 1;
        display: flex;
        flex-direction: row;
        align-items: center;
        gap: var(--ac-global-dimension-static-size-100);
      `,children:[e(ll,{mode:n,onChange:t}),e(il,{}),e(Hl,{})]})}function Hl(){return s(Z,{placement:"bottom left",delay:0,children:[e(F,{variant:"default",size:"compact",icon:e(I,{svg:e(Za,{})}),"aria-label":"Information bout the point-cloud display"}),e(Ga,{title:"Point Cloud Summary",children:e(Kl,{})})]})}function Bl({children:n}){const{theme:t}=Q();return e("div",{css:h`
        flex: 1 1 auto;
        height: 100%;
        position: relative;
        &[data-theme="dark"] {
          background: linear-gradient(
            rgb(21, 25, 31) 11.4%,
            rgb(11, 12, 14) 70.2%
          );
        }
        &[data-theme="light"] {
          background: linear-gradient(#f2f6fd 0%, #dbe6fc 74%);
        }
      `,"data-theme":t,children:n})}function I0(){return s(Bl,{children:[e($l,{},"canvas-tools"),e(Zl,{},"projection")]})}const Zl=G.memo(function(){const t=v(M=>M.points),a=v(M=>M.canvasMode),i=v(M=>M.setSelectedEventIds),r=v(M=>M.setSelectedClusterId),l=v(M=>M.pointGroupColors),o=v(M=>M.pointGroupVisibility),{theme:d}=Q(),c=v(M=>M.inferencesVisibility),[u,m]=p.useState(!0),g=p.useMemo(()=>Ca(t.map(M=>M.position)),[t]),f=(g.maxX-g.minX+(g.maxY-g.minY))/2/Vl,L=f*zl,C=a===xe.move,k=v(M=>M.eventIdToGroup),_=p.useCallback(M=>{const U=k[M.metaData.id]||"unknown";return l[U]||ye},[l,k]),w=p.useMemo(()=>t.filter(M=>M.eventId.includes("PRIMARY")),[t]),H=p.useMemo(()=>t.filter(M=>M.eventId.includes("REFERENCE")),[t]),le=p.useMemo(()=>t.filter(M=>M.eventId.includes("CORPUS")),[t]),Ie=p.useMemo(()=>w.filter(M=>{const U=k[M.eventId];return o[U]}),[w,k,o]),oe=p.useMemo(()=>!H||H.length===0?null:H.filter(M=>{const U=k[M.eventId];return o[U]}),[H,k,o]),se=p.useMemo(()=>le.filter(M=>{const U=k[M.eventId];return o[U]}),[le,k,o]),Ae=p.useMemo(()=>{const M=c.primary?Ie:[],U=c.reference?oe:[],J1=c.corpus?se:[];return[...M,...U||[],...J1||[]]},[Ie,oe,se,c]),A=ba(On,Pn,xa,_n);return e(wa,{camera:{position:[3,3,3]},children:s(A,{children:[e(ya,{autoRotate:u,autoRotateSpeed:2,enableRotate:C,enablePan:C,onEnd:()=>{m(!1)}}),s(va,{bounds:g,boundsZoomPaddingFactor:Rl,children:[e(ka,{points:Ae,onChange:M=>{i(new Set(M.map(U=>U.metaData.id))),r(null)},enabled:a===xe.select}),e(Sa,{size:(g.maxX-g.minX)/4,color:d=="dark"?"#fff":"#505050"}),e(fl,{primaryData:Ie,referenceData:oe,corpusData:se,color:_,radius:f}),e(ol,{radius:L}),e(Nl,{}),e(ul,{pointRadius:f}),e(ml,{})]})]})})}),k1=function(){var n=[{alias:null,args:null,concreteType:"Model",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:null,concreteType:"DimensionConnection",kind:"LinkedField",name:"dimensions",plural:!1,selections:[{alias:null,args:null,concreteType:"DimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dataType",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"DimensionPickerQuery",selections:n,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"DimensionPickerQuery",selections:n},params:{cacheID:"56e356d226d322dabfd9db8010884e4f",id:null,metadata:{},name:"DimensionPickerQuery",operationKind:"query",text:`query DimensionPickerQuery {
  model {
    dimensions {
      edges {
        node {
          id
          name
          type
          dataType
        }
      }
    }
  }
}
`}}}();k1.hash="747256fac1de97803ae6f96e3cb58d98";function Gl(n){const{type:t}=n;let a="gray",i="";switch(t){case"feature":a="blue",i="FEA";break;case"tag":a="purple",i="TAG";break;case"prediction":a="white",i="PRE";break;case"actual":a="orange",i="ACT";break;default:O()}return e(me,{color:a,"aria-label":t,title:"type",children:i})}const Ql=s(re,{children:[e(N,{weight:"heavy",level:4,children:"Model Dimension"}),e(ie,{children:e(y,{children:"A dimension is a feature, tag, prediction, or actual value that is associated with a model inference. Features represent inputs, tags represent metadata, predictions represent outputs, and actuals represent ground truth."})})]});function Ul(n){const{selectedDimension:t,dimensions:a,onChange:i,isLoading:r,...l}=n;return e(he,{...l,defaultSelectedKey:t?t.name:void 0,"aria-label":"Select a dimension",onSelectionChange:o=>{const d=a.find(c=>c.name===o);d&&p.startTransition(()=>i(d))},label:"Dimension",labelExtra:Ql,isDisabled:r,placeholder:r?"Loading...":"Select a dimension...",children:a.map(o=>e(P,{textValue:o.name,children:s("div",{css:h`
              .ac-label {
                margin-right: var(--ac-global-dimension-static-size-100);
              }
            `,children:[e(Gl,{type:o.type}),o.name]})},o.name))})}function jl(n){const[t,a]=p.useState([]),[i,r]=p.useState(!0),{selectedDimension:l,onChange:o,...d}=n;return p.useEffect(()=>{R.fetchQuery(Ze,k1,{},{fetchPolicy:"store-or-network"}).toPromise().then(c=>{const u=(c==null?void 0:c.model.dimensions.edges.map(m=>m.node))??[];a(u),r(!1)})},[]),e(Ul,{...d,onChange:o,dimensions:t,label:"Dimension",selectedDimension:l,isLoading:i})}function Wl(n){return typeof n=="string"&&n in E}const ql=Object.values(E),Xl=s(re,{children:[e(N,{weight:"heavy",level:4,children:"Coloring Strategy"}),e(ie,{children:e(y,{children:"The way in which inference point is colored. Each point in the point-cloud represents a model inference. These inferences can be colored by a particular attribute (such as inferences and dimension) or by a performance value such as correctness (predicted value equals the actual value)"})})]});function Jl(n){const{strategy:t,onChange:a}=n;return e(he,{defaultSelectedKey:t,"aria-label":"Coloring strategy",onSelectionChange:i=>{Wl(i)&&a(i)},label:"Color By",labelExtra:Xl,children:ql.map(i=>e(P,{children:i},i))})}const Yl=h`
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-size-50);
  align-items: center;
`;function We(n){const{name:t,checked:a,onChange:i,color:r,iconShape:l=ue.circle}=n;return s("label",{css:Yl,children:[e("input",{type:"checkbox",checked:a,name:t,onChange:i}),e(v1,{shape:l,color:r}),t]},t)}function eo({hasReference:n,hasCorpus:t}){const a=v(f=>f.inferencesVisibility),i=v(f=>f.setInferencesVisibility),r=v(f=>f.coloringStrategy),l=p.useCallback(f=>{const{name:L,checked:C}=f.target;i({...a,[L]:C})},[a,i]),o=Na(),d=p.useMemo(()=>{switch(r){case E.inferences:return o[0];case E.correctness:case E.dimension:return ne;default:O()}},[r,o]),c=p.useMemo(()=>{switch(r){case E.inferences:return o[1];case E.correctness:case E.dimension:return ne;default:O()}},[r,o]),u=ne,m=r===E.inferences?ue.circle:ue.square,g=r===E.inferences?ue.circle:ue.diamond;return s("form",{css:h`
        display: flex;
        flex-direction: column;
        padding: var(--ac-global-dimension-static-size-100);
      `,children:[e(We,{checked:a.primary,name:"primary",color:d,onChange:l}),n?e(We,{checked:a.reference,name:"reference",onChange:l,color:c,iconShape:m}):null,t?e(We,{checked:a.corpus,name:"corpus",onChange:l,color:u,iconShape:g}):null]})}function no(){const n=v(l=>l.pointGroupVisibility),t=v(l=>l.setPointGroupVisibility),a=v(l=>l.pointGroupColors),i=p.useMemo(()=>Object.keys(n),[n]),r=p.useCallback(l=>{const{name:o,checked:d}=l.target;t({...n,[o]:d})},[n,t]);return s("form",{css:h`
        display: flex;
        flex-direction: column;
      `,children:[e(to,{}),e("div",{css:h`
          padding: var(--ac-global-dimension-static-size-100);
        `,children:i.map(l=>{const o=n[l],d=a[l];return e(We,{name:l,checked:o,color:d,onChange:r},l)})})]})}function to(){const n=v(l=>l.pointGroupVisibility),t=v(l=>l.setPointGroupVisibility),a=v(l=>l.coloringStrategy),i=p.useMemo(()=>Object.values(n).every(l=>!l),[n]),r=p.useCallback(l=>{const{checked:o}=l.target,d=Object.keys(n).reduce((c,u)=>(c[u]=o,c),{});t(d)},[n,t]);return s("label",{css:()=>h`
        display: flex;
        flex-direction: row;
        gap: var(--ac-global-dimension-size-50);
        padding: var(--ac-global-dimension-static-size-50)
          var(--ac-global-dimension-static-size-100);
        background-color: var(--ac-global-background-color-light);
      `,children:[e("input",{type:"checkbox",checked:!i,onChange:r}),`${a}`]})}function A0(){const{referenceInferences:n,corpusInferences:t}=rn(),a=v(g=>g.coloringStrategy),i=v(g=>g.setColoringStrategy),r=v(g=>g.dimension),l=v(g=>g.dimensionMetadata),o=v(g=>g.setDimension),d=n!=null||t!=null,c=a===E.dimension&&r==null,u=a===E.dimension&&r!=null&&l==null,m=a!==E.inferences&&!c&&!u;return s("section",{css:h`
        & > .ac-form {
          padding: var(--ac-global-dimension-static-size-100)
            var(--ac-global-dimension-static-size-100) 0
            var(--ac-global-dimension-static-size-100);
        }
        & > .ac-alert {
          margin: var(--ac-global-dimension-static-size-100);
        }
      `,children:[e(Me,{children:s(J,{children:[e(Jl,{strategy:a,onChange:i}),a===E.dimension?e(jl,{selectedDimension:null,onChange:g=>{o(g)}}):null]})}),d?e(eo,{hasReference:n!=null,hasCorpus:t!=null}):null,m?e(no,{}):null,c?e(Ke,{variant:"info",showIcon:!1,children:"Please select a dimension to color the point cloud by"}):null,u?e("div",{css:h`
            padding: var(--ac-global-dimension-static-size-100);
            min-height: 100px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
          `,children:e(wr,{message:"Calculating point colors"})}):null]})}function ao(n){return typeof n=="string"&&n in we}function E0(n){return s(Re,{defaultValue:n.mode,variant:"inline-button",onChange:t=>{if(ao(t))n.onChange(t);else throw new Error(`Unknown view mode: ${t}`)},children:[e(q,{label:"List",value:we.list,children:e(I,{svg:e(T.ListOutline,{})})}),e(q,{label:"Grid",value:we.gallery,children:e(I,{svg:e(T.Grid,{})})})]})}function D0(n){const{driftRatio:t,primaryToCorpusRatio:a,clusterId:i,isSelected:r,onClick:l,onMouseEnter:o,onMouseLeave:d,metricName:c,primaryMetricValue:u,referenceMetricValue:m,hideReference:g}=n,{percentage:f,comparisonInferencesRole:L}=p.useMemo(()=>typeof a=="number"?{percentage:(a+1)/2*100,comparisonInferencesRole:X.corpus}:typeof t=="number"?{percentage:(t+1)/2*100,comparisonInferencesRole:X.reference}:{percentage:100,comparisonInferencesRole:null},[t,a]);return s("div",{css:h`
        border: 1px solid var(--ac-global-border-color-light);
        border-radius: var(--ac-global-rounding-medium);
        overflow: hidden;
        transition: background-color 0.2s ease-in-out;
        cursor: pointer;
        &:hover {
          background-color: var(--ac-global-color-primary-700);
          border-color: var(--ac-global-color-primary);
        }
        &.is-selected {
          border-color: var(--ac-global-color-primary);
          background-color: var(--ac-global-color-primary-700);
        }
      `,className:r?"is-selected":"",role:"button",onClick:l,onMouseEnter:o,onMouseLeave:d,children:[s("div",{css:h`
          padding: var(--ac-global-dimension-static-size-100);
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
        `,children:[e(x,{"data-testid":"cluster-description",direction:"column",gap:"size-50",alignItems:"start",children:s(x,{direction:"column",alignItems:"start",children:[e(N,{level:3,children:`Cluster ${i}`}),e(y,{color:"text-700",textSize:"small",children:`${n.numPoints} points`})]})}),s("div",{"data-testid":"cluster-metric",css:h`
            display: flex;
            flex-direction: column;
            align-items: end;
          `,children:[e(y,{color:"text-700",textSize:"small",children:c}),e(y,{color:"text-900",textSize:"medium",children:ct(u)}),g?null:e(y,{color:"designationPurple",textSize:"small",children:ct(m)})]})]}),e(io,{primaryPercentage:f,comparisonInferencesRole:L})]})}function io({primaryPercentage:n,comparisonInferencesRole:t}){return s("div",{"data-testid":"inferences-distribution",css:h`
        display: flex;
        flex-direction: row;
      `,children:[e("div",{"data-testid":"primary-distribution",css:h`
          background-image: linear-gradient(
            to right,
            var(--px-primary-color--transparent) 0%,
            var(--px-primary-color)
          );
          height: var(--px-gradient-bar-height);
          width: ${n}%;
        `}),e("div",{"data-testid":"reference-distribution","data-reference-inferences-role":`${t??"none"}`,css:h`
          &[data-reference-inferences-role="reference"] {
            background-image: linear-gradient(
              to right,
              var(--px-reference-color) 0%,
              var(--px-reference-color--transparent)
            );
          }
          &[data-reference-inferences-role="corpus"] {
            background-image: linear-gradient(
              to right,
              var(--px-corpus-color) 0%,
              var(--px-corpus-color--transparent)
            );
          }

          height: var(--px-gradient-bar-height);
          width: ${100-n}%;
        `})]})}const ro=s(re,{children:[e(N,{weight:"heavy",level:4,children:"UMAP N Neighbors"}),e(ie,{children:e(y,{children:"This parameter controls how UMAP balances local versus global structure in the data. It does this by constraining the size of the local neighborhood UMAP will look at when attempting to learn the manifold structure of the data. This means that low values of n_neighbors will force UMAP to concentrate on very local structure (potentially to the detriment of the big picture), while large values will push UMAP to look at larger neighborhoods of each point when estimating the manifold structure of the data, losing fine detail structure for the sake of getting the broader of the data."})}),e("footer",{children:e(V,{href:"https://umap-learn.readthedocs.io/en/latest/parameters.html#n-neighbors",children:"View UMAP documentation"})})]}),lo=s(re,{children:[e(N,{weight:"heavy",level:4,children:"UMAP Minimum Distance"}),e(ie,{children:e(y,{children:"The min_dist parameter controls how tightly UMAP is allowed to pack points together. It, quite literally, provides the minimum distance apart that points are allowed to be in the low dimensional representation. This means that low values of min_dist will result in clumpier embeddings. This can be useful if you are interested in clustering, or in finer topological structure. Larger values of min_dist will prevent UMAP from packing points together and will focus on the preservation of the broad topological structure instead."})}),e("footer",{children:e(V,{href:"https://umap-learn.readthedocs.io/en/latest/parameters.html#min-dist",children:"View UMAP documentation"})})]}),oo=s(re,{children:[e(N,{weight:"heavy",level:4,children:"Number of Samples"}),s(ie,{children:[e(y,{elementType:"p",children:"Determines the number of samples from each inferences to use when projecting the point cloud using UMAP. This number is per-inferences so a value of 500 means that the point cloud will contain up to 1000 points."}),e("br",{}),e(y,{elementType:"p",children:"For best results keep this value low until you have identified a sample that you would like to analyze in more detail."})]})]});function P0(){const n=v(c=>c.umapParameters),t=v(c=>c.setUMAPParameters),{handleSubmit:a,control:i,setError:r,formState:{isDirty:l,isValid:o}}=Te({reValidateMode:"onChange",defaultValues:n}),d=p.useCallback(c=>{const u=parseFloat(c.minDist);if(u<Xn||u>Jn){r("minDist",{message:`must be between ${Xn} and ${Jn}`});return}t({minDist:u,nNeighbors:parseInt(c.nNeighbors,10),nSamples:parseInt(c.nSamples,10)})},[t,r]);return e("section",{css:h`
        & > .ac-form {
          padding: var(--ac-global-dimension-static-size-100)
            var(--ac-global-dimension-static-size-100) 0
            var(--ac-global-dimension-static-size-100);
        }
      `,children:s(Me,{onSubmit:a(d),children:[e(z,{name:"minDist",control:i,rules:{required:"field is required"},render:({field:{onChange:c,onBlur:u,value:m},fieldState:{invalid:g,error:f}})=>e(K,{label:"min distance",labelExtra:lo,type:"number",description:"how tightly to pack points",errorMessage:f==null?void 0:f.message,validationState:g?"invalid":"valid",onChange:L=>c(parseFloat(L)),onBlur:u,value:m.toString()})}),e(z,{name:"nNeighbors",control:i,rules:{required:"n neighbors is required",min:{value:Wn,message:`greater than or equal to ${Wn}`},max:{value:qn,message:`less than or equal to ${qn}`}},render:({field:c,fieldState:{invalid:u,error:m}})=>e(K,{label:"n neighbors",labelExtra:ro,type:"number",step:"0.01",description:"balances local versus global structure",errorMessage:m==null?void 0:m.message,validationState:u?"invalid":"valid",...c,value:c.value})}),e(z,{name:"nSamples",control:i,rules:{required:"n samples is required",max:{value:et,message:`must be below ${et}`},min:{value:Yn,message:`must be above ${Yn}`}},render:({field:{onChange:c,onBlur:u,value:m},fieldState:{invalid:g,error:f}})=>e(K,{label:"n samples",labelExtra:oo,defaultValue:"500",type:"number",description:"number of points to use per inferences",errorMessage:f==null?void 0:f.message,validationState:g?"invalid":"valid",onChange:L=>c(parseInt(L,10)),onBlur:u,value:m.toString()})}),e("div",{css:h`
            display: flex;
            flex-direction: row;
            justify-content: flex-end;
            margin-top: var(--ac-global-dimension-static-size-100);
          `,children:e(F,{variant:l?"primary":"default",type:"submit",isDisabled:!o,css:h`
              width: 100%;
            `,children:"Apply UMAP Parameters"})})]})})}const bn=2147483647,so=s(re,{children:[e(N,{weight:"heavy",level:4,children:"Minimum Cluster Size"}),e(ie,{children:e(y,{elementType:"p",children:"The primary parameter to effect the resulting clustering is min_cluster_size. Ideally this is a relatively intuitive parameter to select – set it to the smallest size grouping that you wish to consider a cluster."})}),e("footer",{children:e(V,{href:"https://hdbscan.readthedocs.io/en/latest/parameter_selection.html#selecting-min-cluster-size",children:"View HDBSCAN documentation"})})]}),co=s(re,{children:[e(N,{weight:"heavy",level:4,children:"Minimum Samples"}),e(ie,{children:e(y,{elementType:"p",children:"The simplest intuition for what min_samples does is provide a measure of how conservative you want you clustering to be. The larger the value of min_samples you provide, the more conservative the clustering – more points will be declared as noise, and clusters will be restricted to progressively more dense areas."})}),e("footer",{children:e(V,{href:"https://hdbscan.readthedocs.io/en/latest/parameter_selection.html#selecting-min-samples",children:"View HDBSCAN documentation"})})]}),uo=s(re,{children:[e(N,{weight:"heavy",level:4,children:"Cluster Selection Epsilon"}),e(ie,{children:e(y,{elementType:"p",children:"In some cases, we want to choose a small min_cluster_size because even groups of few points might be of interest to us. However, if our data set also contains partitions with high concentrations of objects, this parameter setting can result in a large number of micro-clusters. Selecting a value for cluster_selection_epsilon helps us to merge clusters in these regions. Or in other words, it ensures that clusters below the given threshold are not split up any further."})}),e("footer",{children:e(V,{href:"https://hdbscan.readthedocs.io/en/latest/parameter_selection.html#selecting-cluster-selection-epsilon",children:"View HDBSCAN documentation"})})]});function O0(){const n=v(u=>u.hdbscanParameters),t=v(u=>u.setHDBSCANParameters),a=v(u=>u.clustersLoading),{control:i,handleSubmit:r,formState:{isDirty:l,isValid:o},reset:d}=Te({defaultValues:n}),c=p.useCallback(u=>{const m={minClusterSize:parseInt(u.minClusterSize,10),clusterMinSamples:parseInt(u.clusterMinSamples,10),clusterSelectionEpsilon:parseFloat(u.clusterSelectionEpsilon)};t(m),d(m)},[t,d]);return e("section",{css:h`
        & > .ac-form {
          padding: var(--ac-global-dimension-static-size-100)
            var(--ac-global-dimension-static-size-100) 0
            var(--ac-global-dimension-static-size-100);
        }
      `,children:s(Me,{onSubmit:r(c),children:[e(z,{name:"minClusterSize",control:i,rules:{required:"field is required",min:{value:ui,message:"must be greater than 1"},max:{value:bn,message:"must be less than 2,147,483,647"}},render:({field:{onChange:u,onBlur:m,value:g},fieldState:{invalid:f,error:L}})=>e(K,{label:"min cluster size",labelExtra:so,type:"number",description:"the smallest size for a cluster",errorMessage:L==null?void 0:L.message,validationState:f?"invalid":"valid",onChange:C=>u(parseInt(C,10)),onBlur:m,value:g.toString()})}),e(z,{name:"clusterMinSamples",control:i,rules:{required:"field is required",min:{value:nt,message:`must be greater than ${nt}`},max:{value:bn,message:"must be less than 2,147,483,647"}},render:({field:{onBlur:u,onChange:m,value:g},fieldState:{invalid:f,error:L}})=>e(K,{label:"cluster minimum samples",labelExtra:co,type:"number",description:"determines if a point is a core point",errorMessage:L==null?void 0:L.message,validationState:f?"invalid":"valid",onChange:C=>m(parseInt(C,10)),onBlur:u,value:g.toString()})}),e(z,{name:"clusterSelectionEpsilon",control:i,rules:{required:"field is required",min:{value:0,message:"must be a non-negative number"},max:{value:bn,message:"must be less than 2,147,483,647"}},render:({field:{onBlur:u,onChange:m,value:g},fieldState:{invalid:f,error:L}})=>e(K,{label:"cluster selection epsilon",labelExtra:uo,type:"number",description:"A distance threshold",errorMessage:L==null?void 0:L.message,validationState:f?"invalid":"valid",onChange:C=>m(parseInt(C,10)),onBlur:u,value:g.toString()})}),e("div",{css:h`
            display: flex;
            flex-direction: row;
            justify-content: flex-end;
            margin-top: var(--ac-global-dimension-static-size-100);
          `,children:e(F,{variant:l?"primary":"default",type:"submit",isDisabled:!o,loading:a,css:h`
              width: 100%;
            `,children:a?"Applying parameters":"Apply Clustering Config"})})]})})}function _0(n){return e("div",{css:h`
        background-color: var(--ac-global-color-grey-200);
        border: 1px solid var(--ac-global-color-grey-300);
        padding: var(--ac-global-dimension-static-size-100);
        border-radius: var(--ac-global-rounding-medium);
        display: flex;
        flex-direction: column;
        gap: var(--ac-global-dimension-static-size-50);
        min-width: 200px;
      `,children:n.children})}function F0(n){return s("div",{css:h`
        display: flex;
        flex-direction: row;
        justify-content: space-between;
      `,children:[s("div",{css:h`
          display: flex;
          flex-direction: row;
          gap: var(--ac-global-dimension-static-size-100);
          align-items: center;
        `,children:[e(po,{color:n.color,shape:n.shape??"line"}),e(y,{children:n.name})]}),e(y,{children:n.value})]})}function N0(){return e("div",{css:h`
        height: 1px;
        background-color: var(--ac-global-color-grey-300);
        width: 100%;
      `})}const mo=n=>{if(n==="line")return h`
      width: 8px;
      height: 2px;
    `;if(n==="circle")return h`
      width: 8px;
      height: 8px;
      border-radius: 50%;
    `;if(n==="square")return h`
      width: 8px;
      height: 8px;
    `};function po({color:n,shape:t="line"}){return e("div",{css:h(mo(t),h`
          background-color: ${n};
          flex: none;
        `)})}const V0={dataKey:"timestamp",stroke:"var(--ac-global-colo-grey-400)",style:{fill:"var(--ac-global-text-color-700)"},scale:"time",type:"number",domain:["auto","auto"],padding:"gap"},z0={stroke:"var(--ac-global-color-grey-900)",label:{value:"▼",position:"top",style:{fill:"#fabe32",fontSize:Dt.typography.sizes.small.fontSize}}},R0={cursor:{fill:"var(--ac-global-color-grey-300)"}},Fe=60,Ne=Fe*24,yn=2*Ne;function K0(n){const{start:t,end:a}=n,i=Math.floor((a.valueOf()-t.valueOf())/1e3/60/60);return i<=1?{evaluationWindowMinutes:1,samplingIntervalMinutes:1}:i<=24?{evaluationWindowMinutes:Fe,samplingIntervalMinutes:Fe}:{evaluationWindowMinutes:Ne,samplingIntervalMinutes:Ne}}function $0(n){const{start:t,end:a}=n,i=Math.floor((a.valueOf()-t.valueOf())/1e3/60/60);return i<=1?{evaluationWindowMinutes:yn,samplingIntervalMinutes:1}:i<=24?{evaluationWindowMinutes:yn,samplingIntervalMinutes:Fe}:{evaluationWindowMinutes:yn,samplingIntervalMinutes:Ne}}function go(n){let t;return n<Fe?t="%H:%M %p":n<Ne?t="%x %H:%M %p":t="%-m/%-d",t}function H0(n){const t=n.samplingIntervalMinutes;return p.useMemo(()=>nn(go(t)),[t])}const ho=Object.freeze({blue100:"#A4C7E0",blue200:"#7EB0D2",blue300:"#5899C5",blue400:"#3C80AE",blue500:"#2F6488",orange100:"#FECC95",orange200:"#FDB462",orange300:"#FC9C31",orange400:"#F78403",orange500:"#C46903",purple100:"#BEBADA",purple200:"#9E98C8",purple300:"#7F77B6",purple400:"#6157A3",purple500:"#4D4581",pink100:"#FCCDE5",pink200:"#F99FCD",pink300:"#F66FB4",pink400:"#F33F9B",pink500:"#F10E82",gray100:"#f0f0f0",gray200:"#d9d9d9",gray300:"#bdbdbd",gray400:"#969696",gray500:"#737373",gray600:"#525252",gray700:"#252525",default:"#ffffff",primary:"#9efcfd",reference:"#baa1f9"}),fo=Object.freeze({default:"#000000",blue100:"#2F6488",blue200:"#3C80AE",blue300:"#5899C5",blue400:"#7EB0D2",blue500:"#A4C7E0",orange100:"#C46903",orange200:"#F78403",orange300:"#FC9C31",orange400:"#FDB462",orange500:"#FECC95",purple100:"#4D4581",purple200:"#6157A3",purple300:"#7F77B6",purple400:"#9E98C8",purple500:"#BEBADA",pink100:"#F10E82",pink200:"#F33F9B",pink300:"#F66FB4",pink400:"#F99FCD",pink500:"#FCCDE5",gray100:"#252525",gray200:"#525252",gray300:"#737373",gray400:"#969696",gray500:"#bdbdbd",gray600:"#d9d9d9",gray700:"#f0f0f0",primary:"#00add0",reference:"#4500d9"}),B0=()=>{const{theme:n}=Q();return p.useMemo(()=>n==="dark"?ho:fo,[n])};function Z0(n){switch(n.__typename){case"NominalBin":return n.name;case"IntervalBin":return`${xn(n.range.start)} - ${xn(n.range.end)}`;case"MissingValueBin":return"(empty)";case"%other":throw new Error("Unexpected bin type %other");default:O()}}function Lo(n){return typeof n=="string"&&n in Se}function G0(n){return s(Re,{defaultValue:n.size,variant:"inline-button",onChange:t=>{if(Lo(t))n.onChange(t);else throw new Error(`Unknown grid size: ${t}`)},children:[e(q,{label:"Small",value:Se.small,children:"S"}),e(q,{label:"Medium",value:Se.medium,children:"M"}),e(q,{label:"Large",value:Se.large,children:"L"})]})}function Co(n){const{message:t,...a}=n;return e("div",{css:h`
        width: 100%;
        display: flex;
        justify-content: center;
      `,children:s("div",{css:i=>h`
          margin: ${i.spacing.margin24}px;
          display: flex;
          flex-direction: column;
          align-items: center;
        `,children:[e(Ot,{...a}),t&&e(y,{children:t})]})})}function bo(n){switch(n){case"OK":return"success";case"ERROR":return"danger";case"UNSET":return"grey-500";default:O()}}function yo({statusCode:n}){let t=e(T.MinusCircleOutline,{});const a=bo(n);switch(n){case"OK":t=e(T.CheckmarkCircleOutline,{});break;case"ERROR":t=e(T.AlertCircleOutline,{});break;case"UNSET":t=e(T.MinusCircleOutline,{});break;default:O()}return e(I,{svg:t,color:a,"aria-label":n})}function vo(n){return s(Z,{children:[e(ae,{children:e(vn,{textSize:n.textSize,children:n.tokenCountTotal})}),e(Y,{children:s(x,{direction:"column",gap:"size-50",children:[s(x,{direction:"row",gap:"size-100",justifyContent:"space-between",children:["prompt tokens",e(vn,{children:n.tokenCountPrompt})]}),s(x,{direction:"row",gap:"size-100",justifyContent:"space-between",children:["completion tokens",e(vn,{children:n.tokenCountCompletion})]})]})})]})}function vn({children:n,...t}){return s(x,{direction:"row",gap:"size-50",alignItems:"center",children:[e(I,{svg:e(T.TokensOutline,{}),css:h`
          color: var(--ac-global-text-color-900);
        `}),e(y,{...t,children:n})]})}const ko=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("mask",{id:"path-2-inside-1_33_16916",fill:"currentColor",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M13 8C13 8.64491 12.8779 9.2613 12.6556 9.82732L17.1924 14.3641L14.364 17.1926L9.82706 12.6557C9.26111 12.8779 8.64481 13 8 13C5.23858 13 3 10.7614 3 8C3 7.13361 3.22036 6.31869 3.60809 5.60822L6 8L7.5 7.50016L8 6.00016L5.60803 3.60819C6.31854 3.2204 7.13353 3 8 3C10.7614 3 13 5.23858 13 8Z"})}),e("path",{d:"M12.6556 9.82732L11.7248 9.46171L11.4853 10.0713L11.9485 10.5344L12.6556 9.82732ZM17.1924 14.3641L17.8995 15.0713L18.6066 14.3641L17.8995 13.657L17.1924 14.3641ZM14.364 17.1926L13.6569 17.8997L14.364 18.6068L15.0711 17.8997L14.364 17.1926ZM9.82706 12.6557L10.5342 11.9486L10.0711 11.4855L9.4615 11.7249L9.82706 12.6557ZM3.60809 5.60822L4.31518 4.90109L3.37037 3.95634L2.7303 5.12917L3.60809 5.60822ZM6 8L5.29291 8.70713L5.72988 9.14407L6.31613 8.94871L6 8ZM7.5 7.50016L7.81614 8.44888L8.29055 8.29079L8.44869 7.81639L7.5 7.50016ZM8 6.00016L8.94869 6.31639L9.14413 5.73007L8.70711 5.29306L8 6.00016ZM5.60803 3.60819L5.12895 2.73042L3.95616 3.37053L4.90093 4.3153L5.60803 3.60819ZM13.5863 10.1929C13.8537 9.51235 14 8.77206 14 8H12C12 8.51776 11.9021 9.01026 11.7248 9.46171L13.5863 10.1929ZM17.8995 13.657L13.3627 9.12022L11.9485 10.5344L16.4853 15.0713L17.8995 13.657ZM15.0711 17.8997L17.8995 15.0713L16.4853 13.657L13.6569 16.4855L15.0711 17.8997ZM9.11995 13.3628L13.6569 17.8997L15.0711 16.4855L10.5342 11.9486L9.11995 13.3628ZM8 14C8.77194 14 9.51211 13.8537 10.1926 13.5865L9.4615 11.7249C9.0101 11.9022 8.51768 12 8 12V14ZM2 8C2 11.3137 4.68629 14 8 14V12C5.79086 12 4 10.2091 4 8H2ZM2.7303 5.12917C2.2644 5.98288 2 6.96206 2 8H4C4 7.30516 4.17633 6.65449 4.48588 6.08727L2.7303 5.12917ZM6.70709 7.29287L4.31518 4.90109L2.901 6.31535L5.29291 8.70713L6.70709 7.29287ZM7.18387 6.55145L5.68387 7.05129L6.31613 8.94871L7.81614 8.44888L7.18387 6.55145ZM7.05132 5.68394L6.55132 7.18394L8.44869 7.81639L8.94869 6.31639L7.05132 5.68394ZM4.90093 4.3153L7.2929 6.70727L8.70711 5.29306L6.31514 2.90109L4.90093 4.3153ZM8 2C6.96197 2 5.98271 2.26444 5.12895 2.73042L6.08712 4.48596C6.65437 4.17636 7.3051 4 8 4V2ZM14 8C14 4.68629 11.3137 2 8 2V4C10.2091 4 12 5.79086 12 8H14Z",fill:"currentColor",fillOpacity:"0.9",mask:"url(#path-2-inside-1_33_16916)"})]}),So=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("mask",{id:"path-2-inside-1_2321_643",fill:"white",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M13 8C13 8.64491 12.8779 9.2613 12.6556 9.82732L17.1924 14.3641L14.364 17.1926L9.82706 12.6557C9.26111 12.8779 8.64481 13 8 13C5.23858 13 3 10.7614 3 8C3 7.13361 3.22036 6.31869 3.60809 5.60822L6 8L7.5 7.50016L8 6.00016L5.60803 3.60819C6.31854 3.2204 7.13353 3 8 3C10.7614 3 13 5.23858 13 8Z"})}),e("path",{d:"M12.6556 9.82732L11.7248 9.46171L11.4853 10.0713L11.9485 10.5344L12.6556 9.82732ZM17.1924 14.3641L17.8995 15.0713L18.6066 14.3641L17.8995 13.657L17.1924 14.3641ZM14.364 17.1926L13.6569 17.8997L14.364 18.6068L15.0711 17.8997L14.364 17.1926ZM9.82706 12.6557L10.5342 11.9486L10.0711 11.4855L9.4615 11.7249L9.82706 12.6557ZM3.60809 5.60822L4.31518 4.90109L3.37037 3.95634L2.7303 5.12917L3.60809 5.60822ZM6 8L5.29291 8.70713L5.72988 9.14407L6.31613 8.94871L6 8ZM7.5 7.50016L7.81614 8.44888L8.29055 8.29079L8.44869 7.81639L7.5 7.50016ZM8 6.00016L8.94869 6.31639L9.14413 5.73007L8.70711 5.29306L8 6.00016ZM5.60803 3.60819L5.12895 2.73042L3.95616 3.37053L4.90093 4.3153L5.60803 3.60819ZM13.5863 10.1929C13.8537 9.51235 14 8.77206 14 8H12C12 8.51776 11.9021 9.01026 11.7248 9.46171L13.5863 10.1929ZM17.8995 13.657L13.3627 9.12022L11.9485 10.5344L16.4853 15.0713L17.8995 13.657ZM15.0711 17.8997L17.8995 15.0713L16.4853 13.657L13.6569 16.4855L15.0711 17.8997ZM9.11995 13.3628L13.6569 17.8997L15.0711 16.4855L10.5342 11.9486L9.11995 13.3628ZM8 14C8.77194 14 9.51211 13.8537 10.1926 13.5865L9.4615 11.7249C9.0101 11.9022 8.51768 12 8 12V14ZM2 8C2 11.3137 4.68629 14 8 14V12C5.79086 12 4 10.2091 4 8H2ZM2.7303 5.12917C2.2644 5.98288 2 6.96206 2 8H4C4 7.30516 4.17633 6.65449 4.48588 6.08727L2.7303 5.12917ZM6.70709 7.29287L4.31518 4.90109L2.901 6.31535L5.29291 8.70713L6.70709 7.29287ZM7.18387 6.55145L5.68387 7.05129L6.31613 8.94871L7.81614 8.44888L7.18387 6.55145ZM7.05132 5.68394L6.55132 7.18394L8.44869 7.81639L8.94869 6.31639L7.05132 5.68394ZM4.90093 4.3153L7.2929 6.70727L8.70711 5.29306L6.31514 2.90109L4.90093 4.3153ZM8 2C6.96197 2 5.98271 2.26444 5.12895 2.73042L6.08712 4.48596C6.65437 4.17636 7.3051 4 8 4V2ZM14 8C14 4.68629 11.3137 2 8 2V4C10.2091 4 12 5.79086 12 8H14Z",fill:"black",mask:"url(#path-2-inside-1_2321_643)"})]}),wo=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("path",{d:"M4.43782 6.78868L10 3.57735L15.5622 6.78868V13.2113L10 16.4226L4.43782 13.2113V6.78868Z",stroke:"currentColor",strokeOpacity:"0.9"})]}),xo=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{d:"M4.43782 6.78868L10 3.57735L15.5622 6.78868V13.2113L10 16.4226L4.43782 13.2113V6.78868Z",stroke:"black"})]}),To=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("path",{d:"M5 16C5 16 5 11 10 11C15 11 15 16 15 16",stroke:"currentColor",strokeOpacity:"0.9"}),e("rect",{x:"6.5",y:"4.5",width:"7",height:"5",rx:"0.5",stroke:"currentColor",strokeOpacity:"0.9"})]}),Mo=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{width:"20",height:"20",rx:"4",fill:"currentColor"}),e("path",{d:"M10 11C5 11 5 16 5 16H15C15 16 15 11 10 11Z",stroke:"black"}),e("rect",{x:"6.5",y:"4.5",width:"7",height:"5",rx:"0.5",stroke:"black"})]}),Io=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 6C10 7.10457 9.10457 8 8 8C6.89543 8 6 7.10457 6 6C6 4.89543 6.89543 4 8 4C9.10457 4 10 4.89543 10 6ZM10.0558 8.18487C9.51887 8.6903 8.7956 9 8 9C7.91155 9 7.824 8.99617 7.7375 8.98867L7.10304 11.2093C8.21409 11.6488 9 12.7326 9 14C9 15.6569 7.65685 17 6 17C4.34315 17 3 15.6569 3 14C3 12.3431 4.34315 11 6 11C6.0409 11 6.08161 11.0008 6.12212 11.0024L6.76944 8.73682C5.72625 8.26703 5 7.21833 5 6C5 4.34315 6.34315 3 8 3C9.65685 3 11 4.34315 11 6C11 6.50075 10.8773 6.97285 10.6604 7.38788L12.1873 8.6094C12.6908 8.22697 13.3189 8 14 8C15.6569 8 17 9.34315 17 11C17 12.6569 15.6569 14 14 14C12.3431 14 11 12.6569 11 11C11 10.3864 11.1842 9.81579 11.5004 9.34053L10.0558 8.18487ZM16 11C16 12.1046 15.1046 13 14 13C12.8954 13 12 12.1046 12 11C12 9.89543 12.8954 9 14 9C15.1046 9 16 9.89543 16 11ZM6 16C7.10457 16 8 15.1046 8 14C8 12.8954 7.10457 12 6 12C4.89543 12 4 12.8954 4 14C4 15.1046 4.89543 16 6 16Z",fill:"currentColor",fillOpacity:"0.9"})]}),Ao=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 6.00003C10 7.1046 9.10457 8.00003 8 8.00003C6.89543 8.00003 6 7.1046 6 6.00003C6 4.89546 6.89543 4.00003 8 4.00003C9.10457 4.00003 10 4.89546 10 6.00003ZM10.0558 8.1849C9.51887 8.69033 8.7956 9.00003 8 9.00003C7.91155 9.00003 7.824 8.9962 7.7375 8.9887L7.10304 11.2093C8.21409 11.6488 9 12.7326 9 14C9 15.6569 7.65685 17 6 17C4.34315 17 3 15.6569 3 14C3 12.3432 4.34315 11 6 11C6.0409 11 6.08161 11.0008 6.12212 11.0025L6.76944 8.73685C5.72625 8.26706 5 7.21836 5 6.00003C5 4.34318 6.34315 3.00003 8 3.00003C9.65685 3.00003 11 4.34318 11 6.00003C11 6.50078 10.8773 6.97288 10.6604 7.38791L12.1873 8.60943C12.6908 8.227 13.3189 8.00003 14 8.00003C15.6569 8.00003 17 9.34318 17 11C17 12.6569 15.6569 14 14 14C12.3431 14 11 12.6569 11 11C11 10.3864 11.1842 9.81582 11.5004 9.34056L10.0558 8.1849ZM16 11C16 12.1046 15.1046 13 14 13C12.8954 13 12 12.1046 12 11C12 9.89546 12.8954 9.00003 14 9.00003C15.1046 9.00003 16 9.89546 16 11ZM6 16C7.10457 16 8 15.1046 8 14C8 12.8955 7.10457 12 6 12C4.89543 12 4 12.8955 4 14C4 15.1046 4.89543 16 6 16Z",fill:"black"})]}),Eo=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("path",{d:"M14.65 6.5C14.65 6.98637 14.2466 7.52091 13.379 7.95472C12.5323 8.37806 11.3382 8.65 10 8.65C8.66184 8.65 7.46767 8.37806 6.62099 7.95472C5.75338 7.52091 5.35 6.98637 5.35 6.5C5.35 6.01363 5.75338 5.47909 6.62099 5.04528C7.46767 4.62194 8.66184 4.35 10 4.35C11.3382 4.35 12.5323 4.62194 13.379 5.04528C14.2466 5.47909 14.65 6.01363 14.65 6.5Z",stroke:"currentColor",strokeOpacity:"0.9",strokeWidth:"0.7"}),e("path",{d:"M14.6875 6.83482V9.62479C14.6875 9.62479 13.0769 11.1873 10 11.1873C6.92308 11.1873 5.3125 9.62479 5.3125 9.62479V6.7437",stroke:"currentColor",strokeOpacity:"0.9",strokeWidth:"0.7"}),e("path",{d:"M14.6875 9.625V12.125C14.6875 12.125 13.0769 13.6875 10 13.6875C6.92308 13.6875 5.3125 12.125 5.3125 12.125V9.625",stroke:"currentColor",strokeOpacity:"0.9",strokeWidth:"0.7"}),e("path",{d:"M14.6875 12.125V14.625C14.6875 14.625 13.0769 16.1875 10 16.1875C6.92308 16.1875 5.3125 14.625 5.3125 14.625V12.125",stroke:"currentColor",strokeOpacity:"0.9",strokeWidth:"0.7"})]}),Do=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{d:"M14.65 6.5C14.65 6.98637 14.2466 7.52091 13.379 7.95472C12.5323 8.37806 11.3382 8.65 10 8.65C8.66184 8.65 7.46767 8.37806 6.62099 7.95472C5.75338 7.52091 5.35 6.98637 5.35 6.5C5.35 6.01363 5.75338 5.47909 6.62099 5.04528C7.46767 4.62194 8.66184 4.35 10 4.35C11.3382 4.35 12.5323 4.62194 13.379 5.04528C14.2466 5.47909 14.65 6.01363 14.65 6.5Z",stroke:"black",strokeWidth:"0.7"}),e("path",{d:"M14.6875 6.83504V9.625C14.6875 9.625 13.0769 11.1875 10 11.1875C6.92308 11.1875 5.3125 9.625 5.3125 9.625V6.74392",stroke:"black",strokeWidth:"0.7"}),e("path",{d:"M14.6875 9.625V12.125C14.6875 12.125 13.0769 13.6875 10 13.6875C6.92308 13.6875 5.3125 12.125 5.3125 12.125V9.625",stroke:"black",strokeWidth:"0.7"}),e("path",{d:"M14.6875 12.125V14.625C14.6875 14.625 13.0769 16.1875 10 16.1875C6.92308 16.1875 5.3125 14.625 5.3125 14.625V12.125",stroke:"black",strokeWidth:"0.7"})]}),Po=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor"}),e("path",{d:"M4.5359 10L8 4L11.4641 10H4.5359Z",stroke:"currentColor"}),e("path",{d:"M8.5359 10L12 16L15.4641 10H8.5359Z",stroke:"currentColor"})]}),Oo=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{d:"M4.5359 10L8 4L11.4641 10H4.5359Z",stroke:"black"}),e("path",{d:"M8.5359 10L12 16L15.4641 10H8.5359Z",stroke:"black"})]}),_o=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 15C12.7614 15 15 12.7614 15 10C15 7.23858 12.7614 5 10 5C7.23858 5 5 7.23858 5 10C5 12.7614 7.23858 15 10 15ZM10 16C13.3137 16 16 13.3137 16 10C16 6.68629 13.3137 4 10 4C6.68629 4 4 6.68629 4 10C4 13.3137 6.68629 16 10 16Z",fill:"currentColor",fillOpacity:"0.9"})]}),Fo=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 15C12.7614 15 15 12.7614 15 10C15 7.23858 12.7614 5 10 5C7.23858 5 5 7.23858 5 10C5 12.7614 7.23858 15 10 15ZM10 16C13.3137 16 16 13.3137 16 10C16 6.68629 13.3137 4 10 4C6.68629 4 4 6.68629 4 10C4 13.3137 6.68629 16 10 16Z",fill:"black"})]}),No=()=>e("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"})}),Vo=()=>e("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"})}),zo=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor"}),e("path",{d:"M14.4254 5.58523L15.744 6.87427L15.7249 6.89333L15.7043 6.91394L15.6837 6.93453L15.6631 6.95509L15.6425 6.97562L15.622 6.99612L15.6015 7.01659L15.581 7.03703L15.5606 7.05745L15.5402 7.07783L15.5198 7.09819L15.4995 7.11852L15.4791 7.13882L15.4588 7.15909L15.4386 7.17934L15.4183 7.19956L15.3981 7.21974L15.3779 7.23991L15.3578 7.26004L15.3377 7.28015L15.3176 7.30022L15.2975 7.32028L15.2774 7.3403L15.2574 7.3603L15.2374 7.38027L15.2175 7.40021L15.1975 7.42013L15.1776 7.44002L15.1577 7.45988L15.1379 7.47972L15.118 7.49953L15.0982 7.51931L15.0784 7.53907L15.0587 7.5588L15.0389 7.57851L15.0192 7.59819L14.9996 7.61785L14.9799 7.63748L14.9603 7.65708L14.9407 7.67666L14.9211 7.69621L14.9016 7.71574L14.882 7.73524L14.8625 7.75472L14.8431 7.77417L14.8236 7.7936L14.8042 7.81301L14.7848 7.83239L14.7654 7.85174L14.746 7.87107L14.7267 7.89038L14.7074 7.90966L14.6881 7.92892L14.6689 7.94815L14.6496 7.96736L14.6304 7.98655L14.6113 8.00571L14.5921 8.02485L14.573 8.04397L14.5538 8.06306L14.5347 8.08213L14.5157 8.10118L14.4966 8.1202L14.4776 8.1392L14.4586 8.15818L14.4396 8.17714L14.4207 8.19607L14.4017 8.21498L14.3828 8.23387L14.3639 8.25274L14.3451 8.27158L14.3262 8.2904L14.3074 8.3092L14.2886 8.32798L14.2698 8.34674L14.2511 8.36547L14.2323 8.38418L14.2136 8.40288L14.1949 8.42155L14.1763 8.4402L14.1576 8.45883L14.139 8.47743L14.1204 8.49602L14.1018 8.51459L14.0832 8.53313L14.0647 8.55166L14.0462 8.57016L14.0277 8.58864L14.0092 8.60711L13.9907 8.62555L13.9723 8.64397L13.9538 8.66238L13.9354 8.68076L13.917 8.69913L13.8987 8.71747L13.8803 8.73579L13.862 8.7541L13.8437 8.77239L13.8254 8.79065L13.8071 8.8089L13.7889 8.82713L13.7707 8.84534L13.7524 8.86353L13.7343 8.8817L13.7161 8.89986L13.6979 8.91799L13.6798 8.93611L13.6617 8.95421L13.6436 8.97229L13.6255 8.99036L13.6074 9.0084L13.5894 9.02643L13.5713 9.04444L13.5533 9.06243L13.5353 9.0804L13.5173 9.09836L13.4994 9.1163L13.4814 9.13422L13.4635 9.15213L13.4456 9.17002L13.4277 9.18789L13.4098 9.20574L13.392 9.22358L13.3741 9.2414L13.3563 9.25921L13.3385 9.277L13.3207 9.29477L13.3029 9.31253L13.2852 9.33027L13.2674 9.34799L13.2497 9.3657L13.232 9.38339L13.2143 9.40107L13.1966 9.41873L13.1789 9.43638L13.1613 9.45401L13.1436 9.47163L13.126 9.48923L13.1084 9.50681L13.0908 9.52438L13.0733 9.54194L13.0557 9.55948L13.0381 9.57701L13.0206 9.59452L13.0031 9.61202L12.9856 9.6295L12.9681 9.64697L12.9506 9.66443L12.9332 9.68187L12.9157 9.6993L12.8983 9.71671L12.8809 9.73412L12.8634 9.7515L12.8461 9.76888L12.8287 9.78624L12.8113 9.80358L12.794 9.82092L12.7766 9.83824L12.7593 9.85555L12.742 9.87284L12.7247 9.89013L12.7074 9.9074L12.6901 9.92466L12.6728 9.9419L12.6556 9.95913L12.6383 9.97636L12.6211 9.99356L12.6039 10.0108L12.5867 10.0279L12.5695 10.0451L12.5523 10.0623L12.5351 10.0794L12.518 10.0966L12.5008 10.1137L12.4837 10.1308L12.4666 10.1479L12.4495 10.165L12.4324 10.1821L12.4153 10.1992L12.3982 10.2162L12.3811 10.2333L12.364 10.2503L12.347 10.2674L12.33 10.2844L12.3129 10.3014L12.2959 10.3184L12.2789 10.3354L12.2619 10.3524L12.2449 10.3693L12.2279 10.3863L12.211 10.4032L12.194 10.4202L12.177 10.4371L12.1601 10.454L12.1432 10.471L12.1262 10.4879L12.1093 10.5048L12.0924 10.5216L12.0755 10.5385L12.0586 10.5554L12.0417 10.5723L12.0249 10.5891L12.008 10.606L11.9911 10.6228L11.9743 10.6396L11.9575 10.6565L11.9406 10.6733L11.9238 10.6901L11.907 10.7069L11.8902 10.7237L11.8734 10.7404L11.8566 10.7572L11.8398 10.774L11.823 10.7907L11.8062 10.8075L11.7895 10.8243L11.7727 10.841L11.7559 10.8577L11.7392 10.8745L11.7225 10.8912L11.7057 10.9079L11.689 10.9246L11.6723 10.9413L11.6556 10.958L11.6389 10.9747L11.6221 10.9914L11.6054 11.0081L11.5888 11.0247L11.5721 11.0414L11.5554 11.0581L11.5387 11.0747L11.522 11.0914L11.5054 11.108L11.4887 11.1247L11.4721 11.1413L11.4554 11.1579L11.4388 11.1746L11.4221 11.1912L11.4055 11.2078L11.3888 11.2244L11.3722 11.241L11.3556 11.2576L11.339 11.2742L11.3224 11.2908L11.3057 11.3074L11.2891 11.324L11.2725 11.3406L11.2559 11.3572L11.2393 11.3738L11.2227 11.3903L11.2061 11.4069L11.1895 11.4235L11.173 11.44L11.1564 11.4566L11.1398 11.4732L11.1232 11.4897L11.1066 11.5063L11.0901 11.5228L11.0735 11.5394L11.0569 11.5559L11.0404 11.5725L11.0238 11.589L11.0072 11.6056L10.9907 11.6221L10.9741 11.6386L10.9576 11.6552L10.941 11.6717L10.9245 11.6883L10.9079 11.7048L10.8914 11.7213L10.8748 11.7378L10.8583 11.7544L10.8417 11.7709L10.8252 11.7874L10.8086 11.804L10.7921 11.8205L10.7755 11.837L10.759 11.8535L10.7424 11.8701L10.7259 11.8866L10.7094 11.9031L10.6928 11.9196L10.6763 11.9362L10.6597 11.9527L10.6432 11.9692L10.6266 11.9857L10.6101 12.0023L10.5935 12.0188L10.577 12.0353L10.5604 12.0519L10.5439 12.0684L10.5273 12.0849L10.5108 12.1015L10.4942 12.118L10.4777 12.1345L10.4611 12.1511L10.4446 12.1676L10.428 12.1841L10.4114 12.2007L10.3949 12.2172L10.3783 12.2338L10.3618 12.2503L10.3452 12.2669L10.3286 12.2834L10.312 12.3L10.2955 12.3165L10.2789 12.3331L10.2623 12.3497L10.2457 12.3662L10.2291 12.3828L10.2125 12.3994L10.1959 12.4159L10.1793 12.4325L10.1627 12.4491L10.1461 12.4657L10.1295 12.4823L10.1129 12.4989L10.0963 12.5155L10.0797 12.5321L10.0631 12.5487L10.0464 12.5653L10.0298 12.5819L10.0132 12.5985L9.99652 12.6151L9.97987 12.6318L9.96322 12.6484L9.94657 12.665L9.92991 12.6817L9.91324 12.6983L9.89657 12.715L9.87989 12.7316L9.86321 12.7483L9.84653 12.7649L9.82984 12.7816L9.81314 12.7983L9.79644 12.815L9.77973 12.8317L9.76301 12.8484L9.74629 12.8651L9.72957 12.8818L9.71283 12.8985L9.69609 12.9152L9.67935 12.9319L9.6626 12.9487L9.64584 12.9654L9.62907 12.9822L9.6123 12.9989L9.59552 13.0157L9.57873 13.0324L9.56194 13.0492L9.54514 13.066L9.52833 13.0828L9.51151 13.0996L9.49469 13.1164L9.47786 13.1332L9.46102 13.15L9.44417 13.1668L9.42732 13.1837L9.41045 13.2005L9.39358 13.2174L9.3767 13.2342L9.35981 13.2511L9.34292 13.268L9.32601 13.2849L9.3091 13.3018L9.29217 13.3187L9.27524 13.3356L9.2583 13.3525L9.24135 13.3694L9.22439 13.3864L9.20742 13.4033L9.19044 13.4203L9.17345 13.4372L9.15645 13.4542L9.13945 13.4712L9.12243 13.4882L9.1054 13.5052L9.08836 13.5222L9.07131 13.5393L9.05426 13.5563L9.03719 13.5734L9.02011 13.5904L9.00302 13.6075L8.98592 13.6246L8.9688 13.6417L8.95168 13.6588L8.93455 13.6759L8.9174 13.693L8.90024 13.7101L8.88308 13.7273L8.8659 13.7444L8.84871 13.7616L8.8315 13.7788L8.81429 13.796L8.79706 13.8132L8.77983 13.8304L8.76257 13.8477L8.74531 13.8649L8.72804 13.8821L8.71075 13.8994L8.69345 13.9167L8.67614 13.934L8.65881 13.9513L8.64147 13.9686L8.62412 13.9859L8.60676 14.0033L8.58938 14.0206L8.57199 14.038L8.55458 14.0554L8.53716 14.0728L8.51973 14.0902L8.50229 14.1076L8.48483 14.1251L8.46736 14.1425L8.44987 14.16L8.43237 14.1775L8.41485 14.195L8.39732 14.2125L8.37978 14.23L8.36222 14.2475L8.34465 14.2651L8.32706 14.2827L8.30945 14.3002L8.29184 14.3178L8.2742 14.3355L8.25656 14.3531L8.23889 14.3707L8.22121 14.3884L8.20352 14.4061L8.18581 14.4238L8.16808 14.4415L8.15034 14.4592L8.13258 14.4769L8.11481 14.4947L8.09702 14.5124L8.07921 14.5302L8.06139 14.548L8.04355 14.5658L8.0257 14.5837L8.00783 14.6015L7.98994 14.6194L7.97203 14.6373L7.95411 14.6552L7.93617 14.6731L7.91821 14.691L7.90024 14.709L7.88225 14.727L7.86424 14.7449L7.84621 14.763L7.82817 14.781L7.81011 14.799L7.79203 14.8171L7.77393 14.8352L7.75581 14.8533L7.73768 14.8714L7.71952 14.8895L7.70135 14.9076L7.68316 14.9258L7.66495 14.944L7.64673 14.9622L7.62848 14.9804L7.61022 14.9987L7.59193 15.0169L7.57363 15.0352L7.55531 15.0535L7.53697 15.0718L7.5186 15.0902L7.50022 15.1085L7.48182 15.1269L7.4634 15.1453L7.44496 15.1637L7.4265 15.1822L7.40802 15.2006L7.38952 15.2191L7.371 15.2376L7.35246 15.2561L7.33389 15.2747L7.31531 15.2932L7.29671 15.3118L7.27808 15.3304L7.25944 15.3491L7.24077 15.3677L7.22208 15.3864L7.20337 15.4051L7.18464 15.4238L7.16589 15.4425L7.14712 15.4612L7.12832 15.48L7.10951 15.4988L7.09067 15.5176L7.07181 15.5365L7.05292 15.5553L7.03402 15.5742L7.01509 15.5931L6.99614 15.612C6.27167 16.3357 5.09652 16.3361 4.37259 15.613C3.64838 14.8896 3.64838 13.7168 4.37259 12.9935L13.1214 4.2547L14.4178 5.57764L14.4177 5.57772L14.4254 5.58523Z",stroke:"currentColor"}),e("path",{d:"M12.5299 10.2848L7.32791 15.5545C7.12956 15.7555 6.88934 15.9156 6.62689 16.0225C6.08679 16.2424 5.46752 16.2239 4.94171 15.972L4.77945 16.31L4.94171 15.972C4.6339 15.8246 4.36574 15.6007 4.16736 15.3245L4.02179 15.1219C3.60142 14.5367 3.60138 13.749 4.02169 13.1637C4.12291 13.0228 4.24539 12.8984 4.38476 12.7949L5.72374 11.8006L5.76816 11.7676L5.80115 11.7232L5.91056 11.576C6.30572 11.0443 6.96187 10.4244 7.58765 10.0864C7.90229 9.91646 8.17215 9.83813 8.37711 9.84461C8.55555 9.85025 8.69852 9.9179 8.81563 10.1071C8.88186 10.2141 8.92418 10.3701 8.97238 10.5823C8.97507 10.5942 8.9778 10.6063 8.98058 10.6186C9.00013 10.7052 9.02201 10.8022 9.04751 10.8896C9.07575 10.9865 9.11828 11.1086 9.19239 11.2146C9.29475 11.361 9.4504 11.4075 9.53763 11.4247C9.63768 11.4444 9.74477 11.4446 9.84616 11.436C10.0516 11.4187 10.299 11.3594 10.5607 11.2642C11.0498 11.0864 11.6345 10.7668 12.1516 10.2848L12.5299 10.2848Z",stroke:"currentColor",strokeWidth:"0.75"})]}),Ro=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{d:"M14.4254 5.58523L15.744 6.87427L15.7249 6.89333L15.7043 6.91394L15.6837 6.93453L15.6631 6.95509L15.6425 6.97562L15.622 6.99612L15.6015 7.01659L15.581 7.03703L15.5606 7.05745L15.5402 7.07783L15.5198 7.09819L15.4995 7.11852L15.4791 7.13882L15.4588 7.15909L15.4386 7.17934L15.4183 7.19956L15.3981 7.21974L15.3779 7.23991L15.3578 7.26004L15.3377 7.28015L15.3176 7.30022L15.2975 7.32028L15.2774 7.3403L15.2574 7.3603L15.2374 7.38027L15.2175 7.40021L15.1975 7.42013L15.1776 7.44002L15.1577 7.45988L15.1379 7.47972L15.118 7.49953L15.0982 7.51931L15.0784 7.53907L15.0587 7.5588L15.0389 7.57851L15.0192 7.59819L14.9996 7.61785L14.9799 7.63748L14.9603 7.65708L14.9407 7.67666L14.9211 7.69621L14.9016 7.71574L14.882 7.73524L14.8625 7.75472L14.8431 7.77417L14.8236 7.7936L14.8042 7.81301L14.7848 7.83239L14.7654 7.85174L14.746 7.87107L14.7267 7.89038L14.7074 7.90966L14.6881 7.92892L14.6689 7.94815L14.6496 7.96736L14.6304 7.98655L14.6113 8.00571L14.5921 8.02485L14.573 8.04397L14.5538 8.06306L14.5347 8.08213L14.5157 8.10118L14.4966 8.1202L14.4776 8.1392L14.4586 8.15818L14.4396 8.17714L14.4207 8.19607L14.4017 8.21498L14.3828 8.23387L14.3639 8.25274L14.3451 8.27158L14.3262 8.2904L14.3074 8.3092L14.2886 8.32798L14.2698 8.34674L14.2511 8.36547L14.2323 8.38418L14.2136 8.40288L14.1949 8.42155L14.1763 8.4402L14.1576 8.45883L14.139 8.47743L14.1204 8.49602L14.1018 8.51459L14.0832 8.53313L14.0647 8.55166L14.0462 8.57016L14.0277 8.58864L14.0092 8.60711L13.9907 8.62555L13.9723 8.64397L13.9538 8.66238L13.9354 8.68076L13.917 8.69913L13.8987 8.71747L13.8803 8.73579L13.862 8.7541L13.8437 8.77239L13.8254 8.79065L13.8071 8.8089L13.7889 8.82713L13.7707 8.84534L13.7524 8.86353L13.7343 8.8817L13.7161 8.89986L13.6979 8.91799L13.6798 8.93611L13.6617 8.95421L13.6436 8.97229L13.6255 8.99036L13.6074 9.0084L13.5894 9.02643L13.5713 9.04444L13.5533 9.06243L13.5353 9.0804L13.5173 9.09836L13.4994 9.1163L13.4814 9.13422L13.4635 9.15213L13.4456 9.17002L13.4277 9.18789L13.4098 9.20574L13.392 9.22358L13.3741 9.2414L13.3563 9.25921L13.3385 9.277L13.3207 9.29477L13.3029 9.31253L13.2852 9.33027L13.2674 9.34799L13.2497 9.3657L13.232 9.38339L13.2143 9.40107L13.1966 9.41873L13.1789 9.43638L13.1613 9.45401L13.1436 9.47163L13.126 9.48923L13.1084 9.50681L13.0908 9.52438L13.0733 9.54194L13.0557 9.55948L13.0381 9.57701L13.0206 9.59452L13.0031 9.61202L12.9856 9.6295L12.9681 9.64697L12.9506 9.66443L12.9332 9.68187L12.9157 9.6993L12.8983 9.71671L12.8809 9.73412L12.8634 9.7515L12.8461 9.76888L12.8287 9.78624L12.8113 9.80358L12.794 9.82092L12.7766 9.83824L12.7593 9.85555L12.742 9.87284L12.7247 9.89013L12.7074 9.9074L12.6901 9.92466L12.6728 9.9419L12.6556 9.95913L12.6383 9.97636L12.6211 9.99356L12.6039 10.0108L12.5867 10.0279L12.5695 10.0451L12.5523 10.0623L12.5351 10.0794L12.518 10.0966L12.5008 10.1137L12.4837 10.1308L12.4666 10.1479L12.4495 10.165L12.4324 10.1821L12.4153 10.1992L12.3982 10.2162L12.3811 10.2333L12.364 10.2503L12.347 10.2674L12.33 10.2844L12.3129 10.3014L12.2959 10.3184L12.2789 10.3354L12.2619 10.3524L12.2449 10.3693L12.2279 10.3863L12.211 10.4032L12.194 10.4202L12.177 10.4371L12.1601 10.454L12.1432 10.471L12.1262 10.4879L12.1093 10.5048L12.0924 10.5216L12.0755 10.5385L12.0586 10.5554L12.0417 10.5723L12.0249 10.5891L12.008 10.606L11.9911 10.6228L11.9743 10.6396L11.9575 10.6565L11.9406 10.6733L11.9238 10.6901L11.907 10.7069L11.8902 10.7237L11.8734 10.7404L11.8566 10.7572L11.8398 10.774L11.823 10.7907L11.8062 10.8075L11.7895 10.8243L11.7727 10.841L11.7559 10.8577L11.7392 10.8745L11.7225 10.8912L11.7057 10.9079L11.689 10.9246L11.6723 10.9413L11.6556 10.958L11.6389 10.9747L11.6221 10.9914L11.6054 11.0081L11.5888 11.0247L11.5721 11.0414L11.5554 11.0581L11.5387 11.0747L11.522 11.0914L11.5054 11.108L11.4887 11.1247L11.4721 11.1413L11.4554 11.1579L11.4388 11.1746L11.4221 11.1912L11.4055 11.2078L11.3888 11.2244L11.3722 11.241L11.3556 11.2576L11.339 11.2742L11.3224 11.2908L11.3057 11.3074L11.2891 11.324L11.2725 11.3406L11.2559 11.3572L11.2393 11.3738L11.2227 11.3903L11.2061 11.4069L11.1895 11.4235L11.173 11.44L11.1564 11.4566L11.1398 11.4732L11.1232 11.4897L11.1066 11.5063L11.0901 11.5228L11.0735 11.5394L11.0569 11.5559L11.0404 11.5725L11.0238 11.589L11.0072 11.6056L10.9907 11.6221L10.9741 11.6386L10.9576 11.6552L10.941 11.6717L10.9245 11.6883L10.9079 11.7048L10.8914 11.7213L10.8748 11.7378L10.8583 11.7544L10.8417 11.7709L10.8252 11.7874L10.8086 11.804L10.7921 11.8205L10.7755 11.837L10.759 11.8535L10.7424 11.8701L10.7259 11.8866L10.7094 11.9031L10.6928 11.9196L10.6763 11.9362L10.6597 11.9527L10.6432 11.9692L10.6266 11.9857L10.6101 12.0023L10.5935 12.0188L10.577 12.0353L10.5604 12.0519L10.5439 12.0684L10.5273 12.0849L10.5108 12.1015L10.4942 12.118L10.4777 12.1345L10.4611 12.1511L10.4446 12.1676L10.428 12.1841L10.4114 12.2007L10.3949 12.2172L10.3783 12.2338L10.3618 12.2503L10.3452 12.2669L10.3286 12.2834L10.312 12.3L10.2955 12.3165L10.2789 12.3331L10.2623 12.3497L10.2457 12.3662L10.2291 12.3828L10.2125 12.3994L10.1959 12.4159L10.1793 12.4325L10.1627 12.4491L10.1461 12.4657L10.1295 12.4823L10.1129 12.4989L10.0963 12.5155L10.0797 12.5321L10.0631 12.5487L10.0464 12.5653L10.0298 12.5819L10.0132 12.5985L9.99652 12.6151L9.97987 12.6318L9.96322 12.6484L9.94657 12.665L9.92991 12.6817L9.91324 12.6983L9.89657 12.715L9.87989 12.7316L9.86321 12.7483L9.84653 12.7649L9.82984 12.7816L9.81314 12.7983L9.79644 12.815L9.77973 12.8317L9.76301 12.8484L9.74629 12.8651L9.72957 12.8818L9.71283 12.8985L9.69609 12.9152L9.67935 12.9319L9.6626 12.9487L9.64584 12.9654L9.62907 12.9822L9.6123 12.9989L9.59552 13.0157L9.57873 13.0324L9.56194 13.0492L9.54514 13.066L9.52833 13.0828L9.51151 13.0996L9.49469 13.1164L9.47786 13.1332L9.46102 13.15L9.44417 13.1668L9.42732 13.1837L9.41045 13.2005L9.39358 13.2174L9.3767 13.2342L9.35981 13.2511L9.34292 13.268L9.32601 13.2849L9.3091 13.3018L9.29217 13.3187L9.27524 13.3356L9.2583 13.3525L9.24135 13.3694L9.22439 13.3864L9.20742 13.4033L9.19044 13.4203L9.17345 13.4372L9.15645 13.4542L9.13945 13.4712L9.12243 13.4882L9.1054 13.5052L9.08836 13.5222L9.07131 13.5393L9.05426 13.5563L9.03719 13.5734L9.02011 13.5904L9.00302 13.6075L8.98592 13.6246L8.9688 13.6417L8.95168 13.6588L8.93455 13.6759L8.9174 13.693L8.90024 13.7101L8.88308 13.7273L8.8659 13.7444L8.84871 13.7616L8.8315 13.7788L8.81429 13.796L8.79706 13.8132L8.77983 13.8304L8.76257 13.8477L8.74531 13.8649L8.72804 13.8821L8.71075 13.8994L8.69345 13.9167L8.67614 13.934L8.65881 13.9513L8.64147 13.9686L8.62412 13.9859L8.60676 14.0033L8.58938 14.0206L8.57199 14.038L8.55458 14.0554L8.53716 14.0728L8.51973 14.0902L8.50229 14.1076L8.48483 14.1251L8.46736 14.1425L8.44987 14.16L8.43237 14.1775L8.41485 14.195L8.39732 14.2125L8.37978 14.23L8.36222 14.2475L8.34465 14.2651L8.32706 14.2827L8.30945 14.3002L8.29184 14.3178L8.2742 14.3355L8.25656 14.3531L8.23889 14.3707L8.22121 14.3884L8.20352 14.4061L8.18581 14.4238L8.16808 14.4415L8.15034 14.4592L8.13258 14.4769L8.11481 14.4947L8.09702 14.5124L8.07921 14.5302L8.06139 14.548L8.04355 14.5658L8.0257 14.5837L8.00783 14.6015L7.98994 14.6194L7.97203 14.6373L7.95411 14.6552L7.93617 14.6731L7.91821 14.691L7.90024 14.709L7.88225 14.727L7.86424 14.7449L7.84621 14.763L7.82817 14.781L7.81011 14.799L7.79203 14.8171L7.77393 14.8352L7.75581 14.8533L7.73768 14.8714L7.71952 14.8895L7.70135 14.9076L7.68316 14.9258L7.66495 14.944L7.64673 14.9622L7.62848 14.9804L7.61022 14.9987L7.59193 15.0169L7.57363 15.0352L7.55531 15.0535L7.53697 15.0718L7.5186 15.0902L7.50022 15.1085L7.48182 15.1269L7.4634 15.1453L7.44496 15.1637L7.4265 15.1822L7.40802 15.2006L7.38952 15.2191L7.371 15.2376L7.35246 15.2561L7.33389 15.2747L7.31531 15.2932L7.29671 15.3118L7.27808 15.3304L7.25944 15.3491L7.24077 15.3677L7.22208 15.3864L7.20337 15.4051L7.18464 15.4238L7.16589 15.4425L7.14712 15.4612L7.12832 15.48L7.10951 15.4988L7.09067 15.5176L7.07181 15.5365L7.05292 15.5553L7.03402 15.5742L7.01509 15.5931L6.99614 15.612C6.27167 16.3357 5.09652 16.3361 4.37259 15.613C3.64838 14.8896 3.64838 13.7168 4.37259 12.9935L13.1214 4.2547L14.4178 5.57764L14.4177 5.57772L14.4254 5.58523Z",stroke:"black"}),e("path",{d:"M12.5299 10.2849L7.32791 15.5546C7.12956 15.7556 6.88934 15.9156 6.62689 16.0225C6.08679 16.2425 5.46752 16.224 4.94171 15.9721L4.77945 16.31L4.94171 15.9721C4.6339 15.8246 4.36574 15.6008 4.16736 15.3246L4.02179 15.122C3.60142 14.5368 3.60138 13.749 4.02169 13.1638C4.12291 13.0229 4.24539 12.8984 4.38476 12.795L5.72374 11.8006L5.76816 11.7677L5.80115 11.7233L5.91056 11.5761C6.30572 11.0444 6.96187 10.4244 7.58765 10.0865C7.90229 9.91653 8.17215 9.83821 8.37711 9.84469C8.55555 9.85033 8.69852 9.91798 8.81563 10.1072C8.88186 10.2142 8.92418 10.3701 8.97238 10.5824C8.97507 10.5942 8.9778 10.6063 8.98058 10.6187C9.00013 10.7053 9.02201 10.8022 9.04751 10.8897C9.07575 10.9866 9.11828 11.1087 9.19239 11.2147C9.29475 11.3611 9.4504 11.4075 9.53763 11.4247C9.63768 11.4445 9.74477 11.4447 9.84616 11.4361C10.0516 11.4187 10.299 11.3594 10.5607 11.2643C11.0498 11.0864 11.6345 10.7669 12.1516 10.2849L12.5299 10.2849Z",stroke:"black",strokeWidth:"0.75"})]}),Ko=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor"}),e("path",{d:"M15.4237 6.90042C15.5191 6.92315 15.6152 6.94413 15.7074 6.96092C15.7135 7.05035 15.7162 7.16454 15.7138 7.30375C15.7056 7.77188 15.6408 8.43317 15.515 9.1653C15.2592 10.6537 14.774 12.3014 14.1 13.2C13.4011 14.1319 12.332 14.9694 11.4101 15.584C10.9538 15.8882 10.5429 16.1317 10.2465 16.2989C10.1617 16.3467 10.0865 16.3882 10.0224 16.423C9.97538 16.3925 9.92211 16.3576 9.86327 16.3183C9.61299 16.1515 9.26304 15.908 8.86735 15.6037C8.07099 14.9911 7.11105 14.148 6.4 13.2C5.71286 12.2838 5.10686 10.6159 4.73507 9.12872C4.55136 8.39389 4.4322 7.73262 4.38844 7.26582C4.37726 7.14653 4.37171 7.04688 4.37029 6.96627C4.68202 6.91822 5.07002 6.82212 5.46167 6.6997C6.04643 6.51692 6.71066 6.25305 7.25513 5.93001C7.78069 5.61819 8.40348 5.00685 8.92133 4.49851C8.96063 4.45994 8.99932 4.42196 9.03732 4.38474C9.32127 4.10667 9.57222 3.86458 9.78023 3.69195C9.86978 3.61763 9.94141 3.56465 9.99619 3.52986C10.0511 3.56629 10.1228 3.62162 10.2126 3.69902C10.4221 3.8796 10.6732 4.13028 10.9589 4.41605L10.9643 4.42138C11.2419 4.69905 11.5471 5.00425 11.8469 5.27159C12.1431 5.53579 12.4648 5.79139 12.7764 5.94721C13.307 6.2125 13.989 6.47149 14.5895 6.66369C14.8912 6.76025 15.179 6.8421 15.4237 6.90042ZM9.92522 3.48908C9.92521 3.48905 9.92594 3.48931 9.92744 3.48994C9.92598 3.48943 9.92523 3.48911 9.92522 3.48908Z",stroke:"currentColor"})]}),$o=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{d:"M9.92516 3.4891C9.92515 3.48907 9.92588 3.48933 9.92738 3.48997C9.92592 3.48946 9.92517 3.48914 9.92516 3.4891ZM9.99613 3.52989C10.051 3.56631 10.1227 3.62164 10.2125 3.69904C10.422 3.87963 10.6731 4.1303 10.9589 4.41608L10.9642 4.4214C11.2419 4.69907 11.5471 5.00428 11.8468 5.27161C12.1431 5.53582 12.4647 5.79142 12.7763 5.94724C13.3069 6.21253 13.9889 6.47151 14.5894 6.66371C14.8911 6.76027 15.179 6.84213 15.4236 6.90044C15.519 6.92317 15.6151 6.94416 15.7074 6.96095C15.7134 7.05037 15.7162 7.16456 15.7137 7.30377C15.7056 7.7719 15.6407 8.4332 15.5149 9.16533C15.2592 10.6537 14.7739 12.3014 14.0999 13.2C13.401 14.1319 12.3319 14.9694 11.4101 15.584C10.9538 15.8882 10.5428 16.1317 10.2465 16.2989C10.1617 16.3467 10.0864 16.3882 10.0223 16.423C9.97532 16.3925 9.92205 16.3576 9.86321 16.3184C9.61293 16.1515 9.26298 15.9081 8.86729 15.6037C8.07092 14.9911 7.11099 14.1481 6.39994 13.2C5.7128 12.2838 5.10679 10.6159 4.73501 9.12874C4.5513 8.39391 4.43214 7.73264 4.38838 7.26584C4.3772 7.14656 4.37164 7.0469 4.37023 6.9663C4.68196 6.91824 5.06996 6.82215 5.46161 6.69972C6.04637 6.51694 6.7106 6.25307 7.25507 5.93003C7.78063 5.61822 8.40342 5.00687 8.92127 4.49853C8.96057 4.45996 8.99926 4.42198 9.03726 4.38477C9.32121 4.1067 9.57216 3.8646 9.78016 3.69197C9.86972 3.61765 9.94135 3.56467 9.99613 3.52989Z",stroke:"black"})]});function Ho({spanKind:n,variant:t="fill"}){const{theme:a}=Q(),i=a==="dark",r=t==="fill";let l=r?e(Vo,{}):e(No,{}),o=i?"--ac-global-color-grey-600":"--ac-global-color-grey-500";switch(n){case"llm":o=i?"--ac-global-color-orange-1000":"--ac-global-color-orange-500",l=r?e(xo,{}):e(wo,{});break;case"chain":o=i?"--ac-global-color-blue-1000":"--ac-global-color-blue-500",l=r?e(Fo,{}):e(_o,{});break;case"retriever":o=i?"--ac-global-color-seafoam-1000":"--ac-global-color-seafoam-500",l=r?e(Do,{}):e(Eo,{});break;case"embedding":o=i?"--ac-global-color-indigo-1000":"--ac-global-color-indigo-500",l=r?e(Ao,{}):e(Io,{});break;case"agent":o=i?"--ac-global-text-color-900":"--ac-global-text-color-500",l=r?e(Mo,{}):e(To,{});break;case"tool":o=i?"--ac-global-color-yellow-1200":"--ac-global-color-yellow-500",l=r?e(So,{}):e(ko,{});break;case"reranker":o=i?"--ac-global-color-celery-1000":"--ac-global-color-celery-500",l=r?e(Oo,{}):e(Po,{});break;case"evaluator":o=i?"--ac-global-color-indigo-1000":"--ac-global-color-indigo-500",l=r?e(Ro,{}):e(zo,{});break;case"guardrail":o=i?"--ac-global-color-fuchsia-1200":"--ac-global-color-fuchsia-500",l=r?e($o,{}):e(Ko,{});break}return e("div",{css:h`
        color: var(${o});
        width: 20px;
        height: 20px;
      `,title:n,children:l})}const S1=p.createContext(null);function w1(){const n=p.useContext(S1);if(n===null)throw new Error("useTraceTree must be used within a TraceTreeProvider");return n}function Bo(n){const[t,a]=p.useState(!1),i=p.useCallback(r=>{p.startTransition(()=>{a(r)})},[]);return e(S1.Provider,{value:{isCollapsed:t,setIsCollapsed:i},children:n.children})}function Zo(n){const t=n.reduce((i,r)=>(i.set(r.context.spanId,{span:r,children:[]}),i),new Map),a=[];for(const i of n){const r=t.get(i.context.spanId);if(i.parentId===null||!t.has(i.parentId))a.push(r);else{const l=t.get(i.parentId);l&&l.children.push(r)}}for(const i of t.values())i.children.sort((r,l)=>new Date(r.span.startTime).valueOf()-new Date(l.span.startTime).valueOf());return a}const $n=30;function Q0(n){const{spans:t,onSpanClick:a,selectedSpanNodeId:i}=n,r=Zo(t);return e(Bo,{children:s("div",{css:h`
          display: flex;
          flex-direction: column;
          overflow: hidden;
          height: 100%;
          align-items: stretch;
        `,children:[e(Go,{}),e("ul",{css:h`
            flex: 1 1 auto;
            display: flex;
            flex-direction: column;
            width: 100%;
            overflow: auto;
          `,"data-testid":"trace-tree",children:r.map(l=>e(x1,{node:l,onSpanClick:a,selectedSpanNodeId:i},l.span.id))})]})})}function Go(){const n=pe(r=>r.showMetricsInTraceTree),t=pe(r=>r.setShowMetricsInTraceTree),{isCollapsed:a,setIsCollapsed:i}=w1();return e(b,{borderBottomWidth:"thin",borderColor:"dark",padding:"size-100",children:s(x,{direction:"row",justifyContent:"end",flex:"none",gap:"size-100",children:[s(Z,{offset:5,children:[e(F,{variant:"default",size:"compact","aria-label":a?"Expand all":"Collapse all",onClick:()=>{i(!a)},icon:e(I,{svg:a?e(T.RowCollapseOutline,{}):e(T.RowExpandOutline,{})})}),e(Y,{children:a?"Expand all nested spans":"Collapse all nested spans"})]}),s(Z,{offset:5,children:[e(F,{variant:"default",size:"compact","aria-label":n?"Hide metrics in trace tree":"Show metrics in trace tree",onClick:()=>{t(!n)},icon:e(I,{svg:n?e(T.TimerOutline,{}):e(T.TimerOffOutline,{})})}),e(Y,{children:n?"Hide metrics in trace tree":"Show metrics in trace tree"})]})]})})}const Qo=h`
  font-weight: 500;
  color: var(--ac-global-text-color-900);
  display: inline-block;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;function x1(n){const{node:t,selectedSpanNodeId:a,onSpanClick:i,nestingLevel:r=0}=n,l=t.children,[o,d]=p.useState(!1),{isCollapsed:c}=w1(),u=l.length>0,m=pe(w=>w.showMetricsInTraceTree);p.useEffect(()=>{d(c)},[c]);const{name:g,latencyMs:f,statusCode:L,tokenCountTotal:C,tokenCountPrompt:k,tokenCountCompletion:_}=t.span;return s("div",{children:[e("button",{className:"button--reset",css:h`
          width: 100%;
          min-width: 200px;
          cursor: pointer;
        `,onClick:()=>{p.startTransition(()=>{i&&i(t.span)})},children:s(Uo,{isSelected:a===t.span.id,nestingLevel:r,children:[s(x,{direction:"row",gap:"size-100",justifyContent:"start",alignItems:"center",flex:"1 1 auto",minWidth:0,children:[e(Ho,{spanKind:t.span.spanKind}),e("span",{css:Qo,title:g,children:g}),L==="ERROR"?e(yo,{statusCode:"ERROR"}):null,typeof C=="number"&&m?e(vo,{tokenCountTotal:C,tokenCountPrompt:k??0,tokenCountCompletion:_??0}):null,f!=null&&m?e(Ur,{latencyMs:f,showIcon:!1}):null]}),e("div",{css:qo,"data-testid":"span-controls",children:u?e(Jo,{isCollapsed:o,onClick:()=>{d(!o)}}):null})]})}),l.length?e("ul",{css:h`
            display: ${o?"none":"flex"};
            flex-direction: column;
          `,children:l.map((w,H)=>{const le=l[H+1];return s("li",{css:h`
                  position: relative;
                `,children:[le?e(jo,{...le.span,nestingLevel:r}):null,e(Wo,{...w.span,nestingLevel:r}),e(x1,{node:w,onSpanClick:i,selectedSpanNodeId:a,nestingLevel:r+1})]},w.span.context.spanId)})}):null]})}function Uo(n){return e("div",{className:n.isSelected?"is-selected":"",css:h`
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        gap: var(--ac-global-dimension-static-size-100);
        padding-right: var(--ac-global-dimension-static-size-100);
        padding-top: var(--ac-global-dimension-static-size-100);
        padding-bottom: var(--ac-global-dimension-static-size-100);
        border-left: 4px solid transparent;
        box-sizing: border-box;
        &:hover {
          background-color: var(--ac-global-color-grey-200);
        }
        &.is-selected {
          background-color: var(--ac-global-color-primary-300);
          border-color: var(--ac-global-color-primary);
        }
        & > *:first-child {
          margin-left: ${n.nestingLevel*$n+16}px;
        }
      `,children:n.children})}function jo({statusCode:n,nestingLevel:t}){return e("div",{"aria-hidden":"true","data-testid":"span-tree-edge-connector",css:a=>h`
        position: absolute;
        border-left: 1px solid
          ${n==="ERROR"?a.colors.statusDanger:"var(--ac-global-color-grey-700)"};
        top: 0;
        left: ${t*$n+29}px;
        width: 42px;
        bottom: 0;
        z-index: 1;
      `})}function Wo({nestingLevel:n,statusCode:t}){return e("div",{"aria-hidden":"true",css:a=>{const i=t==="ERROR"?a.colors.statusDanger:"var(--ac-global-color-grey-700)";return h`
          position: absolute;
          border-left: 1px solid ${i};
          border-bottom: 1px solid ${i};
          border-radius: 0 0 0 11px;
          top: -5px;
          left: ${n*$n+29}px;
          width: 15px;
          height: 24px;
        `}})}const qo=h`
  width: 20px;
  flex: none;
`,Xo=h`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  border: none;
  background: none;
  cursor: pointer;
  color: var(--ac-global-text-color-900);
  border-radius: 4px;
  transition: transform 0.2s;
  transition: background-color 0.5s;
  flex: none;
  background-color: rgba(0, 0, 0, 0.1);
  &:hover {
    background-color: rgba(0, 0, 0, 0.3);
  }
  &.is-collapsed {
    transform: rotate(-90deg);
  }
`;function Jo({isCollapsed:n,onClick:t}){return e("button",{onClick:a=>{a.stopPropagation(),a.preventDefault(),t()},className:It("button--reset",{"is-collapsed":n}),css:Xo,children:e(I,{svg:e(T.ArrowIosDownwardOutline,{})})})}class U0 extends G.Component{constructor(t){super(t),this.state={hasError:!1,error:null}}static getDerivedStateFromError(t){return{hasError:!0,error:t}}componentDidCatch(t,a){}render(){return this.state.hasError?e(b,{padding:"size-200",children:s(x,{direction:"column",children:[s(x,{direction:"column",width:"100%",alignItems:"center",children:[e(Ot,{graphicKey:"error"}),e("h1",{children:"Something went wrong"})]}),e("p",{children:"We strive to do our very best but 🐛 bugs happen. It would mean a lot to us if you could file a an issue. If you feel comfortable, please include the error details below in your issue. We will get back to you as soon as we can."}),e(x,{direction:"row",width:"100%",justifyContent:"end",children:e(V,{href:"https://github.com/Arize-ai/phoenix/issues/new?assignees=&labels=bug&template=bug_report.md&title=%5BBUG%5D",children:"file an issue with us"})}),s("details",{open:!0,children:[e("summary",{children:"error details"}),e("pre",{css:h`
                  white-space: pre-wrap;
                  overflow-wrap: break-word;
                  overflow: hidden;
                  overflow-y: auto;
                  max-height: 500px;
                `,children:this.state.error instanceof Error?this.state.error.message:null})]})]})}):this.props.children}}const T1=p.createContext(null);function M1(){let n=p.useContext(T1);return n===null&&(console.warn("useMarkdownMode must be used within a MarkdownDisplayProvider"),n={mode:"text",setMode:()=>{}}),n}function j0(n){const t=pe(r=>r.markdownDisplayMode),a=pe(r=>r.setMarkdownDisplayMode),i=p.useCallback(r=>{p.startTransition(()=>{a(r)})},[a]);return e(T1.Provider,{value:{mode:t,setMode:i},children:n.children})}const Yo=h`
  a {
    color: var(--ac-global-color-primary);
    &:visited {
      color: var(--ac-global-color-purple-900);
    }
  }
`;function es({children:n,mode:t}){return t==="markdown"?e("div",{css:Yo,children:e(Ta,{remarkPlugins:[Ma],children:n})}):e("pre",{css:h`
        white-space: pre-wrap;
        text-wrap: wrap;
        margin: 0;
      `,children:n})}function W0({children:n}){const{mode:t}=M1();return e(es,{mode:t,children:n})}function ns({mode:n,onModeChange:t}){return s(Re,{size:"compact",variant:"inline-button",value:n,onChange:a=>{t(a)},children:[e(q,{label:"text",value:"text",children:s(Z,{placement:"top",delay:1e3,offset:10,children:[e(ae,{children:e(I,{svg:e(Qa,{})})}),e(Y,{children:"Text"})]})}),e(q,{label:"markdown",value:"markdown",children:s(Z,{placement:"top",delay:1e3,offset:10,children:[e(ae,{children:e(I,{svg:e(Ua,{})})}),e(Y,{children:"Markdown"})]})})]})}function q0(){const{mode:n,setMode:t}=M1();return e(ns,{mode:n,onModeChange:t})}function X0(n){const{spanKind:t}=n,a=p.useMemo(()=>{let i="grey-500";switch(t){case"llm":i="orange-1000";break;case"chain":i="blue-1000";break;case"retriever":i="seafoam-1000";break;case"reranker":i="celery-1000";break;case"embedding":i="indigo-1000";break;case"agent":i="grey-900";break;case"tool":i="yellow-1200";break;case"evaluator":i="indigo-1200";break;case"guardrail":i="fuchsia-1200";break}return i},[t]);return e(me,{color:a,children:t})}const I1=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"projectId"},{defaultValue:null,kind:"LocalArgument",name:"spanId"}],t=[{kind:"Variable",name:"id",variableName:"projectId"}],a={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i={kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"spanAnnotationNames",storageKey:null}],type:"Project",abstractKey:null},r=[{kind:"Variable",name:"id",variableName:"spanId"}],l={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null},o={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"EditSpanAnnotationsDialogNewAnnotationQuery",selections:[{alias:"project",args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[a,i],storageKey:null},{alias:"span",args:r,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[a,l],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"EditSpanAnnotationsDialogNewAnnotationQuery",selections:[{alias:"project",args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[o,a,i],storageKey:null},{alias:"span",args:r,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[o,a,l],storageKey:null}]},params:{cacheID:"4aa13fbe70360943615a8ff4d4b2a06f",id:null,metadata:{},name:"EditSpanAnnotationsDialogNewAnnotationQuery",operationKind:"query",text:`query EditSpanAnnotationsDialogNewAnnotationQuery(
  $projectId: GlobalID!
  $spanId: GlobalID!
) {
  project: node(id: $projectId) {
    __typename
    id
    ... on Project {
      spanAnnotationNames
    }
  }
  span: node(id: $spanId) {
    __typename
    id
    ... on Span {
      spanAnnotations {
        id
        name
        annotatorKind
      }
    }
  }
}
`}}}();I1.hash="09b2ee5f96c0192a5618ae6c04c321ae";const A1=function(){var n={defaultValue:null,kind:"LocalArgument",name:"annotationId"},t={defaultValue:null,kind:"LocalArgument",name:"explanation"},a={defaultValue:null,kind:"LocalArgument",name:"label"},i={defaultValue:null,kind:"LocalArgument",name:"name"},r={defaultValue:null,kind:"LocalArgument",name:"score"},l={defaultValue:null,kind:"LocalArgument",name:"spanId"},o=[{items:[{fields:[{kind:"Variable",name:"annotationId",variableName:"annotationId"},{kind:"Literal",name:"annotatorKind",value:"HUMAN"},{kind:"Variable",name:"explanation",variableName:"explanation"},{kind:"Variable",name:"label",variableName:"label"},{kind:"Variable",name:"name",variableName:"name"},{kind:"Variable",name:"score",variableName:"score"}],kind:"ObjectValue",name:"input.0"}],kind:"ListValue",name:"input"}],d=[{kind:"Variable",name:"id",variableName:"spanId"}],c={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:[n,t,a,i,r,l],kind:"Fragment",metadata:null,name:"EditSpanAnnotationsDialogEditAnnotationMutation",selections:[{alias:null,args:o,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"patchSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:null,args:d,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"EditSpanAnnotationsDialog_spanAnnotations"}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[l,n,i,a,r,t],kind:"Operation",name:"EditSpanAnnotationsDialogEditAnnotationMutation",selections:[{alias:null,args:o,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"patchSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:null,args:d,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},c,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[c,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"8b7ea6d08a6f8f06744567701ccb5f34",id:null,metadata:{},name:"EditSpanAnnotationsDialogEditAnnotationMutation",operationKind:"mutation",text:`mutation EditSpanAnnotationsDialogEditAnnotationMutation(
  $spanId: GlobalID!
  $annotationId: GlobalID!
  $name: String!
  $label: String
  $score: Float
  $explanation: String
) {
  patchSpanAnnotations(input: [{annotationId: $annotationId, name: $name, label: $label, score: $score, explanation: $explanation, annotatorKind: HUMAN}]) {
    query {
      node(id: $spanId) {
        __typename
        ... on Span {
          ...EditSpanAnnotationsDialog_spanAnnotations
        }
        __isNode: __typename
        id
      }
    }
  }
}

fragment EditSpanAnnotationsDialog_spanAnnotations on Span {
  id
  spanAnnotations {
    id
    name
    annotatorKind
    score
    label
    explanation
  }
}
`}}}();A1.hash="46647cda8c9874c89d8a4034bf82fe14";const E1=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"id"}],t=[{kind:"Variable",name:"id",variableName:"id"}],a={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"EditSpanAnnotationsDialogSpanAnnotationsQuery",selections:[{alias:null,args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{args:null,kind:"FragmentSpread",name:"EditSpanAnnotationsDialog_spanAnnotations"}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"EditSpanAnnotationsDialogSpanAnnotationsQuery",selections:[{alias:null,args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},a,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}]},params:{cacheID:"8649eb1dd42a29a0d38b9a1538490de4",id:null,metadata:{},name:"EditSpanAnnotationsDialogSpanAnnotationsQuery",operationKind:"query",text:`query EditSpanAnnotationsDialogSpanAnnotationsQuery(
  $id: GlobalID!
) {
  node(id: $id) {
    __typename
    ...EditSpanAnnotationsDialog_spanAnnotations
    __isNode: __typename
    id
  }
}

fragment EditSpanAnnotationsDialog_spanAnnotations on Span {
  id
  spanAnnotations {
    id
    name
    annotatorKind
    score
    label
    explanation
  }
}
`}}}();E1.hash="07aedb847a2af03a77823f0afc0c98d4";const D1=function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{argumentDefinitions:[],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:["node"],operation:E1,identifierInfo:{identifierField:"id",identifierQueryVariableName:"id"}}},name:"EditSpanAnnotationsDialog_spanAnnotations",selections:[n,{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[n,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}}();D1.hash="07aedb847a2af03a77823f0afc0c98d4";const P1=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"spanId"}],t=[{kind:"Variable",name:"id",variableName:"spanId"}],a={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"EditSpanAnnotationsDialogQuery",selections:[{alias:"span",args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[a,{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"EditSpanAnnotationsDialog_spanAnnotations"}],type:"Span",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"EditSpanAnnotationsDialogQuery",selections:[{alias:"span",args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},a,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}]},params:{cacheID:"532b3c148c3bf1411b8820714c68f4e3",id:null,metadata:{},name:"EditSpanAnnotationsDialogQuery",operationKind:"query",text:`query EditSpanAnnotationsDialogQuery(
  $spanId: GlobalID!
) {
  span: node(id: $spanId) {
    __typename
    id
    ... on Span {
      ...EditSpanAnnotationsDialog_spanAnnotations
    }
  }
}

fragment EditSpanAnnotationsDialog_spanAnnotations on Span {
  id
  spanAnnotations {
    id
    name
    annotatorKind
    score
    label
    explanation
  }
}
`}}}();P1.hash="36093f4285a168993ec87fd6aac82365";const O1=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"},{defaultValue:null,kind:"LocalArgument",name:"spanId"}],t=[{items:[{kind:"Variable",name:"input.0",variableName:"input"}],kind:"ListValue",name:"input"}],a=[{kind:"Variable",name:"id",variableName:"spanId"}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"NewSpanAnnotationFormMutation",selections:[{alias:null,args:t,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"createSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"EditSpanAnnotationsDialog_spanAnnotations"}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"NewSpanAnnotationFormMutation",selections:[{alias:null,args:t,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"createSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},i,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[i,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"d6f016f4dfb0c142854c3ecd840b09f5",id:null,metadata:{},name:"NewSpanAnnotationFormMutation",operationKind:"mutation",text:`mutation NewSpanAnnotationFormMutation(
  $input: CreateSpanAnnotationInput!
  $spanId: GlobalID!
) {
  createSpanAnnotations(input: [$input]) {
    query {
      node(id: $spanId) {
        __typename
        ... on Span {
          ...EditSpanAnnotationsDialog_spanAnnotations
        }
        __isNode: __typename
        id
      }
    }
  }
}

fragment EditSpanAnnotationsDialog_spanAnnotations on Span {
  id
  spanAnnotations {
    id
    name
    annotatorKind
    score
    label
    explanation
  }
}
`}}}();O1.hash="ded0a7a64a2706f6ec472a63c1c57eca";const ts=h`
  color: var(--ac-global-text-color-900);
  font-size: 12px;
`;function _1(n){const{initialData:t,isReadOnly:a,onSubmit:i,isSubmitting:r=!1}=n,{control:l,handleSubmit:o,formState:{isDirty:d,isValid:c},setError:u,reset:m}=Te({defaultValues:t,disabled:a}),g=p.useCallback(L=>{const C=!L.label,k=L.score===""||L.score==null;if(C&&k){u("label",{type:"manual",message:"Label or score is required"}),u("score",{type:"manual",message:"Label or score is required"});return}const _={...L,score:L.score!=null?parseFloat(L.score.toString()):null};i&&i(_),m(_)},[i,u,m]),f=a;return s(Me,{onSubmit:o(g),children:[e(b,{padding:"size-200",children:s(x,{direction:"column",gap:"size-100",children:[s("div",{css:h`
              display: flex;
              flex-direction: row;
              width: 100%;
              overflow: hidden;
              gap: var(--ac-global-dimension-size-100);
              & > * {
                flex: 1 1 auto;
              }
              .ac-textfield {
                min-width: 0;
              }
            `,children:[e(z,{name:"label",control:l,render:({field:{onChange:L,onBlur:C,value:k},fieldState:{invalid:_,error:w}})=>e(K,{label:"Label",placeholder:"e.x. good, bad",description:"A categorical label like 'good' or 'bad'",isReadOnly:a,errorMessage:w==null?void 0:w.message,validationState:_?"invalid":"valid",onChange:L,onBlur:C,value:(k==null?void 0:k.toString())||""})}),e(z,{name:"score",control:l,render:({field:{onChange:L,onBlur:C,value:k},fieldState:{invalid:_,error:w}})=>e(K,{label:"Score",type:"number",placeholder:"e.x. 0.8",description:"A numeric grade",errorMessage:w==null?void 0:w.message,isReadOnly:a,validationState:_?"invalid":"valid",onChange:L,onBlur:C,value:(k==null?void 0:k.toString())||""})})]}),s("details",{open:!f,css:ts,children:[e("summary",{children:"Annotation Details"}),e(b,{paddingTop:"size-50",children:e(z,{name:"explanation",control:l,render:({field:{onChange:L,onBlur:C,value:k},fieldState:{invalid:_,error:w}})=>e(An,{label:"Explanation",height:70,isReadOnly:a,description:"Why this score or label was given",errorMessage:w==null?void 0:w.message,validationState:_?"invalid":"valid",onChange:L,onBlur:C,value:(k==null?void 0:k.toString())||""})})})]})]})}),e(J,{children:a?null:e(b,{paddingTop:"size-100",paddingBottom:"size-100",paddingEnd:"size-200",paddingStart:"size-200",borderTopWidth:"thin",borderColor:"dark",children:e(x,{direction:"row",justifyContent:"end",children:e(F,{variant:d?"primary":"default",type:"submit",size:"compact",disabled:!c||!d||r,children:r?"Saving...":"Save"})})})})]})}function as(n){const{annotationName:t,spanNodeId:a,onCreated:i}=n,[r,l]=R.useMutation(O1);return e(_1,{initialData:{name:t},isSubmitting:l,onSubmit:d=>{r({variables:{input:{spanId:a,annotatorKind:"HUMAN",...d},spanId:a},onCompleted:()=>{i()}})}})}const F1=function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"annotationId"},{defaultValue:null,kind:"LocalArgument",name:"spanId"}],t=[{fields:[{items:[{kind:"Variable",name:"annotationIds.0",variableName:"annotationId"}],kind:"ListValue",name:"annotationIds"}],kind:"ObjectValue",name:"input"}],a=[{kind:"Variable",name:"id",variableName:"spanId"}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SpanAnnotationActionMenuDeleteMutation",selections:[{alias:null,args:t,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"deleteSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"EditSpanAnnotationsDialog_spanAnnotations"}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SpanAnnotationActionMenuDeleteMutation",selections:[{alias:null,args:t,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"deleteSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},{kind:"TypeDiscriminator",abstractKey:"__isNode"},i,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[i,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"422687a283120080277d2649c1b9f6ee",id:null,metadata:{},name:"SpanAnnotationActionMenuDeleteMutation",operationKind:"mutation",text:`mutation SpanAnnotationActionMenuDeleteMutation(
  $annotationId: GlobalID!
  $spanId: GlobalID!
) {
  deleteSpanAnnotations(input: {annotationIds: [$annotationId]}) {
    query {
      node(id: $spanId) {
        __typename
        ... on Span {
          ...EditSpanAnnotationsDialog_spanAnnotations
        }
        __isNode: __typename
        id
      }
    }
  }
}

fragment EditSpanAnnotationsDialog_spanAnnotations on Span {
  id
  spanAnnotations {
    id
    name
    annotatorKind
    score
    label
    explanation
  }
}
`}}}();F1.hash="a898fcb037b08cb626daaf3d385588ce";function is(n){const{onDelete:t,isDisabled:a=!1}=n;return e("div",{onClick:i=>{i.preventDefault(),i.stopPropagation()},children:e(_t,{align:"end",buttonSize:"compact",isDisabled:a,onAction:i=>{switch(i){case"deleteAnnotation":t();break}},children:e(P,{children:s(x,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(I,{svg:e(T.TrashOutline,{})}),e(y,{children:"Delete"})]})},"deleteAnnotation")})})}function rs(n){const{annotationId:t,spanNodeId:a,annotationName:i,onSpanAnnotationActionSuccess:r,onSpanAnnotationActionError:l}=n,[o,d]=p.useState(null),[c,u]=R.useMutation(F1),m=p.useCallback(()=>{p.startTransition(()=>{c({variables:{annotationId:t,spanId:a},onCompleted:()=>{r({title:"Annotation Deleted",message:`Annotation ${i} has been deleted.`})},onError:f=>{l(f)}})})},[c,t,a,r,i,l]),g=p.useCallback(()=>{d(s(fe,{size:"S",title:"Delete Annotation",children:[e(b,{padding:"size-200",children:e(y,{color:"danger",children:`Are you sure you want to delete annotation ${i}? This cannot be undone.`})}),e(b,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:e(x,{direction:"row",justifyContent:"end",children:e(F,{variant:"danger",onClick:()=>{m(),d(null)},children:"Delete Annotation"})})})]}))},[m,i]);return s("div",{children:[e(is,{onDelete:g,isDisabled:u}),e(tn,{type:"modal",isDismissable:!0,onDismiss:()=>d(null),children:o})]})}function J0(n){const{projectId:t,spanNodeId:a}=n,[i,r]=p.useState(null),l=ln();return e(fe,{title:"Annotate",size:"M",isDismissable:!0,extra:e(ls,{projectId:t,spanNodeId:a,disabled:i!==null,onAnnotationNameSelect:r}),children:s("div",{css:h`
          height: 100%;
          overflow-y: auto;
          padding: var(--ac-global-dimension-size-200);
        `,children:[i&&e(b,{paddingBottom:"size-200",children:e(ds,{spanNodeId:a,name:i,onDelete:()=>{r(null)},onCreated:()=>{r(null),l({title:"New Span Annotation",message:`Annotation ${i} has been created.`})}})}),e(p.Suspense,{children:e(ss,{...n})})]})})}function ls(n){const{projectId:t,disabled:a=!1,spanNodeId:i,onAnnotationNameSelect:r}=n,[l,o]=p.useState(!1);return s(In,{placement:"bottom end",crossOffset:300,isOpen:l,onOpenChange:d=>{o(d)},children:[e(F,{variant:"default",disabled:a,size:"compact",icon:e(I,{svg:e(T.PlusCircleOutline,{})}),onClick:()=>{o(!0)},children:"New"}),e(os,{projectId:t,spanNodeId:i,onAnnotationNameSelect:d=>{r(d),o(!1)}})]})}function os(n){const{projectId:t,spanNodeId:a,onAnnotationNameSelect:i}=n;return e(an,{title:"New Annotation",backgroundColor:"light",borderColor:"light",variant:"compact",bodyStyle:{padding:0},children:e(p.Suspense,{children:e(ms,{projectId:t,spanId:a,onAnnotationNameSelect:i})})})}function ss(n){const t=R.useLazyLoadQuery(P1,{spanId:n.spanNodeId},{fetchPolicy:"store-and-network"});return e(cs,{span:t.span})}function cs(n){const{span:t}=n,[a]=R.useRefetchableFragment(D1,t),i=a.spanAnnotations||[],r=i.length>0;return s("div",{children:[!r&&e(Co,{graphicKey:"documents",message:"No annotations for this span"}),e("ul",{css:h`
          display: flex;
          flex-direction: column;
          gap: var(--ac-global-dimension-size-200);
        `,children:i.map((l,o)=>e("li",{children:e(us,{annotation:l,spanNodeId:a.id})},`${o}_${l.name}`))})]})}function ds(n){const{spanNodeId:t,name:a,onDelete:i,onCreated:r}=n;return s(an,{variant:"compact",title:a,borderColor:"orange-900",extra:s(x,{direction:"row",alignItems:"center",gap:"size-100",children:[e(N1,{kind:"HUMAN"}),e(F,{variant:"default",size:"compact",isDisabled:!0,"aria-label":"delete annotation",icon:e(I,{svg:e(T.CloseOutline,{})}),onClick:i})]}),bodyStyle:{padding:0},children:[e(Ke,{variant:"info",banner:!0,children:"Fill out the fields below and click save to create a new annotation."}),e(as,{annotationName:a,spanNodeId:t,onCreated:r})]})}function us(n){const{annotation:t,spanNodeId:a}=n,[i,r]=p.useState(null),l=ln(),[o,d]=R.useMutation(A1),c=p.useCallback(u=>{p.startTransition(()=>{o({variables:{annotationId:t.id,spanId:a,...u},onCompleted:()=>{l({title:"Annotation Updated",message:`Annotation ${t.name} has been updated.`})},onError:m=>{r(m)}})})},[t.id,t.name,o,l,a]);return s(an,{variant:"compact",title:t.name,titleExtra:t.label||typeof t.score=="number"&&ge(t.score)||null,collapsible:!0,bodyStyle:{padding:0},extra:s(x,{gap:"size-100",alignItems:"center",children:[e(N1,{kind:t.annotatorKind}),e(rs,{annotationId:t.id,spanNodeId:a,annotationName:t.name,onSpanAnnotationActionSuccess:u=>{l(u)},onSpanAnnotationActionError:u=>{r(u)}})]}),children:[i&&e(Ke,{variant:"danger",banner:!0,children:i.message}),e(_1,{initialData:t,isReadOnly:t.annotatorKind==="LLM",isSubmitting:d,onSubmit:u=>{c(u)}})]})}function N1(n){const{kind:t}=n;return e(me,{color:t==="HUMAN"?"blue-900":"orange-900",children:t})}function ms(n){const{projectId:t,spanId:a,onAnnotationNameSelect:i}=n,r=R.useLazyLoadQuery(I1,{projectId:t,spanId:a}),[l,o]=p.useState(""),d=p.useMemo(()=>{var m,g;return((g=(m=r==null?void 0:r.span)==null?void 0:m.spanAnnotations)==null?void 0:g.map(f=>f.name))||[]},[r.span.spanAnnotations]),c=p.useMemo(()=>(r.project.spanAnnotationNames||[]).filter(g=>!d.includes(g)),[r.project.spanAnnotationNames,d]),u=c.length>0;return s(J,{children:[e(b,{padding:"size-200",children:s(x,{direction:"row",gap:"size-100",alignItems:"end",children:[e(K,{label:"Annotation Name",value:l,placeholder:"e.x. correctness",onChange:m=>{o(m)}}),e(F,{variant:"primary",onClick:()=>{i(l)},children:"Create"})]})}),u&&s(J,{children:[e(b,{borderTopWidth:"thin",borderBottomWidth:"thin",borderColor:"light",paddingStart:"size-200",paddingTop:"size-100",paddingBottom:"size-100",backgroundColor:"grey-300",children:e("label",{children:"select from existing"})}),e(ja,{selectionMode:"single",onSelectionChange:m=>{if(m==="all"||m.size===0)return;const f=m.values().next().value;o(f||"")},disabledKeys:d,children:c.map(m=>e(P,{children:m},m))})]})]})}const V1=function(){var n={defaultValue:null,kind:"LocalArgument",name:"description"},t={defaultValue:null,kind:"LocalArgument",name:"metadata"},a={defaultValue:null,kind:"LocalArgument",name:"name"},i=[{alias:null,args:[{fields:[{kind:"Variable",name:"description",variableName:"description"},{kind:"Variable",name:"metadata",variableName:"metadata"},{kind:"Variable",name:"name",variableName:"name"}],kind:"ObjectValue",name:"input"}],concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"createDataset",plural:!1,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"dataset",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"exampleCount",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"experimentCount",storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[n,t,a],kind:"Fragment",metadata:null,name:"CreateDatasetFormMutation",selections:i,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,n,t],kind:"Operation",name:"CreateDatasetFormMutation",selections:i},params:{cacheID:"6aa615e27e1ccaa5431ba481842b43d0",id:null,metadata:{},name:"CreateDatasetFormMutation",operationKind:"mutation",text:`mutation CreateDatasetFormMutation(
  $name: String!
  $description: String = null
  $metadata: JSON = null
) {
  createDataset(input: {name: $name, description: $description, metadata: $metadata}) {
    dataset {
      id
      name
      description
      metadata
      createdAt
      exampleCount
      experimentCount
    }
  }
}
`}}}();V1.hash="5921369d33cc0fb1dffb5d943469a378";function z1({datasetName:n,datasetDescription:t,datasetMetadata:a,onSubmit:i,isSubmitting:r,submitButtonText:l,formMode:o}){const{control:d,handleSubmit:c,formState:{isDirty:u}}=Te({defaultValues:{name:n??"Dataset "+new Date().toISOString(),description:t??"",metadata:JSON.stringify(a,null,2)??"{}"}});return s(Me,{children:[s(b,{padding:"size-200",children:[e(z,{name:"name",control:d,rules:{required:"Dataset name is required"},render:({field:{onChange:m,onBlur:g,value:f},fieldState:{invalid:L,error:C}})=>e(K,{label:"Dataset Name",description:"The name of the dataset",errorMessage:C==null?void 0:C.message,validationState:L?"invalid":"valid",onChange:m,onBlur:g,value:f.toString()})}),e(z,{name:"description",control:d,render:({field:{onChange:m,onBlur:g,value:f},fieldState:{invalid:L,error:C}})=>e(An,{label:"description",description:"A description of the dataset",isRequired:!1,height:100,errorMessage:C==null?void 0:C.message,validationState:L?"invalid":"valid",onChange:m,onBlur:g,value:f==null?void 0:f.toString()})}),e(z,{name:"metadata",control:d,rules:{validate:m=>ur(m)?!0:"metadata must be a valid JSON object"},render:({field:{onChange:m,onBlur:g,value:f},fieldState:{invalid:L,error:C}})=>e(Vr,{validationState:L?"invalid":"valid",label:"metadata",errorMessage:C==null?void 0:C.message,description:"A JSON object containing metadata for the dataset",children:e(Pr,{value:f,onChange:m,onBlur:g})})})]}),e(b,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:e(x,{direction:"row",justifyContent:"end",children:e(F,{disabled:o==="edit"?!u:!1,variant:u?"primary":"default",size:"compact",loading:r,onClick:c(i),children:l})})})]})}function ps(n){const{onDatasetCreated:t,onDatasetCreateError:a}=n,[i,r]=R.useMutation(V1),l=p.useCallback(o=>{i({variables:{...o,metadata:JSON.parse(o.metadata)},onCompleted:d=>{t(d.createDataset.dataset)},updater:d=>{const c=R.ConnectionHandler.getConnectionID("client:root","DatasetPicker__datasets"),m=d.getRootField("createDataset").getLinkedRecord("dataset"),g=d.get(c);if(g&&m){const f=R.ConnectionHandler.createEdge(d,g,m,"DatasetEdge");R.ConnectionHandler.insertEdgeAfter(g,f)}},onError:d=>{a(d)}})},[i,t,a]);return e(z1,{isSubmitting:r,onSubmit:l,submitButtonText:r?"Creating...":"Create Dataset",formMode:"create"})}const R1=function(){var n={defaultValue:null,kind:"LocalArgument",name:"datasetId"},t={defaultValue:null,kind:"LocalArgument",name:"description"},a={defaultValue:null,kind:"LocalArgument",name:"metadata"},i={defaultValue:null,kind:"LocalArgument",name:"name"},r=[{alias:null,args:[{fields:[{kind:"Variable",name:"datasetId",variableName:"datasetId"},{kind:"Variable",name:"description",variableName:"description"},{kind:"Variable",name:"metadata",variableName:"metadata"},{kind:"Variable",name:"name",variableName:"name"}],kind:"ObjectValue",name:"input"}],concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"patchDataset",plural:!1,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"dataset",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[n,t,a,i],kind:"Fragment",metadata:null,name:"EditDatasetFormMutation",selections:r,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,i,t,a],kind:"Operation",name:"EditDatasetFormMutation",selections:r},params:{cacheID:"d68da97aac0aaababba2324b7d10e250",id:null,metadata:{},name:"EditDatasetFormMutation",operationKind:"mutation",text:`mutation EditDatasetFormMutation(
  $datasetId: GlobalID!
  $name: String!
  $description: String = null
  $metadata: JSON = null
) {
  patchDataset(input: {datasetId: $datasetId, name: $name, description: $description, metadata: $metadata}) {
    dataset {
      name
      description
      metadata
    }
  }
}
`}}}();R1.hash="17e232f5c22d36d0663f140c00343680";function Y0({datasetName:n,datasetId:t,datasetDescription:a,onDatasetEdited:i,onDatasetEditError:r,datasetMetadata:l}){const[o,d]=R.useMutation(R1);return e(z1,{datasetName:n,datasetDescription:a,datasetMetadata:l,onSubmit:u=>{o({variables:{datasetId:t,...u,metadata:JSON.parse(u.metadata)},onCompleted:()=>{i()},onError:m=>{r(m)}})},isSubmitting:d,submitButtonText:d?"Saving...":"Save",formMode:"edit"})}const K1=function(){var n=[{alias:null,args:null,concreteType:"DatasetEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"dataset",args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"exampleCount",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],t=[{kind:"Literal",name:"first",value:100}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"DatasetPickerQuery",selections:[{alias:"datasets",args:null,concreteType:"DatasetConnection",kind:"LinkedField",name:"__DatasetPicker__datasets_connection",plural:!1,selections:n,storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"DatasetPickerQuery",selections:[{alias:null,args:t,concreteType:"DatasetConnection",kind:"LinkedField",name:"datasets",plural:!1,selections:n,storageKey:"datasets(first:100)"},{alias:null,args:t,filters:null,handle:"connection",key:"DatasetPicker__datasets",kind:"LinkedHandle",name:"datasets"}]},params:{cacheID:"ba71791351337fdd4016ab2dc41ef65e",id:null,metadata:{connection:[{count:null,cursor:null,direction:"forward",path:["datasets"]}]},name:"DatasetPickerQuery",operationKind:"query",text:`query DatasetPickerQuery {
  datasets(first: 100) {
    edges {
      dataset: node {
        id
        name
        exampleCount
      }
      cursor
      node {
        __typename
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
}
`}}}();K1.hash="5949a605c226a9ac97df28e12c7858bd";function ec(n){const t=R.useLazyLoadQuery(K1,{},{fetchPolicy:"store-and-network"});return e(he,{label:n.label,"data-testid":"dataset-picker",size:n.size,className:"dataset-picker","aria-label":"select a dataset",onSelectionChange:n.onSelectionChange,placeholder:n.placeholder??"Select a dataset",onBlur:n.onBlur,isRequired:!0,validationState:n.validationState,errorMessage:n.errorMessage,selectedKey:n.selectedKey,children:t.datasets.edges.map(({dataset:a})=>e(P,{"aria-label":a.name,children:s(x,{direction:"column",justifyContent:"space-between",width:"100%",children:[e(y,{children:a.name}),s(y,{color:"text-700",textSize:"small",children:[a.exampleCount," examples"]})]})},a.id))})}function nc({onDatasetCreated:n}){const[t,a]=p.useState(null),[i,r]=p.useState(!1),l=ln();return s(In,{placement:"bottom right",isOpen:i,onOpenChange:o=>{a(null),r(o)},children:[e(F,{variant:"default",icon:e(I,{svg:e(T.PlusCircleOutline,{})}),"aria-label":"Create a new dataset"}),e(an,{title:"Create New Dataset",bodyStyle:{padding:0},variant:"compact",borderColor:"light",backgroundColor:"light",children:s(b,{width:"500px",children:[t?e(Ke,{variant:"danger",children:t}):null,e(ps,{onDatasetCreateError:o=>a(o.message),onDatasetCreated:({id:o,name:d})=>{a(null),r(!1),l({title:"Dataset Created",message:`Dataset "${d}" created successfully`}),n&&n(o)}})]})})]})}function gs(n){const t=Date.now(),a=Ce(je(t,365));switch(n){case"15m":return{start:kn(Ia(t,15)),end:a};case"1h":return{start:kn(Sn(t,1)),end:a};case"12h":return{start:Ce(Sn(t,12)),end:a};case"1d":return{start:Ce(de(t,1)),end:a};case"7d":return{start:Ce(de(t,7)),end:a};case"30d":return{start:Ce(de(t,30)),end:a};case"all":return{start:new Date("01/01/1971"),end:a};default:O()}}const $1=p.createContext(null);function hs(){const n=G.useContext($1);if(n===null)throw new Error("useLastNTimeRange must be used within a LastNTimeRangeProvider");return n}function tc({children:n}){const t=pe(r=>r.lastNTimeRangeKey),a=pe(r=>r.setLastNTimeRangeKey),i=gs(t);return e($1.Provider,{value:{timeRangeKey:t,setTimeRangeKey:a,timeRange:i},children:n})}const H1=[{key:"15m",label:"Last 15 Min"},{key:"1h",label:"Last Hour"},{key:"12h",label:"Last 12 Hours"},{key:"1d",label:"Last Day"},{key:"7d",label:"Last 7 Days"},{key:"30d",label:"Last Month"},{key:"all",label:"All Time"}];H1.reduce((n,t)=>({...n,[t.key]:t}),{});function fs(n){const{isDisabled:t,selectedKey:a,onSelectionChange:i}=n;return e(he,{"aria-label":"Time Range",addonBefore:e(I,{svg:e(T.CalendarOutline,{})}),isDisabled:t,selectedKey:a,onSelectionChange:r=>{i&&i(r)},align:"end",children:H1.map(({key:r,label:l})=>e(P,{children:l},r))})}function ac(){const{timeRangeKey:n,setTimeRangeKey:t}=hs();return e(fs,{selectedKey:n,onSelectionChange:t})}function ic({indeterminate:n,...t}){const a=p.useRef(null);return G.useEffect(()=>{typeof n=="boolean"&&(a.current.indeterminate=!t.checked&&n)},[a,n,t.checked]),e("div",{onClick:i=>{i.stopPropagation()},children:e("input",{type:"checkbox",ref:a,css:h`
          cursor: pointer;
        `,...t})})}function rc(n){const{isCommitting:t,onSubmit:a,defaultName:i}=n,{control:r,handleSubmit:l,formState:{isDirty:o,isValid:d}}=Te({defaultValues:{name:i??"New Key",description:"",expiresAt:""}});return e(fe,{title:"Create an API Key",isDismissable:!0,children:s(Da,{onSubmit:l(a),children:[s(b,{padding:"size-200",children:[e(z,{name:"name",control:r,rules:{required:"System key name is required"},render:({field:{onChange:c,onBlur:u,value:m},fieldState:{invalid:g,error:f}})=>e(K,{label:"Name",description:"A short name to identify this key",errorMessage:f==null?void 0:f.message,validationState:g?"invalid":"valid",onChange:c,onBlur:u,value:m.toString()})}),e(z,{name:"description",control:r,render:({field:{onChange:c,onBlur:u,value:m},fieldState:{invalid:g,error:f}})=>e(An,{label:"description",description:"A description of the system key",isRequired:!1,height:100,errorMessage:f==null?void 0:f.message,validationState:g?"invalid":"valid",onChange:c,onBlur:u,value:m==null?void 0:m.toString()})}),e(z,{name:"expiresAt",control:r,rules:{validate:c=>{const u=Aa(c);return c&&!Ea(u)?"Date is not in a valid format":u<new Date?"Date must be in the future":!0}},render:({field:{name:c,onChange:u,onBlur:m,value:g},fieldState:{invalid:f,error:L}})=>e(K,{label:"Expires At",type:"datetime-local",name:c,description:"The date at which the key will expire. Optional",errorMessage:L==null?void 0:L.message,validationState:f?"invalid":"valid",onChange:u,onBlur:m,defaultValue:g})})]}),e(b,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderColor:"dark",borderTopWidth:"thin",children:e(x,{direction:"row",gap:"size-100",justifyContent:"end",children:e(F,{variant:o?"primary":"default",type:"submit",size:"compact",disabled:!d||t,children:t?"Creating...":"Create Key"})})})]})})}function lc(n){const{jwt:t}=n;return s(fe,{title:"New API Key Created",isDismissable:!0,size:"M",children:[e(Ke,{variant:"success",banner:!0,children:"You have successfully created a new API key. The API key will only be displayed once below. Please copy and save it in a secure location."}),s("div",{css:h`
          .ac-field {
            width: 100%;
          }
        `,children:[e(b,{padding:"size-200",children:s(x,{direction:"row",gap:"size-100",alignItems:"end",children:[e(K,{label:"API Key",isReadOnly:!0,value:t,minWidth:"100%"}),e(Rn,{text:t,size:"default"})]})}),s(b,{padding:"size-200",borderTopColor:"light",borderTopWidth:"thin",children:[e(N,{level:2,weight:"heavy",children:"How to Use the API Key"}),e(b,{paddingBottom:"size-100",paddingTop:"size-100",children:e(y,{children:"When interacting with Phoenix clients and OTEL SDKs, set the environment variable"})}),e(B,{children:e(W,{value:`PHOENIX_API_KEY=${t}`})}),e(b,{paddingBottom:"size-100",paddingTop:"size-100",children:e(y,{children:"When using OpenTelemetry SDKs pass the API key in the headers"})}),e(B,{children:e(W,{value:`OTEL_EXPORTER_OTLP_HEADERS='Authorization=Bearer ${t}'`})}),e(b,{paddingBottom:"size-100",paddingTop:"size-100",children:s(y,{children:["When using the Phoenix REST and GraphQL APIs, pass the API key as a"," ",e(V,{href:"https://swagger.io/docs/specification/authentication/bearer-authentication/",children:"bearer token"}),"."]})}),e(B,{children:e(W,{value:`Authorization: Bearer ${t}`})})]})]})]})}function oc({handleDelete:n}){const[t,a]=p.useState(null),i=()=>{a(s(fe,{title:"Delete API Key",children:[e(b,{padding:"size-200",children:e(y,{color:"danger",children:"Are you sure you want to delete this key? This cannot be undone and will disable all uses of this key."})}),e(b,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:e(x,{direction:"row",justifyContent:"end",children:e(F,{variant:"danger",onClick:()=>{n(),a(null)},children:"Delete Key"})})})]}))};return s(J,{children:[e(F,{variant:"danger",size:"compact",icon:e(I,{svg:e(T.TrashOutline,{})}),"aria-label":"Delete System Key",onClick:i}),e(tn,{isDismissable:!0,onDismiss:()=>{a(null)},children:t})]})}const B1=function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},t={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null};return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"ViewerContextRefetchQuery",selections:[{args:null,kind:"FragmentSpread",name:"ViewerContext_viewer"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"ViewerContextRefetchQuery",selections:[{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"viewer",plural:!1,selections:[n,{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null},{alias:null,args:null,concreteType:"UserRole",kind:"LinkedField",name:"role",plural:!1,selections:[t],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"authMethod",storageKey:null},{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"apiKeys",plural:!0,selections:[n,t,{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"12e359dfec5f96fcfcbeff2e8110b80f",id:null,metadata:{},name:"ViewerContextRefetchQuery",operationKind:"query",text:`query ViewerContextRefetchQuery {
  ...ViewerContext_viewer
}

fragment APIKeysTableFragment on User {
  apiKeys {
    id
    name
    description
    createdAt
    expiresAt
  }
  id
}

fragment ViewerContext_viewer on Query {
  viewer {
    id
    username
    email
    profilePictureUrl
    role {
      name
    }
    authMethod
    ...APIKeysTableFragment
  }
}
`}}}();B1.hash="bec0ae2a629134a5b9afe1846eaec2c9";const Z1={argumentDefinitions:[],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:[],operation:B1}},name:"ViewerContext_viewer",selections:[{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"viewer",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null},{alias:null,args:null,concreteType:"UserRole",kind:"LinkedField",name:"role",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"authMethod",storageKey:null},{args:null,kind:"FragmentSpread",name:"APIKeysTableFragment"}],storageKey:null}],type:"Query",abstractKey:null};Z1.hash="bec0ae2a629134a5b9afe1846eaec2c9";const G1=G.createContext({viewer:null,refetchViewer:()=>{}});function Q1(){const n=G.useContext(G1);if(n==null)throw new Error("useViewer must be used within a ViewerProvider");return n}function sc({query:n,children:t}){const[a,i]=R.useRefetchableFragment(Z1,n),r=()=>{p.startTransition(()=>{i({},{fetchPolicy:"network-only"})})};return e(G1.Provider,{value:{viewer:a.viewer,refetchViewer:r},children:t})}function Ls(n){const{fallback:t=null,children:a}=n,{viewer:i}=Q1();return i?a:e(J,{children:t})}function U1(n){const{fallback:t=null,children:a}=n,{viewer:i}=Q1();return!i||i.role.name!=="ADMIN"?e(J,{children:t}):a}const Hn="https://app.phoenix.arize.com",Cs="https://llamatrace.com",bs=[Hn,Cs],j1=bs.includes(Be),W1=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.25",y:"0.25",width:"31.5",height:"31.5"}),e("g",{mask:"url(#mask0_1112_37116)",children:e("path",{d:"M26.2795 13.8229C26.824 12.1886 26.6365 10.3984 25.7657 8.91186C24.4562 6.63186 21.8237 5.45886 19.2527 6.01086C18.109 4.72236 16.4657 3.98961 14.743 4.00011C12.115 3.99411 9.78324 5.68611 8.97474 8.18661C7.28649 8.53236 5.82924 9.58911 4.97649 11.0869C3.65724 13.3609 3.95799 16.2274 5.72049 18.1774C5.17599 19.8116 5.36349 21.6019 6.23424 23.0884C7.54374 25.3684 10.1762 26.5414 12.7472 25.9894C13.8902 27.2779 15.5342 28.0106 17.257 27.9994C19.8865 28.0061 22.219 26.3126 23.0275 23.8099C24.7157 23.4641 26.173 22.4074 27.0257 20.9096C28.3435 18.6356 28.042 15.7714 26.2802 13.8214L26.2795 13.8229ZM17.2585 26.4311C16.2062 26.4326 15.187 26.0644 14.3792 25.3901C14.416 25.3706 14.4797 25.3354 14.521 25.3099L19.3 22.5499C19.5445 22.4111 19.6945 22.1509 19.693 21.8696V15.1324L21.7127 16.2986C21.7345 16.3091 21.7487 16.3301 21.7517 16.3541V21.9334C21.7487 24.4144 19.7395 26.4259 17.2585 26.4311ZM7.59549 22.3039C7.06824 21.3934 6.87849 20.3261 7.05924 19.2904C7.09449 19.3114 7.15674 19.3496 7.20099 19.3751L11.98 22.1351C12.2222 22.2769 12.5222 22.2769 12.7652 22.1351L18.5995 18.7661V21.0986C18.601 21.1226 18.5897 21.1459 18.571 21.1609L13.7402 23.9501C11.5885 25.1891 8.84049 24.4526 7.59624 22.3039H7.59549ZM6.33774 11.8721C6.86274 10.9601 7.69149 10.2626 8.67849 9.90036C8.67849 9.94161 8.67624 10.0144 8.67624 10.0654V15.5861C8.67474 15.8666 8.82474 16.1269 9.06849 16.2656L14.9027 19.6339L12.883 20.8001C12.8627 20.8136 12.8372 20.8159 12.8147 20.8061L7.98324 18.0146C5.83599 16.7711 5.09949 14.0239 6.33699 11.8729L6.33774 11.8721ZM22.9322 15.7339L17.098 12.3649L19.1177 11.1994C19.138 11.1859 19.1635 11.1836 19.186 11.1934L24.0175 13.9826C26.1685 15.2254 26.9057 17.9771 25.663 20.1281C25.1372 21.0386 24.3092 21.7361 23.323 22.0991V16.4134C23.3252 16.1329 23.176 15.8734 22.933 15.7339H22.9322ZM24.9422 12.7084C24.907 12.6866 24.8447 12.6491 24.8005 12.6236L20.0215 9.86361C19.7792 9.72186 19.4792 9.72186 19.2362 9.86361L13.402 13.2326V10.9001C13.4005 10.8761 13.4117 10.8529 13.4305 10.8379L18.2612 8.05086C20.413 6.80961 23.164 7.54836 24.4045 9.70086C24.9287 10.6099 25.1185 11.6741 24.9407 12.7084H24.9422ZM12.304 16.8656L10.2835 15.6994C10.2617 15.6889 10.2475 15.6679 10.2445 15.6439V10.0646C10.246 7.58061 12.2612 5.56761 14.7452 5.56911C15.796 5.56911 16.813 5.93811 17.6207 6.61011C17.584 6.62961 17.521 6.66486 17.479 6.69036L12.7 9.45036C12.4555 9.58911 12.3055 9.84861 12.307 10.1299L12.304 16.8641V16.8656ZM13.4012 14.5001L16 12.9994L18.5987 14.4994V17.5001L16 19.0001L13.4012 17.5001V14.5001Z",fill:"var(--ac-global-text-color-900)"})})]}),ys=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M24.3968 1.6001H7.60314C4.28768 1.6001 1.59998 4.28781 1.59998 7.60326V24.3969C1.59998 27.7124 4.28768 30.4001 7.60314 30.4001H24.3968C27.7123 30.4001 30.4 27.7124 30.4 24.3969V7.60326C30.4 4.28781 27.7123 1.6001 24.3968 1.6001Z",fill:"black"}),e("path",{d:"M20.4595 22.9326C20.3942 22.8597 20.3287 22.7869 20.2634 22.7142C19.8027 22.2107 19.5742 21.6292 19.7557 20.8584C18.0112 21.4241 16.3359 21.5521 14.6059 21.1564C14.5605 21.6739 14.5424 22.1469 14.4722 22.6121C14.3864 23.1814 14.2552 23.7437 14.1477 24.3097C14.1102 24.5069 14.069 24.7054 14.0567 24.9049C14.02 25.4989 14.0332 26.0987 13.9532 26.6862C13.912 26.9884 13.7144 27.2694 13.5982 27.535H12.303L12.31 27.5189C12.3792 27.3307 12.4482 27.1426 12.5174 26.9544L12.5139 26.9589C12.5839 26.8887 12.6537 26.8184 12.7237 26.7482L12.7192 26.7527C12.7545 26.7172 12.7899 26.6819 12.8252 26.6464L13.0159 26.6244C13.0344 26.3096 13.0315 26.4252 13.0344 26.3096C13.0482 25.7476 13.04 25.184 13.0099 24.6227C12.9987 24.4167 12.9055 24.215 12.8499 24.0114C12.8112 24.0124 12.7725 24.0134 12.7339 24.0144C12.5274 24.7594 12.3209 25.5046 12.1144 26.2496L12.1235 26.2456C11.9757 26.5136 11.7677 27.0334 11.6199 27.3014C11.436 27.318 10.9177 27.2861 10.4885 27.2886C10.5235 26.9346 10.6549 26.7491 10.878 26.5487C11.3579 26.118 11.487 25.4862 11.4852 24.8812C11.4827 24.0362 11.3699 23.1917 11.3042 22.3469C11.3974 22.1771 11.4514 21.9604 11.5899 21.8451C12.5272 21.0642 13.2919 20.1312 14.0057 19.1537C14.6967 18.2074 15.3922 17.2629 16.0434 16.2891C16.7605 15.2164 17.5035 14.1457 17.668 12.8106C18.8827 12.9386 20.0424 13.2344 21.131 13.8176C21.4637 13.9957 21.8812 14.0157 22.2597 14.1082C22.4 14.2166 22.608 14.2959 22.6692 14.4382C22.9775 15.1554 23.2792 15.8786 23.523 16.6194C23.8229 17.5306 23.903 18.4651 23.748 19.4289C23.5624 20.5829 23.0542 21.576 22.3997 22.5182C22.2909 22.675 22.2555 22.8829 22.1862 23.0672L22.1887 23.0642C22.075 23.1445 21.9549 23.2172 21.849 23.3065C21.5627 23.548 21.4935 24.0167 21.0379 24.0824C21.0317 24.0576 21.0287 24.0326 21.0292 24.0069C21.0052 23.9615 20.9814 23.9164 20.9574 23.8711C20.7914 23.5582 20.6252 23.2456 20.4592 22.9327L20.4595 22.9326ZM8.62136 9.51022C8.44703 9.50288 8.26653 9.63839 8.08886 9.70789C8.08886 9.70789 7.92619 11.0549 7.92619 11.7327C7.92619 12.4106 8.15803 12.9852 8.19736 13.6229C8.22536 14.0771 8.24753 14.5626 8.42353 14.9684C8.63486 15.4552 8.7267 15.9257 8.70036 16.4434C8.62736 17.8817 9.37319 18.8549 10.5164 19.5961C11.0305 19.0374 11.5887 18.5127 12.0495 17.9131C12.9719 16.7127 13.7595 15.4267 14.1932 13.9569C14.2835 13.6507 14.343 13.3357 14.4312 12.9639C14.4792 12.9149 14.5777 12.8141 14.6762 12.7132L12.3105 12.7066C12.2757 12.6751 12.2514 12.6529 12.2165 12.6214L11.9172 9.70205C10.8187 9.63455 9.72053 9.55639 8.62103 9.51005L8.62136 9.51022ZM11.0974 6.03072C10.7014 5.23139 10.1199 4.61372 9.23886 4.26172C9.22486 4.50289 9.21353 4.69605 9.2012 4.90972C8.90686 4.69755 8.64653 4.51005 8.31036 4.26772C8.35336 4.70072 8.39503 5.00289 8.41103 5.30655C8.44253 5.90689 8.18469 6.20839 7.58003 6.29239C7.46219 6.30872 7.33986 6.29239 7.22136 6.30622C6.86669 6.34722 6.67719 6.54672 6.62953 6.90005C6.56719 7.36139 6.80303 7.66355 7.18053 7.84722C7.57336 8.03839 7.99219 8.17639 8.47136 8.36605C8.40119 8.60255 8.32986 8.83639 8.26286 9.07139C8.20253 9.28289 8.14703 9.49572 8.08936 9.70805C8.26703 9.63855 8.44736 9.50305 8.62186 9.51039C9.72136 9.55672 10.8195 9.63472 11.918 9.70238C11.856 8.43122 11.6695 7.18522 11.0977 6.03105L11.0974 6.03072ZM22.7327 23.7432C22.7654 23.7774 22.7979 23.8114 22.8305 23.8456C22.8647 23.8799 22.8989 23.9142 22.933 23.9484C22.967 23.9811 23.0009 24.0137 23.0349 24.0464C23.1599 24.1296 23.2849 24.2129 23.4097 24.2961C23.4704 23.9702 23.8405 23.5016 24.1502 23.2742C24.278 23.1804 24.3344 22.9924 24.4334 22.8546C24.4887 22.7776 24.5649 22.7156 24.6317 22.6469C24.6047 22.4296 24.5622 22.2131 24.5539 21.9951C24.53 21.3696 24.5692 20.7522 24.3732 20.1277C24.1377 19.3777 24.2292 18.5857 24.2729 17.7916C24.9915 17.6471 25.2974 17.1784 25.3377 16.5476C25.3864 15.7856 25.2435 15.0506 24.7662 14.4271C24.424 13.9802 23.9605 13.7294 23.3855 13.8199C23.0047 13.8797 22.6349 14.0094 22.26 14.1079C22.4004 14.2162 22.6084 14.2956 22.6695 14.4379C22.9779 15.1551 23.2795 15.8782 23.5234 16.6191C23.8232 17.5302 23.9034 18.4647 23.7484 19.4286C23.5627 20.5826 23.0545 21.5757 22.4 22.5179C22.2912 22.6747 22.2559 22.8826 22.1865 23.0669C22.3687 23.2924 22.5507 23.5177 22.7329 23.7432H22.7327ZM16.429 12.7566C16.3242 14.1091 15.68 15.2467 14.965 16.3461C14.3355 17.3139 13.7025 18.2844 12.9959 19.1956C12.4884 19.8499 11.857 20.4084 11.2809 21.0096C11.2887 21.4552 11.2965 21.9011 11.3044 22.3467C11.3975 22.1769 11.4515 21.9602 11.59 21.8449C12.5274 21.0641 13.292 20.1311 14.0059 19.1536C14.6969 18.2072 15.3924 17.2627 16.0435 16.2889C16.7607 15.2162 17.5037 14.1456 17.6682 12.8104C17.2552 12.7924 16.8422 12.7746 16.4292 12.7566H16.429ZM11.0757 19.9797C11.6089 19.3922 12.2085 18.8511 12.6599 18.2062C13.3574 17.2101 13.9809 16.1586 14.582 15.1002C14.923 14.5001 15.171 13.8462 15.203 13.1314C15.2087 13.0027 15.3402 12.8799 15.4135 12.7542C15.3532 12.7559 15.293 12.7576 15.2327 12.7592C15.1554 12.7434 15.078 12.7274 15.0009 12.7116C14.8927 12.7122 14.7847 12.7127 14.6765 12.7134C14.578 12.8142 14.4794 12.9151 14.4315 12.9641C14.3434 13.3357 14.2837 13.6509 14.1935 13.9571C13.7599 15.4269 12.9722 16.7129 12.0499 17.9132C11.589 18.5129 11.0309 19.0376 10.5167 19.5962C10.703 19.7241 10.8894 19.8519 11.0757 19.9799V19.9797ZM15.712 12.7541C15.752 13.8777 15.2507 14.8322 14.7135 15.7546C14.1947 16.6451 13.6115 17.5002 13.0197 18.3452C12.6715 18.8424 12.2557 19.2926 11.8627 19.7576C11.6777 19.9764 11.4749 20.1802 11.28 20.3907C11.2804 20.5971 11.2805 20.8032 11.2809 21.0096C11.857 20.4084 12.4884 19.8499 12.9959 19.1956C13.7025 18.2846 14.3357 17.3141 14.965 16.3461C15.68 15.2467 16.3242 14.1091 16.429 12.7566C16.19 12.7557 15.951 12.7549 15.7119 12.7541H15.712ZM23.4289 24.3776C23.5199 24.5641 23.6867 24.7499 23.6879 24.9369C23.692 25.6002 23.6439 26.2644 23.6017 26.9272C23.598 26.9859 23.4942 27.0382 23.4369 27.0935C23.3985 27.1222 23.36 27.1509 23.3217 27.1796C23.2885 27.2149 23.2554 27.2502 23.2222 27.2854C23.186 27.3172 23.1497 27.3489 23.1135 27.3807C23.1704 27.4447 23.2244 27.5609 23.2844 27.564C23.6212 27.582 23.9594 27.5727 24.3122 27.5727C24.6089 26.8482 24.7105 26.1406 24.6009 25.4002C24.5792 25.2536 24.5384 25.0701 24.6017 24.9571C25.0337 24.1864 24.9189 23.4202 24.6317 22.6467C24.5649 22.7154 24.4887 22.7774 24.4334 22.8544C24.3344 22.9922 24.278 23.1802 24.1502 23.2741C23.8405 23.5014 23.4704 23.9701 23.4097 24.2959C23.4145 24.3234 23.4209 24.3505 23.4289 24.3774V24.3776ZM15.4137 12.7541C15.3404 12.8796 15.2089 13.0026 15.2032 13.1312C15.1712 13.8461 14.9232 14.4999 14.5822 15.1001C13.9809 16.1586 13.3575 17.2101 12.66 18.2061C12.2085 18.8509 11.609 19.3919 11.0759 19.9796C11.144 20.1166 11.212 20.2536 11.2802 20.3906C11.475 20.1799 11.6779 19.9762 11.8629 19.7574C12.2559 19.2926 12.6717 18.8422 13.0199 18.345C13.6115 17.5001 14.1949 16.6449 14.7137 15.7544C15.2509 14.8321 15.7522 13.8776 15.7122 12.7539C15.6127 12.7539 15.5134 12.7539 15.4139 12.7539L15.4137 12.7541ZM15.0009 12.7114C15.0782 12.7272 15.1555 12.7432 15.2327 12.7591C15.1554 12.7432 15.078 12.7272 15.0009 12.7114ZM12.2212 12.6641C12.251 12.6782 12.281 12.6924 12.3109 12.7066C12.2842 12.6857 12.2542 12.6716 12.2212 12.6641ZM20.2559 26.4779C20.1152 26.5756 19.9745 26.6732 19.8339 26.7709C19.8065 26.9284 19.7792 27.0859 19.7505 27.2509H20.9545C20.9545 27.0077 20.9384 26.7889 20.9602 26.5741C20.9747 26.4314 21.0054 26.2596 21.0949 26.1604C21.8912 25.2774 22.2055 24.2307 22.189 23.064C22.0754 23.1444 21.9552 23.2171 21.8494 23.3064C21.563 23.5479 21.4939 24.0166 21.0382 24.0822C21.0512 24.9702 20.7829 25.7662 20.256 26.4779H20.2559Z",fill:"url(#paint0_linear_1119_37286)"}),e("defs",{children:s("linearGradient",{id:"paint0_linear_1119_37286",x1:"3.72803",y1:"12.2264",x2:"26.5747",y2:"25.3626",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#F6DDD7"}),e("stop",{offset:"0.25",stopColor:"#FCABE6"}),e("stop",{offset:"0.3",stopColor:"#F3ADE6"}),e("stop",{offset:"0.38",stopColor:"#DDB3E8"}),e("stop",{offset:"0.48",stopColor:"#B8BCEC"}),e("stop",{offset:"0.59",stopColor:"#85CAF1"}),e("stop",{offset:"0.7",stopColor:"#50D8F6"}),e("stop",{offset:"0.76",stopColor:"#50D8F6"}),e("stop",{offset:"0.86",stopColor:"#B58FE8"})]})})]}),q1=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.25",y:"0.25",width:"31.5",height:"31.5"}),e("path",{d:"M24.0371 13.2112C24.5781 13.7522 24.5781 14.6325 24.0371 15.1734L22.8253 16.3657L22.813 16.2974C22.7245 15.8074 22.4915 15.3627 22.1398 15.011C21.875 14.7467 21.5619 14.5513 21.2091 14.4303C20.9902 14.6504 20.8698 14.9388 20.8698 15.2423C20.8698 15.3039 20.8754 15.3678 20.8866 15.4316C21.0809 15.5016 21.2528 15.6097 21.3973 15.7542C21.9382 16.2951 21.9382 17.1754 21.3973 17.7164L20.3422 18.7714C20.0718 19.0419 19.7167 19.1769 19.3611 19.1769C19.0055 19.1769 18.6505 19.0419 18.38 18.7714C17.839 18.2305 17.839 17.3502 18.38 16.8092L19.5918 15.6175L19.6042 15.6858C19.6921 16.1747 19.925 16.6194 20.2778 16.9716C20.5433 17.237 20.8373 17.4134 21.1895 17.5338L21.2545 17.4689C21.4516 17.2718 21.5597 17.0097 21.5597 16.7302C21.5597 16.6681 21.5541 16.6059 21.5434 16.5449C21.3402 16.4777 21.1727 16.3819 21.0204 16.2296C20.8009 16.0101 20.6642 15.7295 20.6262 15.4187C20.6234 15.3963 20.6217 15.3745 20.6194 15.3521C20.5892 14.9472 20.7354 14.5518 21.0204 14.2674L22.0754 13.2123C22.337 12.9508 22.6853 12.8063 23.0566 12.8063C23.4278 12.8063 23.7762 12.9502 24.0377 13.2123L24.0371 13.2112ZM29.5464 16C29.5464 19.8601 26.4059 23 22.5464 23H9C5.14048 23 2 19.8601 2 16C2 12.1399 5.14048 9 9 9H22.5464C26.4065 9 29.5464 12.1405 29.5464 16ZM15.4904 19.5106C15.6007 19.3768 15.0911 18.9999 14.987 18.8616C14.7753 18.632 14.7742 18.3016 14.6314 18.0334C14.2819 17.2236 13.8804 16.42 13.3187 15.7346C12.7251 14.9847 11.9926 14.3642 11.3492 13.6603C10.8715 13.1692 10.7438 12.4698 10.3222 11.9417C9.74088 11.0832 7.90296 10.8491 7.6336 12.0615C7.63472 12.0996 7.62296 12.1237 7.58992 12.1478C7.44096 12.2558 7.30824 12.3796 7.1968 12.5291C6.92408 12.9088 6.88208 13.5528 7.22256 13.8938C7.23376 13.7141 7.23992 13.5444 7.38216 13.4156C7.64536 13.6413 8.04296 13.7214 8.34816 13.5528C9.0224 14.5154 8.8544 15.8471 9.38976 16.8842C9.5376 17.1295 9.68656 17.3798 9.8764 17.5949C10.0304 17.8346 10.5624 18.1174 10.5938 18.3391C10.5994 18.7199 10.5546 19.136 10.8043 19.4546C10.9219 19.6932 10.633 19.9329 10.4 19.9032C10.0976 19.9446 9.72856 19.6999 9.46368 19.8506C9.37016 19.9519 9.18704 19.8399 9.1064 19.9805C9.0784 20.0533 8.9272 20.1558 9.01736 20.2258C9.1176 20.1496 9.21056 20.0701 9.34552 20.1154C9.32536 20.2252 9.41216 20.2409 9.48104 20.2728C9.4788 20.3473 9.43512 20.4234 9.49224 20.4867C9.55888 20.4195 9.59864 20.3243 9.70448 20.2963C10.0562 20.765 10.414 19.822 11.175 20.2465C11.0205 20.2386 10.8833 20.2582 10.7791 20.3854C10.7534 20.4139 10.7315 20.4475 10.7769 20.4845C11.1874 20.2196 11.1851 20.5752 11.4517 20.466C11.6566 20.359 11.8605 20.2252 12.1041 20.2633C11.8672 20.3316 11.8577 20.522 11.7188 20.6827C11.6953 20.7074 11.6841 20.7354 11.7115 20.7762C12.2032 20.7348 12.2435 20.5713 12.6406 20.3708C12.9368 20.1899 13.2319 20.6284 13.4884 20.3786C13.545 20.3243 13.6222 20.3428 13.6922 20.3355C13.6026 19.8578 12.6176 20.4229 12.6333 19.7822C12.9502 19.5666 12.8774 19.1539 12.8987 18.8207C13.2633 19.0229 13.6687 19.1405 14.026 19.3337C14.2063 19.6249 14.4891 20.0096 14.866 19.9844C14.8761 19.9553 14.885 19.9295 14.8957 19.8998C15.0099 19.9194 15.1566 19.995 15.2194 19.8506C15.3902 20.0292 15.641 20.0202 15.8645 19.9743C16.0297 19.8399 15.5537 19.6484 15.4898 19.5101L15.4904 19.5106ZM25.4926 14.1923C25.4926 13.5405 25.2394 12.9284 24.7797 12.4686C24.3199 12.0089 23.7078 11.7558 23.0554 11.7558C22.403 11.7558 21.791 12.0089 21.3312 12.4686L20.2762 13.5237C20.0298 13.7701 19.8427 14.0596 19.7201 14.3838L19.7128 14.4023L19.6938 14.4079C19.3107 14.5261 18.973 14.7288 18.6902 15.0116L17.6352 16.0666C16.6849 17.0175 16.6849 18.5642 17.6352 19.5146C18.095 19.9743 18.707 20.2274 19.3589 20.2274C20.0107 20.2274 20.6234 19.9743 21.0831 19.5146L22.1382 18.4595C22.3834 18.2142 22.5694 17.9258 22.692 17.6022L22.6993 17.5837L22.7183 17.5775C23.0946 17.4622 23.4418 17.2527 23.7235 16.9716L24.7786 15.9166C25.2383 15.4568 25.4914 14.8447 25.4914 14.1923H25.4926ZM11.6533 18.7216C11.5626 19.0755 11.5329 19.6786 11.0726 19.696C11.0345 19.9004 11.2142 19.9771 11.3772 19.9116C11.539 19.8371 11.6158 19.9704 11.6701 20.1031C11.9198 20.1395 12.2894 20.0197 12.3034 19.724C11.9305 19.509 11.8151 19.1002 11.6527 18.7216H11.6533Z",fill:"var(--ac-global-text-color-900)"})]}),vs=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M29.5341 0H2.46593C1.10403 0 0 1.10403 0 2.46593V29.5341C0 30.896 1.10403 32 2.46593 32H29.5341C30.896 32 32 30.896 32 29.5341V2.46593C32 1.10403 30.896 0 29.5341 0Z",fill:"#0EAF9C"}),e("path",{d:"M24.1471 21.3058C24.1471 21.4934 23.9942 21.6447 23.806 21.6447C22.1086 21.6447 20.7328 20.2777 20.7328 18.5913V13.1026C20.7328 10.6667 18.7453 8.69255 16.2944 8.69255C13.8435 8.69255 11.9651 10.6674 11.9651 13.1026V15.1358C11.9611 15.3197 12.1082 15.4716 12.2925 15.4749C12.2951 15.4749 12.2971 15.4749 12.2997 15.4749H14.2389C14.4271 15.4787 14.5833 15.33 14.5872 15.1424C14.5872 15.1398 14.5872 15.1378 14.5872 15.1352V13.0201C14.5872 12.083 15.3513 11.3239 16.2944 11.3239C17.2375 11.3239 18.0016 12.083 18.0016 13.0201V25.7697C17.9976 25.9606 17.8388 26.1126 17.6466 26.1086C15.9571 26.1086 14.5872 24.7475 14.5872 23.0689C14.5872 23.0643 14.5872 23.0597 14.5872 23.0552V18.9842C14.5833 18.7958 14.4284 18.6451 14.2389 18.6451H12.2997C12.1147 18.6451 11.9651 18.7939 11.9651 18.9776C11.9651 18.9802 11.9651 18.9822 11.9651 18.9848V20.342C11.9651 22.0285 10.4801 23.3955 8.78276 23.3955C8.59391 23.3955 8.44165 23.2436 8.44165 23.0565V13.1033C8.44165 8.79386 11.9572 5.30078 16.2944 5.30078C20.6315 5.30078 24.1471 8.79386 24.1471 13.1033V21.3058Z",fill:"white"})]}),ks=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[s("g",{clipPath:"url(#clip0_1112_37203)",children:[e("path",{d:"M29.0909 0H23.2727V6.39251H29.0909V0Z",fill:"black"}),e("path",{d:"M32 0H26.1818V6.39251H32V0Z",fill:"#F7D046"}),e("path",{d:"M5.81818 0H0V6.39251H5.81818V0Z",fill:"black"}),e("path",{d:"M5.81818 6.39258H0V12.7851H5.81818V6.39258Z",fill:"black"}),e("path",{d:"M5.81818 12.7852H0V19.1777H5.81818V12.7852Z",fill:"black"}),e("path",{d:"M5.81818 19.1777H0V25.5702H5.81818V19.1777Z",fill:"black"}),e("path",{d:"M5.81818 25.5698H0V31.9623H5.81818V25.5698Z",fill:"black"}),e("path",{d:"M8.7273 0H2.90912V6.39251H8.7273V0Z",fill:"#F7D046"}),e("path",{d:"M32 6.39258H26.1818V12.7851H32V6.39258Z",fill:"#F2A73B"}),e("path",{d:"M8.7273 6.39258H2.90912V12.7851H8.7273V6.39258Z",fill:"#F2A73B"}),e("path",{d:"M23.2727 6.39258H17.4545V12.7851H23.2727V6.39258Z",fill:"black"}),e("path",{d:"M26.1818 6.39258H20.3636V12.7851H26.1818V6.39258Z",fill:"#F2A73B"}),e("path",{d:"M14.5455 6.39258H8.72729V12.7851H14.5455V6.39258Z",fill:"#F2A73B"}),e("path",{d:"M20.3637 12.7852H14.5455V19.1777H20.3637V12.7852Z",fill:"#EE792F"}),e("path",{d:"M26.1818 12.7852H20.3636V19.1777H26.1818V12.7852Z",fill:"#EE792F"}),e("path",{d:"M14.5455 12.7852H8.72729V19.1777H14.5455V12.7852Z",fill:"#EE792F"}),e("path",{d:"M17.4545 19.1777H11.6364V25.5702H17.4545V19.1777Z",fill:"black"}),e("path",{d:"M20.3637 19.1777H14.5455V25.5702H20.3637V19.1777Z",fill:"#EB5829"}),e("path",{d:"M32 12.7852H26.1818V19.1777H32V12.7852Z",fill:"#EE792F"}),e("path",{d:"M8.7273 12.7852H2.90912V19.1777H8.7273V12.7852Z",fill:"#EE792F"}),e("path",{d:"M29.0909 19.1777H23.2727V25.5702H29.0909V19.1777Z",fill:"black"}),e("path",{d:"M32 19.1777H26.1818V25.5702H32V19.1777Z",fill:"#EB5829"}),e("path",{d:"M29.0909 25.5698H23.2727V31.9623H29.0909V25.5698Z",fill:"black"}),e("path",{d:"M8.7273 19.1777H2.90912V25.5702H8.7273V19.1777Z",fill:"#EB5829"}),e("path",{d:"M32 25.5698H26.1818V31.9623H32V25.5698Z",fill:"#EA3326"}),e("path",{d:"M8.7273 25.5698H2.90912V31.9623H8.7273V25.5698Z",fill:"#EA3326"})]}),e("defs",{children:e("clipPath",{id:"clip0_1112_37203",children:e("rect",{width:"32",height:"32",fill:"white"})})})]}),Ss=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M26.6667 18.52C26.5078 18.3292 26.2852 18.2025 26.04 18.1633C25.7949 18.1241 25.5438 18.175 25.3333 18.3067L16 25.16V25.4533C16.1347 25.4374 16.2712 25.4501 16.4005 25.4908C16.5299 25.5314 16.6492 25.5989 16.7506 25.689C16.852 25.7791 16.9331 25.8896 16.9887 26.0133C17.0442 26.137 17.0729 26.2711 17.0729 26.4067C17.0729 26.5423 17.0442 26.6763 16.9887 26.8C16.9331 26.9237 16.852 27.0342 16.7506 27.1243C16.6492 27.2144 16.5299 27.2819 16.4005 27.3226C16.2712 27.3632 16.1347 27.3759 16 27.36C16.2165 27.361 16.4274 27.2907 16.6 27.16L26.48 19.8667C26.6725 19.7053 26.7982 19.4781 26.8327 19.2293C26.8672 18.9804 26.808 18.7277 26.6667 18.52Z",fill:"#669DF6"}),e("path",{d:"M16 27.3598C15.7666 27.3322 15.5514 27.2198 15.3953 27.0441C15.2392 26.8684 15.153 26.6415 15.153 26.4065C15.153 26.1714 15.2392 25.9446 15.3953 25.7689C15.5514 25.5931 15.7666 25.4808 16 25.4532V25.1598L6.66669 18.3065C6.45707 18.172 6.20525 18.1194 5.95931 18.1587C5.71337 18.1981 5.49054 18.3266 5.33335 18.5198C5.19277 18.7276 5.13659 18.981 5.17621 19.2287C5.21584 19.4764 5.34831 19.6997 5.54669 19.8532L15.4267 27.1465C15.5952 27.2753 15.8012 27.3455 16.0134 27.3465L16 27.3598Z",fill:"#AECBFA"}),e("path",{d:"M16 24.4531C15.6123 24.4531 15.2334 24.5681 14.9111 24.7834C14.5887 24.9988 14.3375 25.3049 14.1892 25.6631C14.0408 26.0212 14.002 26.4153 14.0776 26.7955C14.1533 27.1757 14.3399 27.5249 14.614 27.7991C14.8882 28.0732 15.2374 28.2598 15.6176 28.3355C15.9978 28.4111 16.3919 28.3723 16.75 28.2239C17.1082 28.0756 17.4143 27.8244 17.6297 27.502C17.845 27.1797 17.96 26.8008 17.96 26.4131C17.96 25.8933 17.7535 25.3948 17.3859 25.0272C17.0183 24.6596 16.5198 24.4531 16 24.4531ZM16 27.3598C15.8095 27.3598 15.6234 27.3031 15.4653 27.197C15.3071 27.0909 15.1841 26.9402 15.1119 26.764C15.0396 26.5878 15.0214 26.3941 15.0595 26.2075C15.0977 26.021 15.1904 25.85 15.326 25.7162C15.4616 25.5825 15.6339 25.4922 15.821 25.4566C16.0081 25.4211 16.2015 25.442 16.3767 25.5168C16.5519 25.5915 16.7008 25.7166 16.8047 25.8762C16.9086 26.0358 16.9626 26.2227 16.96 26.4131C16.96 26.5386 16.9351 26.6628 16.8867 26.7785C16.8383 26.8942 16.7673 26.9992 16.678 27.0873C16.5887 27.1754 16.4827 27.2448 16.3663 27.2916C16.25 27.3384 16.1254 27.3616 16 27.3598Z",fill:"#4285F4"}),e("path",{d:"M8.00001 8.14679C7.73587 8.14333 7.48352 8.03687 7.29673 7.85008C7.10993 7.66328 7.00347 7.41093 7.00001 7.14679V4.64012C6.98365 4.4982 6.99749 4.35441 7.04061 4.21821C7.08373 4.08201 7.15517 3.95647 7.25023 3.84982C7.34529 3.74317 7.46183 3.65782 7.5922 3.59939C7.72256 3.54095 7.86382 3.51074 8.00668 3.51074C8.14955 3.51074 8.2908 3.54095 8.42117 3.59939C8.55153 3.65782 8.66807 3.74317 8.76313 3.84982C8.85819 3.95647 8.92963 4.08201 8.97275 4.21821C9.01587 4.35441 9.02971 4.4982 9.01335 4.64012V7.14679C9.00984 7.41322 8.90153 7.66756 8.71188 7.85472C8.52222 8.04188 8.26647 8.14681 8.00001 8.14679Z",fill:"#AECBFA"}),e("path",{d:"M7.97336 17.0135C8.533 17.0135 8.98669 16.5598 8.98669 16.0002C8.98669 15.4405 8.533 14.9868 7.97336 14.9868C7.41371 14.9868 6.96002 15.4405 6.96002 16.0002C6.96002 16.5598 7.41371 17.0135 7.97336 17.0135Z",fill:"#AECBFA"}),e("path",{d:"M7.97336 14.0667C8.533 14.0667 8.98669 13.613 8.98669 13.0534C8.98669 12.4937 8.533 12.04 7.97336 12.04C7.41371 12.04 6.96002 12.4937 6.96002 13.0534C6.96002 13.613 7.41371 14.0667 7.97336 14.0667Z",fill:"#AECBFA"}),e("path",{d:"M7.97336 11.1067C8.533 11.1067 8.98669 10.6531 8.98669 10.0934C8.98669 9.53376 8.533 9.08008 7.97336 9.08008C7.41371 9.08008 6.96002 9.53376 6.96002 10.0934C6.96002 10.6531 7.41371 11.1067 7.97336 11.1067Z",fill:"#AECBFA"}),e("path",{d:"M24 11.0801C23.7336 11.0766 23.4792 10.9682 23.2921 10.7786C23.1049 10.5889 23 10.3332 23 10.0667V7.56006C23 7.29484 23.1054 7.04049 23.2929 6.85295C23.4804 6.66542 23.7348 6.56006 24 6.56006C24.2652 6.56006 24.5196 6.66542 24.7071 6.85295C24.8946 7.04049 25 7.29484 25 7.56006V10.0667C25.0018 10.1992 24.9772 10.3306 24.9277 10.4535C24.8783 10.5764 24.8049 10.6882 24.7119 10.7825C24.6188 10.8767 24.508 10.9516 24.3858 11.0027C24.2636 11.0538 24.1325 11.0801 24 11.0801Z",fill:"#4285F4"}),e("path",{d:"M24.0266 17.0267C24.5863 17.0267 25.04 16.573 25.04 16.0133C25.04 15.4537 24.5863 15 24.0266 15C23.467 15 23.0133 15.4537 23.0133 16.0133C23.0133 16.573 23.467 17.0267 24.0266 17.0267Z",fill:"#4285F4"}),e("path",{d:"M24.0266 14.0267C24.5863 14.0267 25.04 13.573 25.04 13.0133C25.04 12.4537 24.5863 12 24.0266 12C23.467 12 23.0133 12.4537 23.0133 13.0133C23.0133 13.573 23.467 14.0267 24.0266 14.0267Z",fill:"#4285F4"}),e("path",{d:"M24.0266 5.65313C24.5863 5.65313 25.04 5.19945 25.04 4.6398C25.04 4.08015 24.5863 3.62646 24.0266 3.62646C23.467 3.62646 23.0133 4.08015 23.0133 4.6398C23.0133 5.19945 23.467 5.65313 24.0266 5.65313Z",fill:"#4285F4"}),e("path",{d:"M16 20.0001C15.7359 19.9967 15.4835 19.8902 15.2967 19.7034C15.1099 19.5166 15.0035 19.2642 15 19.0001V16.4534C15.0285 16.2064 15.1468 15.9785 15.3324 15.813C15.518 15.6476 15.758 15.5562 16.0067 15.5562C16.2553 15.5562 16.4953 15.6476 16.6809 15.813C16.8665 15.9785 16.9849 16.2064 17.0133 16.4534V18.9734C17.0151 19.1076 16.9902 19.2408 16.9401 19.3653C16.8899 19.4898 16.8156 19.6031 16.7213 19.6986C16.627 19.7941 16.5147 19.87 16.3909 19.9217C16.2671 19.9735 16.1342 20.0001 16 20.0001Z",fill:"#669DF6"}),e("path",{d:"M16 22.9466C16.5597 22.9466 17.0134 22.4929 17.0134 21.9333C17.0134 21.3736 16.5597 20.9199 16 20.9199C15.4404 20.9199 14.9867 21.3736 14.9867 21.9333C14.9867 22.4929 15.4404 22.9466 16 22.9466Z",fill:"#669DF6"}),e("path",{d:"M16 14.5335C16.5597 14.5335 17.0134 14.0798 17.0134 13.5202C17.0134 12.9605 16.5597 12.5068 16 12.5068C15.4404 12.5068 14.9867 12.9605 14.9867 13.5202C14.9867 14.0798 15.4404 14.5335 16 14.5335Z",fill:"#669DF6"}),e("path",{d:"M16 11.5735C16.5597 11.5735 17.0134 11.1199 17.0134 10.5602C17.0134 10.0006 16.5597 9.54688 16 9.54688C15.4404 9.54688 14.9867 10.0006 14.9867 10.5602C14.9867 11.1199 15.4404 11.5735 16 11.5735Z",fill:"#669DF6"}),e("path",{d:"M20 14.0535C19.7359 14.0501 19.4835 13.9436 19.2967 13.7568C19.1099 13.57 19.0035 13.3177 19 13.0535V10.5469C18.9837 10.4049 18.9975 10.2612 19.0406 10.125C19.0837 9.98875 19.1552 9.8632 19.2502 9.75655C19.3453 9.64991 19.4618 9.56456 19.5922 9.50613C19.7226 9.44769 19.8638 9.41748 20.0067 9.41748C20.1495 9.41748 20.2908 9.44769 20.4212 9.50613C20.5515 9.56456 20.6681 9.64991 20.7631 9.75655C20.8582 9.8632 20.9296 9.98875 20.9728 10.125C21.0159 10.2612 21.0297 10.4049 21.0133 10.5469V13.0535C21.0098 13.32 20.9015 13.5743 20.7119 13.7615C20.5222 13.9486 20.2665 14.0535 20 14.0535Z",fill:"#4285F4"}),e("path",{d:"M20.0133 8.59991C20.573 8.59991 21.0267 8.14622 21.0267 7.58658C21.0267 7.02693 20.573 6.57324 20.0133 6.57324C19.4537 6.57324 19 7.02693 19 7.58658C19 8.14622 19.4537 8.59991 20.0133 8.59991Z",fill:"#4285F4"}),e("path",{d:"M20.0133 19.9334C20.573 19.9334 21.0267 19.4797 21.0267 18.9201C21.0267 18.3604 20.573 17.9067 20.0133 17.9067C19.4537 17.9067 19 18.3604 19 18.9201C19 19.4797 19.4537 19.9334 20.0133 19.9334Z",fill:"#4285F4"}),e("path",{d:"M20.0133 16.9734C20.573 16.9734 21.0267 16.5198 21.0267 15.9601C21.0267 15.4005 20.573 14.9468 20.0133 14.9468C19.4537 14.9468 19 15.4005 19 15.9601C19 16.5198 19.4537 16.9734 20.0133 16.9734Z",fill:"#4285F4"}),e("path",{d:"M11.9867 19.9334C12.5463 19.9334 13 19.4797 13 18.9201C13 18.3604 12.5463 17.9067 11.9867 17.9067C11.427 17.9067 10.9733 18.3604 10.9733 18.9201C10.9733 19.4797 11.427 19.9334 11.9867 19.9334Z",fill:"#AECBFA"}),e("path",{d:"M11.9867 11.5735C12.5463 11.5735 13 11.1199 13 10.5602C13 10.0006 12.5463 9.54688 11.9867 9.54688C11.427 9.54688 10.9733 10.0006 10.9733 10.5602C10.9733 11.1199 11.427 11.5735 11.9867 11.5735Z",fill:"#AECBFA"}),e("path",{d:"M11.9867 8.59991C12.5463 8.59991 13 8.14622 13 7.58658C13 7.02693 12.5463 6.57324 11.9867 6.57324C11.427 6.57324 10.9733 7.02693 10.9733 7.58658C10.9733 8.14622 11.427 8.59991 11.9867 8.59991Z",fill:"#AECBFA"}),e("path",{d:"M12 16.9735C11.7381 16.9737 11.4862 16.8724 11.2973 16.6909C11.1083 16.5095 10.997 16.2619 10.9867 16.0001V13.4668C10.9867 13.2016 11.0921 12.9472 11.2796 12.7597C11.4671 12.5722 11.7215 12.4668 11.9867 12.4668C12.2519 12.4668 12.5063 12.5722 12.6938 12.7597C12.8813 12.9472 12.9867 13.2016 12.9867 13.4668V16.0001C12.9798 16.2584 12.8733 16.504 12.6893 16.6854C12.5054 16.8669 12.2584 16.9701 12 16.9735Z",fill:"#AECBFA"})]}),ws=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("g",{clipPath:"url(#clip0_1148_5989)",children:e("path",{d:"M1.96742 0.421623C1.1852 0.496042 0.711124 0.64488 0.616309 0.868135C0.379272 1.5379 0.189642 30.6108 0.42668 30.9829C0.592605 31.2309 1.75409 31.3798 4.64594 31.5286C9.88446 31.8511 30.9571 31.7022 31.2652 31.3798C31.4074 31.2309 31.5259 25.7239 31.5733 16.1736C31.6445 2.15806 31.6208 1.19061 31.2415 0.892941C31.0045 0.719297 29.9852 0.496042 28.9896 0.421623C27.1171 0.24798 4.21927 0.272786 1.96742 0.421623ZM15.7867 2.10844C15.8815 2.3317 15.8578 3.10069 15.763 3.84488C15.6208 5.18441 15.5971 5.20922 14.8385 5.20922C11.6148 5.20922 11.5674 11.386 14.7911 11.4852C15.2652 11.51 15.6445 11.6092 15.6445 11.7332C15.6445 11.8325 15.5259 12.7255 15.36 13.6929L15.0993 15.4294L14.0089 15.2805C10.8326 14.8092 10.2874 14.8092 9.86075 15.2557C9.60001 15.5286 9.5052 15.9007 9.57631 16.2232C10.1452 18.2573 9.83705 18.8526 8.29631 18.8526C6.58964 18.8526 6.3052 18.4061 6.92149 16.6201C7.15853 15.8759 7.13483 15.7519 6.63705 15.3301C6.21038 14.9581 5.6889 14.8836 3.84001 14.8836H1.58816L1.73038 12.8247C1.8252 11.7084 1.89631 8.80612 1.89631 6.39992V2.00922L2.56001 1.91C2.91557 1.86038 5.99705 1.78596 9.43409 1.76116C14.7911 1.73635 15.6682 1.78596 15.7867 2.10844ZM30.0326 2.05883C30.1985 2.23248 30.1985 15.3798 30.0326 15.5286C30.0089 15.5534 29.1556 15.6278 28.1363 15.6774L26.2874 15.8015L26.4296 15.2061C26.643 14.2387 26.1215 12.9488 25.363 12.527C24.4859 12.0557 22.5185 12.0557 21.4519 12.5022C20.4326 12.9488 20.0771 13.6681 20.1956 15.0325L20.2667 16.0991L19.2 15.9751C16.6163 15.6774 16.5452 15.6526 16.6874 15.0325C16.7585 14.71 16.9482 13.5937 17.0904 12.5519C17.3274 10.865 17.3274 10.5922 16.9719 10.1953C16.6637 9.82317 16.3556 9.74875 15.6208 9.84798C14.4593 10.0216 13.9852 9.62472 13.9852 8.50844C13.9852 7.04488 14.3171 6.67279 15.5971 6.7472C16.5452 6.82162 16.7111 6.7472 16.9956 6.20147C17.1615 5.85418 17.3037 4.7379 17.3037 3.64643V1.68674L23.5615 1.78596C26.9985 1.81077 29.9141 1.95961 30.0326 2.05883ZM24.4385 13.9162C24.8415 14.1395 24.8889 14.3875 24.8415 15.7022L24.7704 17.2402L27.4963 17.1906L30.2222 17.1658L30.1985 18.679C30.1748 19.5224 30.1511 22.4743 30.1274 25.2278L30.1037 30.2635H23.2296H16.3556V28.527V26.8154L17.5408 26.9643C18.6548 27.0883 18.7496 27.0635 19.5793 26.1953C20.4326 25.3022 20.4326 25.2774 20.3378 23.541C20.2667 21.9534 20.1719 21.7053 19.5556 21.1596C18.963 20.6139 18.7022 20.5395 17.4696 20.6387L16.0711 20.7379L16.2133 20.0185C16.2845 19.6216 16.3556 18.8278 16.3556 18.2325V17.1906L17.4933 17.3891C18.1096 17.4883 19.2711 17.5875 20.0533 17.5875C21.9259 17.6123 22.2104 17.3146 21.8311 15.7519C21.6889 15.1069 21.6178 14.4867 21.7126 14.3627C22.0919 13.7177 23.6563 13.4697 24.4385 13.9162ZM5.09631 17.6371C5.12001 19.1751 5.6889 19.9937 6.92149 20.341C8.34372 20.7627 9.88446 20.4402 10.7141 19.5968C11.2593 19.0263 11.3778 18.679 11.3778 17.7115V16.5457L12.4682 16.7193C13.0845 16.7937 13.8193 16.8681 14.1274 16.8681C14.6963 16.8681 14.6963 16.9177 14.6963 19.3488C14.6963 21.4573 14.7674 21.9038 15.1467 22.3007C15.5971 22.772 15.6682 22.772 16.7822 22.3999C17.4222 22.1767 18.1096 22.0774 18.323 22.1519C18.7971 22.3255 19.0341 23.8387 18.7259 24.6821C18.4889 25.3022 18.3941 25.3519 17.4696 25.2278C16.9245 25.1782 16.3082 25.0294 16.1185 24.955C15.9052 24.8557 15.5496 24.955 15.2889 25.1534C14.8859 25.4511 14.7911 25.8728 14.7437 27.8821L14.6489 30.2635H11.7571C10.1452 30.2635 7.22964 30.1891 5.26224 30.0898L1.65927 29.941V23.1441V16.3472L3.38964 16.4216L5.09631 16.496V17.6371Z",fill:"#EF4036"})}),e("defs",{children:e("clipPath",{id:"clip0_1148_5989",children:e("rect",{width:"32",height:"32",fill:"transparent"})})})]}),xs=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M18.2835 6L26.4963 26.5994H31L22.7873 6H18.2835Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M8.75587 18.4479L11.566 11.2087L14.3762 18.4479H8.75587ZM9.21147 6L1 26.5994H5.59136L7.27074 22.2735H15.8616L17.5407 26.5994H22.132L13.9206 6H9.21147Z",fill:"var(--ac-global-text-color-900)"})]}),Ts=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M18.9623 11.0195C16.8877 11.0195 15.208 12.6992 15.208 14.7739C15.208 16.8485 16.8877 18.5282 18.9623 18.5282C21.037 18.5282 22.7167 16.8485 22.7167 14.7739C22.7167 12.6992 21.0332 11.0195 18.9623 11.0195ZM18.9623 17.1208C17.6662 17.1208 16.6154 16.07 16.6154 14.7739C16.6154 13.4777 17.6662 12.4269 18.9623 12.4269C20.2585 12.4269 21.3093 13.4777 21.3093 14.7739C21.3093 16.07 20.2585 17.1208 18.9623 17.1208Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M13.7781 11.0308C13.6515 11.0155 13.5212 11.0078 13.3908 11.0078C13.3256 11.0078 13.2642 11.0078 13.2029 11.0078C13.1415 11.0078 13.0763 11.0155 13.015 11.0193C12.7619 11.0385 12.5126 11.0807 12.2672 11.1459C11.7648 11.2801 11.2969 11.514 10.8904 11.84C10.4763 12.1736 10.1426 12.5954 9.91639 13.0786C9.80518 13.3202 9.72081 13.5733 9.67096 13.8341C9.64411 13.9607 9.62494 14.091 9.61343 14.2214C9.6096 14.2866 9.60193 14.348 9.60193 14.417V14.5129V14.6011V15.8589L9.6096 17.1167L9.61727 18.3746H11.0247L11.0323 17.1167V15.8589L11.04 14.6011V14.4707C11.04 14.4323 11.0477 14.3902 11.0515 14.3518C11.0592 14.2751 11.0707 14.1946 11.086 14.1179C11.1167 13.9683 11.1666 13.8188 11.2317 13.6807C11.3621 13.4008 11.5539 13.1553 11.7955 12.9598C12.0486 12.7603 12.3362 12.6108 12.6468 12.5264C12.8079 12.4842 12.9689 12.4536 13.1377 12.4382C13.1798 12.4382 13.222 12.4305 13.2642 12.4305C13.3064 12.4305 13.3486 12.4305 13.3908 12.4305C13.4713 12.4305 13.5518 12.4344 13.6324 12.442C13.9545 12.4727 14.2651 12.5724 14.5451 12.7297L15.2468 11.5102C14.7982 11.2494 14.2996 11.0845 13.7858 11.027L13.7781 11.0308Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M4.789 11.0002C2.71434 10.981 1.01934 12.6453 1.00016 14.72C0.98099 16.7946 2.64532 18.4896 4.71997 18.5088H6.02383V17.1014H4.789C3.49282 17.1168 2.43057 16.0775 2.41523 14.7813C2.39989 13.4852 3.43913 12.4229 4.73531 12.4076H4.789C6.08518 12.4076 7.13593 13.4583 7.13977 14.7545V18.2135C7.13977 19.4982 6.09285 20.5451 4.81201 20.5605C4.19843 20.5566 3.6117 20.3074 3.17836 19.874L2.1813 20.8711C2.87157 21.5652 3.80728 21.9602 4.78517 21.9717H4.83502C6.88283 21.941 8.52799 20.2805 8.53949 18.2327V14.6663C8.48964 12.6261 6.82531 11.0002 4.789 11.0002Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M27.2533 11.0195C25.1787 11.0195 23.499 12.6992 23.499 14.7739C23.499 16.8485 25.1787 18.5282 27.2533 18.5282H28.538V17.1208H27.2533C25.9572 17.1208 24.9064 16.07 24.9064 14.7739C24.9064 13.4777 25.9572 12.4269 27.2533 12.4269C28.469 12.4269 29.4852 13.3588 29.5926 14.5706V21.7801H31V14.7739C30.9962 12.703 29.3242 11.0195 27.2533 11.0195Z",fill:"var(--ac-global-text-color-900)"})]}),Ms=()=>e("svg",{version:"1.1",id:"Layer_1",xmlns:"http://www.w3.org/2000/svg",x:"0px",y:"0px",width:"32",height:"32",viewBox:"0 0 400 400",enableBackground:"new 0 0 400 400",xmlSpace:"preserve",children:e("path",{fill:"var(--ac-global-text-color-900)",stroke:"none",d:`
M108.357758,374.748016
	C68.931068,356.066071 45.775341,325.019348 36.873970,283.154297
	C30.389435,252.656082 33.336266,222.467133 42.685719,193.016541
	C58.768898,142.354813 85.827126,98.280418 124.748680,61.938580
	C145.764755,42.315449 169.544373,26.902735 197.551865,18.696321
	C233.877899,8.052515 266.357330,15.785578 295.642151,38.813885
	C311.787628,51.509991 325.734741,66.145889 333.571045,85.621201
	C340.671906,103.268669 340.516388,121.362411 336.592682,139.643417
	C333.681305,153.207916 328.341309,165.942825 322.998566,178.398621
	C323.824585,180.318497 325.412994,180.144730 326.588379,180.303497
	C348.189026,183.221146 362.405640,201.825790 365.324188,224.059479
	C369.047516,252.424057 359.334717,276.863831 342.760071,298.986633
	C309.078064,343.943359 264.191742,371.643372 209.528900,383.468353
	C175.162979,390.902557 141.349426,389.043335 108.357758,374.748016
M271.080261,209.564880
	C276.822632,194.262497 283.971436,179.601944 291.199829,164.964279
	C296.215637,154.807129 300.561798,144.335480 303.180573,133.260727
	C307.179047,116.351280 306.355347,100.337906 294.874695,86.023811
	C283.959991,72.415321 271.036224,61.444416 255.257523,53.889622
	C243.448471,48.235489 231.098053,46.722847 218.275681,48.963493
	C190.663696,53.788551 168.189636,68.463501 148.031158,86.866074
	C121.336411,111.235603 101.638069,140.797668 86.485901,173.465500
	C72.204773,204.255356 64.520126,236.334229 69.392883,270.412170
	C73.207108,297.087158 84.966972,319.501312 107.685608,335.065063
	C135.185516,353.904266 165.862350,356.662231 197.639496,351.232513
	C226.848587,346.241608 253.160049,333.984497 277.058044,316.581299
	C297.531555,301.671906 314.873077,283.874969 325.936218,260.777405
	C331.523773,249.111649 333.769897,236.736618 330.307495,223.889450
	C329.156708,219.619415 327.376648,215.425262 322.397522,214.499054
	C317.326202,213.555649 314.021484,216.935379 310.871582,220.215073
	C310.074585,221.044922 309.510468,222.103455 308.867737,223.075668
	C300.009247,236.475174 289.673126,248.552429 277.708557,259.333801
	C249.653473,284.614502 216.635345,296.440063 179.132095,296.318329
	C161.393463,296.260742 149.833130,287.682251 145.810806,270.539856
	C140.823715,249.285797 142.451172,227.976303 150.218277,207.764145
	C164.287735,171.151611 185.422729,138.726166 211.975861,109.887596
	C218.737091,102.544426 225.840866,95.432785 234.904358,90.815033
	C237.647705,89.417328 240.608063,87.398354 243.710663,89.989059
	C247.025345,92.756889 246.760300,96.405632 245.685867,100.093086
	C244.092072,105.562981 241.271606,110.502014 238.899857,115.639061
	C231.912460,130.773315 225.552048,146.141083 222.041946,162.530533
	C217.079269,185.702393 230.538971,209.662094 252.994049,217.609100
	C261.908478,220.763977 266.484222,218.869110 271.080261,209.564880
z`})}),Is=()=>e("svg",{fill:"var(--ac-global-text-color-900)",width:"32",height:"32",viewBox:"0 0 32 32",xmlns:"http://www.w3.org/2000/svg",children:e("path",{d:"M 15.994141 3 C 15.629141 3 15.264219 3.0895313 14.949219 3.2695312 L 5.0390625 8.9902344 C 4.3990625 9.3602344 4 10.060781 4 10.800781 L 4 21.179688 C 4 21.929688 4.3990625 22.620234 5.0390625 22.990234 L 7.640625 24.490234 C 8.900625 25.110234 9.3499219 25.109375 9.9199219 25.109375 C 11.789922 25.109375 12.859375 23.979531 12.859375 22.019531 L 12.859375 11.310547 C 12.859375 11.150547 12.730312 11.019531 12.570312 11.019531 L 11.320312 11.019531 C 11.150313 11.019531 11.029297 11.150547 11.029297 11.310547 L 11.029297 22.009766 C 11.029297 22.889766 10.120391 23.749531 8.6503906 23.019531 L 5.9296875 21.449219 C 5.8296875 21.399219 5.7695313 21.289687 5.7695312 21.179688 L 5.7695312 10.810547 C 5.7695312 10.690547 5.8296875 10.589297 5.9296875 10.529297 L 15.839844 4.8105469 C 15.929844 4.7505469 16.050391 4.7505469 16.150391 4.8105469 L 26.060547 10.529297 C 26.160547 10.589297 26.220703 10.690781 26.220703 10.800781 L 26.220703 21.179688 C 26.220703 21.289687 26.160313 21.399219 26.070312 21.449219 L 16.150391 27.179688 C 16.060391 27.229688 15.929844 27.229688 15.839844 27.179688 L 13.289062 25.669922 C 13.219062 25.619922 13.120781 25.610391 13.050781 25.650391 C 12.340781 26.050391 12.210781 26.100078 11.550781 26.330078 C 11.390781 26.380078 11.140625 26.479766 11.640625 26.759766 L 14.949219 28.720703 C 15.269219 28.900703 15.630234 29 15.990234 29 C 16.360234 29 16.719062 28.900703 17.039062 28.720703 L 26.960938 22.990234 C 27.600938 22.620234 28 21.929688 28 21.179688 L 28 10.810547 C 28 10.060547 27.600938 9.37 26.960938 9 L 17.039062 3.2695312 C 16.724063 3.0895313 16.359141 3 15.994141 3 z M 18.660156 11.005859 C 15.830156 11.005859 14.140625 12.205078 14.140625 14.205078 C 14.140625 16.375078 15.819062 16.974141 18.539062 17.244141 C 21.789062 17.564141 22.039062 18.045547 22.039062 18.685547 C 22.039062 19.785547 21.150547 20.255859 19.060547 20.255859 C 16.430547 20.255859 15.850156 19.594922 15.660156 18.294922 C 15.640156 18.154922 15.520859 18.054688 15.380859 18.054688 L 14.089844 18.054688 C 13.929844 18.054688 13.810547 18.185938 13.810547 18.335938 C 13.810547 20.005937 14.720547 21.994141 19.060547 21.994141 C 22.200547 21.994141 24 20.755703 24 18.595703 C 24 16.455703 22.549766 15.884609 19.509766 15.474609 C 16.419766 15.074609 16.109375 14.864531 16.109375 14.144531 C 16.109375 13.544531 16.380156 12.755859 18.660156 12.755859 C 20.690156 12.755859 21.449766 13.194453 21.759766 14.564453 C 21.789766 14.694453 21.899062 14.794922 22.039062 14.794922 L 23.330078 14.794922 C 23.410078 14.794922 23.479063 14.755313 23.539062 14.695312 C 23.589062 14.645313 23.619375 14.564609 23.609375 14.474609 C 23.409375 12.114609 21.840156 11.005859 18.660156 11.005859 z"})}),X1=()=>e("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{d:"M15.357 4L26.714 27H4L15.357 4Z",fill:"var(--ac-global-text-color-900)"})}),As=()=>e("svg",{width:"32",height:"32",viewBox:"0 0 40 40",version:"1.1",xmlns:"http://www.w3.org/2000/svg",children:s("g",{stroke:"none",strokeWidth:"1",fill:"none",fillRule:"evenodd",children:[e("g",{id:"Icon-Architecture-BG/32/Machine-Learning",fill:"#01A88D",children:e("rect",{id:"Rectangle",x:"0",y:"0",width:"40",height:"40"})}),e("g",{id:"Icon-Service/32/Amazon-Bedrock_32",transform:"translate(6.000000, 6.000000)",fill:"#FFFFFF",children:e("path",{d:"M10.516,26.9332116 L8.293,25.6632116 L11.724,23.9472116 L11.277,23.0532116 L7.277,25.0532116 L7.297,25.0942116 L4,23.2102116 L4,19.8092116 L7.724,17.9472116 L7.277,17.0532116 L3.536,18.9232116 L1,17.2322116 L1,14.8092116 L4.724,12.9472116 L4.277,12.0532116 L1,13.6912116 L1,10.7672116 L3.523,9.08621158 L7,11.0382116 L7,14.1912116 L5.277,15.0532116 L5.724,15.9472116 L7.5,15.0592116 L9.277,15.9472116 L9.724,15.0532116 L8,14.1912116 L8,10.7672116 L10.778,8.91621158 C10.916,8.82321158 11,8.66721158 11,8.50021158 L11,5.00021158 L10,5.00021158 L10,8.23221158 L7.278,10.0472116 L4,8.20721158 L4,4.03521158 L7,2.65721158 L7,7.00021158 L8,7.00021158 L8,2.19821158 L10.492,1.05421158 L14,2.80921158 L14,17.1912116 L6.277,21.0532116 L6.724,21.9472116 L14,18.3092116 L14,25.1912116 L10.516,26.9332116 Z M25.5,19.5002116 C25.5,20.0512116 25.052,20.5002116 24.5,20.5002116 C23.949,20.5002116 23.5,20.0512116 23.5,19.5002116 C23.5,18.9492116 23.949,18.5002116 24.5,18.5002116 C25.052,18.5002116 25.5,18.9492116 25.5,19.5002116 L25.5,19.5002116 Z M20.5,24.0002116 C20.5,24.5512116 20.052,25.0002116 19.5,25.0002116 C18.949,25.0002116 18.5,24.5512116 18.5,24.0002116 C18.5,23.4492116 18.949,23.0002116 19.5,23.0002116 C20.052,23.0002116 20.5,23.4492116 20.5,24.0002116 L20.5,24.0002116 Z M19.5,4.00021158 C19.5,3.44921158 19.949,3.00021158 20.5,3.00021158 C21.052,3.00021158 21.5,3.44921158 21.5,4.00021158 C21.5,4.55121158 21.052,5.00021158 20.5,5.00021158 C19.949,5.00021158 19.5,4.55121158 19.5,4.00021158 L19.5,4.00021158 Z M26,11.5002116 C26.552,11.5002116 27,11.9492116 27,12.5002116 C27,13.0512116 26.552,13.5002116 26,13.5002116 C25.449,13.5002116 25,13.0512116 25,12.5002116 C25,11.9492116 25.449,11.5002116 26,11.5002116 L26,11.5002116 Z M24.071,13.0002116 C24.295,13.8602116 25.071,14.5002116 26,14.5002116 C27.103,14.5002116 28,13.6032116 28,12.5002116 C28,11.3972116 27.103,10.5002116 26,10.5002116 C25.071,10.5002116 24.295,11.1402116 24.071,12.0002116 L15,12.0002116 L15,9.00021158 L20.5,9.00021158 C20.777,9.00021158 21,8.77621158 21,8.50021158 L21,5.92921158 C21.86,5.70521158 22.5,4.92921158 22.5,4.00021158 C22.5,2.89721158 21.603,2.00021158 20.5,2.00021158 C19.398,2.00021158 18.5,2.89721158 18.5,4.00021158 C18.5,4.92921158 19.14,5.70521158 20,5.92921158 L20,8.00021158 L15,8.00021158 L15,2.50021158 C15,2.31021158 14.893,2.13821158 14.724,2.05321158 L10.724,0.0532115843 C10.588,-0.0147884157 10.43,-0.0177884157 10.291,0.0452115843 L3.291,3.26021158 C3.115,3.34121158 3,3.51921158 3,3.71421158 L3,8.23221158 L0.223,10.0842116 C0.084,10.1772116 0,10.3332116 0,10.5002116 L0,17.5002116 C0,17.6672116 0.084,17.8232116 0.223,17.9162116 L3,19.7672116 L3,23.5002116 C3,23.6792116 3.096,23.8452116 3.252,23.9342116 L10.252,27.9342116 C10.329,27.9782116 10.414,28.0002116 10.5,28.0002116 C10.577,28.0002116 10.654,27.9822116 10.724,27.9472116 L14.724,25.9472116 C14.893,25.8622116 15,25.6892116 15,25.5002116 L15,21.0002116 L19,21.0002116 L19,22.0712116 C18.14,22.2952116 17.5,23.0712116 17.5,24.0002116 C17.5,25.1032116 18.398,26.0002116 19.5,26.0002116 C20.603,26.0002116 21.5,25.1032116 21.5,24.0002116 C21.5,23.0712116 20.86,22.2952116 20,22.0712116 L20,20.5002116 C20,20.2242116 19.777,20.0002116 19.5,20.0002116 L15,20.0002116 L15,17.0002116 L21.293,17.0002116 L22.784,18.4902116 C22.608,18.7882116 22.5,19.1302116 22.5,19.5002116 C22.5,20.6032116 23.398,21.5002116 24.5,21.5002116 C25.603,21.5002116 26.5,20.6032116 26.5,19.5002116 C26.5,18.3972116 25.603,17.5002116 24.5,17.5002116 C24.131,17.5002116 23.788,17.6082116 23.491,17.7832116 L21.854,16.1462116 C21.76,16.0532116 21.633,16.0002116 21.5,16.0002116 L15,16.0002116 L15,13.0002116 L24.071,13.0002116 Z",id:"Fill-5"})})]})}),Es=()=>e("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M19.2593 6.61905C19.0126 7.16696 18.7815 8.04669 18.5292 9.00706C18.4235 9.40941 18.3141 9.82591 18.1982 10.2381H23.1482C23.7004 10.2381 24.1482 10.6858 24.1482 11.2381V17.0307C24.5195 16.902 24.8948 16.7804 25.2572 16.663C26.122 16.383 26.9141 16.1264 27.4074 15.8525C29.0175 14.9587 30.6667 17.4728 30.6667 19.4716C30.6667 21.4703 29.0371 23.9954 27.4074 23.0906C26.914 22.8166 26.1217 22.56 25.2569 22.2799L25.2568 22.2799C24.8945 22.1625 24.5194 22.041 24.1482 21.9124V27.3333C24.1482 27.8856 23.7004 28.3333 23.1482 28.3333H8.85186C8.29957 28.3333 7.85186 27.8856 7.85186 27.3333V21.9159C7.48052 22.0446 7.10529 22.1662 6.74283 22.2836C5.8781 22.5636 5.086 22.8202 4.59263 23.0941C2.98259 23.9879 1.33337 21.4738 1.33337 19.475C1.33337 17.4763 2.963 14.9511 4.59263 15.856C5.08608 16.13 5.87835 16.3866 6.74324 16.6667C7.10558 16.7841 7.48066 16.9056 7.85186 17.0342V11.2381C7.85186 10.6858 8.29957 10.2381 8.85186 10.2381H13.8018C13.686 9.82578 13.5765 9.40914 13.4708 9.00667L13.4708 9.00661L13.4708 9.00659L13.4707 9.00657L13.4707 9.00656C13.2185 8.04639 12.9875 7.16687 12.7408 6.61905C11.9359 4.83128 14.2 3 16.0001 3C17.8001 3 20.0742 4.80952 19.2593 6.61905ZM12.2564 21.0247C11.9603 21.3049 11.5203 21.259 11.2731 20.9233C11.0258 20.5877 11.0663 20.0881 11.3625 19.8087L15.5529 15.8503C15.5746 15.8294 15.5991 15.8157 15.6237 15.8019C15.6363 15.7949 15.6489 15.7879 15.6611 15.7799C15.6701 15.7739 15.6788 15.7676 15.6874 15.7614C15.7062 15.7477 15.7248 15.7342 15.7464 15.7245C15.8281 15.688 15.9133 15.6667 15.9999 15.6667C16.0865 15.6667 16.1717 15.688 16.2534 15.7245C16.275 15.7342 16.2936 15.7478 16.3124 15.7614C16.321 15.7676 16.3296 15.7739 16.3386 15.7799C16.3509 15.7879 16.3635 15.7949 16.376 15.8019C16.4006 15.8157 16.4251 15.8294 16.4469 15.8503L20.6373 19.8087C20.9341 20.0881 20.9739 20.5877 20.7267 20.9233C20.4801 21.259 20.0402 21.3049 19.7433 21.0247L16.6983 18.1485V28.3333H15.9999H15.1852L15.3015 18.1485L12.2564 21.0247Z",fill:"var(--ac-global-text-color-900)"})}),Ds=h`
  border-radius: var(--ac-global-rounding-medium);
  border: 1px solid var(--ac-global-color-grey-400);
  padding: var(--ac-global-dimension-size-100)
    var(--ac-global-dimension-size-150);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--ac-global-dimension-size-100);
  transition:
    background-color 0.2s ease-in-out,
    border-color 0.2s ease-in-out;
  &:hover {
    background-color: var(--ac-global-color-grey-100);
    border-color: var(--ac-global-color-primary);
  }
  min-width: 230px;
  .integration__main-link {
    flex: 1 1 auto;
    color: var(--ac-global-text-color-900);
    text-decoration: none;
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: var(--ac-global-dimension-size-150);
  }
  .integration__github-link {
    color: var(--ac-global-color-grey-500);
    transition: color 0.2s ease-in-out;
    display: flex;
    align-items: center;
    &:hover {
      color: var(--ac-global-color-grey-700);
    }
  }
`;function Bn({docsHref:n,githubHref:t,icon:a,name:i}){return s("div",{css:Ds,children:[s("a",{href:n,className:"integration__main-link",target:"_blank",rel:"noreferrer",children:[a,i]}),e("div",{children:e("a",{href:t,target:"_blank",rel:"noreferrer",className:"integration__github-link","aria-label":"GitHub link",children:e(zs,{})})})]})}const Ps=[{name:"OpenAI",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/openai",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-openai",icon:e(W1,{})},{name:"LlamaIndex",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-llama-index",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/llamaindex",icon:e(ys,{})},{name:"LangChain",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/langchain",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-langchain",icon:e(q1,{})},{name:"Haystack",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/haystack",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-haystack",icon:e(vs,{})},{name:"Vertex AI",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/vertex",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-vertexai",icon:e(Ss,{})},{name:"Mistral AI",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/mistralai",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-mistralai",icon:e(ks,{})},{name:"DSPy",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/dspy",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-dspy",icon:e(ws,{})},{name:"Anthropic",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/anthropic",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-anthropic",icon:e(xs,{})},{name:"Bedrock",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/bedrock",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-bedrock",icon:e(As,{})},{name:"Groq",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/groq",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-groq",icon:e(Ts,{})},{name:"CrewAI",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/crewai",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-crewai",icon:e(Ms,{})},{name:"LiteLLM",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/litellm",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-litellm",icon:e(Es,{})}],Zn=h`
  width: 100%;
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-size-100);
  flex-wrap: wrap;
`;function Os(){return e("ul",{css:Zn,children:Ps.map(n=>e("li",{children:e(Bn,{...n},n.name)},n.name))})}const _s=[{name:"Node",docsHref:"https://opentelemetry.io/docs/languages/js/getting-started/nodejs/",githubHref:"https://github.com/open-telemetry/opentelemetry-js",icon:e(Is,{})},{name:"Vercel",docsHref:"https://vercel.com/docs/observability/otel-overview",githubHref:"https://github.com/vercel/otel",icon:e(X1,{})}];function Fs(){return e("ul",{css:Zn,children:_s.map(n=>e("li",{children:e(Bn,{...n},n.name)},n.name))})}const Ns=[{name:"OpenAI NodeJS SDK",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/openai-node-sdk",githubHref:"https://github.com/Arize-ai/openinference/tree/main/js/packages/openinference-vercel",icon:e(W1,{})},{name:"LangChain.js",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/langchain.js",githubHref:"https://github.com/Arize-ai/openinference/tree/main/js/packages/openinference-instrumentation-langchain",icon:e(q1,{})},{name:"Vercel AI SDK",docsHref:"https://docs.arize.com/phoenix/tracing/integrations-tracing/vercel-ai-sdk",githubHref:"https://github.com/Arize-ai/openinference/tree/main/js/packages/openinference-vercel",icon:e(X1,{})}];function Vs(){return e("ul",{css:Zn,children:Ns.map(n=>e("li",{children:e(Bn,{...n},n.name)},n.name))})}const zs=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 24 24",children:s("g",{"data-name":"Layer 2",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M12 1A10.89 10.89 0 0 0 1 11.77 10.79 10.79 0 0 0 8.52 22c.55.1.75-.23.75-.52v-1.83c-3.06.65-3.71-1.44-3.71-1.44a2.86 2.86 0 0 0-1.22-1.58c-1-.66.08-.65.08-.65a2.31 2.31 0 0 1 1.68 1.11 2.37 2.37 0 0 0 3.2.89 2.33 2.33 0 0 1 .7-1.44c-2.44-.27-5-1.19-5-5.32a4.15 4.15 0 0 1 1.11-2.91 3.78 3.78 0 0 1 .11-2.84s.93-.29 3 1.1a10.68 10.68 0 0 1 5.5 0c2.1-1.39 3-1.1 3-1.1a3.78 3.78 0 0 1 .11 2.84A4.15 4.15 0 0 1 19 11.2c0 4.14-2.58 5.05-5 5.32a2.5 2.5 0 0 1 .75 2v2.95c0 .35.2.63.75.52A10.8 10.8 0 0 0 23 11.77 10.89 10.89 0 0 0 12 1","data-name":"github",fill:"currentColor"})]})}),Rs="https://docs.arize.com/phoenix/tracing/how-to-tracing/setup-tracing",Ks="https://docs.arize.com/phoenix/tracing/how-to-tracing/setup-tracing/setup-tracing-python/using-otel-python-directly",$s="https://docs.arize.com/phoenix/setup/configuration",Hs="pip install arize-phoenix-otel",Bs="pip install openinference-instrumentation-openai openai";function Zs({isAuthEnabled:n,isHosted:t}){return t?`PHOENIX_CLIENT_HEADERS='api_key=<your-api-key>'
PHOENIX_COLLECTOR_ENDPOINT='${Hn}'`:n?"PHOENIX_API_KEY='<your-api-key>'":`PHOENIX_COLLECTOR_ENDPOINT='${Be}'`}const Gs=`from openinference.instrumentation.openai import OpenAIInstrumentor

OpenAIInstrumentor().instrument(tracer_provider=tracer_provider)`,Qs=`import os
from openai import OpenAI

client = OpenAI(
    # This is the default and can be omitted
    api_key=os.environ.get("OPENAI_API_KEY"),
)

chat_completion = client.chat.completions.create(
    messages=[
        {
            "role": "user",
            "content": "Say this is a test",
        }
    ],
    model="gpt-3.5-turbo",
)`,Us=({isHosted:n,projectName:t})=>`from phoenix.otel import register

tracer_provider = register(
  project_name="${t}",
  endpoint="${(n?Hn:Be)+"/v1/traces"}"
)`;function cc(n){const t=j1,a=window.Config.authenticationEnabled,i=Zs({isAuthEnabled:a,isHosted:t}),r=n.projectName||"your-next-llm-project";return s("div",{children:[e(b,{paddingTop:"size-200",paddingBottom:"size-100",children:e(N,{level:2,weight:"heavy",children:"Install Dependencies"})}),e(b,{paddingBottom:"size-100",children:s(y,{children:["Use the Phoenix OTEL or"," ",e(V,{href:Ks,children:"OpenTelemetry"})," to configure your application to send traces to Phoenix."]})}),e(B,{children:e(W,{value:Hs})}),e(b,{paddingTop:"size-200",paddingBottom:"size-100",children:e(N,{level:2,weight:"heavy",children:"Setup your Environment"})}),e(b,{paddingBottom:"size-100",children:s(y,{children:[e("b",{children:"arize-phoenix-otel"})," automatically picks up your configuration from",e(V,{href:$s,children:"environment variables"})]})}),e(B,{children:e(W,{value:i})}),a?e(b,{paddingBottom:"size-100",paddingTop:"size-100",children:e(U1,{fallback:s(y,{children:["Personal API keys can be created and managed on your"," ",e(V,{href:"/profile",children:"Profile"})]}),children:s(y,{children:["System API keys can be created and managed in"," ",e(V,{href:"/settings",children:"Settings"})]})})}):null,e(b,{paddingTop:"size-200",paddingBottom:"size-100",children:e(N,{level:2,weight:"heavy",children:"Setup OpenTelemetry"})}),e(b,{paddingBottom:"size-100",children:s(y,{children:["Register your application to send traces to this project. The code below should be added ",e("b",{children:"BEFORE"})," any code execution."]})}),e(b,{paddingBottom:"size-100",children:e(B,{children:e(W,{value:Us({projectName:r,isHosted:t})})})}),t?null:e(b,{paddingBottom:"size-100",children:s(y,{children:["To configure gRPC and batching, see our"," ",e(V,{href:Rs,children:"setup guide"}),"."]})}),e(b,{paddingTop:"size-200",paddingBottom:"size-100",children:e(N,{level:2,weight:"heavy",children:"Setup Instrumentation"})}),e(b,{paddingBottom:"size-100",children:e(y,{children:"Add instrumentation to your application so that your application code is traces."})}),e(qa,{variant:"compact",children:s(Wa,{children:[e(jn,{name:"Instrumentation",children:s(b,{padding:"size-200",children:[s(y,{children:["Trace your application using"," ",e(V,{href:"https://github.com/Arize-ai/openinference",children:"OpenInference"})," ","instrumentation and OpenTelemetry"]}),e(b,{paddingTop:"size-200",paddingBottom:"size-200",children:e(Os,{})}),s(y,{children:["For more integrations, checkout our"," ",e(V,{href:"https://docs.arize.com/phoenix/tracing/integrations-tracing",children:"comprehensive guide"})]})]})}),e(jn,{name:"OpenAI Example",children:s(b,{padding:"size-200",children:[s("p",{children:["Install"," ",e(V,{href:"https://github.com/Arize-ai/openinference",children:"OpenInference"})," ","instrumentation as well as ",e("b",{children:"openai"})]}),e(B,{children:e(W,{value:Bs})}),s("p",{children:["Instrument ",e("b",{children:"openai"})," at the beginning of your code"]}),e(b,{paddingBottom:"size-50",children:e(B,{children:e(W,{value:Gs})})}),s("p",{children:["Use ",e("b",{children:"openai"})," as you normally and traces will be sent to Phoenix"]}),e(b,{paddingBottom:"size-50",children:e(B,{children:e(W,{value:Qs})})})]})})]})})]})}function js(n){const{value:t}=n;return s("div",{className:"typescript-code-block",css:d1,children:[e(Rn,{text:t}),e(Fr,{value:t})]})}const Ws="https://docs.arize.com/phoenix/tracing/how-to-tracing/setup-tracing",qs=n=>`import { Resource } from '@opentelemetry/resources';
import { SEMRESATTRS_PROJECT_NAME } from '@arizeai/openinference-semantic-conventions';

resource: new Resource({
    [SEMRESATTRS_PROJECT_NAME]: "${n}",
});`;function dc(n){const t=j1,i=n.projectName||"your-next-llm-project";return s("div",{children:[e(b,{paddingTop:"size-200",paddingBottom:"size-100",children:e(N,{level:2,weight:"heavy",children:"Setup OpenTelemetry"})}),e(b,{paddingBottom:"size-100",children:s(y,{children:["Configure"," ",e(V,{href:Ws,children:"OpenTelemetry"})," ","to send traces to Phoenix."]})}),e(b,{paddingTop:"size-200",paddingBottom:"size-100",children:e(Fs,{})}),e(b,{paddingTop:"size-200",paddingBottom:"size-100",children:e(N,{level:2,weight:"heavy",children:"Setup your Environment"})}),e(b,{paddingBottom:"size-100",children:s(y,{children:["Set the authentication headers in the environment variable"," ",e("b",{children:"OTEL_EXPORTER_OTLP_HEADERS"}),". See"," ",e(V,{href:"https://opentelemetry.io/docs/languages/sdk-configuration/otlp-exporter/#otel_exporter_otlp_traces_headers",children:"environment variables"})]})}),e(B,{children:e(W,{value:t?"OTEL_EXPORTER_OTLP_HEADERS='<auth-headers>'":"OTEL_EXPORTER_OTLP_HEADERS='Authorization=Bearer <your-api-key>'"})}),e(Ls,{children:e(b,{paddingBottom:"size-100",paddingTop:"size-100",children:e(U1,{fallback:s(y,{children:["Your personal API keys can be created and managed on your"," ",e(V,{href:"/profile",children:"Profile"})]}),children:s(y,{children:["System API keys can be created and managed in"," ",e(V,{href:"/settings",children:"Settings"})]})})})}),e(b,{paddingTop:"size-200",paddingBottom:"size-100",children:e(N,{level:2,weight:"heavy",children:"Set the Project Name"})}),e(b,{paddingBottom:"size-100",children:s(y,{children:["Set the project name for your app in the ",e("b",{children:"Resource Attributes"}),"."]})}),e(b,{paddingBottom:"size-100",children:e(B,{children:e(W,{value:"npm install @arizeai/openinference-semantic-conventions --save"})})}),e(b,{paddingBottom:"size-100",children:e(B,{children:e(js,{value:qs(i)})})}),e(b,{paddingBottom:"size-100",children:s(y,{children:["Add the resources to the NodeJS SDK or Vercel OTEL registration. See"," ",e(V,{href:"https://opentelemetry.io/docs/languages/js/resources/",children:"resources"})," ","for details."]})}),e(b,{paddingTop:"size-200",paddingBottom:"size-100",children:e(N,{level:2,weight:"heavy",children:"Setup Instrumentation"})}),e(b,{paddingBottom:"size-100",children:e(y,{children:"Add instrumentation to your application so that your application code is traces."})}),e(b,{paddingBottom:"size-100",children:e(Vs,{})})]})}function uc(n){return e("button",{className:"button--reset",onClick:t=>{t.stopPropagation(),n.onClick(t)},"aria-label":n["aria-label"],css:h`
        color: var(--ac-global-text-color-white-900);
        .ac-icon-wrap {
          font-size: 1.2rem;
        }

        &:hover {
          color: var(--ac-global-color-primary);
        }
      `,children:e(I,{svg:n.isExpanded?e(T.ChevronDownOutline,{}):e(T.ChevronRightOutline,{})})})}const Xs=24*60*60*1e3,mc=30*Xs;function pc({sequenceNumber:n}){return s(me,{color:"yellow-1000",children:["#",n]})}function gc(n){const{projectId:t,isQuiet:a=!1}=n,i=Mt(),[r,l]=p.useState(null),o=ln();return s("div",{onClick:d=>{d.preventDefault(),d.stopPropagation()},children:[s(_t,{buttonSize:"compact",align:"end",isQuiet:a,disabledKeys:t?[]:["GO_TO_EXPERIMENT_RUN_TRACES"],onAction:d=>{switch(d){case"GO_TO_EXPERIMENT_RUN_TRACES":return i(`/projects/${t}`);case"VIEW_METADATA":{l(e(fe,{title:"Metadata",onDismiss:()=>l(null),children:e(Or,{value:JSON.stringify(n.metadata,null,2)})}));break}case"COPY_EXPERIMENT_ID":{Tt(n.experimentId),o({title:"Copied",message:"The experiment ID has been copied to your clipboard"});break}default:O()}},children:[e(P,{children:s(x,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(I,{svg:e(T.Trace,{})}),e(y,{children:"View run traces"})]})},"GO_TO_EXPERIMENT_RUN_TRACES"),e(P,{children:s(x,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(I,{svg:e(T.InfoOutline,{})}),e(y,{children:"View metadata"})]})},"VIEW_METADATA"),e(P,{children:s(x,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(I,{svg:e(T.ClipboardCopy,{})}),e(y,{children:"Copy experiment ID"})]})},"COPY_EXPERIMENT_ID")]}),e(tn,{type:"modal",isDismissable:!0,onDismiss:()=>{l(null)},children:r})]})}var pn=(n=>(n.ADMIN="ADMIN",n.MEMBER="MEMBER",n))(pn||{});function Js(n){return n.toLocaleLowerCase()}function Ys(n){return typeof n=="string"&&n in pn}const e2=Object.values(pn),n2=h`
  .ac-field-label {
    display: none;
  }
`;function t2({onChange:n,role:t,includeLabel:a=!0,...i}){return e(he,{css:a?void 0:n2,label:"Role",className:"role-picker",defaultSelectedKey:t??void 0,"aria-label":"User Role",onSelectionChange:r=>{Ys(r)&&n(r)},width:"100%",...i,children:e2.map(r=>e(P,{children:Js(r)},r))})}const Ue=4;function hc({onSubmit:n,email:t,username:a,password:i,role:r,isSubmitting:l}){const{control:o,handleSubmit:d,formState:{isDirty:c}}=Te({defaultValues:{email:t??"",username:a??"",password:i??"",confirmPassword:"",role:r??pn.MEMBER}});return e("div",{css:h`
        .role-picker {
          width: 100%;
          .ac-dropdown--picker,
          .ac-dropdown-button {
            width: 100%;
          }
        }
      `,children:s(Me,{onSubmit:d(n),children:[s(b,{padding:"size-200",children:[e(z,{name:"email",control:o,rules:{required:"Email is required",pattern:{value:/^[^@\s]+@[^@\s]+[.][^@\s]+$/,message:"Invalid email format"}},render:({field:{name:u,onChange:m,onBlur:g,value:f},fieldState:{invalid:L,error:C}})=>e(K,{label:"Email",type:"email",name:u,isRequired:!0,description:"The user's email address. Must be unique.",errorMessage:C==null?void 0:C.message,validationState:L?"invalid":"valid",onChange:m,onBlur:g,value:f})}),e(z,{name:"username",control:o,rules:{required:"Email is required"},render:({field:{name:u,onChange:m,onBlur:g,value:f},fieldState:{invalid:L,error:C}})=>e(K,{label:"Username",name:u,isRequired:!0,description:"A unique username.",errorMessage:C==null?void 0:C.message,validationState:L?"invalid":"valid",onChange:m,onBlur:g,value:f==null?void 0:f.toString()})}),e(z,{name:"password",control:o,rules:{required:"Password is required",minLength:{value:Ue,message:`Password must be at least ${Ue} characters`}},render:({field:{name:u,onChange:m,onBlur:g,value:f},fieldState:{invalid:L,error:C}})=>e(K,{label:"Password",type:"password",isRequired:!0,description:"Password must be at least 4 characters",name:u,errorMessage:C==null?void 0:C.message,validationState:L?"invalid":"valid",onChange:m,onBlur:g,defaultValue:f})}),e(z,{name:"confirmPassword",control:o,rules:{required:"Please confirm your password",minLength:{value:Ue,message:`Password must be at least ${Ue} characters`},validate:(u,m)=>u===m.password||"Passwords do not match"},render:({field:{name:u,onChange:m,onBlur:g,value:f},fieldState:{invalid:L,error:C}})=>e(K,{label:"Confirm Password",isRequired:!0,type:"password",description:"Confirm the new password",name:u,errorMessage:C==null?void 0:C.message,validationState:L?"invalid":"valid",onChange:m,onBlur:g,defaultValue:f??void 0})}),e(z,{name:"role",control:o,render:({field:{onChange:u,value:m},fieldState:{invalid:g,error:f}})=>e(t2,{onChange:u,role:m,validationState:g?"invalid":"valid",errorMessage:f==null?void 0:f.message})})]}),e(b,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderColor:"dark",borderTopWidth:"thin",children:e(x,{direction:"row",gap:"size-100",justifyContent:"end",children:e(F,{variant:c?"primary":"default",type:"submit",size:"compact",disabled:l,children:l?"Adding...":"Add User"})})})]})})}function fc({name:n,profilePictureUrl:t,size:a=75}){const i=n.length?n[0].toUpperCase():"?",r=u1(n),l=p.useMemo(()=>{const o=Pa(.3,r);return[r,o]},[r]);return e("div",{css:h`
        width: ${a}px;
        height: ${a}px;
        border-radius: 50%;
        font-size: ${Math.floor(a/2)}px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        border: 1px solid var(--ac-global-color-grey-300);
        color: white;
        background: linear-gradient(
          120deg,
          ${l[0]},
          ${l[1]}
        );
        overflow: hidden;
        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
      `,children:t?e("img",{src:t}):i})}function a2({blocker:n}){return e(b,{padding:"size-100",borderTopColor:"dark",borderTopWidth:"thin",children:s(x,{justifyContent:"end",gap:"size-100",children:[e(F,{variant:"default",onClick:()=>n.reset&&n.reset(),size:"compact",children:"Cancel"}),e(F,{variant:"primary",onClick:()=>n.proceed&&n.proceed(),size:"compact",children:"Confirm"})]})})}function Lc({blocker:n,message:t="Are you sure you want to leave the page? Some changes may not be saved."}){if(n.state==="blocked")return e(tn,{type:"modal",isDismissable:!0,onDismiss:()=>n.reset(),children:s(fe,{title:"Confirm Navigation",size:"S",children:[e(b,{padding:"size-200",children:e(y,{children:t})}),e(a2,{blocker:n})]})})}function i2(n){const t=65+n;return String.fromCharCode(t)}function Cc({index:n}){const t=p.useMemo(()=>i2(n),[n]),a=p.useMemo(()=>Oa[n%8],[n]),i=p.useMemo(()=>Mn(.8,a),[a]);return e("div",{css:h`
        color: ${a};
        background-color: ${i};
        width: 24px;
        height: 24px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        border-radius: var(--ac-global-rounding-small);
      `,children:t})}function r2({listeners:n,attributes:t},a){return e("button",{ref:a,...n,...t,"aria-roledescription":"draggable","aria-pressed":"false","aria-disabled":"false",className:"button--reset",css:h`
        cursor: grab;
        background-color: var(--ac-global-color-grey-200);
        border: 1px solid var(--ac-global-color-grey-400);
        color: var(--ac-global-text-color-900);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: var(--ac-global-dimension-size-100)
          var(--ac-global-dimension-size-50);
        border-radius: var(--ac-global-rounding-small);
        overflow: hidden;
      `,children:e("svg",{viewBox:"0 0 20 20",width:"12",fill:"currentColor",children:e("path",{d:"M7 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 2zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 14zm6-8a2 2 0 1 0-.001-4.001A2 2 0 0 0 13 6zm0 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 14z"})})})}const bc=G.forwardRef(r2),l2={lineNumbers:!1,highlightActiveLine:!1,foldGutter:!1,highlightActiveLineGutter:!1,bracketMatching:!1},yc=({templateLanguage:n,...t})=>{const{theme:a}=Q(),i=a==="light"?zt:He,r=p.useMemo(()=>{const l=[];switch(n){case te.FString:l.push(Ui());break;case te.Mustache:l.push(Xi());break;case te.NONE:break;default:O()}return l},[n]);return e($e,{theme:i,extensions:r,basicSetup:l2,...t})};function vc({preInitializationMinHeight:n,children:t}){const[a,i]=p.useState(!1),[r,l]=p.useState(!1),o=p.useRef(null);return p.useEffect(()=>{const d=new IntersectionObserver(([u])=>{i(u.isIntersecting)});o.current&&d.observe(o.current);const c=o.current;return()=>{c&&d.unobserve(c)}},[]),p.useLayoutEffect(()=>{a&&!r&&l(!0)},[r,a]),e("div",{ref:o,css:h`
        min-height: ${r?"auto":`${n}px`};
      `,children:t})}const o2=n=>n==="auto"||n==="required"||n==="none",Ye="tool_",bt=n=>`${Ye}${n}`,s2=n=>n.startsWith(Ye)?n.slice(Ye.length):n;function kc({choice:n,onChange:t,toolNames:a}){const i=n==null||typeof n=="string"?n:bt(n.function.name);return e(he,{selectedKey:i,label:"Tool Choice","aria-label":"Tool Choice for an LLM",onSelectionChange:r=>{typeof r=="string"&&(r.startsWith(Ye)?t({type:"function",function:{name:s2(r)}}):o2(r)&&t(r))},children:[e(P,{textValue:"auto",children:s(x,{gap:"size-100",children:["Tools auto-selected by LLM ",e(me,{children:"auto"})]})},"auto"),e(P,{textValue:"required",children:s(x,{gap:"size-100",children:["Use at least one tool ",e(me,{children:"required"})]})},"required"),e(P,{textValue:"none",children:s(x,{gap:"size-100",children:["Don't use any tools ",e(me,{children:"none"})]})},"none"),...a.map(r=>e(P,{textValue:r,children:r},bt(r)))]})}function Sc(n){return Object.values(te).includes(n)}export{x0 as $,s0 as A,i0 as B,ur as C,n1 as D,f0 as E,b0 as F,n0 as G,L0 as H,Ur as I,Pr as J,g0 as K,wr as L,p0 as M,c0 as N,ln as O,Rn as P,Or as Q,u0 as R,l0 as S,te as T,Ze as U,rn as V,Li as W,y0 as X,v0 as Y,k0 as Z,T0 as _,O as a,U0 as a$,Q as a0,hi as a1,gi as a2,v as a3,Ut as a4,al as a5,K0 as a6,$0 as a7,H0 as a8,V0 as a9,E2 as aA,b2 as aB,M0 as aC,Y2 as aD,A0 as aE,P0 as aF,m0 as aG,I0 as aH,$r as aI,R0 as aJ,Z0 as aK,p1 as aL,Hr as aM,e0 as aN,ge as aO,Br as aP,zr as aQ,J0 as aR,bo as aS,yo as aT,vo as aU,jr as aV,C0 as aW,ec as aX,nc as aY,pe as aZ,X0 as a_,z0 as aa,B0 as ab,Tn as ac,F0 as ad,N0 as ae,_0 as af,ct as ag,g1 as ah,Co as ai,bl as aj,yl as ak,Xt as al,Tl as am,Oe as an,J2 as ao,V as ap,ue as aq,v1 as ar,we as as,G0 as at,E0 as au,Nn as av,D0 as aw,O0 as ax,A2 as ay,I2 as az,G2 as b,F2 as b$,h2 as b0,Ho as b1,j0 as b2,q0 as b3,W0 as b4,Q0 as b5,hs as b6,u1 as b7,Kr as b8,D2 as b9,h0 as bA,oc as bB,lc as bC,rc as bD,hc as bE,Js as bF,fc as bG,Ys as bH,t2 as bI,w2 as bJ,M2 as bK,T2 as bL,Q1 as bM,W2 as bN,_r as bO,sr as bP,Cc as bQ,pr as bR,M1 as bS,P2 as bT,O2 as bU,H2 as bV,$2 as bW,K2 as bX,j2 as bY,vc as bZ,N2 as b_,d0 as ba,cc as bb,dc as bc,ps as bd,ic as be,s1 as bf,Zo as bg,uc as bh,ac as bi,y2 as bj,C2 as bk,tc as bl,mc as bm,Y0 as bn,S0 as bo,W as bp,Be as bq,B as br,U1 as bs,Ls as bt,Rr as bu,pc as bv,qr as bw,gc as bx,Yr as by,w0 as bz,V2 as c,kc as c0,bc as c1,yc as c2,Sc as c3,Lc as c4,sc as c5,S2 as c6,X2 as c7,v2 as c8,f2 as d,Q2 as e,yr as f,st as g,U2 as h,Dn as i,Je as j,Bi as k,or as l,_2 as m,B2 as n,Z2 as o,nr as p,z2 as q,R2 as r,L2 as s,q2 as t,r0 as u,k2 as v,x2 as w,o0 as x,t0 as y,a0 as z};
